# react 模版代码

## 快速上手
启动项目
```javascript
npm i
npm start
```
在浏览器中输入 http://localhost:8900 查看运行结果。

## 更多
[react项目介绍](http://confluence.56qq.cn/pages/viewpage.action?pageId=13161410)

[galileo2.0构建命令介绍](http://confluence.56qq.cn/pages/viewpage.action?pageId=12870965)

