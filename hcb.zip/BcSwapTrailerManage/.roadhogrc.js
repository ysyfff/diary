module.exports = function (config) {
  config.devtool = 'source-map';
  return config;
};
