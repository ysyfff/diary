export default ({ getRes }) => ({
  'POST /common/web/mobile/login-by-code.do': () => getRes({ id: '1', token: 'xxx', name: 'gogo' }),
});
