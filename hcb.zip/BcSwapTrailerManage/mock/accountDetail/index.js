import datas from './datas';

export default ({ getRes }) => ({
  'GET /admin/enterprise/user/account/info': () => getRes(datas.detail),
});
