import Mock from 'mockjs';

const mockData = Mock.mock({
  detail: {
    id: '1',
    idCard: '372926197007100531',
    account: '15884411193',
    address: '天府五街',
    city: '成都',
    county: '高新区',
    province: '四川',
    creditCode: '23424sc',
    name: '中国工商银行',
    shortName: '中国工商银行',
    legalPerson: 'gogo',
    mainBusiness: '赚钱',
    types: '地炼企业',
    attachmentList: [
      { id: '1', name: '营业执照', url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png' },
      { id: '2', name: '质检报告', url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png' },
      { id: '3', name: '银行开户许可证', url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png' },
    ]
  }
});

export default mockData;
