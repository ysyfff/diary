import { list } from './datas';

export default ({ getRes }) => ({
  'POST /web/e/customer/list': () => getRes(list),
});
