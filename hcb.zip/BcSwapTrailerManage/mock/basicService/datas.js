import Mock from 'mockjs';

const list = Mock.mock({
  'datas|5-50': [
    {
      "address": "地址",
      "contractDate": "签约日期",
      "mnemonicCode": "助记码",
      "taxIdCode": "纳税人识别号",
      "openBank": "开户银行",
      "bankCode": "银行卡号",
      "code": "编码",
      "companyName": "客户单位",
      "createTime": "创建时间",
      "createUserId": "创建人id",
      "createUserName": "创建人姓名",
      "effective": "是否启用",
      "id": "id",
      "invoiceHead": "发票抬头",
      "name": "客户名称",
      "phone": "联系电话",
      "shortName": "客户简称",
      "cityId": "市",
      "countyId": "区",
      "provinceId": "省",
      "updateTime": "修改时间",
      "lineType": "客户类型id",
      "lineTypeName": "客户类型名称",
      "linePrices": [
        {
          "cityId": "合同线路出发城市id",
          "cityName": "合同线路出发城市名称",
          "createTime": "2018-10-04 14:04:52",
          "createUserId": 1077934,
          "createUserName": "万富强",
          "customerId": "客户id",
          "effective": 1,
          "endCityId": "合同线路到达地城市id",
          "endCityName": "合同线路到达地城市名称",
          "id": 8,
          "linePriceId": "合同线路id",
          "lineName": "合同线路名称",
          "lineType": "合同线路类型id",
          "typeName": "合同线路类型名称",
          "updateTime": "2018-10-04 14:04:52",
          "updateUserId": 1077934,
          "updateUserName": "万富强",
          "vehiclePrice": "整车价格",
          "volumePrice": "体积单价",
          "weightPrice": "重量单价"
        }
      ]
    }
  ]
});

export {
  list
}
