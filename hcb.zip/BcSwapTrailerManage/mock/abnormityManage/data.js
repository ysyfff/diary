import Mock from 'mockjs';

const mockData = Mock.mock({
  'detail|52-104' : [{
    abnormityNo: '201811070321',
    'status|1': ['1','0'],
    waybillNo: '201811070321ts',
    'abnormityNumber|1-50': 5,
    createTime: '2017-05-08',
    createDept: '某某某事业部',
    createUserName: '黄远',
    createDescription: '这个东西从路上掉落',
    processTime: '2018-01-04',
    processUserName: '某某某',
    processDeptName: '处理的部门',
    processDescription: '允许赔偿',
    'operation|1-4': ['查看', '修改', '处理', '取消'],
    abnormityName: '遗失',
    abnormityTypeName: '部分遗失'
  }],
  cancel: {
    content: 'OK',
  }
});

export default mockData;