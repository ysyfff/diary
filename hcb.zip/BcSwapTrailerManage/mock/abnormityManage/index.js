import datas from './data';

export default ({ getRes }) => ({
  'POST /web/m/waybill-abnormity/list': () => getRes(datas.detail),
  'POST /web/m/waybill-abnormity/cancel': () => getRes(datas.cancel),
});