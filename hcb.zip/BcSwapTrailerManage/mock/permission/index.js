import { list, success, authList, details } from './datas';

export default ({ getRes }) => ({
  'POST /web/e/role/list': () => getRes(list),
  'POST /web/e/role/add': () => getRes(success),
  'POST /web/e/role/edit': () => getRes(success),
  'POST /web/e/role/enable': () => getRes(success),
  'POST /web/e/role/disable': () => getRes(success),
  'POST /web/e/auth/list': () => getRes(authList),
  'POST /web/e/role/detail': () => getRes(details),
});
