import Mock from 'mockjs';

const mockData = Mock.mock({
  'list|5-20': [
    {
      'id|+1': 1,
      name: '鲁班七号',
      account: '18009061432',
      roleId: '2',
    }
  ]
});

export default mockData.list;
