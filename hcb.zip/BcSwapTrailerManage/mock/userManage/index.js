import list from './list';

export default ({ initData, respond }) => {
  // 初始化响应数据
  initData(list);

  return {
    'GET /admin/enterprise/user/list': respond({ list, total: list.length }),
    'POST /admin/enterprise/user/save': respond('add'),
    'PUT /admin/enterprise/user/update': respond('update'),
    'DELETE /admin/enterprise/user/del': respond('del'),
  };
};
