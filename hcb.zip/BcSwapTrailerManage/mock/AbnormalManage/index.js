
import { list, success, authList } from './datas';




export default ({ getRes }) => ({
  'POST /web/m/waybill/registerabnormity-list': () => getRes(list),
  'POST /web/e/role/add': () => getRes(success),
  'POST /web/e/auth/list': () => getRes(authList)
});
