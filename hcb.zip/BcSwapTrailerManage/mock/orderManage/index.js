import datas from './datas';

export default ({ getRes }) => ({
  'POST /admin/order/listPage': () => getRes({ list: datas.list, total: datas.list.length }),
  'POST /admin/order/countAllOrder': () => getRes(datas.orderCounts),
});
