import Mock from 'mockjs';

const mockData = Mock.mock({
  'list|5-200': [
    {
      id: 1,
      buyerName: '貂蝉',
      loadQuantity: 1000,
      oilNumName: '#0',
      oilSpecName: 'aa',
      oilTypeName: '提货中',
      orderNo: 123123123123,
      price: 12314385934,
      quantity: '张三',
      status: Mock.mock('@datetime'),
      createTime: Mock.mock('@datetime')
    }
  ],
  orderCounts: [
    {
      count: 10,
      status: 10,
      statusName: '待确认',
    },
    {
      count: 2,
      status: 20,
      statusName: '已确认',
    },
  ]
});

export default mockData;
