import { _ } from 'carno/third-party';
import { Type } from 'carno/utils';

// 历史记录队列
let pathQueueCache = [];

// 上一个历史记录
let prevPath;

const pathQueue = {
  models: {

    // 新增配载
    '/stowageManage/addStowage': {
      namespace: 'addStowage',
      matchPath: ['/waybillManage/detailWaybill']
    },
  },

  clear() {
    pathQueueCache = [];
  },

  // 更新历史记录
  update({ pathname, dispatch }) {
    pathQueueCache.push(pathname);
    const pathLen = pathQueueCache.length;
    if (pathLen > 10) {
      pathQueueCache.shift();
    }

    if (pathQueueCache.length - 2 >= 0) {
      prevPath = pathQueueCache[pathQueueCache.length - 2];
    }

    this.matchModels({ pathname, dispatch });
    return prevPath;
  },

  // 获取上一个历史
  getPrevPath() {
    return prevPath;
  },

  // 是否是要触发重置的path
  resetSearchDispatch({ namespace, matchPath }) {
    return (prevPath) => {
      const hasMatchPath = (
        Type.isArray(matchPath)
          ? matchPath.filter(path => _.includes(prevPath, path)).length
          : _.includes(prevPath, matchPath)
      );

      if (hasMatchPath) {
        return false;
      }
      return dispatch => dispatch({ type: `${namespace}/resetModal` });
    };
  },

  // 匹配模块
  matchModels({ pathname, dispatch }) {
    const model = this.models[pathname];
    const prevPath = this.getPrevPath();

    if (model) {
      const resetSearch = this.resetSearchDispatch(model)(prevPath);
      resetSearch && resetSearch(dispatch);
    }
  }
};

export default {
  update: pathQueue.update.bind(pathQueue),
  getPrevPath: pathQueue.getPrevPath.bind(pathQueue),
  clear: pathQueue.clear.bind(pathQueue),
};

