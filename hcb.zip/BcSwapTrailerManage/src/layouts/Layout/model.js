import { Model } from 'carno/addons';
import pathQueue from '../prevPath';

export default Model.extend({
  namespace: 'layout',

  state: {
    siteName: '甩挂后台管理系统',
    prevPath: ''
  },

  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname }) => {
        pathQueue.update({ pathname, dispatch });
        const prevPath = pathQueue.getPrevPath();
        dispatch({ type: 'updatePrevPath', payload: prevPath });
        if (pathname === '/login') {
          pathQueue.clear();
        }
      });
    }
  },

  reducers: {
    updatePrevPath(state, { payload }) {
      return {
        ...state,
        prevPath: payload
      };
    }
  },
});
