import React from 'react';
import { connect } from 'dva';
import { Switch, Redirect, Route } from 'dva/router';
import { HLayout } from 'carno';
import { widthAuthoredRoute } from 'components';
import { Paths } from 'configs/constants';
import { cookie } from 'carno/lib/third-party';
import routes from './routes.config';

import './index.less';

const renderRoutes = routes => routes.map((route) => {
  const {
    path,
    name,
    component,
    permission,
    ...restProps
  } = route;
  return (
    <Route
      key={path}
      {...restProps}
      path={path}
      component={widthAuthoredRoute({ permission })(component)}
      breadcrumbName={name}
    />);
});

const routeList = renderRoutes(routes);

function Layout({
  dispatch,
  location,
  siteName,
  menus
}) {
  const props = {
    siteName,
    layout: 'primary',
    isAsideFixed: true,
    user: { username: cookie.get('username') },
    nav: { menus },
    pathname: location.pathname,
    header: {
      onLogout() {
        dispatch({ type: 'login/logout' });
      }
    }
  };
  return (
    <HLayout {...props}>
      <Switch>
        {routeList}
        <Redirect to={Paths.LOGIN} />
      </Switch>
    </HLayout>
  );
}

function mapStateToProps({ layout, login }) {
  return {
    ...layout,
    menus: login.menus
  };
}

export default connect(mapStateToProps)(Layout);
