import { Type } from 'carno/utils';

// 获取转换增值服务
export default (value) => {
  let data;
  if (Type.isEmpty(value)) {
    data = [];
  } else if (value === 'ALL') {
    data = ['DELIVERYCAR', 'DELIVERYVEHICLE'];
  } else {
    data = [value];
  }
  return data;
};
