import { _ } from 'carno/third-party';
import SITE from 'configs/mapData';

export default (id = '', step = '-', fullName = true) => {
  const idStr = id ? id.toString() : '';
  const fullNames = [];
  let name = '';

  if (idStr.length >= 2) {
    const provinceId = idStr.substr(0, 2);
    name = SITE[provinceId];
    fullNames.push(name);
  }
  if (idStr.length >= 4) {
    const cityId = idStr.substr(0, 4);
    name = SITE[cityId];
    fullNames.push(name);
  }
  if (idStr.length >= 6) {
    const countyId = idStr.substr(0, 6);
    name = SITE[countyId];
    countyId === '120119' && (name = '滨海新区');
    fullNames.push(name);
  }

  return fullName ? _.uniq(fullNames).join(step) : name;
};
