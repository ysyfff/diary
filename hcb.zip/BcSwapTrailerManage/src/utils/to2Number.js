export default num => Number(num.toString().match(/^\d+(?:\.\d{0,2})?/));
