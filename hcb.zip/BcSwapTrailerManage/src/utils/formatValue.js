import { Popover } from 'antd';

export const defaultKey = '--';

export const formatValue = (value) => {
  if (value !== '' && value !== undefined && value !== null) {
    if (value.length > 20) {
      return (
        <Popover content={value}>
          <span>{`${value.substr(0, 20)}...`}</span>
        </Popover>
      );
    }
    return value;
  }
  return defaultKey;
};
