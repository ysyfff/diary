import { cookie, qs } from 'carno/third-party';
import { getServer } from './index';

export default ({ server, url, params }) => {
  const token = {
    sid: cookie.get('sid'),
    st: cookie.get('st')
  };
  const serverUrl = `${getServer()[server]}${url}?${qs.stringify({ ...token, ...params })}`;
  window.open(serverUrl, '_blank');
};
