// 把数组转成对象
export default (arr, key = 'key') =>
  arr.reduce((obj, x) => {
    obj[x[key]] = x;
    return obj;
  }, {});
