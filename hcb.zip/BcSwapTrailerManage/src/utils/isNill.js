export default function isNill(obj, type) {
  if (Array.isArray(type) && (!obj || (obj === null) || (obj.length === 0))) return [];
  if (!obj || (obj === null)) return type;
  return obj;
}
