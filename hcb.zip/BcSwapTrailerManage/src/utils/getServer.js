import { getDeployEnv } from 'carno/utils';
import { servers as serverConfigs } from 'configs';

export default (servers = serverConfigs) => servers[getDeployEnv(process.env.DEPLOY_ENV)];
