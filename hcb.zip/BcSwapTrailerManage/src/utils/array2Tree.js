function searchParent(prev, next) {
  next.label = next.name;
  next.value = `${next.id}`;
  next.key = `${next.id}`;
  if (!Array.isArray(prev.children)) return;
  for (let i = 0; i < prev.children.length; i += 1) {
    const opp = prev.children[i];
    if (opp.id === next.parentId) {
      if (opp.children) {
        opp.children.push(next);
      } else {
        opp.children = [next];
      }
      break;
    } else {
      searchParent(opp, next);
    }
  }
}

export default function array2Tree(data) {
  const result = { children: [] };
  data.forEach((item) => {
    item.label = item.name;
    item.value = `${item.id}`;
    item.key = `${item.id}`;
    if (item.parentId === 0) {
      result.children.push(item);
    } else {
      searchParent(result, item);
    }
  });
  return result.children;
}
