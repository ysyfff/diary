function assert(condition, message) {
  if (!condition) {
    throw new Error(`[project]-${message}`);
  }
}

export default assert;
