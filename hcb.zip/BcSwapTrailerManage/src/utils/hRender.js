export default v => (v || '--');
