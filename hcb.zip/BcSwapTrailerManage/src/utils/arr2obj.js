
/**
 *
 * 将数组转换成对象
 * arr2obj({arr: a, footKey: 'value', valueKey: 'key'})
 * or
 * arr2obj({arr: a, footKey: 'value', valueKey: 'rest'})
 *
 *
const a = [{
  key: '全部',
  value: ''
}, {
  key: '启用',
  value: true,
  color: 'green'
}, {
  key: '禁用',
  value: false
}];
 */

export default function arr2obj({ arr, footKey, valueKey }) {
  return arr.reduce((acc, next) => {
    const key = next[footKey];
    let value;
    if (valueKey === 'rest') {
      const tmpNext = { ...next };
      delete tmpNext[footKey];
      value = tmpNext;
    } else {
      value = next[valueKey];
    }

    acc[key] = value;
    return acc;
  }, {});
}
