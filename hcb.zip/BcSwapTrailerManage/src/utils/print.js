export default function print(elem) {
  const strPrintFeature = `
    height: 400,
    width: 600
  `;
  const printWindow = window.open('', 'PRINT', strPrintFeature);

  printWindow.document.write(`<html><head><title>${document.title}</title>`);
  printWindow.document.write('</head><body>');
  printWindow.document.write(document.getElementById(elem).innerHTML);
  printWindow.document.write('</body></html>');

  printWindow.document.close(); // necessary for IE >= 10
  printWindow.focus(); // necessary for IE >= 10*/

  printWindow.print();
  printWindow.close();

  return false;
}
