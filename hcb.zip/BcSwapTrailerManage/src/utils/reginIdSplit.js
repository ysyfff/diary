export default (reginId = '') => {
  const reginIdStr = reginId ? `${reginId}` : '';

  const provinceId = reginIdStr.substr(0, 2);
  const cityId = reginIdStr.substr(0, 4);
  const countyId = reginIdStr.substr(0, 6);

  return {
    provinceId: provinceId.length >= 2 ? provinceId : '',
    cityId: cityId.length >= 4 ? cityId : '',
    countyId: countyId.length >= 6 ? countyId : '',
  };
};
