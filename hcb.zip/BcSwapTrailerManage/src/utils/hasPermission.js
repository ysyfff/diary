// 检查字段是否有权限
const checkPermission = (authorityMap, permission) => {
  const res = permission.split(':').reduce((prev, next) => {
    if (!prev) return null;
    return prev[next] || null;
  }, authorityMap);
  return !!res;
};

const hasPermission = (authorityMap, permission) => {
  if (typeof permission === 'string') {
    return checkPermission(authorityMap, permission);
  }
  if (Array.isArray(permission)) {
    return permission.some(pis => checkPermission(authorityMap, pis));
  }
  return false;
};

export default hasPermission;
