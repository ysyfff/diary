import { qs, cookie } from 'carno/third-party';
import getServer from './getServer';

export const downFile = ({ server, url, params }) => {
  const token = {
    sid: cookie.get('sid'),
    st: cookie.get('st')
  };
  const serverUrl = `${getServer()[server]}${url}?${qs.stringify({ ...token, ...params })}`;
  console.log(serverUrl);
  window.open(serverUrl, '_blank');
};
