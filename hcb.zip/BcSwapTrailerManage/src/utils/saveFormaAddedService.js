import { Type } from 'carno/utils';

// 保存转化增值服务
export default (value) => {
  let data;
  if (Type.isEmpty(value)) {
    data = null;
  } else if (value.length === 2) {
    data = 'ALL';
  } else {
    data = value[0];
  }
  return data;
};
