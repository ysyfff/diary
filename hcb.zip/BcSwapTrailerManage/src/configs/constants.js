export const PAGE_SIZE = 10;
export const DATE_FORMAT = 'YYYY-MM-DD';
export const DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss';

export const DOMAIN_ID = 1;
export const APP_CLIENT_ID = 311;
// export const APP_CLIENT_ID = 290;
export const BIZDEPT = 'sc-admin';
export const SMS_CODE_TYPE = 'VERIFICATION_CODE';

// 详情页面类型
export const detailPageType = {
  detail: 'detail', // 详情
  create: 'create', // 创建
  dispose: 'dispose', // 处理
  modification: 'modification', // 修改
};

// 页面路径
export const Paths = {
  INDEX: '/index',
  LOGIN: '/login',
  //  订单列表
  ORDER_MANAGE: '/orderManage',
  //  添加订单
  ADD_ORDER: '/orderManage/addOrder',
  DETAIL_ORDER: '/orderManage/detailOrder/:orderNo',
  EDIT_ORDER: '/orderManage/editOrder/:orderNo',
  USER_MANAGE: '/accountManage/userManage',
  ACCOUNT_DETAIL: '/accountManage/accountDetail',
  WAYBILL_MANAGE: '/waybillManage',
  ADD_WAYBILL: '/waybillManage/addWaybill',
  GOODS_STOCK: '/sendStation/goodsStock',
  DETAIL_WAYBILL: '/waybillManage/detailWaybill/:waybillNo',
  EDIT_WAYBILL: '/waybillManage/editWaybill/:waybillNo',
  STOWAGE_MANAGE: '/sendStation/stowageManage',
  ADD_STOWAGE: '/sendStation/stowageManage/addStowage',
  ADD_SHARING: '/sendStation/stowageManage/addSharing',
  EDIT_STOWAGE: '/sendStation/stowageManage/editStowage/:stowageNo',
  EDIT_SHARING: '/sendStation/stowageManage/editSharing/:stowageNo',
  STOWAGE_MANAGE_DETAIL: '/sendStation/stowageManage/stowageDetail/:stowageNo',
  TRANSPORT_MANAGE: '/baseService/transportManage',
  SITE_MANAGE: '/baseService/siteManage',
  CUSTOMER_MANAGE: '/baseService/customerManage',
  CONTRACT_PATH_MANAGE: '/baseService/customerManage/contractPathManage',
  BASE_SERVICE: '/baseService',
  STOCK_MANAGE: '/sendStation/stockManage',
  TO_SITE_MANAGE: '/toSiteManage',
  ARRIVE_MANAGE: '/toSiteManage/arriveManage',
  SEND_STATION: '/sendStation',
  SEND_STATION_PICKUP: '/sendStation/pickup',
  SEND_STATION__PICKUP_DETAIL: '/sendStation/pickup/detail/:sendNo',
  SEND_STATION_PICKUP_ADD: '/sendStation/pickup/add',
  TRUCK_SEND: '/sendStation/truckSend',
  TRUCK_SEND_TRUCK_DETAIL: '/sendStation/truckSend/truckDetail/:dispatchNo',
  TRUCK_SEND_UPDATE_TRUCK: '/sendStation/truckSend/updateTruck/:dispatchNo',
  TRUCK_SEND_TRUCK_DISPATCH: '/sendStation/truckSend/truckDispatch/:stowageNo',
  TRUCK_SEND_ADD_TRUCK: '/sendStation/truckSend/addTruck',
  ARRIVE_STOCK: '/toSiteManage/arriveStock',
  DELIVERY_MANAGE: '/toSiteManage/deliveryManage',
  DELIVERY_NOTE_DETAIL: '/toSiteManage/deliveryManage/deliveryNoteDetail/:id',
  ADD_DELIVERY_NOTE: '/toSiteManage/deliveryManage/addDeliveryNote',
  SEND_STATION_PICKUP_EDIT: '/sendStation/pickup/edit/:sendNo',
  SEND_STATION_PICKUP_DETAIL: '/sendStation/pickup/detail/:sendNo',
  LINE_MANAGE: '/baseService/lineManage',
  DRIVER_MANAGE: '/baseService/driverManage',
  TRAILER_MANAGE: '/baseService/trailerManage',
  SIGN_MANAGE: '/toSiteManage/signManage',
  SIGN_SELF: '/toSiteManage/signManage/signSelf',
  SIGN_OTHER: '/toSiteManage/signManage/signOther',
  ARRIVE_DETAIL: '/toSiteManage/arriveManage/arriveDetail/:dispatchNo',
  DELIVERY_NOTE_EDIT: '/toSiteManage/deliveryManage/noteEdit/:id',
  // 打印送货单预览页面
  PRINT_WAYBILL: '/waybillManage/PrintWaybill/:waybillNo',
  PRINT_TAG: '/waybillManage/PrintTag/:waybillNo',
  PREVIEW_DELIVERY_NOTE: '/toSiteManage/deliveryManage/previewDeliveryNote/:id',
  PREVIEW_PICK_UP: '/sendStation/pickup/preview/:id',
  PRINT_HANDOVER: '/sendStation/printHandOver/:stowageNo/:dispatchNo',
  CREATE_CUSTOMER: '/baseService/customerManage/create',
  CUSTOMER_DETAIL: '/baseService/customerManage/detail/:id',
  PERMISSION: '/permission',
  DEPARTMENT_MANAGE: '/permission/departmentManage',
  MEMBER: '/permission/member',
  STRUCTURE: '/permisssion/structure',
  ROLE: '/permission/role',
  EMPLOYEE: '/permission/employee',
  // 异常管理
  ABNORMAL_MANAGE: '/abnormalManage',
  ABNORMITY_Detail: '/abnormalManage/AbnormalManageDetails/detail/:abnormityNo',
  ABNORMITY_Creat: '/abnormalManage/AbnormalManageDetails/create/:waybillNo',
  ABNORMITY_Dispose: '/abnormalManage/AbnormalManageDetails/dispose/:abnormityNo',
  ABNORMITY_Modification: '/abnormalManage/AbnormalManageDetails/modification/:abnormityNo',
};

export const createWaybillNo = 'isCreate';

// 派件方式
export const sendWays = [
  { key: 'EMERGENCYW', value: '急件' },
  { key: 'SLOW', value: '慢件' }
];

// 交接方式
export const connectWays = [
  { key: 'SELFLIFTING', value: '自提' },
  { key: 'DELIVERY', value: '送货' },
  { key: 'DIRECTDRIVER', value: '司机直达' }
];

// 包装类型
export const boxType = [
  { key: 'BOX', value: '箱装' },
  { key: 'BUCKET', value: '桶装' },
  { key: 'BAG', value: '袋装' },
  { key: 'PACKING', value: '包装' },
  { key: 'BUNDLING', value: '捆装' },
  { key: 'CANNING', value: '罐装' },
  { key: 'TP', value: '托盘' },
  { key: 'TPZX', value: '托盘+纸箱' },
  { key: 'TPT', value: '托盘+桶' },
  { key: 'TT', value: '铁桶' },
  { key: 'MT', value: '木桶' },
  { key: 'DT', value: '大桶' },
  { key: 'SLT', value: '塑料桶' },
  { key: 'XZ', value: '纤袋' },
  { key: 'BZD', value: '编织袋' },
  { key: 'SH', value: '散货' },
  { key: 'BOTTLED', value: '瓶装' },
  { key: 'QT', value: '其他' },
];

export const newBoxType = [
  { key: 'TP', value: '托盘' },
  { key: 'TPZX', value: '托盘+纸箱' },
  { key: 'TPT', value: '托盘+桶' },
  { key: 'TT', value: '铁桶' },
  { key: 'MT', value: '木桶' },
  { key: 'DT', value: '大桶' },
  { key: 'SLT', value: '塑料桶' },
  { key: 'XZ', value: '纤袋' },
  { key: 'BAG', value: '袋装' },
  { key: 'BZD', value: '编织袋' },
  { key: 'SH', value: '散货' },
  { key: 'QT', value: '其他' },
];

export const pickUpStatus = [
  { key: 'WAITLOAD', value: '待发车', color: 'rgb(255, 162, 61)' },
  { key: 'LOADING', value: '在途中', color: 'rgb(33, 168, 59)' },
  { key: 'COMPLETELOAD', value: '已完成', color: '' },
  { key: 'CANCEL', value: '已取消', color: '' },
];

// 主营服务
export const mainType = [
  { key: 'CHANNELSERVICE', value: '通道服务' },
  { key: 'VEHICLESERVICE', value: '整车服务' },
];

// 组织架构用户状态
export const userStatus = [
  { key: 'ENABLE', value: '启用' },
  { key: 'DISABLE', value: '禁用' },
];

// 将数组转换成a[key] = key对象
export function transform2KeyKey(arr) {
  return arr.reduce((acc, next) => {
    acc[next.key] = next.key;
    return acc;
  }, {});
}

// 将数组转换为a[key] = value对象
export function transform2Object(arr) {
  return arr.reduce((acc, next) => {
    acc[next.key] = next.value;
    return acc;
  }, {});
}

// 将数组转换为a[key] = {...other}对象
export function transform2FullObject(arr) {
  return arr.reduce((acc, next) => {
    const { key, ...other } = next;
    acc[key] = other;
    return acc;
  }, {});
}

// 将数组适配成antd的options数组
export function transform2Options(arr) {
  return arr.reduce((acc, next) => {
    acc.push({
      label: next.value,
      value: next.key
    });
    return acc;
  }, []);
}

export function transform2SearchOptions(arr) {
  return arr.reduce((acc, next) => {
    acc.push({
      key: next.value,
      value: next.key
    });
    return acc;
  }, []);
}


// 增值服务
export const appreciationType = [
  { key: 'DELIVERYCAR', value: '提货' },
  // { key: 'NO', value: '--' },
  { key: 'DELIVERYVEHICLE', value: '送货' }
];

export const appreciationTypeAll = appreciationType.concat([{
  key: 'ALL',
  value: '提货+送货',
}, {
  key: 'NO',
  value: '无增值服务'
}]);

// 付款方式
export const payWayType = [
  { key: 'RECHARGE', value: '充值预付' },
  { key: 'PREPAY', value: '现金转账' },
];

// 签收方式
export const signingType = [
  {
    key: 'SELF_SIGNED',
    value: '自提签收'
  },
  {
    key: 'DELIVERY_SIGNED',
    value: '送货签收'
  }
];

//  回单
export const tagType = [
  { key: 'A', value: '签回单' },
  { key: 'B', value: '签原单' },
  { key: 'C', value: '打收条' },
  { key: 'D', value: '签信封' },
  { key: 'E', value: '1份回单' },
];

// 司机类别
export const driverType = [
  { key: 'GROUNDLINE', value: '干线' },
  { key: 'SHORT', value: '短驳' }
];

// 驾驶类型
export const steerType = [
  { key: '单驾', value: '单驾' },
  { key: '双驾', value: '双驾' }
];


// 司机所属
export const driverTo = [
  { key: 'OWN', value: '自有' },
  { key: 'PARTNER', value: '合伙人' }
];

// 司机状态
export const driverStatus = [
  { key: '0', value: '禁用' },
  { key: '1', value: '启用' }
];

// 司机归属
export const belongTypes = [
  { key: 'OWN', value: '自有' },
  { key: 'PARTNER', value: '合伙人' },
];

// 车牌颜色
export const plateNumberType = [{
  key: '黄牌',
  value: 0
}, {
  key: '蓝牌',
  value: 1
}, {
  key: '绿牌',
  value: 2
}, {
  key: '黄绿牌',
  value: 3
}, {
  key: '黑牌',
  value: 4
}, {
  key: '白牌',
  value: 5
}, {
  key: '蓝白渐变牌',
  value: 6
}];

// 车辆类型
export const carType = [
  {
    key: '全部',
    value: ''
  },
  {
    key: '半挂牵引车',
    value: '半挂牵引车'
  },
  {
    key: '全挂牵引车',
    value: '全挂牵引车'
  }
];

// 客户类型
export const CustomerType = [
  { key: 'A', value: 'A类客户' },
  { key: 'B', value: 'B类客户' }
];
// 正则表达式

// 校验手机号
export const regPhone = /^1[3456789]{1}[0-9]{9}$/;
export const reg = {
  charNumber: {
    message: '最长20位字符，只能输入数字和字母',
    pattern: /^[0-9a-zA-Z]{1,20}$/,
  },
  charNumberMid: {
    message: '最长20位字符，只能输入数字,字母和-',
    pattern: /^[0-9a-zA-Z\\-]{1,20}$/,
  }
};

// 登记部门
export const registrationDepartment = [{
  title: 'Node1',
  value: '0-0',
  key: '0-0',
  children: [{
    title: 'Child Node1',
    value: '0-0-1',
    key: '0-0-1',
  }, {
    title: 'Child Node2',
    value: '0-0-2',
    key: '0-0-2',
  }],
}, {
  title: 'Node2',
  value: '0-1',
  key: '0-1',
}];
// 异常类型
export const abnormityType = [{
  value: '遗失',
  key: '1',
}, {
  value: '破损/污染/短少',
  key: '2'
}, {
  value: '操作类',
  key: '3',
}, {
  value: '时效类',
  key: '4',
}, {
  value: '其他类',
  key: '5'
}];

export const enableList = [{
  key: '全部',
  value: ''
}, {
  key: '启用',
  value: true
}, {
  key: '禁用',
  value: false
}];

export const isNot = [{
  key: '是',
  value: 1
}, {
  key: '否',
  value: 0
}];

// 员工状态
export const employeeStatus = [{

  key: '全部',
  value: ''
}, {
  key: '启用',
  value: 'ENABLE'
}, {
  key: '禁用',
  value: 'DISABLE'
}];

export const mobileReg = /^1[0-9]\d{9}$/; // 手机号

// 产品时效
export const dispatchType = [
  { key: 'EMERGENCYW', value: '急件' },
  { key: 'SLOW', value: '慢件' },
];

export const AbnormalStatus = [
  { key: 'WAIT_PROCESS', value: '待处理' },
  { key: 'COMPLETE', value: '已处理' },
];
