/**
 * @author yang.huang3
 */
const buttonAuthoritesConfig = {
  order: {
    create: 'dapt:order:create', // 创建订单
    pickup: 'dapt:order:pickup', // 提货派车
    orderToWaybill: 'dapt:order:order-to-waybill', // 转运单
    modify: 'dapt:order:modify', // 修改订单
    cancel: 'dapt:order:cancel', // 取消订单
    export: 'dapt:order:export', // 导出订单
  },
  waybill: {
    create: 'dapt:waybill:create', // 创建订单
    modify: 'dapt:waybill:modify', // 修改订单
    cancel: 'dapt:waybill:cancel', // 取消订单
    export: 'dapt:waybill:export', // 导出订单
  },

  stowage: { // 配载管理
    create: 'dapt:start-station:stowage:create', // 新建配载单
    modify: 'dapt:start-station:stowage:modify', // 修改配载
    loadComplete: 'dapt:start-station:stowage:load-complete', // 完成装车
    sealNoEntering: 'dapt:start-station:stowage:sealNo-entering', // 修改封签
    stowageDispatch: 'dapt:start-station:stowage:stowage-dispatch', // 调度派车
    loadCancel: 'dapt:start-station:stowage:load-cancel', // 取消装车
    export: 'dapt:start-station:stowage:export', // 导出表单
  },
  dispatch: { // 干线派车
    create: 'dapt:start-station:dispatch:create', // 新建干线派车单
    modify: 'dapt:start-station:dispatch:modify', // 修改
    depart: 'dapt:start-station:dispatch:depart', // 确认发车
    cancel: 'dapt:start-station:dispatch:cancel', // 取消派车
    export: 'dapt:start-station:dispatch:export', // 导出表单

  },
  pickup: {
    // 新建提货单
    create: 'dapt:start-station:pickup:create',
    // 完成提货
    complete: 'dapt:start-station:pickup:complete',
    // 确认发车
    start: 'dapt:start-station:pickup:start',
    // 修改派车
    modify: 'dapt:start-station:pickup:modify',
    // 取消派车
    cancel: 'dapt:start-station:pickup:cancel',
    // 表单导出
    export: 'dapt:start-station:pickup:export'
  },
  stock: {
    // 发货库存导出
    export: 'dapt:start-station:stock:export',
    // 操作库存
    change: 'dapt:start-station:stock:change'
  },

  abnormity: {
    // 新建异常单号
    create: 'dapt:abnormity:create',
    // 异常单号处理
    process: 'dapt:abnormity:process',
    // 修改异常单号
    modify: 'dapt:abnormity:modify',
    // 取消异常单号
    cancel: 'dapt:abnormity:cancel',
    // 导出异常单号
    export: 'dapt:abnormity:export',
  },

  arriveStock: { // 到货库存
    change: 'dapt:arrive-station:arrive-stock:change',
    export: 'dapt:arrive-station:arrive-stock:export',
  },

  selfSigned: { // 到站管理-签收管理-自提签收
    export: 'dapt:arrive-station:signed:self-signed:export',
  },

  delivery: {
    create: 'dapt:arrive-station:delivery:create',
    intransit: 'dapt:arrive-station:delivery:intransit',
    complete: 'dapt:arrive-station:delivery:complete',
    modify: 'dapt:arrive-station:delivery:modify',
    cancel: 'dapt:arrive-station:delivery:cancel',
    export: 'dapt:arrive-station:delivery:export'
  },

  deliverySigned: { // 到站管理-签收管理-送货签收
    // 确认签收
    doSigned: 'dapt:arrive-station:signed:deliverySigned:do-signed',
  },

  'dispatch-arrive': {
    // 到车管理
    confirm: 'dapt:arrive-station:dispatch-arrive:confirm',
    // 导出表单
    export: 'dapt:arrive-station:dispatch-arrive:export',
  }
};

export default buttonAuthoritesConfig;
