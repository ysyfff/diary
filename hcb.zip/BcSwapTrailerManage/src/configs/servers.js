const env = {
  dev: {
    sso: '//sso.qa-ag.56qq.com/',
    admin: '//dapt.dev-ag.56qq.com',
    dapt: '//dapt.dev-ag.56qq.com',
    op: '//op-permission.dev-ag.56qq.com',
    uc: '//tms.dev-ag.56qq.com/uc',
  },
  qa: {
    sms: '//sms.qa-ag.56qq.com',
    sso: '//sso.qa-ag.56qq.com/',
    admin: '//dapt.qa-ag.56qq.com',
    dapt: '//dapt.qa-ag.56qq.com',
    op: '//op-permission.qa-ag.56qq.com',
    uc: '//tms.qa-ag.56qq.com/uc',
  },
  pub: {
    sms: '//sms.qa-ag.56qq.com',
    sso: '//sso.qa-ag.56qq.com',
    admin: '//dapt-biz.dev-ag.56qq.com',
    dapt: '//dapt-biz.dev-ag.56qq.com',
    op: '//op-permission.qa-ag.56qq.com',
  },
  prod: {
    sms: '//sms.56qq.cn',
    sso: '//sso.56qq.com',
    admin: '//dapt.56qq.com',
    dapt: '//dapt.56qq.com',
    op: '//op-permission.56qq.com',
    uc: '//tms.56qq.com/uc',
  }
};

const { dev, qa, pub, prod } = env;

const servers = {
  local: qa,
  dev,
  qa,
  pub,
  prod,
};

export default servers;
