import {
  Paths
} from './constants';

const menus = [{
  title: '首页',
  key: 'index',
  path: Paths.INDEX,
  icon: 'home',
  permission: 'dapt:index',
},
{
  title: '订单管理',
  key: 'orderManage',
  path: Paths.ORDER_MANAGE,
  icon: 'profile',
  permission: 'dapt:order',
},
{
  title: '运单管理',
  key: 'waybillManage',
  path: Paths.WAYBILL_MANAGE,
  icon: 'bars',
  permission: 'dapt:waybill',
},
{
  title: '发站管理',
  key: 'sendStation',
  icon: 'shop',
  path: Paths.SEND_STATION,
  permission: 'dapt:start-station',
  children: [{
    title: '提货管理',
    key: 'pickup',
    path: Paths.SEND_STATION_PICKUP,
    permission: 'dapt:start-station:pickup'
  }, {
    title: '发货库存',
    key: 'goodsStock',
    path: Paths.GOODS_STOCK,
    permission: 'dapt:start-station:stock'
  }, {
    title: '配载管理',
    key: 'stowageManage',
    path: Paths.STOWAGE_MANAGE,
    permission: 'dapt:start-station:stowage'
  }, {
    title: '干线派车',
    key: 'truckSend',
    path: Paths.TRUCK_SEND,
    permission: 'dapt:start-station:dispatch'
  }]
},
{
  title: '到站管理',
  key: 'toSiteManage',
  icon: 'bank',
  path: Paths.TO_SITE_MANAGE,
  permission: 'dapt:arrive-station',
  children: [{
    title: '到车管理',
    key: 'arriveManage',
    path: Paths.ARRIVE_MANAGE,
    permission: 'dapt:arrive-station:dispatch-arrive'
  }, {
    title: '到货库存',
    key: 'arriveStock',
    path: Paths.ARRIVE_STOCK,
    permission: 'dapt:arrive-station:arrive-stock'
  }, {
    title: '送货管理',
    key: 'deliveryManage',
    path: Paths.DELIVERY_MANAGE,
    permission: 'dapt:arrive-station:delivery'
  }, {
    title: '签收管理',
    key: 'signManage',
    path: Paths.SIGN_MANAGE,
    permission: 'dapt:arrive-station:signed',
    children: [
      {
        title: '自提签收',
        key: 'signSelf',
        path: Paths.SIGN_SELF,
        permission: 'dapt:arrive-station:signed:self-signed'
      },
      {
        title: '送货签收',
        key: 'signOther',
        path: Paths.SIGN_OTHER,
        permission: 'dapt:arrive-station:signed:delivery-signed'
      }
    ]
  }]
},
{
  title: '异常管理',
  key: 'abnormalManage',
  path: Paths.ABNORMAL_MANAGE,
  icon: 'exclamation-circle',
  permission: 'dapt:abnormity'
},
{
  title: '基础信息',
  key: 'baseService',
  icon: 'car',
  path: '/baseService',
  permission: 'dapt:basis',
  children: [{
    title: '挂车管理',
    key: 'transportManage',
    path: Paths.TRANSPORT_MANAGE,
    permission: 'dapt:basis:compartment'
  },
  {
    title: '站点管理',
    key: 'siteManage',
    path: Paths.SITE_MANAGE,
    permission: 'dapt:basis:site'
  },
  {
    title: '客户管理',
    key: 'customerManage',
    path: Paths.CUSTOMER_MANAGE,
    permission: 'dapt:basis:customer'
  },
  {
    title: '线路管理',
    key: 'lineManage',
    path: Paths.LINE_MANAGE,
    permission: 'dapt:basis:line'
  },
  {
    title: '司机管理',
    key: 'driverManage',
    path: Paths.DRIVER_MANAGE,
    permission: 'dapt:basis:driver'
  },
  {
    title: '车辆管理',
    key: 'trailerManage',
    path: Paths.TRAILER_MANAGE,
    permission: 'dapt:basis:truck'
  }
  ]
}, {
  title: '权限管理',
  key: 'auth',
  icon: 'setting',
  path: Paths.PERMISSION,
  permission: 'dapt:permision',
  children: [
    {
      title: '员工管理',
      key: 'member',
      path: Paths.EMPLOYEE,
      permission: 'dapt:permision:staff'
    },
    {
      title: '组织架构',
      key: 'structure',
      path: Paths.DEPARTMENT_MANAGE,
      permission: 'dapt:permision:org'
    },
    {
      title: '角色管理',
      key: 'role',
      path: Paths.ROLE,
      permission: 'dapt:permision:role'
    }
  ]
},
];


export default menus;
