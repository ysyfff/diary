// 订单状态
export const orderStatus = [
  { key: '10', name: '全部', status: 'processing' },
  { key: '20', name: '未提贷', status: 'error' },
  { key: '30', name: '提货中', status: 'processing' },
  { key: '40', name: '已提货', status: 'success' },
  { key: '50', name: '已取消', status: 'error' },
];

// 运单状态
export const waybillStatus = [
  { key: 'ALL', name: '全部' },
  { key: 'UN_LOAD', name: '未装车' },
  { key: 'TRANSPORTING', name: '在途中' },
  { key: 'ARRIVED', name: '已到达' },
  { key: 'SIGNED', name: '已签收' },
  { key: 'CANCEL', name: '已取消' }
];

export const stowageTabs = [
  { key: '10', name: '全部' },
  { key: '20', name: '装载中' },
  { key: '30', name: '已装车' }
];

export const stowageStatus = [
  { key: '10', name: '全部', status: '' },
  { key: '20', name: '装载中', status: 'CARLOAD_LOADING' },
  { key: '30', name: '已装车', status: 'CARLOAD_LOADED' },
  { key: '40', name: '在途中', status: 'IN_TRANSIT' },
  { key: '50', name: '已到达', status: 'ARRIVED' },
  { key: '60', name: '已取消', status: 'CANCEL' },
  { key: '70', name: '已派车', status: 'DISPATCHED' },
  { key: '80', name: '装载中', status: 'CARPOOL_LOADING' },
  { key: '90', name: '已装车', status: 'CARPOOL_LOADED' },
  { key: '100', name: '未装车', status: 'UNLOAD' },
  { key: '110', name: '已装车', status: 'LOADED' }
];

// 干线车辆状态
export const TRUCK_STATUS = [
  { key: '', name: '全部' },
  { key: 'WAIT_DEPART', name: '待发车' },
  { key: 'IN_TRANSIT', name: '在途中' },
  { key: 'ARRIVED', name: '已到达' },
  { key: 'CANCEL', name: '已取消' }
];

// 服务类型
export const STOWAGE_TYPE = [
  { key: 'VEHICLESERVICE', name: '整车服务' },
  { key: 'CHANNELSERVICE', name: '通道服务' }
];

export const DRIVER_TYPE = [
  { name: '干线司机', value: 'GROUNDLINE' },
  { name: '短驳司机', value: 'SHORT' },
  { name: '临调司机', value: 'TEMP' }
];

// 异常状态
export const abnormalStatus = [
  { key: 'all', name: '全部', status: '' },
  { key: 'pending', name: '待处理', status: 'WAIT_PROCESS' },
  { key: 'processed', name: '已处理', status: 'COMPLETE' }
];
