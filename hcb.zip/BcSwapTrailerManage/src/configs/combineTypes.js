import { TableUtil, FormUtil } from 'carno/addons';

TableUtil.combineTypes({
  // ellipsis: value => <HEllipsis length={100} tooltip>{value}</HEllipsis>,
});

FormUtil.combineTypes({
  // uploadImg: ({ initialValue, inputProps }) => ({
  //   input: <UploadImg {...inputProps} />,
  //   initialValue,
  // }),
});
