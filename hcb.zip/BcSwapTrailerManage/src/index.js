import dva from 'dva';
import helper from 'components/helper';
// import kepler from 'kepler';
import 'carno/dist/index.css';
import RouterConfigs from './router';
import './styles/global.less';
// const env = process.env.NODE_ENV;

/* window.kepler.install({
  serviceId: 'web-bc-SwapTrailerManage',
  // isReport: env === 'production' || env === 'development',
  isReport: env === 'production',
  userId: 'BCFE',
  ignoreErrors: [],
  reportDelay: 1000,
  reportMaxCount: 10
}); */

// TODO - 可以在登录后通过调用setConfig传入用户ID
// kepler.setConfig({ userId })

// 1. Initialize
const app = dva({
  onError(e) {
    console.log(e);
  }
});

// 3. Model
function importAll(r) {
  r.keys().forEach(key => app.model(r(key).default));
}

importAll(require.context('./layouts', true, /model\.js$/));
importAll(require.context('./pages', true, /model\.js$/));
importAll(require.context('./models', true, /\.js$/));

// 4. Router
app.router(({ history }) => <RouterConfigs history={history} />);

// 5. Start
app.start('#root');

helper.install();
