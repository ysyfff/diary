import React from 'react';
import { Type } from 'carno/utils';
import { HTable } from 'carno';

const calculateTableWidth = fields => fields.reduce((acc, next) => acc + next.width, 0);


export default class BaseHTable extends React.PureComponent {
  getProps = () => {
    const {
      tableFields,
      search,
      total,
      list,
      loading,
      calculateScrollX,
      onPaginationSearch,
      extraFields = [],
      scrollX = calculateScrollX ? calculateTableWidth(tableFields) : 1950,
      ...otherProps
    } = this.props;
    const { pn, ps } = search;
    const fields = [...tableFields];
    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => onPaginationSearch({ pn, ps }),
      onShowSizeChange: (current, size) => onPaginationSearch({ ps: size, pn: 1 })
    };
    // debugger
    return {
      tableProps: {
        fields,
        extraFields,
        dataSource: list,
        loading: Type.isObject(loading) ? loading[Object.keys(loading)[0]] : loading,
        search,
        scroll: { x: scrollX },
        pagination,
        locale: { emptyText: '暂无数据' },
        style: { marginTop: 16 },
        ...otherProps
      },
    };
  }
  render() {
    const { tableProps } = this.getProps();
    return <HTable {...tableProps} />;
  }
}
