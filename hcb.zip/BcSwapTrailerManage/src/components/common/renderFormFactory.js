import React from 'react';
import assert from '../../utils/assert';
import formElementMaps from './HOC/formElementMaps';
import HOCFormElement from './HOC/HOCFormElement';

const formLayoutProps = {
  xs: { span: 24 },
  sm: { span: 24 },
  md: { span: 24 },
  lg: { span: 12 },
  xl: { span: 8 }
};

function renderFormFactory(formConfig, callback, formLayout = formLayoutProps) {
  assert(Array.isArray(formConfig), 'formConfig需为数组');
  const formMap = {};
  let components = formConfig.map((config, index) => {
    const { type, key } = config;
    formMap[key] = index;
    config.__key__ = key;
    config['form-layout'] = { ...formLayoutProps, ...formLayout };
    const InputComponent = formElementMaps[type];
    assert(typeof InputComponent !== 'undefined', `未找到${type}类型表单元素组件`);
    const HOCComponent = HOCFormElement(InputComponent);
    return <HOCComponent {...config} />;
  });
  return {
    components,
    callback,
    formMap,
    formLayout,
    rerender(nextConfig) {
      for (let i = 0, len = nextConfig.length; i < len; i += 1) {
        const config = nextConfig[i];
        const { key } = config;
        const index = formMap[key];
        if (typeof index !== 'undefined') {
          components[index] = React.cloneElement(components[index], { ...config });
        }
      }
      components = [...components];
      return {
        components,
        callback
      };
    }
  };
}

export default renderFormFactory;
