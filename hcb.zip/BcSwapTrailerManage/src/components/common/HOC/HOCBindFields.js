import React from 'react';

// 获取初始fields值
function getDefaultValues(props) {
  const fields = {};
  const fieldKeys = [];
  const { components } = props.render;
  components.forEach((component) => {
    const { key } = component;
    const { defaultValue, disabled } = component.props;
    // 去除disabled组件value双向绑定
    if (!disabled) {
      fields[key] = {
        value: typeof defaultValue === 'undefined' ? undefined : defaultValue
      };
      fieldKeys.push(key);
    }
  });
  return { fields, fieldKeys };
}

function formatValues(values) {
  const finalValues = { ...values };
  Object.keys(finalValues).forEach((key) => {
    const value = typeof finalValues[key].value === 'undefined' ?
      '' : finalValues[key].value;
    finalValues[key] = value;
  });
  return finalValues;
}

export default function HOCBindFields(WrapperComponent) {
  return class HOC extends React.PureComponent {
    constructor(props) {
      super(props);
      const defaultValues = getDefaultValues(props);
      this.defaultValues = defaultValues.fields;
      this.state = {
        ...defaultValues,
        valuesChanged: false
      };
    }

    componentWillReceiveProps(nextProps) {
      if (this.props.render !== nextProps.render) {
        // rerender后重新获取默认fields
        const defaultValues = getDefaultValues(nextProps);
        this.setState({
          ...defaultValues,
          valuesChanged: false,
        });
      }
    }

    formatValues(v) {
      const { callback } = this.props.render;
      let values = formatValues(v || this.state.fields);
      values = callback && typeof callback === 'function' ?
        callback(values) : values;
      return values;
    }

    handleFormChange = (changedFields) => {
      let isChanged = null;
      const { fields } = this.state;
      const keys = Object.keys(changedFields);
      const isRest = keys.length > 0 && keys
        .every(key => !Object.prototype.hasOwnProperty.call(changedFields[key], 'value'));
      if (!isRest) {
        const validating = changedFields.validating || false;
        if (validating) return;
      }
      // 获取新的form表单values
      const nextFields = { ...fields, ...changedFields };
      isChanged = Object.keys(this.defaultValues)
        .some(key => this.defaultValues[key].value !== nextFields[key].value);
      // 判断值是否被修改
      this.setState({
        fields: isRest ? this.defaultValues : nextFields,
        valuesChanged: isChanged
      }, () => {
        const { onValuesChange } = this.props;
        onValuesChange && onValuesChange(this.formatValues());
      });
    }

    render() {
      const { fieldKeys, fields, valuesChanged } = this.state;
      return (<WrapperComponent
        onChange={this.handleFormChange}
        fieldKeys={fieldKeys}
        fields={fields}
        defaultValues={this.defaultValues}
        valuesChanged={valuesChanged}
        {...this.props}
      />);
    }
  };
}
