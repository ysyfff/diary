import React from 'react';
import { Form } from 'antd';
import hoistNonReactStatic from 'hoist-non-react-statics';

const FormItem = Form.Item;
// 获取displayName
function getDisplayName(component) {
  return component.displayName || component.name || 'Component';
}

export default function HOCFormElement(WrapperComponet) {
  return class HOCElement extends React.Component {
    static displayName = `HOC${getDisplayName(WrapperComponet)}`;

    handleRenderSelect = (props) => {
      const { options = [], ...restProps } = props;
      const { Option } = WrapperComponet;
      return (
        <WrapperComponet key={props.__key__} {...restProps}>
          {
            options.map(option =>
              <Option key={option.key} value={option.value}>{option.key}</Option>)
          }
        </WrapperComponet>
      );
    }

    handleRenderCheckbox = (props) => {
      const { text } = props;
      return <WrapperComponet key={props.__key__}>{text}</WrapperComponet>;
    }

    handleRender = (elementType) => {
      const { defaultValue, ...restProps } = this.props;
      switch (elementType) {
        case 'select':
          return this.handleRenderSelect(restProps, defaultValue);
        case 'checkbox':
          return this.handleRenderCheckbox(restProps);
        default:
          return <WrapperComponet {...restProps} />;
      }
    }

    render() {
      hoistNonReactStatic(HOCElement, WrapperComponet);
      const {
        __key__,
        label,
        fields = {},
        defaultValue,
        form
      } = this.props;
      const baseItemLayout = {
        labelCol: { span: 7 },
        wrapperCol: { span: 10 }
      };
      const formItemLayout = { ...(this.props['base-item-layout'] || baseItemLayout), ...this.props.itemlayout };
      const { getFieldDecorator } = form;
      return (
        <FormItem
          label={label}
          {...formItemLayout}
          key={__key__}
        >
          {
            getFieldDecorator(__key__, {
              initialValue: defaultValue,
              ...fields
            })(this.handleRender(this.props.type))
          }
        </FormItem>
      );
    }
  };
}
