import { PureComponent } from 'react';

class BaseComponent extends PureComponent {
  constructor(props, context) {
    super(props, context);
    this.bind = this.bind.bind(this);
  }

  bind(fnArray) {
    if (Array.isArray(fnArray) && fnArray.length > 0) {
      fnArray.forEach((fn) => {
        this[fn] = this[fn].bind(this);
      });
    }
  }
}

export default BaseComponent;
