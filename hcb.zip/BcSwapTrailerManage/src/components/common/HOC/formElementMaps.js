import { Form, Input, DatePicker, Select, InputNumber, Checkbox } from 'antd';

const { RangePicker } = DatePicker;

export default {
  form: Form,
  input: Input,
  datepicker: DatePicker,
  select: Select,
  rangepicker: RangePicker,
  hidden: Input,
  inputnumber: InputNumber,
  textarea: Input.TextArea,
  'date-picker': DatePicker,
  checkbox: Checkbox
};
