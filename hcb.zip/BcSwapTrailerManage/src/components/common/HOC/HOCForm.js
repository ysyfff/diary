import React from 'react';
import { Form, Col } from 'antd';

function createFields(props) {
  const fields = {};
  props.fieldKeys.forEach((key) => {
    fields[key] = Form.createFormField(props.fields[key]);
  });
  return fields;
}

function formatValues(values) {
  const finalValues = { ...values };
  Object.keys(finalValues).forEach((key) => {
    const value = typeof finalValues[key].value === 'undefined' ? '' : finalValues[key].value;
    finalValues[key] = value;
  });
  return finalValues;
}

export default function HOCForm(WrapperComponent) {
  class HOC extends WrapperComponent {
    getFields = () => {
      const { render, form, baseItemLayout } = this.props;
      return render.components.map((Component) => {
        const { key, props } = Component;
        return (
          <Col key={key} {...(props.layout || props['form-layout'])}>
            {React.cloneElement(Component, { form, 'base-item-layout': baseItemLayout })}
          </Col>
        );
      });
    }

    formatValues(v) {
      const { callback } = this.props.render;
      let values = formatValues(v || this.props.fields);
      values = callback && typeof callback === 'function' ?
        callback(values) : values;
      return values;
    }

    render() {
      const { layout } = this.props;
      return (
        <Form gutter={24} layout={layout}>
          {super.render()}
        </Form>
      );
    }
  }

  return Form.create({
    onFieldsChange(props, changedFields) {
      props.onChange(changedFields);
    },
    mapPropsToFields(props) {
      return createFields(props);
    }
  })(HOC);
}
