import { Row } from 'antd';
import BaseComponent from '../HOC/BaseComponent';
import HOCForm from '../HOC/HOCForm';

import './index.less';

class ModalFormLayout extends BaseComponent {
  static defaultProps = {
    layout: 'horizontal',
    baseItemLayout: {
      labelCol: { span: 6 },
      wrapperCol: { span: 8 }
    }
  };

  render() {
    return (
      <Row>
        {this.getFields()}
      </Row>
    );
  }
}

export default HOCForm(ModalFormLayout);
