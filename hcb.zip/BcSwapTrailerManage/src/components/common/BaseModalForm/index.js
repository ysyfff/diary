/**
 * @author yang.huang3
 * @description 用于处理基本弹出表单组件, 可满足大部分需求
 * @since 2018.08.25
 */
import { Modal } from 'antd';
import BaseComponent from '../HOC/BaseComponent';
import HOCBindFields from '../HOC/HOCBindFields';
import ModalFormLayout from './ModalFormLayout';

function formatValues(values) {
  const finalValues = { ...values };
  Object.keys(finalValues).forEach((key) => {
    const value = typeof finalValues[key].value === 'undefined' ?
      '' : finalValues[key].value;
    finalValues[key] = value;
  });
  return finalValues;
}

class BaseModalForm extends BaseComponent {
  static defaultProps = {
    formProps: {
      layout: 'horizontal',
    },
    visible: false,
    disabledOkButton: false,
    baseItemLayout: {
      labelCol: { span: 8 },
      wrapperCol: { span: 16 }
    }
  };

  constructor(props) {
    super(props);
    this.state = {
      visible: props.visible,
      disabled: true // ok按钮禁用
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.visible !== nextProps.visible) {
      this.setState({ visible: true });
    }
    if (this.props.valuesChanged !== nextProps.valuesChanged) {
      this.setState({ disabled: !nextProps.valuesChanged });
    }
  }

  handleOk = () => {
    const { form } = this.form.props;
    const { onOk } = this.props;
    form.validateFields(async (error) => {
      if (!error) {
        const value = this.formatValues();
        const datas = onOk && await onOk(value);
        if (datas) this.changeModalVisible();
      }
    });
  }

  formatValues(v) {
    const { callback } = this.props.render;
    let values = formatValues(v || this.props.fields);
    values = callback && typeof callback === 'function' ?
      callback(values) : values;
    return values;
  }

  handleCancel = () => {
    this.changeModalVisible();
  }

  changeModalVisible = (callback) => {
    this.setState(({ visible }) => ({
      visible: !visible
    }), () => {
      callback && callback();
    });
  }

  render() {
    let modalContent = null;
    const {
      title,
      width = 750,
      content,
      disabledOkButton,
      loading,
      ...restProps
    } = this.props;
    const contentRender = (
      <div className="modalLayout">
        <ModalFormLayout
          wrappedComponentRef={(form) => { this.form = form; }}
          {...restProps}
        />
      </div>
    );
    modalContent = content ? React.cloneElement(content, {
      ...restProps,
      wrappedComponentRef: (form) => { this.form = form; }
    }) : contentRender;
    const { visible, disabled } = this.state;
    return (
      <Modal
        title={title}
        width={width}
        visible={visible}
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        okButtonProps={{
          disabled: disabled && disabledOkButton,
          loading: loading || false
        }}
        centered
        maskClosable={false}
      >
        {modalContent}
      </Modal>
    );
  }
}

export default HOCBindFields(BaseModalForm);
