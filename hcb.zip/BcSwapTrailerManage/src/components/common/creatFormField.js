import { Input, Select, DatePicker, InputNumber, Form, Row, Col } from 'antd';
import { HCityPicker } from 'carno';
import { Type } from 'carno/utils';
import styles from './creatFormField.less';

// 生成form表单控件
const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

const FieldWith = 300;

// 渲染输入框
const renderInput = (field, getFieldDecorator) => (
  <FormItem
    label={field.label}
    labelCol={field.labelCol}
    wrapperCol={field.wrapperCol}
  >
    {
      Type.isFunction(field.render)
        ? field.render(field, getFieldDecorator) :
        getFieldDecorator(field.key, {
          initialValue: field.initialValue || [],
          rules: field.rules,
        })(
          <Input
            disabled={field.disabled}
            size={field.size}
            maxLength={field.maxLength}
            style={{ width: field.width || FieldWith }}
            placeholder={field.placeholder}
          />
        )
    }
  </FormItem>
);

// 渲染文字节点
const renderText = (field, filler) => {
  const result = Type.isEmpty(field.initialValue) ? (filler[field.key] || '--') : field.initialValue;

  return (
    <FormItem
      label={field.label}
    >
      <div style={{ display: 'inline-block', wordWrap: 'break-word', wordBreak: 'break-all', maxWidth: 400 }}>
        {
          Type.isFunction(field.initialValue)
            ?
            field.initialValue(filler[field.key], filler)
            : result
        }
      </div>
    </FormItem>
  );
};

// 渲染下拉框
const renderSelect = (field, getFieldDecorator) => {
  const { keys, search, options = [] } = field;
  return (
    <FormItem
      label={field.label}
    >
      {
        getFieldDecorator(field.key, {
          initialValue: field.initialValue || [],
          rules: field.rules
        })(
          <Select
            style={{ width: FieldWith }}
            allowClear
            optionFilterProp="children"
            showSearch={search}
          >
            {
              options.map(option => (
                <Option
                  value={option[keys.value]}
                  key={option[keys.value]}
                >
                  {option[keys.content]}
                </Option>
              ))
            }
          </Select>
        )
      }
    </FormItem>
  );
};

// 渲染数字输入框
const renderInputNumber = (field, getFieldDecorator) => (
  <FormItem
    label={field.label}
  >
    {
      Type.isFunction(field.render)
        ? field.render(field, getFieldDecorator)
        : getFieldDecorator(field.key, {
          initialValue: field.initialValue,
          rules: field.rules
        })(
          <InputNumber
            {...field}
            min={field.min || 0}
            precision={field.precision || 0}
            max={field.max}
            style={{ width: FieldWith }}
            placeholder={field.placeholder}
          />
        )
    }
  </FormItem>
);

const cityPickerProps = {
  style: { width: FieldWith },
  multiple: false,
  cityBatch: false,
  areaBatch: false,
  provinceBatch: false
};
// 渲染地址选择
const renderCityPicker = (field, getFieldDecorator) => (
  <FormItem
    label={field.label}
  >
    {
      getFieldDecorator(field.key, {
        initialValue: field.initialValue || [],
        rules: field.rules
      })(
        <HCityPicker
          {...cityPickerProps}
          placeholder={field.placeholder}
        />
      )
    }
  </FormItem>
);

// 日期选择
const dateCityPicker = (field, getFieldDecorator) => (
  <FormItem
    label={field.label}
  >
    {
      getFieldDecorator(field.key, {
        rules: field.rules,
        initialValue: field.initialValue || null
      })(
        <DatePicker
          showTime
          format="YYYY-MM-DD HH:mm:ss"
          style={{ width: FieldWith }}
          placeholder={field.placeholder}
        />
      )
    }
  </FormItem>
);

// 文本输入框
const renderTextarea = (field, getFieldDecorator) => (
  <FormItem
    label={field.label}
  >
    {
      Type.isFunction(field.render)
        ? field.render(field, getFieldDecorator)
        : getFieldDecorator(field.key, {
          initialValue: field.initialValue || '',
          rules: field.rules
        })(
          <TextArea
            style={{ width: FieldWith }}
            placeholder={field.placeholder}
            maxLength={field.maxLength}
          />
        )
    }
  </FormItem>
);

export default function creatFormField({
  fields = [],
  form,
  filler
}) {
  const { getFieldDecorator } = form;


  const typeMap = {
    input: field => renderInput(field, getFieldDecorator),
    text: renderText,
    select: field => renderSelect(field, getFieldDecorator),
    inputNumber: field => renderInputNumber(field, getFieldDecorator),
    cityPicker: field => renderCityPicker(field, getFieldDecorator),
    datePicker: field => dateCityPicker(field, getFieldDecorator),
    textarea: field => renderTextarea(field, getFieldDecorator),
    custom: field => field.render(field, getFieldDecorator),
  };

  function renderField(field) {
    const { type } = field;
    const renderType = typeMap[type];
    if (Type.isFunction(renderType)) {
      return renderType(field, filler);
    }
    return null;
  }


  const renderItem = ({ show, title, titleExtra, contentFields = [] }, i) => (
    show === undefined || show === true ? <Form layout="inline" key={i}>
      {Type.isEmpty(title) ?
        <Row type="flex">
          {
            Type.isFunction(contentFields) ? contentFields() :
              contentFields.map(field => (
                field && (field.show === undefined || field.show === true) && (
                  <Col span={field.span || 12} key={field.ukey || field.key}>
                    {renderField(field)}
                  </Col>
                )
              ))
          }
        </Row>
        :
        <div className="infoItem">
          <div className="infoTitle">
            {Type.isFunction(title) ? title() : title}
            <span className="ml20">{Type.isFunction(titleExtra) ? titleExtra(getFieldDecorator) : null}</span>
          </div>
          <div className="infoContent">
            <Row type="flex">
              {
                Type.isFunction(contentFields) ? contentFields() :
                  contentFields.map(field => (
                    field && (field.show === undefined || field.show === true) && (
                      <Col span={field.span || 12} key={field.ukey || field.key}>
                        {renderField(field)}
                      </Col>
                    )
                  ))
              }
            </Row>
          </div>
        </div>
      }
    </Form> : null
  );


  return <div className={styles['form-fields']}>{fields.map(renderItem)}</div>;
}
