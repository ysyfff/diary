import { Row, Col, Form, Button } from 'antd';
import BaseComponent from '../HOC/BaseComponent';
import HOCForm from '../HOC/HOCForm';
import HOCBindFields from '../HOC/HOCBindFields';
import './index.less';

const FormItem = Form.Item;

const PAGE_SIZE = 10;

class BaseFormLayout extends BaseComponent {
  static defaultProps = {
    layout: 'inline',
    baseItemLayout: {
      labelCol: {
        xxl: { span: 8 },
        xl: { span: 6 },
        lg: { span: 6 },
        md: { span: 6 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xxl: { span: 8 },
        xl: { span: 10 },
        lg: { span: 14 },
        md: { span: 14 },
        sm: { span: 14 }
      }
    }
  };

  handleReset = () => {
    const { resetFields } = this.props.form;
    const { onSearch } = this.props;
    resetFields();
    const values = this.formatValues(this.props.defaultValues);
    onSearch && onSearch({ pn: 1, ps: PAGE_SIZE, ...values });
  }

  handleSearch = () => {
    this.props.form.validateFields((error) => {
      if (!error) {
        this.props.onSearch(this.formatValues());
      }
    });
  }

  render() {
    return (
      <div className="searchBar searchLayout">
        <Row>
          {this.getFields()}
        </Row>
        <Row className="searchButtonLayout">
          <Col style={{ display: 'inline-block' }}>
            <FormItem>
              <Button type="primary" onClick={this.handleSearch}>查询</Button>
              <Button onClick={this.handleReset}>重置</Button>
            </FormItem>
          </Col>
        </Row>
      </div>
    );
  }
}

export default HOCBindFields(HOCForm(BaseFormLayout));
