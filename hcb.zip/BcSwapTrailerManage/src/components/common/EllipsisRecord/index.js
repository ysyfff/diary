import React from 'react';
import { Popover } from 'antd';
import assert from 'utils/assert';
import './index.less';

const MIN_TIMES = 1.4;
const MAX_TIMES = 2.4;
const BASE_RECORD_LENGTH = 50;
const BASE_LINE_HEIGHT = 20;


class EllipsisRecord extends React.PureComponent {
  state = {
    overflow: false,
    popoverWidth: 0
  };

  componentDidMount() {
    const { overflow, popoverWidth } = this.getOverflow();
    this.changeState(overflow, popoverWidth);
  }

  componentDidUpdate() {
    const { overflow, popoverWidth } = this.getOverflow();
    if (this.state.overflow !== overflow) {
      this.changeState(overflow, popoverWidth);
    }
  }

  getOverflow = () => {
    const originHeight = this.origin ? this.origin.clientHeight : 0;
    const originWidth = this.origin ? this.origin.clientWidth : 0;
    const copyWidth = this.origin ? this.copy.clientWidth : 0;
    const copyHeight = this.origin ? this.copy.clientHeight : 0;
    return {
      overflow: originWidth < copyWidth || originHeight !== copyHeight,
      popoverWidth: originWidth
    };
  }

  changeState = (overflow, popoverWidth) => {
    this.setState({ overflow, popoverWidth });
  }

  render() {
    const {
      record,
      width,
      row,
      title = null,
      popoverContent,
      enabelPlacement = false,
      popoverStyle = {},
      cursor
    } = this.props;
    assert(!(width && row), 'width和row不能同时传递');
    const { overflow, popoverWidth } = this.state;
    const times = record.length / BASE_RECORD_LENGTH;
    const realTimes = (times > MIN_TIMES ? Math.min(times, MAX_TIMES) : MIN_TIMES);
    let style;
    if (width) {
      style = {
        maxWidth: `${width * realTimes}px`
      };
    } else {
      style = {
        maxWidth: `${popoverWidth * realTimes}px`
      };
    }
    let theCursor;
    if (overflow) {
      theCursor = 'pointer';
    } else if (cursor) {
      theCursor = cursor;
    } else {
      theCursor = 'initial';
    }
    const Component = (
      <div
        className="record-ellipsis-container"
        style={{ width: `${width}px` }}
      >
        {width &&
          (
            <div
              className="record-ellipsis"
              style={{
                overflow: 'hidden',
                whiteSpace: 'nowrap',
                zindex: 99999999999,
                cursor: theCursor
              }}
              ref={origin => this.origin = origin}
            >
              {record}
            </div >
          )
        }
        {
          row && (
            <div
              className="record-ellipsis"
              style={{
                display: '-webkit-box',
                overflow: 'hidden',
                lineHeight: `${BASE_LINE_HEIGHT}px`,
                maxHeight: `${20 * row}px`,
                wordBreak: 'break-all',
                WebkitBoxOrient: 'vertical',
                WebkitLineClamp: row,
                whiteSpace: 'pre-wrap',
                textOverflow: 'ellipsis',
                cursor: overflow ? 'pointer' : 'initial'
              }}
              ref={origin => this.origin = origin}
            >
              {record}
            </div >
          )
        }
        {
          width && (
            <div
              className="record-copy"
              ref={copy => this.copy = copy}
            >{record}</div>
          )
        }
        {
          row && (
            <div
              className="record-copy"
              style={{
                lineHeight: `${BASE_LINE_HEIGHT}px`,
                wordBreak: 'break-word',
                whiteSpace: 'pre-wrap'
              }}
              ref={copy => this.copy = copy}
            >{record}</div>
          )
        }
      </div>
    );
    return (
      <React.Fragment>
        {
          overflow &&
          <Popover
            ref={popup => this.popup = popup}
            content={popoverContent || record}
            title={title}
            placement={realTimes === MAX_TIMES && enabelPlacement ? 'leftTop' : 'top'}
            autoAdjustOverflow
            overlayStyle={{
              ...style,
              zIndex: 99999,
              wordBreak: 'break-all',
              ...popoverStyle
            }}
          >
            {Component}
          </Popover>
        }
        {!overflow && Component}
      </React.Fragment>
    );
  }
}

export default EllipsisRecord;
