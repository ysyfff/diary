import React from 'react';
import { Input, Table } from 'antd';
import { debounce } from 'lodash';

import './index.less';

class AutoSearchInput extends React.PureComponent {
  static defaultProps = {
    dataLength: 10
  };

  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
      value: '',
      isSelectResult: true
    };
    this.debounceRequest = debounce(this.debounceChange, 300);
  }

  componentDidMount() {
    window.addEventListener('click', this.handleClickOutside, false);
  }

  componentWillUnmount() {
    window.removeEventListener('click', this.handleClickOutside, false);
  }

  setValue = (value) => {
    this.setState({
      value,
      isSelectResult: true
    });
  }
  handleClickOutside = () => {

  }

  clearValue = () => {
    this.setState({
      value: '',
      isSelectResult: true
    });
  }


  handleRow = record => ({
    onClick: () => {
      const { onChange, inputKey, onSelecting } = this.props;
      // debugger
      if (record) {
        onChange && onChange(record[inputKey], record);
        onSelecting && onSelecting({ v: record[inputKey], obj: record });
        this.setState({
          visible: false,
          value: record[inputKey],
          isSelectResult: true
        });
      }
    }
  })

  handleChange = (e) => {
    const { onChange } = this.props;
    const value = e.target.value;
    onChange && onChange(value);
    this.setState({ value, isSelectResult: true }, () => {
      if (!(value === 0 || value)) {
        this.setState({ visible: false });
      } else {
        this.debounceRequest();
      }
    });
  }

  debounceChange = async () => {
    const { onSearch } = this.props;
    const { value } = this.state;
    const visible = value === 0 || value ? !!1 : !!0;
    this.setState({ visible, loading: true });
    if (onSearch) {
      await onSearch(value);
      this.setState({ visible, loading: false });
    }
  }

  handleBlur = () => {
    this.timer = setTimeout(() => {
      this.setState(({ isSelectResult, value }) => ({
        visible: false,
        value: isSelectResult ? value : ''
      }), () => {
        const { value } = this.state;
        this.props.onChange(value);
        clearTimeout(this.timer);
      });
    }, 300);
  }

  handleClick = (e) => {
    e.stopPropagation();
  }

  handleFocus = async () => {
    const { onSearch } = this.props;
    const { value } = this.state;
    this.setState({ visible: true, loading: true });
    if (onSearch) {
      await onSearch(value || '');
      this.setState({ visible: true, loading: false });
    }
  }

  render() {
    const {
      columns,
      dataSource = [],
      dropDownTableWidth,
      dataLength,
      ...other
    } = this.props;
    const { visible, loading } = this.state;
    // 截取dataSource
    let datas = [...dataSource];
    if (dataSource.length > dataLength) {
      datas = datas.slice(0, 10);
    }
    return (
      <div className="auto-search-input">
        <Input
          {...other}
          value={this.props.value}
          onChange={this.handleChange}
          ref={input => this.input = input}
          onBlur={this.handleBlur}
          onClick={this.handleClick}
          autoComplete="off"
          maxLength={20}
        />
        <div
          className="wrapper-table-content"
          style={{ width: `${dropDownTableWidth}px`, display: visible ? 'block' : 'none' }}
        >
          <Table
            rowKey={record => record.waybillNo}
            onRow={this.handleRow}
            pagination={false}
            loading={loading}
            columns={columns}
            dataSource={datas}
            scroll={{ y: 300 }}
            bordered
          />
        </div>
      </div>
    );
  }
}

export default AutoSearchInput;
