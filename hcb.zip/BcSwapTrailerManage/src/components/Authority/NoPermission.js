import React from 'react';
import styles from './index.less';

const NoPermission = () => (
  <div className={styles['no-permission']}>
    <div className="no-permission-warpper">
      <div className="img-block">
        <div className="img-ele" />
      </div>
      <div className="content">
        <div className="desc">抱歉，您没有权限访问该页面</div>
        <div className="desc">请联系管理员</div>
      </div>
    </div>
  </div>
);

export default NoPermission;
