import React from 'react';
import { hasPermission } from 'utils';
import AuthoredContext from './AuthoredContext';

const Empty = ({ renderLine }) => renderLine ? <span>--</span> : null;

class AuthortyWarpper extends React.PureComponent {
  static defaultProps = {
    renderLine: false
  };

  render() {
    const { renderLine, children, code } = this.props;
    return (
      <AuthoredContext.Consumer>
        {({ userAuthority }) => {
          if (code) {
            const has = hasPermission(userAuthority, code);
            return has ? children : <Empty renderLine={renderLine} />;
          }
          return children;
        }}
      </AuthoredContext.Consumer>
    );
  }
}

export default AuthortyWarpper;
