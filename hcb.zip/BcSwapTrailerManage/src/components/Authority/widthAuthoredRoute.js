/**
 * @author yang.huang3
 * @description 带权限控制的组件
 * @since 2018/11/09
 */
import React from 'react';
import { AuthoredContext, NoPermission } from 'components';
import buttonAuthoritesConfig from 'configs/buttonAuthoritesConfig';
import { hasPermission } from 'utils';

const widthAuthoredRoute = ({ permission }) => WrapperComponent =>
  class AuthoredComponent extends React.PureComponent {
    render() {
      return (
        <React.Fragment>
          <AuthoredContext.Consumer>
            {({ userAuthority }) => {
              const has = hasPermission(userAuthority, permission);
              if (!userAuthority) return null;
              return has ?
                <WrapperComponent
                  {...this.props}
                  permission={buttonAuthoritesConfig}
                />
                : <NoPermission />;
            }}
          </AuthoredContext.Consumer>
        </React.Fragment>
      );
    }
  };
export default widthAuthoredRoute;

