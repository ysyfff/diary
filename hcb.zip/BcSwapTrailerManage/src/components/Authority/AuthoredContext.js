import React from 'react';

const AuthoredContext = React.createContext();

export default AuthoredContext;
