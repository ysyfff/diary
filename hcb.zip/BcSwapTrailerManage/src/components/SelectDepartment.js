/**
 * 组织模糊搜索
 * @props   {String}   vlaue     false
 * @props   {Func}     onChange   false
 */
import { TreeSelect } from 'antd';
import services from 'services';
/* 常用部门类型枚举（如有误差，以dms为准） */
/* type: 1-大区、2-职能部门、3-事业部、4-市场部、5-车管组 */
const TreeNode = TreeSelect.TreeNode;
class SelectDepartment extends React.Component {
  static defaultProps={
    params: {}, // 过滤树
    selectParams: {} // 可选择条件
  };
  constructor(props) {
    super(props);
    const value = props.value || undefined;
    this.state = {
      value: value && value.toString(),
      departmentTree: [],
    };
    this.handleChange = this.handleChange.bind(this);
    this.triggerChange = this.triggerChange.bind(this);
  }
  componentDidMount() {
    services.departmentManage.departmentTree().then((response) => {
      this.setState({
        departmentTree: [response]
      });
    });
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || undefined;
      this.setState({ value: value && value.toString() });
    }
  }
  handleChange(value, label, extra) {
    if (!('value' in this.props)) {
      this.setState({ value });
    }
    const extraVal = (extra && extra.triggerNode && extra.triggerNode.props) || {};
    this.triggerChange(value, extraVal);
  }
  triggerChange(changedValue, extraVal) {
    const { onChange, extraChange } = this.props;
    if (onChange) {
      onChange(changedValue);
      extraChange && extraChange(extraVal);
    }
  }
  render() {
    const { params, selectParams, placeholder } = this.props;
    const loop = data => data.map((item) => {
      if (item.children) {
        let flag = true;
        let disabled = true;
        if (Object.keys(params).length) {
          Object.keys(params).forEach((key) => {
            if (item[key] !== params[key]) {
              flag = false;
            }
          });
        }
        if (Object.keys(selectParams).length) {
          Object.keys(selectParams).forEach((key) => {
            if (item[key] !== selectParams[key]) {
              disabled = false;
            }
          });
        }
        if (flag) {
          return (
            <TreeNode disabled={!disabled} key={item.id} title={item.name} value={item.id.toString()}>
              {loop(item.children)}
            </TreeNode>
          );
        }
        return (
          loop(item.children)
        );
      }
      let flag = true;
      let disabled = true;
      if (Object.keys(params).length) {
        Object.keys(params).forEach((key) => {
          if (item[key] !== params[key]) {
            flag = false;
          }
        });
      }
      if (Object.keys(selectParams).length) {
        Object.keys(selectParams).forEach((key) => {
          if (item[key] !== selectParams[key]) {
            disabled = false;
          }
        });
      }
      if (flag) {
        return <TreeNode disabled={!disabled} key={item.id} value={item.id.toString()} title={item.name} />;
      }
      return '';
    });
    const treeSelectProps = { ...this.props,
      ...{
        showSearch: true,
        value: this.state.value,
        dropdownStyle: { maxHeight: 400, overflow: 'auto' },
        placeholder: placeholder || '请选择',
        allowClear: true,
        getPopupContainer: () => document.getElementById('root'),
        treeDefaultExpandAll: true,
        onChange: this.handleChange,
        treeNodeFilterProp: 'title' } };
    return (
      <TreeSelect {...treeSelectProps}>
        {loop(this.state.departmentTree)}
      </TreeSelect>
    );
  }
}
export default SelectDepartment;
