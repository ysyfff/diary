import React from 'react';
import { withRouter } from 'dva/router';
import { Button, Spin, Card } from 'antd';
import columns from './fields';

import styles from './index.less';

const RANGE_LENGTH = 8;

const range = (len) => {
  const rangeArray = [];
  for (let i = 0; i < len; i += 1) {
    rangeArray.push(i);
  }
  return rangeArray;
};

const rangeArray = range(RANGE_LENGTH);

@withRouter
class DeliveryNotePrint extends React.PureComponent {
  static defaultProps = {
    drivers: []
  };

  state = {
    showButton: true
  }

  componentDidMount() {
    const beforePrint = () => {

    };
    const afterPrint = () => {
      this.setState({ showButton: true });
    };

    if (window.matchMedia) {
      this.mediaQueryList = window.matchMedia('print');
      this.mql = (mql) => {
        if (mql.matches) {
          beforePrint();
        } else {
          afterPrint();
        }
      };
      this.mediaQueryList.addListener(this.mql);
    }
    // 打印操作监听
    window.onbeforeprint = beforePrint;
    window.onafterprint = afterPrint;
  }

  componentWillUnmount() {
    this.mediaQueryList.removeListener(this.mql);
  }

  print = () => {
    this.setState({ showButton: false }, () => {
      window.print();
    });
  }

  back = () => {
    const { history } = this.props;
    history.go(-1);
  }

  render() {
    const { showButton } = this.state;
    const { loading = false, history, dataSource = [] } = this.props;
    return (
      <Spin spinning={loading}>
        <div className={`${styles['delivery-print-preview']} print-preview`}>
          {dataSource.length === 0 && (
            <Card>
              <span>派车单暂无调度信息！</span>
            </Card>
          )}
          {dataSource.map((data, index) => (
            <div key={`table_${index}`} className="print-preview-wrapper">
              <div className="print-preview-container">
                <React.Fragment >
                  <div className="print-header-wrapper">
                    <div className="print-logo">
                      <img className="logo" alt="logo" src={require('./images/logo.png')} />
                    </div>
                    <div className="print-title" >
                      <em>月</em>
                      <em style={{ marginLeft: '1.2cm' }}>日</em>
                      <em>短驳派车单</em>
                    </div>
                  </div>
                  <div className="deliver" />
                  <div className="print-table-wrapper">
                    <table className="print-table">
                      <colgroup>
                        {rangeArray.map(range => (
                          <col
                            key={`col_${range}`}
                          />)
                        )}
                      </colgroup>
                      <tbody>
                        {columns.map((column, index) => (
                          <React.Fragment key={`row-${index}`}>
                            { index === columns.length - 1 && (
                              <tr className="deliver-tr">
                                <td colSpan={RANGE_LENGTH} className="line" />
                              </tr>
                            )}
                            <tr className="print-table-row">
                              {
                                (column || []).map((col, index) => {
                                  const { key, name, colSpan = 1 } = col;
                                  return (
                                    <React.Fragment key={`${key}_${index}`}>
                                      <td
                                        align="center"
                                        style={{ width: '70px' }}
                                      >
                                        {name}
                                      </td>
                                      <td
                                        align="center"
                                        colSpan={colSpan}
                                        style={{ width: '15%' }}
                                      >
                                        {data[key]}
                                      </td>
                                    </React.Fragment>
                                  );
                                })
                              }
                            </tr>
                          </React.Fragment>

                        ))}
                      </tbody>
                    </table>
                  </div>
                  { dataSource.length > 1 && <div className="page-next" /> }
                </React.Fragment>
              </div>
            </div>
          ))}
          <style type="text/css" media="print">
            {
              `@page {
                size: landscape;
                margin: 0;
              }

              .print-preview {
                width: 100%;
                height: 100%;
                max-width: 21.4cm;
              }

              .print-preview .print-preview-wrapper{
                width: 100%;
                height: 100%;
                display: table;
              }

              .print-preview .print-preview-container {
                display: table-cell;
                vertical-align: middle;
              }
              `
            }
          </style>
          <div style={{ textAlign: 'center', margin: '12px 0' }}>
            <Button
              type="primary"
              style={{ display: showButton && !loading && dataSource.length > 0 ? 'inline' : 'none' }}
              onClick={this.print}
            >打印
            </Button>
            <Button
              type="primary"
              style={{
                marginLeft: '12px',
                display: showButton && !loading && history.length > 1 ? 'inline' : 'none'
              }}
              onClick={this.back}
            >返回</Button>
          </div>
        </div>
      </Spin>
    );
  }
}

export default DeliveryNotePrint;
