import defaultInputTypeMap from '../config/inputTypeMap';
import { colLayout, formItemLayout } from '../config/layout';
import { combineDistinctObject } from '../utils';

class Helper {
  constructor(options) {
    if (!Helper._instance) {
      Helper._instance = options ? this._init(options) : new Helper();
    }
    return Helper._instance;
  }

  _init({
    defaultInputType,
    inputTypeMap
  }) {
    if (!Helper._instance) {
      this.defaultInputType = defaultInputType;
      this.inputTypeMap = combineDistinctObject(
        defaultInputTypeMap,
        inputTypeMap
      );
      this.colLayout = colLayout;
      this.formItemLayout = formItemLayout;
    } else {
      throw new Error('_init method can\'t be called');
    }
  }

  _setInputTypeMap(inputTypeMap = {}) {
    this.inputTypeMap = combineDistinctObject(
      defaultInputTypeMap,
      inputTypeMap
    );
  }

  getInputTypeMap() {
    return this.inputTypeMap;
  }

  getDefaultInputType() {
    return this.defaultInputType;
  }

  getColLayout() {
    return this.colLayout;
  }

  getFormItemLayout() {
    return this.formItemLayout;
  }

  install(options = {}) {
    const { inputTypeMap = {} } = options;
    this._setInputTypeMap(inputTypeMap);
  }
}

export default new Helper({
  defaultInputType: 'input',
  inputTypeMap: { }
});
