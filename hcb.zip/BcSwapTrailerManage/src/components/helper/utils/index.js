export const isObject = object => Object.prototype.toString.call(object) === '[object Object]';

export const isNotEmptyObject = object => isObject(object) && Object.keys(object).length > 0;

export const isArray = object => Object.prototype.toString.call(object) === '[object Array]';

export const isUndefined = object => typeof object === 'undefined';

export const isFunction = object => Object.prototype.toString.call(object) === '[object Function]';

export const assert = (condition, message) => {
  if (!condition) {
    throw new Error(`[antd-helper]-${message}`);
  }
};
// 合并两个不同的对象，前一个对象的key不能被覆盖
export const combineDistinctObject = (a, b) => {
  assert(isObject(b), 'b must be a Object');
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  const res = {};
  if (aKeys.length === 0 || bKeys.length === 0) return { ...a, ...b };
  bKeys.filter(key => aKeys.indexOf(key) === -1).forEach((key) => { res[key] = b[key]; });
  return { ...a, ...res };
};
