import React from 'react';
import { Card, Row, Button } from 'antd';
import PropTypes from 'prop-types';
import createFormFields from '../form/createFormFields';

import styles from './index.less';

class SearchBar extends React.PureComponent {
  static propTypes = {
    onSearch: PropTypes.func.isRequired
  };

  handleSearch = () => {
    const { helper, onSearch } = this.props;
    onSearch(helper.getFieldsValues());
  }

  handleReset = () => {
    const { getForm } = this.props.helper;
    const form = getForm();
    form.resetFields();
  }

  render() {
    return (
      <div className={styles['search-bar']}>
        <Card>
          <Row>{this.props.children}</Row>
          <Row className="search-button-group" type="flex" justify="end" align="middle">
            <Button onClick={this.handleSearch} className="search-button" type="primary">查询</Button>
            <Button onClick={this.handleReset}>重置</Button>
          </Row>
        </Card>
      </div>
    );
  }
}

export default createFormFields()(SearchBar);
