import React from 'react';
import { Card } from 'antd';
import PropTypes from 'prop-types';
// import createFormFields from '../form/createFormFields';

import styles from './index.less';

class HCard extends React.PureComponent {
  static propTypes = {
    title: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.element
    ]).isRequired
  };

  render() {
    const { title, style, ...restProps } = this.props;
    return (
      <div className={styles['h-card']} style={style}>
        <Card title={title} {...restProps}>
          {this.props.children}
        </Card>
      </div>
    );
  }
}

export default HCard;
