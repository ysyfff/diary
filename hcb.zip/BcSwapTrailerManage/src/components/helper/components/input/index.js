/**
 * @author yang.huang
 * @description 在antd input组件的基础上添加clear功能
 * @since 2018/10/11
 */
import React from 'react';
import { Input, Icon } from 'antd';
import PropTypes from 'prop-types';

import styles from './index.less';

class HInput extends React.PureComponent {
  static defaultProps = {
    showClear: true
  };

  static propTypes = {
    showClear: PropTypes.bool
  };

  static getDerivedStateFromProps = nextProps => ({
    value: nextProps.value
  });

  constructor(props) {
    super(props);
    this.state = {
      show: false,
      value: props.value || undefined
    };
  }

  handleMouseOver = () => {
    const { showClear } = this.props;
    const { value } = this.state;
    if (value && showClear) {
      this.setState({ show: true });
    }
  }

  handleMouseOut = () => {
    const { showClear } = this.props;
    if (showClear) {
      this.setState({ show: false });
    }
  }

  // 监听input onChange事件
  handleChange = (e) => {
    const { onChange, showClear } = this.props;
    const { value } = e.target;
    this.setState({ value });
    if (showClear) {
      this.setState({ show: value === 0 || value });
    }
    // 用于form修改value
    if (onChange) onChange(e);
  }

  handleClear = () => {
    const { onChange, showClear } = this.props;
    this.setState({ value: undefined });
    if (showClear) {
      this.setState({ show: false });
    }
    if (onChange) onChange(undefined);
  }

  render() {
    const { showClear, disabled, onChange, ...restProps } = this.props;
    const { show, value } = this.state;
    return (
      <div
        className={styles['h-input']}
        onMouseOver={this.handleMouseOver}
        onMouseOut={this.handleMouseOut}
      >
        <Input
          {...restProps}
          value={value}
          autoComplete="off"
          onChange={this.handleChange}
          disabled={disabled}
        />
        {
          showClear && !disabled && (
            <span
              className={`input-clear-icon ${show ? 'visible' : 'visible-hidden'}`}
            >
              <Icon type="close" onClick={this.handleClear} />
            </span>
          )
        }
      </div>
    );
  }
}

export default HInput;
