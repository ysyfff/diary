/**
 * @description 省市区地址组件
 */

import React from 'react';
import { HCityPicker } from 'carno';

class CityPicker extends React.PureComponent {
  static getDerivedStateFromProps = nextProps => ({
    value: nextProps.value || []
  });

  constructor(props) {
    super(props);
    this.state = {
      restProps: {
        style: {
          width: '100%',
        },
        multiple: false,
        cityBatch: false,
        areaBatch: false,
        provinceBatch: false
      },
      value: props.value || []
    };
  }

  handleChange = (value) => {
    const { onChange } = this.props;
    onChange && onChange(value);
  }

  render() {
    const { restProps, value } = this.state;
    const { disabled, placeholder } = this.props;
    return (
      <div>
        <HCityPicker
          onChange={this.handleChange}
          value={value}
          disabled={disabled}
          placeholder={placeholder}
          {...restProps}
        />
      </div>
    );
  }
}

export default CityPicker;
