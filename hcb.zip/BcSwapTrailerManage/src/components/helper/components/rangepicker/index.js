/**
 * @author yang.huang
 * @description 日期区间选择组件
 * @since 2018/10/15
 */
import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { DatePicker, Popover } from 'antd';

import styles from './index.less';

const { RangePicker } = DatePicker;

class HRangePicker extends React.PureComponent {
  static defaultProps = {
    startDateKey: 'startDate',
    endDateKey: 'endDate',
    formatType: 'date'
  };

  static propTypes = {
    startDateKey: PropTypes.string,
    endDateKey: PropTypes.string,
    formatType: PropTypes.oneOf(['date', 'datetime'])
  };

  static getDerivedStateFromProps = (nextProps) => {
    const { startDateKey, endDateKey } = nextProps;
    const nextValue = nextProps.value || { [startDateKey]: '', [endDateKey]: '' };
    const values = Object.values(nextValue);
    if (values.some(value => !value)) return { value: [] };
    return {
      value: [moment(values[0]), moment(values[1])],
      popoverContent: `${values[0]} ~ ${values[1]}`
    };
  };

  constructor(props) {
    super(props);
    this.state = {
      value: props.value || [],
      popoverContent: null,
      showPopover: false,
      isOpenPanel: false
    };
  }

  handleChange = (dates, dateString) => {
    const { startDateKey, endDateKey } = this.props;
    const startDate = dateString[0];
    const endDate = dateString[1];
    const { onChange } = this.props;
    if (onChange) onChange({ [startDateKey]: startDate, [endDateKey]: endDate });
    this.setState({
      value: dates,
      showPopover: false,
      popoverContent: dates.length !== 0 ? `${startDate} ~ ${endDate}` : null
    });
  }

  handleOpenChange = (status) => {
    const { onOpenChange } = this.props;
    this.setState({
      showPopover: false,
      isOpenPanel: status
    });
    if (onOpenChange) onOpenChange(status);
  }

  handleMouseEnter = () => {
    const { isOpenPanel } = this.state;
    this.setState(({ value }) => ({
      showPopover: !isOpenPanel && value.length !== 0
    }));
  }

  handleMouseLeave =() => {
    this.setState({ showPopover: false });
  }

  render() {
    const { value, popoverContent, showPopover } = this.state;
    const { format, formatType, ...restProps } = this.props;
    const _format = formatType === 'date' ? 'YYYY-MM-DD' : 'YYYY-MM-DD hh:mm:ss';
    const _formatType = formatType === 'datetime' || format === 'YYYY-MM-DD hh:mm:ss';
    return (
      <div className={styles['h-rangepicker']}>
        <Popover visible={_formatType && showPopover} content={popoverContent}>
          <RangePicker
            {...restProps}
            format={format || _format}
            value={value}
            onChange={this.handleChange}
            onOpenChange={this.handleOpenChange}
            onMouseEnter={this.handleMouseEnter}
            onMouseLeave={this.handleMouseLeave}
          />
        </Popover>
      </div>
    );
  }
}

export default HRangePicker;
