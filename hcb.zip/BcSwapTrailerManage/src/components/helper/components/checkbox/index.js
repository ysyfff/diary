/**
 * @description 复选框组件
 */

import React from 'react';
import { Checkbox } from 'antd';


class HCheckbox extends React.PureComponent {
  static getDerivedStateFromProps = nextProps => ({
    checked: nextProps.value || false
  });

  constructor(props) {
    super(props);
    this.state = {
      checked: props.value || false
    };
  }

  handleChange = (value) => {
    const { onChange, onValueChange } = this.props;
    onChange && onChange(value.target.checked);
    onValueChange && onValueChange(value.target.checked);
  }

  render() {
    const { name, style, disabled } = this.props;
    const { checked } = this.state;
    return (
      <div>
        <Checkbox
          onChange={this.handleChange}
          checked={checked}
          value={checked}
          disabled={disabled}
          style={style}
        >{name}</Checkbox>
      </div>
    );
  }
}

export default HCheckbox;
