import React from 'react';
import { Select } from 'antd';
import styles from './index.less';

const { Option } = Select;

class HSelect extends React.PureComponent {
  handleChange = (value) => {
    const { onChange, onValueChange } = this.props;
    onChange && onChange(value);
    onValueChange && onValueChange(value);
  }

  render() {
    const { onChange, options = [], ...restProps } = this.props;
    return (
      <div className={styles['h-select']}>
        <Select onChange={this.handleChange} {...restProps}>
          {options.map((option) => {
            const { value, key, ...restOption } = option;
            return (<Option key={key} value={key} {...restOption}>{value}</Option>);
          })}
        </Select>
      </div>
    );
  }
}

export default HSelect;
