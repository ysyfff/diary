/**
 * @author yang.huang
 * @description 日期区间选择组件
 * @since 2018/10/15
 */
import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { DatePicker } from 'antd';

import styles from './index.less';

class HDatePicker extends React.PureComponent {
  static defaultProps = {
    startDateKey: 'startDate',
    endDateKey: 'endDate',
    formatType: 'date'
  };

  static propTypes = {
    startDateKey: PropTypes.string,
    endDateKey: PropTypes.string,
    formatType: PropTypes.oneOf(['date', 'datetime'])
  };

  static getDerivedStateFromProps = (nextProps) => {
    const { value } = nextProps;
    return {
      value: value ? moment(value) : undefined
    };
  };

  constructor(props) {
    super(props);
    this.state = {
      value: props.value || undefined
    };
  }

  handleChange = (dates) => {
    const { onChange } = this.props;
    const date = dates ? dates.format('YYYY-MM-DD HH:mm:ss') : undefined;
    if (onChange) onChange(date);
    this.setState({ value: date });
  }

  render() {
    const { value } = this.state;
    const { format, formatType, ...restProps } = this.props;
    const _format = formatType === 'date' ? 'YYYY-MM-DD' : 'YYYY-MM-DD HH:mm:ss';
    return (
      <div className={styles['h-datepicker']}>
        <DatePicker
          {...restProps}
          format={format || _format}
          value={value}
          onChange={this.handleChange}
        />
      </div>
    );
  }
}

export default HDatePicker;
