import React from 'react';
import { InputNumber } from 'antd';

import styles from './index.less';

const HInputNumber = props => (
  <div className={styles['h-input-number']}>
    <InputNumber {...props} />
  </div>
);

export default HInputNumber;
