import React from 'react';
import { Card } from 'antd';
import PropTypes from 'prop-types';
import { Type } from 'carno/utils';
import createFormFields from '../form/createFormFields';

import styles from './index.less';

class SearchCard extends React.PureComponent {
  static propTypes = {
    title: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.element
    ]).isRequired
  };

  static defaultProps = {
    list: {}
  };

  componentWillReceiveProps = (nextProps) => {
    if (this.props.list !== nextProps.list) {
      this.props.helper.setFieldsValues(nextProps.list);
    }
  }

  render() {
    const { title, extraContent = null, style, ...restProps } = this.props;
    return (
      <div className={title ? styles['h-search-card'] : null} style={style}>
        {Type.isNill(title) || title === '' ?
          <div {...restProps}>
            {this.props.children}
            {extraContent}
          </div>
          :
          <Card title={title} {...restProps}>
            {this.props.children}
            {extraContent}
          </Card>
        }
      </div>
    );
  }
}

export default createFormFields()(SearchCard);
