import React from 'react';

class FormItem extends React.PureComponent {
  render() {
    const { children, ...restProps } = this.props;
    return (
      <React.Fragment>
        {React.cloneElement(children, { ...restProps })}
      </React.Fragment>
    );
  }
}

export default FormItem;
