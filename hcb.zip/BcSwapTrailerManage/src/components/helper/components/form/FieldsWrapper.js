import React from 'react';
import { Form } from 'antd';
import FormFieldsContext from './FormFieldsContext';

const FieldsWrapper = ({
  form,
  children,
  formProps
}) => (
  <FormFieldsContext.Provider value={form}>
    <Form {...formProps}>
      {children}
    </Form>
  </FormFieldsContext.Provider>
);

export default Form.create()(FieldsWrapper);
