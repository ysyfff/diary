import React from 'react';
import { Form } from 'antd';
import FormFieldsContext from './FormFieldsContext';

class FieldsWrapperWithForm extends React.PureComponent {
  render() {
    const {
      form,
      children,
      formProps
    } = this.props;
    return (
      <FormFieldsContext.Provider value={form}>
        <Form {...formProps}>
          {children}
        </Form>
      </FormFieldsContext.Provider>
    );
  }
}

export default Form.create({
  onFieldsChange(props, changedFields) {
    const { onFieldsChange } = props;
    if (onFieldsChange) onFieldsChange(changedFields);
  },
  onValuesChange(props, changedValues) {
    const { onValuesChange } = props;
    if (onValuesChange) onValuesChange(changedValues);
  },
  mapPropsToFields(props) {
    const { fields } = props;
    return fields;
  }

})(FieldsWrapperWithForm);
