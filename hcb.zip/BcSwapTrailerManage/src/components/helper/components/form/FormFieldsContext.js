import React from 'react';

const FormFieldsContext = React.createContext();

export default FormFieldsContext;
