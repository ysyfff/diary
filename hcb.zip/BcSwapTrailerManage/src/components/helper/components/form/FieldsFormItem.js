import React from 'react';
import { Form, Col } from 'antd';

const FormItem = Form.Item;

class FieldsFormItem extends React.Component {
  componentDidUpdate(nextProps) {
    const { field, form } = nextProps;
    const { hidden = false } = field;
    const value = form.getFieldValue(field.key);
    if (hidden && value) form.setFieldsValue({ [field.key]: undefined });
  }

  render() {
    const {
      field,
      form,
      children,
      formItemCol,
      options
    } = this.props;
    const { getFieldDecorator } = form;
    const { label, key, col, hidden = false } = field;
    return (
      <React.Fragment>
        {
          hidden ? null : (
            <Col {...col}>
              <FormItem label={label} {...formItemCol}>
                {getFieldDecorator(key, {
                  ...options
                })(children)}
              </FormItem>
            </Col>
          )
        }
      </React.Fragment>
    );
  }
}

export default FieldsFormItem;
