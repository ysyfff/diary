/**
 * @author yang.huang
 * @description 创建FormFields
 * @since 2018/10/12
 */
import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Form } from 'antd';
import helper from '../../addons/helper';
import {
  isArray,
  isObject,
  assert,
  isUndefined,
  isFunction
} from '../../utils';
import FormItem from './FormItem';
import FieldsWrapperWithForm from './FieldsWrapperWithForm';
import FieldsWrapper from './FieldsWrapper';
import FormFieldsContext from './FormFieldsContext';
import FieldsFormItem from './FieldsFormItem';

const createFields = (fields) => {
  const formFields = {};
  Object.keys(fields).forEach((key) => {
    formFields[key] = Form.createFormField({ value: fields[key] });
  });
  return formFields;
};

const createFormFields = (
  fieldsProps = {
    isMapPropsToFields: true,
    formProps: {
      layout: 'horizontal'
    }
  }
) => WrapperComponent => class HOCFormItem extends React.PureComponent {
  static defaultProps = {
    extraFields: []
  };

  static propTypes = {
    fields: PropTypes.array.isRequired,
    extraFields: PropTypes.array
  };

  constructor(props) {
    super(props);
    // 保存组件在数组中的位置映射
    this.elKeyMap = {};
    // 保存配置文件渲染后的components
    this.components = null;
    // 保存上一次extraFields
    this.prevExtraFields = [];
    // 保存默认fields
    this.defaultFields = {};
    // 保存默认values
    this.defaultValues = {};
    // 保存返回的所有值域
    this.values = {};
    //
    this.state = { fields: {} };
  }

  onValuesChange = (changedValues) => {
    const { onValuesChange } = this.props;
    const values = Object.values(changedValues);
    const keys = Object.keys(changedValues);
    const value = isArray(values) && values.length === 1 ? values[0] : undefined;
    const key = isArray(keys) && keys.length === 1 ? keys[0] : undefined;
    // 消除为undefined的key
    if (isUndefined(value)) {
      if (key in this.values) delete this.values[key];
    } else {
      this.values = { ...this.values, ...changedValues };
    }
    onValuesChange && onValuesChange(this.values);
  }

  onFieldsChange = (changedFields) => {
    // console.log(changedFields);
    const keys = Object.keys(changedFields || {});
    const changed = {};
    if (keys.length === 0) return;
    keys.forEach((key) => {
      changed[key] = Form.createFormField(changedFields[key]);
    });
    // 是否是重置操作
    const isRest = keys.length > 0 && keys
      .every(key => !Object.prototype.hasOwnProperty.call(changedFields[key], 'value'));
    this.setState(({ fields }) => ({
      fields: isRest ? this.defaultFields
        : { ...fields, ...changed }
    }));
    if (isRest) this.values = this.defaultValues;
  }

  getFields = (form, fields, extraFields, dataSource) => {
    this.form = form;
    // 遍历fields只会执行一次
    const components = this.components
      || fields.map((field, index) => this.resolveFieldToComponent(field, form, index, dataSource));
    // 判断extraFields是否改变
    const changed = this.prevExtraFields !== extraFields;
    if (changed) {
      this.components = this.rerender(components, extraFields, form, dataSource);
    }
    return this.components;
  }

  /** 获取fieldsItem
   * field: {
   *  key: xxx,
   *  label: xxxx,
   *  type: xxxx,// type与render同时出现时render的优先级更高
   *  col: { // 表单元素布局
   *    xxl: xxxx
   *  },
   *  el: { // Col布局
   *    placeholder: xxxx
   *  },
   *  formItem: {
   *    props: {} // FormItem props,
   *    options: {} // getFieldDecorator options
   *  }
   * }
   * */
  resolveFieldToComponent = (field, form, index, dataSource) => {
    const { onValuesChange } = this.props;
    // input类型映射
    const inputTypeMap = helper.getInputTypeMap();
    // 默认的input类型
    const defaultInputType = helper.getDefaultInputType();
    // 默认的表单布局
    const colLayout = helper.getColLayout();
    // 获取FormItem布局
    const formItemLayout = helper.getFormItemLayout();
    const {
      key, // 元素的唯一标识
      type, // 元素类型
      render, // render新的元素
      el = {}, // 表单元素props
      col = {}, // Col布局
      hidden = false,
      formItem = {// 用于设置表单FormItem
        props: {},
        options: {
          initialValue: el.defaultValue
        }
      },
    } = field;
    // console.log(dataSource, 'jj')
    assert(key, 'key is required');
    const inputType = type || defaultInputType;
    const Component = render || inputTypeMap[inputType];
    const { props, options = {} } = formItem;
    const { defaultValue, ...resetEl } = el;
    assert(isFunction(Component), 'Component should be function');
    this.elKeyMap[key] = index;
    const value = hidden ? undefined : (defaultValue || options.initialValue || undefined);
    // form附初始值
    if (!hidden) {
      this.defaultFields[key] = Form.createFormField({ value });
    } else {
      delete this.values[key];
      delete this.defaultFields[key];
      delete this.defaultValues[key];
    }
    // 不保留值为undefined的key
    if (!isUndefined(value)) {
      this.defaultValues[key] = value;
      this.values[key] = value;
      onValuesChange && onValuesChange(this.values);
    }
    // 初始值
    options.initialValue = value;
    // 设置field
    field.type = inputType; // 组件类型
    field.col = { ...colLayout[`col_${this.props.col}`], ...col };
    const formItemCol = { ...formItemLayout[`col_${this.props.col}`], ...props };
    return (
      <FieldsFormItem
        key={key}
        field={field}
        form={form}
        formItemCol={formItemCol}
        options={options}
      >
        <FormItem>
          {type === 'text' ?
            <Component form={form} {...resetEl}>
              {dataSource[key] || '--'}
            </Component>
            :
            <Component form={form} {...resetEl} />
          }
        </FormItem>
      </FieldsFormItem>
    );
  }
  // components rerender
  rerender = (components, nextConfigs, form, dataSource) => {
    assert(isObject(nextConfigs) || isArray(nextConfigs),
      nextConfigs, 'nextConfigs must be Object or Array');
    const nextRender = (nextConfig) => {
      const { key, type, render } = nextConfig;
      assert(key, 'key is required');
      const index = this.elKeyMap[key];
      if (!isUndefined(index)) {
        const { props } = components[index];
        if (render) {
          assert(isFunction(render), 'render should be function');
        }
        if (render || (props.type && props.type !== type)) {
          const { options } = props;
          // 处理原组件有验证时重新渲染组件后会进入validating状态
          if (options.rules) {
            const { formItem = {}, el = {} } = nextConfig;
            if (!formItem.options || !formItem.options.rules) {
              nextConfig.formItem = {
                options: {
                  initialValue: el.defaultValue,
                  rules: [{ required: false }],
                  ...(formItem.options || {})
                },
                ...(formItem.props || {})
              };
            }
          }
        }
        // 重新渲染组件
        components[index] = this.resolveFieldToComponent(
          _.merge(props.field, nextConfig), form, index, dataSource
        );
      } else {
        const Component = this.resolveFieldToComponent(nextConfig, form, components.length, dataSource);
        components.push(Component);
      }
    };
    if (isObject(nextConfigs)) {
      nextRender(nextConfigs);
    } else {
      nextConfigs.forEach(config => nextRender(config));
    }
    this.prevExtraFields = nextConfigs;
    return components;
  }

  createHelper = () => ({
    resetFields: () => this.form.resetFields(),
    getFieldsValues: (isValidate = false) => {
      if (!isValidate) return this.values;
      const errors = [];
      this.form.validateFieldsAndScroll({ force: true }, (error) => {
        errors.push(!!error);
      });
      return {
        value: this.values,
        error: errors.some(error => !!error)
      };
    },
    setFieldsValues: (fieldsValues) => {
      const { onValuesChange } = this.props;
      // 将fieldsValues转化为fields
      assert(isObject(fieldsValues), 'fieldsValues should be Obejct');
      const copyFieldsValues = { ...fieldsValues };
      this.setState(({ fields }) => ({
        fields: { ...fields, ...createFields(copyFieldsValues) }
      }), () => {
        this.values = { ...this.values, ...fieldsValues };
        onValuesChange && onValuesChange(this.values);
      });
    },
    getForm: () => this.form
  });

  render() {
    const { isMapPropsToFields, formProps } = fieldsProps;
    const {
      fields,
      extraFields = [],
      wrappedComponentRef,
      dataSource,
      ...restProps
    } = this.props;

    const props = { ...restProps, helper: this.createHelper() };
    if (isFunction(wrappedComponentRef)) props.ref = wrappedComponentRef;
    return (
      <WrapperComponent {...props}>
        {
          isMapPropsToFields ? (
            <FieldsWrapperWithForm
              formProps={formProps}
              fields={this.state.fields}
              onFieldsChange={this.onFieldsChange}
              onValuesChange={this.onValuesChange}
            >
              <FormFieldsContext.Consumer>
                {form => this.getFields(form, fields, extraFields, dataSource)}
              </FormFieldsContext.Consumer>
            </FieldsWrapperWithForm>
          ) :
            (
              <FieldsWrapper
                formProps={formProps}
              >
                <FormFieldsContext.Consumer>
                  {form => this.getFields(form, fields, extraFields, dataSource)}
                </FormFieldsContext.Consumer>
              </FieldsWrapper>
            )
        }

      </WrapperComponent>
    );
  }
};

export default createFormFields;
