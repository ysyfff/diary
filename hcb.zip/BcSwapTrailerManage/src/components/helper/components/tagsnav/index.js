import React from 'react';

class TagsNav extends React.PureComponent {
  componentDidMount() {

  }

  render() {
    return (
      <div>111</div>
    );
  }
}

export default TagsNav;
