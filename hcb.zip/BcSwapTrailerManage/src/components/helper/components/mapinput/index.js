/**
 * @description 百度地图搜索组件
 */
import React from 'react';
import { Input } from 'antd';
import { Map, AutoComplete } from 'rc-bmap';

class MapInput extends React.PureComponent {
  static getDerivedStateFromProps = nextProps => ({
    value: nextProps.value
  });

  constructor(props) {
    super(props);
    this.state = {
      events: {
        onconfirm(e) {
          const { city, district, business } = e.item.value;
          const { onChange } = props;
          onChange(`${city}${district}${business}`);
        }
      },
      value: props.value || undefined
    };
  }

  handleChange = (value) => {
    const { onChange } = this.props;
    onChange && onChange(value);
  }

  render() {
    // 默认定位中心（上海）
    const mapAddress = { lng: 121.47, lat: 31.23 };

    const { events, value } = this.state;
    const { ak = 'dbLUj1nQTvDvKXkov5fhnH5HIE88RUEO', center = mapAddress } = this.props;


    return (
      <div>
        <Map
          ak={ak}
          center={center}
        >
          <AutoComplete
            input="suggest"
            events={events}
          />
        </Map>
        <Input
          id="suggest"
          onChange={this.handleChange}
          value={value}
        />
      </div>
    );
  }
}

export default MapInput;

