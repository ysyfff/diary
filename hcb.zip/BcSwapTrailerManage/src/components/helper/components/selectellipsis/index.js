import React from 'react';
import { Select } from 'antd';
import { EllipsisRecord } from 'components';
import styles from './index.less';

const { Option } = Select;

class HSelect extends React.PureComponent {
  handleChange = (value) => {
    const { onChange, onValueChange } = this.props;
    onChange && onChange(value);
    onValueChange && onValueChange(value);
  }

  render() {
    const { onChange, options = [], popoverStyle = {}, ellipsis = false, ...restProps } = this.props;
    return (
      <div className={styles['h-select']}>
        <Select onChange={this.handleChange} {...restProps}>
          {options.map((option) => {
            const { value, key, ...restOption } = option;
            return (<Option key={key} value={key} label={value} {...restOption}>
              { ellipsis && <EllipsisRecord popoverStyle={popoverStyle} record={value} row={1} /> }
              { !ellipsis && value }
            </Option>);
          })}
        </Select>
      </div>
    );
  }
}

export default HSelect;
