import React from 'react';

export default class HText extends React.PureComponent {
  componentDidMount = () => {

  }
  render() {
    return (
      <span>{this.props.children}</span>
    );
  }
}
