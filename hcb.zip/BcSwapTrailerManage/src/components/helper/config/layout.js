const colLayout = {
  col_2: {
    xxl: { span: 12 },
    xl: { span: 12 },
    lg: { span: 12 },
    md: { span: 12 },
    sm: { span: 24 },
    xs: { span: 24 }
  },
  col_3: {
    xxl: { span: 8 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 12 },
    sm: { span: 24 },
    xs: { span: 24 }
  },
  col_4: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 12 },
    sm: { span: 24 },
    xs: { span: 24 }
  }
};

const baseLabelColLayout = {
  xxl: { span: 8 },
  xl: { span: 8 },
  lg: { span: 8 },
  md: { span: 8 },
  sm: { span: 6 }
};

const formItemLayout = {
  col_2: {
    labelCol: { ...baseLabelColLayout },
    wrapperCol: {
      xxl: { span: 8 },
      xl: { span: 10 },
      lg: { span: 12 },
      md: { span: 16 },
      sm: { span: 14 }
    }
  },
  col_3: {
    labelCol: { ...baseLabelColLayout },
    wrapperCol: {
      xxl: { span: 12 },
      xl: { span: 16 },
      lg: { span: 16 },
      md: { span: 16 },
      sm: { span: 14 }
    }
  },
  col_4: {
    labelCol: { ...baseLabelColLayout },
    wrapperCol: {
      xxl: { span: 16 },
      xl: { span: 16 },
      lg: { span: 16 },
      md: { span: 16 },
      sm: { span: 14 }
    }
  }
};
export {
  colLayout,
  formItemLayout
};
