import { Input } from 'antd';
import HSelect from '../components/select';
import HInput from '../components/input';
import HInputNumber from '../components/inputnumber';
import HRangePicker from '../components/rangepicker';
import HDatePicker from '../components/datepicker';
import MapInput from '../components/mapinput';
import CityPicker from '../components/citypicker';
import HCheckbox from '../components/checkbox';
import HText from '../components/text';


const { TextArea } = Input;

export default {
  input: HInput,
  select: HSelect,
  textarea: TextArea,
  inputnumber: HInputNumber,
  rangepicker: HRangePicker,
  datepicker: HDatePicker,
  mapinput: MapInput,
  citypicker: CityPicker,
  checkbox: HCheckbox,
  text: HText
};
