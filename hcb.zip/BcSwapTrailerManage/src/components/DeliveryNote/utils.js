import { reginIdSplit, getRegionName } from 'utils';
import { Type } from 'carno/utils';

const isNullArray = value => Array.isArray(value) && value.length === 0;

const isNullObject = value => Type.isObject(value) && Object.keys(value).length === 0;

const isEmptyValue = value => value === '' || value === undefined ||
  value === null || isNullArray(value) || isNullObject(value);

// 转换货物列表
const transformCargoList = cargoList => cargoList.map((cargo) => {
  const { id, name, num, volume, weight } = cargo;
  return {
    id,
    cargoName: name,
    cargoPiece: num,
    cargoWeight: weight,
    cargoVolume: volume,
    cargoList: undefined,
    cargoPackage: undefined
  };
});

// 判断TableForm验证是否通过
const validateForms = (forms, returnValue = false) => {
  const result = [];
  const validators = Object.values(forms).map((form) => {
    let res = false;
    form.validateFieldsAndScroll({ force: true }, (error, value) => {
      const is = Object.values(value).every(val => isEmptyValue(val));
      if (returnValue && !is) result.push(value);
      if (error) res = true;
    });
    return res;
  });
  const error = validators.some(validator => !!validator);
  if (returnValue) return { value: result, error };
  return error;
};
// 转化PickUpDriver
const transformPickUpDriver = pickUpDriver =>
  pickUpDriver.map((pickup) => {
    const { driver, truck, ...rest } = pickup;
    return {
      ...driver,
      driverTruckId: truck.key,
      driverPlateNumber: truck.label,
      ...rest
    };
  });
// 提货用车转化PickUpDriver用于编辑保存
const transformPickUpDriverFormEdit = pickUpDriver =>
  pickUpDriver.map((pickup) => {
    const { driver, truck, pickUpCreateDriverOtherFee, ...rest } = pickup;
    return {
      ...driver,
      driverTruckId: truck.key,
      driverPlateNumber: truck.label,
      pickUpUpdateDriverOtherFee: pickUpCreateDriverOtherFee,
      ...rest
    };
  });
// 转化address
const transformAddress = address => address.map((addr) => {
  const { contact, contactPhone, addressDetail, citypicker = [] } = addr;
  const {
    provinceId,
    cityId,
    countyId
  } = citypicker.length > 0 && reginIdSplit(citypicker[0].id);
  const { name } = citypicker[0];
  return {
    shipperName: contact,
    shipperPhone: contactPhone,
    address: addressDetail,
    provinceId,
    provinceName: name,
    cityId,
    cityName: '',
    countyId,
    countyName: ''
  };
});

// 地址回现
const addressName = (province, city, county) => {
  const addressId = county || city || province;
  const addressCode = province ? [{ id: +addressId, name: getRegionName(addressId, '') }] : [];
  return addressCode;
};
// 转换地址
const transformAddressToComponent = (address = []) => address.map((addr) => {
  const { address, contact, contactPhone, province, city, county } = addr;
  return {
    addressDetail: address,
    contact,
    contactPhone,
    address: addressName(province, city, county)
  };
});

// 用于送货管理、列表转化地址
const deliveryTransformAddress = (record) => {
  const fromId = record.county || record.city || record.province;
  let address = getRegionName(fromId);
  const addr = address.split('-');
  addr.push(record.address || '');
  address = addr.join('');
  return address || '--';
};

const getOtherExpenses = OtherExpenses => OtherExpenses.map(ex => ({
  name: ex.name,
  price: ex.fee
}));
// 用于送货新增转换司机数组
const deliveryTransformDrivers = drivers => drivers.map((ovs) => {
  const { driver, truck, driverFee, pickUpCreateDriverOtherFee = [], ...rest } = ovs;
  return {
    ...rest,
    ...driver,
    driverTruckId: truck.key,
    driverPlateNumber: truck.label,
    deliveryCost: driverFee || undefined,
    otherExpenses: getOtherExpenses(pickUpCreateDriverOtherFee)
  };
});

// 送货管理转化address提交
const deliveryTransformAddressFormSave = (address, waybillNo) => address.map((addr) => {
  const { contact, contactPhone, addressDetail, citypicker = [] } = addr;
  const {
    provinceId,
    cityId,
    countyId
  } = citypicker.length > 0 && reginIdSplit(citypicker[0].id);
  const { name } = citypicker[0];
  return {
    waybillNo,
    contactName: contact,
    mobile: contactPhone,
    address: addressDetail,
    provinceId,
    provinceName: name,
    cityId,
    cityName: '',
    countyId,
    countyName: ''
  };
});
// 用于送货单详情地址回显
const deliveryTransformAddressToComponent = (address = []) => address.map((addr) => {
  const { address, contactName, mobile, provinceId, cityId, countyId } = addr;
  return {
    addressDetail: address,
    contact: contactName,
    contactPhone: mobile,
    address: addressName(provinceId, cityId, countyId)
  };
});

const deliveryGetOtherExpenses = OtherExpenses => OtherExpenses.map(ex => ({
  name: ex.name,
  fee: ex.price
}));
// 用于送货单编辑转换司机数组回显
const deliveryTransformDriversToComponent = drivers => drivers.map((ovs) => {
  const {
    driverId,
    driverName,
    driverMobile,
    driverTruckId,
    driverPlateNumber,
    deliveryCost,
    otherExpenses,
    id
  } = ovs;
  return {
    id,
    driver: { driverId, driverName, driverMobile },
    truck: { key: driverTruckId, label: driverPlateNumber },
    driverFee: deliveryCost || 0,
    pickUpCreateDriverOtherFee: deliveryGetOtherExpenses(otherExpenses || [])
  };
});
// 提货管理判断是否存在相同的司机
const isSameDrivers = (pickUpDriver) => {
  const driverIds = (pickUpDriver || []).map((driverObject) => {
    const { driver: { driverId } } = driverObject;
    return driverId;
  }, []);
  return (pickUpDriver || []).length !== [...new Set(driverIds)].length;
};

export {
  isEmptyValue,
  transformCargoList,
  validateForms,
  transformAddress,
  transformPickUpDriverFormEdit,
  transformAddressToComponent,
  transformPickUpDriver,
  deliveryTransformAddress,
  deliveryTransformDrivers,
  isSameDrivers,
  deliveryTransformAddressFormSave,
  deliveryTransformAddressToComponent,
  deliveryTransformDriversToComponent
};
