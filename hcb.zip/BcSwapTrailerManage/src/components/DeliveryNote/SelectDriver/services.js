import http from 'utils/http';

const { post } = http.create('admin');

// 获取短驳或干线司机
export function getDriver(param) {
  return post('/web/m/driver/search', {
    ...param
  });
}

// 获取临调司机
export function getHcbDriver(param) {
  return post('/web/m/hcb-driver/search', { ...param });
}

