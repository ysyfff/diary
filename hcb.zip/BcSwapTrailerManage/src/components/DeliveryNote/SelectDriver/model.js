import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
// import { tableFields } from '../fields';
// import { getRelateOrderList, getTruckList, getTrailerList, createOrder } from '../services';
import { getDriver, getHcbDriver } from './services';

export default Model.extend({
  namespace: 'selectDriver',
  state: {
    loading: { list: false },
    driverList: [],
    // hcbDriverList: []
  },
  subscriptions: {
    // setupSubscriber({ listen, dispatch }) {
    //   listen('/sendStation/pickup/add', ({ params }) => {
    //     // debugger
    //     dispatch({ type: 'pickupAdd/getTruckList', payload: { ps: 1000, ...params } });
    //     dispatch({ type: 'pickupAdd/getTrailerList', payload: { pn: 1, ps: 1000, ...params } });
    //   });
    // }
  },
  effects: {
    * getDriver({ payload }, { call, update }) {
      // debugger
      const { datas } = yield call(withLoading(getDriver, 'list'), { ...payload, ps: 500 });
      yield update({
        driverList: datas
      });
    },
    * getHcbDriver({ payload }, { call, update }) {
      const datas = yield call(withLoading(getHcbDriver, 'list'), { ...payload, ps: 500 });
      yield update({
        driverList: datas
      });
    },
  },
  reducers: {
    updateDriverList(state, { payload }) {
      return {
        ...state,
        driverList: payload
      };
    }
  }
});
