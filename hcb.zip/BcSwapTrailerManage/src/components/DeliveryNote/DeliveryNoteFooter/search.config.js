import CustomedTableForm from '../CustomedTableForm';
import tableFields from './tableFields';
import { REMARK_FORM_ITEM_LAYOUT } from '../deliveryNoteConsts';

const fields = [{
  key: 'pickUpDriver',
  el: {
    defaultValue: []
  },
  render: ({ form, ...props }) => (
    <CustomedTableForm
      {...props}
      title="调度信息"
      showOrder
      style={{ padding: '12px 6px' }}
      tableFields={tableFields.tableFormFields}
    />
  ),
}, {
  key: 'remark',
  label: '备注信息',
  el: {
    placeholder: '请输入备注信息',
    maxLength: 125
  },
  col: {
    span: 24
  },
  formItem: {
    props: REMARK_FORM_ITEM_LAYOUT
  }
}];

export default fields;
