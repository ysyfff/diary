import NP from 'number-precision';
import SelectDriver from 'components/DeliveryNote/SelectDriver';
import { Form } from 'antd';

const FormItem = Form.Item;

const tableFields = [{
  title: '费用名称',
  dataIndex: 'name',
  editable: true,
  align: 'center',
  width: '40%',
  fields: {
    type: 'input',
    props: {
      maxLength: 20,
      minLength: 1,
      placeholder: '请输入费用名称'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用名称'
      }]
    }
  }
}, {
  title: '费用金额',
  dataIndex: 'fee',
  editable: true,
  align: 'center',
  width: '30%',
  fields: {
    type: 'inputnumber',
    props: {
      precision: 2,
      min: 0.01,
      max: 99999.99,
      placeholder: '请输入费用金额'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用金额'
      }]
    }
  }
}];

const fields = [
  {
    title: '司机',
    dataIndex: 'driver',
    editable: false,
    columnsKey: true,
    align: 'center',
    width: '15%',
    fields: {
      render: ({ form, ...props }) => {
        const { getFieldDecorator } = form;
        return (
          <FormItem style={{ marginBottom: 0 }}>
            {getFieldDecorator('driver', {
              rules: [{
                required: true,
                message: '请选择司机'
              }]
            })(
              <SelectDriver
                disabled={props.disabled}
                nowStatus="SHORT"
                onConfirm={(driver) => {
                  setTimeout(() => {
                    const { truckId, truckPlateNumber } = driver;
                    form.setFieldsValue({
                      truck: (!truckId || !truckPlateNumber) ?
                        undefined : { key: truckId || '', label: truckPlateNumber || '' }
                    });
                  }, 0);
                }}
              />
            )}
          </FormItem>
        );
      },
      props: {
        placeholder: '请选择司机'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入体积！'
        }]
      }
    }
  },
  {
    title: '车头车牌',
    dataIndex: 'truck',
    editable: true,
    align: 'center',
    width: '15%',
    fields: {
      type: 'select',
      props: {
        placeholder: '请选择车牌',
        options: [],
        showSearch: true,
        optionFilterProp: 'children',
        labelInValue: true
      },
      validator: {
        rules: [{
          validator(rule, value, callback) {
            if (!value) {
              callback(['请选择车牌']);
              return;
            }
            const is = Object.values(value).some(val => !val);
            if (is) {
              callback(['请选择车牌']);
            } else {
              callback();
            }
          }
        }, { required: true, message: ' ' }]
      }
    }
  },
  {
    title: '运费',
    dataIndex: 'driverFee',
    editable: true,
    align: 'center',
    width: '15%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入运费'
      }
    }
  },
  {
    title: '其他费用',
    dataIndex: 'pickUpCreateDriverOtherFee',
    editable: true,
    align: 'center',
    fields: {
      type: 'extracost',
      props: {
        tableFields,
        modalProps: { title: '其他费用', width: 650 },
        calculateKey: 'fee',
        inputProps: {
          placeholder: '请添加其他费用'
        }
      }
    }
  },
  {
    title: '费用合计',
    dataIndex: 'sum',
    editable: false,
    align: 'center',
    width: '12%',
    fields: {
      render: ({ form }) => {
        let sum = 0.00;
        const { getFieldValue } = form;
        const cargoWeight = getFieldValue('driverFee') || 0;
        const yunfei = getFieldValue('pickUpCreateDriverOtherFee') || [];
        yunfei.forEach((value) => {
          sum = NP.plus(sum, (value.fee || 0));
        });
        return <span>{NP.plus(cargoWeight, sum)}</span>;
      }
    }
  },
];

export default {
  tableFormFields: fields,
  extraCostFields: tableFields
};
