import React from 'react';
import { Row } from 'antd';
import { createFormFields } from 'components/helper';

class DeliveryNoteFooter extends React.PureComponent {
  static defaultProps = {
    list: {}
  };

  componentWillReceiveProps = (nextProps) => {
    if (this.props.list !== nextProps.list) {
      this.props.helper.setFieldsValues(nextProps.list);
    }
  }

  render() {
    return (
      <Row>{this.props.children}</Row>
    );
  }
}

export default createFormFields()(DeliveryNoteFooter);
