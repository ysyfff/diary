import React from 'react';
import { Icon, Col, Row, Form, Divider } from 'antd';
import Address from './Address';

import styles from './index.less';

const FormItem = Form.Item;


const CARD_COL_ADDRESS_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 3 },
    xl: { span: 4 },
    lg: { span: 3 }
  },
  wrapperCol: {
    xxl: { span: 21 },
    xl: { span: 20 },
    lg: { span: 16 }
  }
};

class GoodsAddress extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      recordArray: [{}],
      flag: true
    };
  }

  componentWillReceiveProps = (nextProps) => {
    if (this.props.value !== nextProps.value) {
      this.setState({
        recordArray: nextProps.value.length === 0 ? [{}] : nextProps.value,
      });
    }
  }

  handleAdd = (e) => {
    e.preventDefault();
    const { recordArray } = this.state;
    this.setState({
      recordArray: recordArray.concat([{}])
    }, () => {
      this.handleSetFiledsError();
    });
  }

  handleSetFiledsError = () => {
    // 取第一个form
    const form = this.forms.address_0;
    // 判断form是否有错误信息
    const fieldsError = form.getFieldsError();
    const isError = Object.values(fieldsError).some(error => error);
    if (isError) form.validateFields({ force: true });
  }

  handleRemove = (e) => {
    e.preventDefault();
    const form = this.forms.address_0;
    const { getFieldsValue, getFieldsError } = form;
    // 在删除前判断form是否有错误信息
    const fieldsError = getFieldsError();
    const isError = Object.values(fieldsError).some(error => error);
    this.setState({
      recordArray: [getFieldsValue()].map(i => ({
        ...i,
        address: i.citypicker,
      }))
    }, () => {
      if (isError) form.validateFields({ force: true });
    });
  }

  changeForms = (key, form) => {
    if (form) {
      this.forms = { ...this.forms, [key]: form };
    } else {
      delete this.forms[key];
    }
  }

  render() {
    const { recordArray } = this.state;
    const {
      onSearch,
      onSelect,
      onSearchAddress,
      disabled = false,
      label = {}
    } = this.props;
    const length = recordArray.length;
    return (
      <Row className={styles['address-container']}>
        {recordArray.map((val, index) => {
          const key = `address_${index}`;
          if (index === 0) {
            return (
              <Col key={key} span={24}>
                <Address
                  disabled={disabled}
                  name={key}
                  value={val}
                  label={label}
                  onSearch={onSearch}
                  len={{ length, index }}
                  onSelect={onSelect}
                  changeForms={this.changeForms}
                  onSearchAddress={onSearchAddress}
                />
              </Col>
            );
          }
          return (
            <React.Fragment key={key}>
              <Divider style={{ display: 'inherit' }} />
              <Col key={key} span={24} style={{ marginTop: '5px' }}>
                <Address
                  disabled={disabled}
                  name={key}
                  value={val}
                  label={label}
                  len={{ length, index }}
                  onSearch={onSearch}
                  onSelect={onSelect}
                  changeForms={this.changeForms}
                  onSearchAddress={onSearchAddress}
                  required={false}
                />
              </Col>
            </React.Fragment>);
        })}
        { !disabled && (
          <Col span={24} className="add-plus-wrapper">
            <FormItem
              {...CARD_COL_ADDRESS_FORM_ITEM_LAYOUT}
              label=" "
              colon={false}
              style={{
                marginBottom: 0,
                lineHeight: 1.2,
                marginTop: '5px'
              }}
            >
              <a
                className="add-plus"
                onClick={recordArray.length === 2 ? this.handleRemove : this.handleAdd}
              >
                <Icon type={recordArray.length === 2 ? ' ' : 'plus'} />
                <span>{recordArray.length === 2 ? '删除地址2' : '添加地址'}</span>
              </a>
            </FormItem>
          </Col>
        )}
      </Row>
    );
  }
}

export default GoodsAddress;
