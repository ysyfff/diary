import React from 'react';
import { HInput } from 'components/helper';
import { Form, Col } from 'antd';
import { reginIdSplit } from 'utils';
import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';

import CityPicker from '../../helper/components/citypicker';

import styles from './address.less';

const FormItem = Form.Item;

const EL_COL_LAYOUT = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 12 },
  md: { span: 24 },
  sm: { span: 24 },
  xs: { span: 24 }
};

const CARD_COL2_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 6 },
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 16 },
    lg: { span: 16 },
  }
};

const CARD_COL_ADDRESS_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 2 },
    xl: { span: 2 },
    lg: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 22 },
    xl: { span: 22 },
    lg: { span: 16 }
  }
};

const shipCustomerFields = [
  {
    title: '发货联系人',
    dataIndex: 'contact',
    key: 'contact',
    width: 200,
  },
  {
    title: '联系电话',
    dataIndex: 'contactPhone',
    key: 'contactPhone',
    width: 200,
  }
];

const recCustomerFields = [
  {
    title: '收货联系人',
    dataIndex: 'contact',
    key: 'contact',
    width: 200,
  },
  {
    title: '联系电话',
    dataIndex: 'contactPhone',
    key: 'contactPhone',
    width: 200,
  }
];

const shipAddressFields = [
  {
    title: '行政区域',
    dataIndex: 'addressName',
    key: 'addressName',
    width: 200,
  },
  {
    title: '详细地址',
    dataIndex: 'address',
    key: 'address',
    width: 200,
  }
];

const isNullArray = value => Array.isArray(value) && value.length === 0;

const isEmptyValue = value => value === '' || value === undefined || value === null || isNullArray(value);

const validator = (key, form, value) => {
  const values = form.getFieldsValue();
  const valuesCopy = { ...values };
  const empty = isEmptyValue(value);
  delete values[key];
  const isValidate = Object.values(values).some(val => !isEmptyValue(val));
  if (isValidate && empty) {
    return true;
  }
  const isEmpty = Object.values(valuesCopy).every(val => isEmptyValue(val));
  if (empty && isEmpty) {
    form.setFieldsValue({
      contact: undefined,
      contactPhone: undefined,
      citypicker: undefined,
      addressDetail: undefined
    });
  }
  return false;
};

class Address extends React.PureComponent {
  componentDidMount() {
    const { form, name, changeForms } = this.props;
    changeForms(name, form);
  }

  componentDidUpdate(nextProps) {
    const { value } = this.props;
    if (this.props.value !== nextProps.value) {
      if (Object.keys(value).length === 0) {
        this.props.form.resetFields();
      } else {
        this.props.form.setFieldsValue({
          contact: value.contact,
          contactPhone: value.contactPhone,
          citypicker: value.address,
          addressDetail: value.addressDetail
        });
      }
    }
  }

  componentWillUnmount() {
    const { name, changeForms } = this.props;
    changeForms(name);
  }

  onSearchAddress = (value) => {
    const { onSearchAddress, form } = this.props;
    const { getFieldsValue } = form;
    const { citypicker = [] } = getFieldsValue();
    const {
      provinceId: province = '',
      cityId: city = '',
      countyId: county = ''
    } = citypicker.length > 0 && reginIdSplit(citypicker[0].id);
    return onSearchAddress(value, province, city, county);
  }

  // 获取正确的label
  getCurrentLabel = (label) => {
    // len记录数组长度，当前address组件index
    const { len: { length, index } } = this.props;
    if (length === 2) return `${label}${index + 1}`;
    return label;
  }

  getEl = () => {
    const {
      required = true,
      form,
      value,
      onSearch,
      disabled = false,
      label = {}
    } = this.props;
    const {
      placeholder = true
    } = label;
    const contactLabel = this.getCurrentLabel(label.contact || '联系人');
    const concatMessage = `请输入${contactLabel}`;
    const contactPhoneLable = this.getCurrentLabel(label.contactPhoneLable || '联系电话');
    const contactPhoneMessage = `请输入${contactPhoneLable}`;
    const citypickerLabel = this.getCurrentLabel(label.citypicker || '提货地址');
    return [{
      key: 'contact',
      label: contactLabel,
      type: 'autosearch',
      col: EL_COL_LAYOUT,
      props: {
        placeholder: placeholder ? concatMessage : '',
        onSearch,
        onSelect: this.selectPhone,
        inputKey: 'contact',
        columns: label.citypicker === '收货地址' ? recCustomerFields : shipCustomerFields,
        disabled,
        maxLength: 20
      },
      itemCol: CARD_COL2_FORM_ITEM_LAYOUT,
      fields: {
        initialValue: value.contact,
        rules: required ? [{
          required: true,
          message: concatMessage
        }] : [{
          validator(rule, value, callback) {
            const is = validator('contact', form, value);
            if (is) {
              callback([concatMessage]);
            } else {
              callback();
            }
          }
        }]
      }
    }, {
      key: 'contactPhone',
      label: contactPhoneLable,
      type: 'input',
      col: EL_COL_LAYOUT,
      props: {
        placeholder: placeholder ? contactPhoneMessage : '',
        disabled,
        maxLength: 20
      },
      itemCol: CARD_COL2_FORM_ITEM_LAYOUT,
      fields: {
        initialValue: value.contactPhone,
        rules: required ? [{
          required: true,
          message: contactPhoneMessage
        }] : [{
          validator(rule, value, callback) {
            const is = validator('contactPhone', form, value);
            if (is) {
              callback([contactPhoneMessage]);
            } else {
              callback([]);
            }
          }
        }]
      }
    }, {
      key: 'citypicker',
      label: citypickerLabel,
      type: 'citypicker',
      col: { span: 12 },
      props: {
        disabled,
        placeholder: placeholder ? '请选择地区' : ''
      },
      itemCol: {
        ...CARD_COL2_FORM_ITEM_LAYOUT,
        style: { marginBottom: 0 }
      },
      fields: {
        initialValue: value.address,
        rules: required ? [{
          required: true,
          message: '请选择省/市/区'
        }] : [{
          validator(rule, value, callback) {
            const is = validator('citypicker', form, value);
            if (is) {
              callback(['请选择省/市/区']);
            } else {
              callback();
            }
          }
        }]
      }
    }, {
      key: 'addressDetail',
      label: ' ',
      type: 'autosearch',
      col: { span: 12 },
      props: {
        disabled,
        placeholder: placeholder ? '请输入详细地址' : '',
        onSearch: this.onSearchAddress,
        onSelect: this.selectAddress,
        inputKey: 'address',
        columns: shipAddressFields,
        maxLength: 50
      },
      itemCol: {
        ...CARD_COL_ADDRESS_FORM_ITEM_LAYOUT,
        required,
        colon: false,
        style: { marginBottom: 0 }
      },
      fields: {
        initialValue: value.addressDetail,
        rules: required ? [{
          required: true,
          message: '请输入详细地址'
        }] : [{
          validator(rule, value, callback) {
            const is = validator('addressDetail', form, value);
            if (is) {
              callback(['请输入详细地址']);
            } else {
              callback();
            }
          }
        }]
      }
    }];
  }

  getInput = (element) => {
    const { props, type = 'input', render } = element;
    if (render) {
      const Component = element.render;
      return <Component {...props} />;
    }
    switch (type) {
      case 'input':
        return <HInput {...props} />;
      case 'citypicker':
        return <CityPicker {...props} />;
      case 'autosearch':
        return (<AutoSearchInput
          {...props}
          scrollX={false}
          isAllowInput
        />);
      default: return <HInput {...props} />;
    }
  }

  selectPhone = (value) => {
    if (value) {
      const { form } = this.props;
      const { setFieldsValue } = form;
      setFieldsValue({
        contactPhone: value.contactPhone
      });
    }
  }

  selectAddress = (value) => {
    if (value) {
      const { form } = this.props;
      const { setFieldsValue } = form;
      setFieldsValue({
        citypicker: value.addressCode
      });
    }
  }

  render() {
    const el = this.getEl();
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <div className={styles['address-row']}>
        {el.map((element) => {
          const {
            label,
            key,
            fields,
            col,
            itemCol
          } = element;
          return (
            <Col
              key={key}
              {...col}
              className="address-col"
            >
              <FormItem
                key={key}
                label={label}
                {...itemCol}
              >
                {getFieldDecorator(key, {
                  ...fields
                })(this.getInput(element))}
              </FormItem>
            </Col>
          );
        })}
      </div>
    );
  }
}

export default Form.create()(Address);
