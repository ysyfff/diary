import { Input, InputNumber, Form } from 'antd';
import { HSelect, SelectEllipsis } from 'components/helper';
import { Type } from 'carno/utils';
import ExtraCostInput from '../../ExtraCostInput';
import EditableContext from './EditableContext';

const FormItem = Form.Item;


class EditableCell extends React.PureComponent {
  getInput = (extraProps) => {
    const { type, fields, dataIndex } = this.props;
    const props = { ...fields.props, ...(extraProps[dataIndex] || {}) };

    switch (type) {
      case 'input':
        return <Input {...props} />;
      case 'inputnumber':
        return <InputNumber {...props} />;
      case 'select':
        return <HSelect {...props} />;
      case 'selectellipsis':
        return <SelectEllipsis {...props} />;
      case 'extracost':
        return <ExtraCostInput {...props} />;
      default:
        return <Input {...props} />;
    }
  };

  render() {
    const {
      editing,
      dataIndex,
      record,
      disabledIdKeys,
      fields = {},
      extraProps,
      showAction,
      ...restProps
    } = this.props;
    const props = fields.props || {};
    if ((!showAction && props.disabled) || (record.id && disabledIdKeys.includes(dataIndex))) {
      props.disabled = true;
    } else {
      props.disabled = false;
    }
    return (
      <EditableContext.Consumer>
        {({ form, extraProps }) => {
          const { getFieldDecorator } = form;
          const { render } = fields;
          let Component = null;
          if (render && Type.isFunction(render)) {
            Component = render;
          }
          Component = Component ? <Component form={form} {...fields.props} /> : restProps.children;
          return (
            <td
              {...restProps}
              // title={dataIndex}
            >
              {editing ? (
                <FormItem style={{ margin: 0 }}>
                  {getFieldDecorator(dataIndex, {
                    ...fields.validator
                  })(this.getInput(extraProps))}
                </FormItem>
              ) : Component}
            </td>
          );
        }}
      </EditableContext.Consumer>
    );
  }
}

export default EditableCell;
