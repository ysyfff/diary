import { EllipsisRecord } from 'components';

const fields = [{
  key: 'driver',
  name: '司机',
  width: 180,
  render: record => <EllipsisRecord record={record} width={180} />
}, {
  key: 'truck',
  name: '车头车牌',
  width: 120,
  render: record => <EllipsisRecord record={record} width={120} />
}, {
  key: 'driverFee',
  name: '运费',
  width: 120,
  render: record => <EllipsisRecord record={record} width={120} />
}, {
  key: 'pickUpCreateDriverOtherFee',
  name: '其他费用',
  width: 400,
  render: record => <EllipsisRecord popoverStyle={{ width: '420px' }} record={record} row={2} />
}, {
  key: 'sum',
  name: '费用合计',
  width: 120,
  render: record => <EllipsisRecord record={record} width={120} />
}];

export default fields;
