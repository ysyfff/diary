import React from 'react';
import { Row } from 'antd';
import { createFormFields } from 'components/helper';

class DeliveryNoteHeader extends React.PureComponent {
  render() {
    return (
      <Row>{this.props.children}</Row>
    );
  }
}

export default createFormFields()(DeliveryNoteHeader);
