const COL = {
  xxl: { span: 8 },
  xl: { span: 8 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const fields = [{
  key: 'waybillNos',
  label: '关联运单',
  col: { ...COL },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  }
}, {
  key: 'business',
  label: '主营服务',
  type: 'select',
  col: { ...COL },
  el: {
    placeholder: '请选择主营服务',
    options: []
  },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  }
}, {
  key: 'sx',
  label: '产品时效',
  type: 'select',
  col: { ...COL },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  },
  el: {
    placeholder: '请选择产品时效',
    options: []
  }
}];

export default fields;
