import React from 'react';

const ExtraCostContext = React.createContext();

export default ExtraCostContext;
