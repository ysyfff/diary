import React from 'react';
import { Form } from 'antd';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';

class EditableRow extends React.Component {
  componentWillMount() {
    this.changeFormsByType('add');
  }

  shouldComponentUpdate(nextProps) {
    return this.props.fields !== nextProps.fields;
  }

  componentWillUnmount() {
    this.changeFormsByType('delete');
  }

  changeFormsByType = (type) => {
    const key = this.props['data-row-key'];
    const { changeForms, form } = this.props;
    // 新增form
    if (type === 'add') {
      changeForms(key, form);
    } else if (type === 'delete') {
      changeForms(key);
    }
  }

  render() {
    const {
      form,
      index,
      changeForms,
      onFieldsChange,
      onValuesChange,
      calculateKey,
      ...props
    } = this.props;
    return (
      <EditableContext.Provider value={{ form, index }}>
        <tr {...props} />
      </EditableContext.Provider>
    );
  }
}

const EditableFormRow = Form.create({
  onFieldsChange(props, changedFields) {
    const { onFieldsChange } = props;
    const key = props['data-row-key'];
    onFieldsChange && onFieldsChange(changedFields, key);
  },
  onValuesChange(props, changedValues) {
    const { onValuesChange } = props;
    const key = props['data-row-key'];
    onValuesChange && onValuesChange(changedValues, key);
  },
  mapPropsToFields(props) {
    if (props.fields) return props.fields;
    return {};
  }
})(EditableRow);

const EditableFormRowWrapper = props => (
  <ExtraCostContext.Consumer>
    {({
      onValuesChange,
      onFieldsChange,
      changeForms,
      fields,
      calculateKey
    }) => {
      const key = props['data-row-key'];
      return (
        <EditableFormRow
          {...props}
          onFieldsChange={onFieldsChange}
          onValuesChange={onValuesChange}
          fields={fields[key]}
          changeForms={changeForms}
          calculateKey={calculateKey}
        />
      );
    }}
  </ExtraCostContext.Consumer>
);

export default EditableFormRowWrapper;

