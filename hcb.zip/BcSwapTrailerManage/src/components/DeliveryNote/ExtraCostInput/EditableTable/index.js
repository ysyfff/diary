import React from 'react';
import { Table, Button, Tooltip } from 'antd';
import { EllipsisRecord } from 'components';
import NP from 'number-precision';
import { Type } from 'carno/utils';
import EditableFormRow from './EditableFormRow';
import EditableCell from './EditableCell';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';

import styles from './index.less';

const EmptyText = props => (
  <Button
    style={{ width: '100%' }}
    onClick={props.onAdd}
    type="dashed"
    icon="plus"
  >添加
  </Button>
);


const isRequired = (fields) => {
  const { validator } = fields;
  if (!validator || (validator && !validator.rules)) {
    return false;
  }
  const { rules } = validator;
  return rules.some(rule => rule.required === true);
};

const RequiredTitle = ({ title }) => (
  <span
    className="ant-form-item-required"
  >
    {title}
  </span>
);

class EditableTable extends React.PureComponent {
  constructor(props) {
    super(props);
    // 保存表单对象
    this.columns = [{
      title: '操作',
      dataIndex: 'operation',
      align: 'center',
      width: '30%',
      render: (text, record) => (
        <EditableContext.Consumer>
          {({ form }) => {
            this.form = { ...this.form, [record.key]: form };
            return (
              <div style={{ padding: '9px 0' }}>
                <span>
                  <ExtraCostContext.Consumer>
                    {({ dataSource }) => (
                      <a
                        onClick={this.handleDelete(dataSource, record.key)}
                        style={{ marginRight: 8 }}
                      >
                        移除
                      </a>
                    )}
                  </ExtraCostContext.Consumer>
                  <ExtraCostContext.Consumer>
                    {({ dataSource }) => (
                      <React.Fragment>
                        {
                          dataSource.length >= this.props.maxRows &&
                          (<Tooltip
                            title={this.props.maxRowsTips}
                            placement="top"
                            trigger="click"
                          >
                            <a>添加</a>
                          </Tooltip>)
                        }
                        {
                          dataSource.length < this.props.maxRows &&
                            (<a onClick={this.handleAdd(dataSource, record.key)}>添加</a>)
                        }
                      </React.Fragment>

                    )}
                  </ExtraCostContext.Consumer>
                </span>
              </div>
            );
          }}
        </EditableContext.Consumer>
      )
    }];
  }

  onRow = changeElKeyMap => (record, index) => {
    const { key } = record;
    changeElKeyMap({ key, index });
  }

  // 移除表格一条记录
  handleDelete = (dataSource, key) => () => {
    const nextDataSouce = [...dataSource];
    const { changeDataSource, deleteRow } = this.props;
    changeDataSource(nextDataSouce.filter(item => item.key !== key));
    deleteRow(key);
  }

  // 新增一条数据
  handleAdd = (dataSource, key) => (e) => {
    e.persist();
    const { changeDataSource } = this.props;
    // 拷贝dataSource
    const copyDataSource = [...dataSource];
    // 获取对应key在数组中的位置
    let position = 0;
    // 获取最大index值
    let maxIndex = copyDataSource[0].index;
    for (let index = 0; index < copyDataSource.length; index += 1) {
      const data = copyDataSource[index];
      if (data.index > maxIndex) {
        maxIndex = data.index;
      }
      if (data.key === key) {
        position = index;
      }
    }
    maxIndex += 1;
    const _key = `record-${maxIndex}`;
    const addValue = {
      key: _key,
      index: maxIndex
    };
    copyDataSource.splice(position + 1, 0, addValue);
    changeDataSource(copyDataSource, _key, position + 1);
    // 更新form, 并将滚动条置底
    this.timer = setTimeout(() => {
      try {
        // 调整表格视图
        const rows = document.querySelectorAll('.__delivery-cost-editable-row');
        rows[position].scrollIntoView();
      } catch (e) {
        if (e) { clearTimeout(this.timer); }
      }
      clearTimeout(this.timer);
    }, 0);
  }

  // 添加一条新的费用信息
  handleNew = () => {
    const { changeDataSource } = this.props;
    changeDataSource([{ key: 'record-1', index: 1 }]);
  }
  // 渲染table footer
  footerRender = (values, dataSource) => () => {
    let sum = 0.00;
    const { calculateKey } = this.props;
    values.forEach((value) => {
      let calculateValue = window.parseFloat(value[calculateKey] || 0);
      calculateValue = window.isNaN(calculateValue) ? 0 : calculateValue;
      sum = NP.plus(sum, (calculateValue));
    });
    return (
      <React.Fragment>
        {dataSource.length > 0 ? (
          <div className="cost-footer">
            <ul className="cost-footer-list">
              <li className="cost-item cost-all">
                <p>合计</p>
              </li>
              <li className="cost-item cost-amount">
                <EllipsisRecord record={sum.toFixed(2)} width={167} />
              </li>
              <li className="cost-item cost-empty" />
            </ul>
          </div>
        ) : null}
      </React.Fragment>
    );
  }

  render() {
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell
      }
    };
    const { tableFields = [] } = this.props;
    return (
      <ExtraCostContext.Consumer>
        {({ value, dataSource, changeElKeyMap }) => {
          const { footerRender } = this.props;
          // table footer
          const footer = (footerRender && footerRender(value, dataSource)) ||
            this.footerRender(value, dataSource);
          const columns = tableFields.concat(this.columns).map((col) => {
            const { fields = {}, dataIndex, title } = col;
            const required = isRequired(fields);
            col.title = required && Type.isString(title) ? <RequiredTitle title={title} /> : title;
            if (!col.editable) {
              return col;
            }

            return {
              ...col,
              onCell: record => ({
                record,
                type: col.fields.type || 'input',
                dataIndex,
                fields: col.fields,
                editing: true
              }),
            };
          });
          return (
            <React.Fragment>
              <Table
                className={styles['delivery-cost-table']}
                components={components}
                rowClassName={() => '__delivery-cost-editable-row'}
                dataSource={dataSource}
                columns={columns}
                onRow={this.onRow(changeElKeyMap)}
                pagination={false}
                locale={{ emptyText: <EmptyText onAdd={this.handleNew} /> }}
                footer={footer}
                scroll={{ y: 200 }}
              />
            </React.Fragment>
          );
        }}
      </ExtraCostContext.Consumer>
    );
  }
}

export default EditableTable;
