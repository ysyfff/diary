import { Input, InputNumber, Form } from 'antd';
import EditableContext from './EditableContext';

const FormItem = Form.Item;

class EditableCell extends React.PureComponent {
  getInput = () => {
    const { type, fields } = this.props;
    switch (type) {
      case 'input':
        return <Input {...fields.props} />;
      case 'inputnumber':
        return <InputNumber {...fields.props} />;
      default:
        return <Input {...fields.props} />;
    }
  };

  render() {
    const {
      editing,
      dataIndex,
      record,
      fields,
      ...restProps
    } = this.props;
    return (
      <EditableContext.Consumer>
        {({ form }) => {
          const { getFieldDecorator } = form;
          return (
            <td {...restProps}>
              {editing ? (
                <FormItem style={{ margin: 0 }}>
                  {getFieldDecorator(dataIndex, {
                    ...fields.validator,
                    initialValue: record[dataIndex],
                  })(this.getInput())}
                </FormItem>
              ) : restProps.children}
            </td>
          );
        }}
      </EditableContext.Consumer>
    );
  }
}

export default EditableCell;
