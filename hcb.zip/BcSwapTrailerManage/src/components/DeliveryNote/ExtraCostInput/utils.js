const format = (values, columnsKeys) => {
  const valuesStr = values.map((value) => {
    const valueStr = columnsKeys.map(column => value[column]);
    return valueStr.join('：');
  });
  return valuesStr.join('；');
};

export {
  format
};
