/**
 * @author yang.huang3
 * @description 其他费用组件
 * @since 2018.09.13
 */
import React from 'react';
import { Input } from 'antd';
import { Form } from 'antd';
import { _ } from 'carno/third-party';
import { Type } from 'carno/utils';
import DeliveryModal from './DeliveryModal';
import ExtraCostContext from './ExtraCostContext';
import { format } from './utils';

const resolveValueToDatasource = (values, columnsKeys) => {
  if (!Type.isArray(values)) throw new Error('value must be array');
  const fields = {};
  if (values.length === 0) {
    return {
      dataSource: [{ key: 'record-1', index: 1 }],
      fields
    };
  }
  const dataSource = values.map((value, index) => {
    const order = index + 1;
    const key = `record-${order}`;
    fields[key] = {};
    columnsKeys.forEach((columnsKey) => {
      fields[key][columnsKey] = Form.createFormField({ value: value[columnsKey] || undefined });
    });
    return {
      key,
      index: order
    };
  });
  return {
    dataSource,
    fields
  };
};

const getColumnsKeys = (tableFields) => {
  const keys = [];
  tableFields.forEach((field) => {
    const { editable, dataIndex } = field;
    if (editable) keys.push(dataIndex);
  });
  return keys;
};

class ExtraCostInput extends React.Component {
  static defaultProps = {
    tableFields: [],
    maxRows: 5,
    maxRowsTips: '已达到最大添加条数',
    modalTitle: '',
  };

  constructor(props) {
    super(props);
    const { tableFields } = props;
    const columnsKeys = getColumnsKeys(tableFields);
    const value = props.value || [];
    const result = resolveValueToDatasource(value, columnsKeys);
    const { dataSource, fields } = result;
    this.state = {
      value, // form表单value
      output: value, // form表单像外输出值
      inputValue: format(value, columnsKeys), // 输入框value
      visible: Symbol('visible'),
      forms: {},
      columnsKeys,
      dataSource,
      fields,
      prevValue: value, // 上一个value
      prevFields: fields, // 上一个fields状态
      prevDataSource: dataSource, // 上一个dataSource状态
    };
    this.elKeyMap = {};
  }

  componentWillReceiveProps = (nextProps) => {
    const { value = [] } = nextProps;
    const { columnsKeys, output } = this.state;
    // 去除空对象
    let copyOutput = [...output];
    copyOutput = copyOutput.filter(value => Object.keys(value).length !== 0);
    if (!_.isEqual(value, copyOutput)) {
      const { dataSource, fields } = resolveValueToDatasource(value, columnsKeys);
      this.setState({
        dataSource,
        fields,
        prevDataSource: dataSource,
        prevFields: fields,
        output: value,
        value,
        prevValue: value,
        inputValue: format(value, columnsKeys)
      });
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    const { visible, fields, dataSource, forms, inputValue } = this.state;
    return visible !== nextState.visible ||
      inputValue !== nextState.inputValue ||
      fields !== nextState.fields ||
      dataSource !== nextState.dataSource ||
      forms !== nextState.forms;
  }

  onFieldsChange = (changedFields, key) => {
    const keys = Object.keys(changedFields || {});
    if (keys.length === 0) return;
    const changed = {};
    keys.forEach((key) => {
      changed[key] = Form.createFormField(changedFields[key]);
    });
    this.setState(({ fields }) => ({
      fields: {
        ...fields,
        [key]: { ...fields[key], ...changed }
      }
    }));
  }

  onValuesChange = (changedValues, key) => {
    const { onChange } = this.props;
    const { output } = this.state;
    let copyOutput = [...output];
    const index = this.elKeyMap[key];
    copyOutput[index] = { ...copyOutput[index], ...changedValues };
    const _output = copyOutput.filter(value => Object.keys(value).length !== 0);
    this.setState({ value: _output, output: copyOutput }, () => {
      onChange && onChange(_output);
      copyOutput = null;
    });
  }

  // 更新forms
  changeForms = (key, form) => {
    const { forms } = this.state;
    let copyForms = { ...forms };
    if (form) {
      // 新增
      copyForms = { ...copyForms, [key]: form };
    } else if (key in copyForms) delete copyForms[key];
    this.setState({ forms: copyForms });
  }

  changeElKeyMap = ({ key, index }) => {
    this.elKeyMap = { ...this.elKeyMap, [key]: index };
  }

  deleteRow = (key) => {
    const { onChange } = this.props;
    const { output, fields } = this.state;
    const copyOutput = [...output];
    const copyFields = { ...fields };
    if (key in copyFields) delete copyFields[key];
    if (key in this.elKeyMap) {
      const index = this.elKeyMap[key];
      copyOutput.splice(index, 1);
      delete this.elKeyMap[key];
    }
    const _output = copyOutput.filter(value => Object.keys(value).length !== 0);
    this.setState({
      fields: copyFields,
      output: copyOutput,
      value: _output
    }, () => {
      onChange && onChange(_output);
    });
  }

  // 输入框点击事件
  handleClick = () => {
    this.setState(({ dataSource }) => ({
      visible: Symbol('visible'),
      dataSource: dataSource.length === 0 ? [{ key: 'record-1', index: 1 }] : dataSource
    }));
  }
  // 更新dataSource
  changeDataSource = (dataSource, key, index) => {
    const { output } = this.state;
    const copyOutput = [...output];
    // 新增列
    if (key && index) {
      copyOutput.splice(index, 0, {});
      this.setState({ output: copyOutput });
    }
    this.setState({ dataSource });
  }

  // 当点击ok按钮时
  handleClickOkButton = ({
    inputValue,
    prevValue,
    prevFields,
    prevDataSource
  }) => {
    this.setState({
      inputValue,
      prevValue,
      prevFields,
      prevDataSource
    });
  }

  // 当点击ok按钮时
  handleClickCancelButton = ({
    prevValue,
    prevFields,
    prevDataSource
  }) => {
    this.setState({
      value: prevValue,
      fields: prevFields,
      dataSource: prevDataSource
    }, () => {
      const { onChange } = this.props;
      onChange && onChange(prevValue);
    });
  }

  render() {
    const {
      visible,
      dataSource,
      forms,
      fields,
      value,
      inputValue,
      prevFields,
      prevDataSource,
      columnsKeys,
      prevValue
    } = this.state;
    const {
      inputProps,
      ...restProps
    } = this.props;
    return (
      <div>
        <Input
          readOnly
          onClick={this.handleClick}
          value={inputValue}
          {...inputProps}
        />
        <ExtraCostContext.Provider
          value={{
            dataSource,
            forms,
            columnsKeys,
            onFieldsChange: this.onFieldsChange,
            onValuesChange: this.onValuesChange,
            changeForms: this.changeForms,
            changeElKeyMap: this.changeElKeyMap,
            fields,
            prevFields,
            prevDataSource,
            prevValue,
            value,
            calculateKey: restProps.calculateKey
          }}
        >
          <DeliveryModal
            {...restProps}
            visible={visible}
            columnsKeys={columnsKeys}
            changeDataSource={this.changeDataSource}
            deleteRow={this.deleteRow}
            handleClickOkButton={this.handleClickOkButton}
            handleClickCancelButton={this.handleClickCancelButton}
          />
        </ExtraCostContext.Provider>
      </div>
    );
  }
}

export default ExtraCostInput;
