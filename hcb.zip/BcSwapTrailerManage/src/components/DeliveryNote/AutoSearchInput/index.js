import React from 'react';
import { Table } from 'antd';
import { debounce } from 'lodash';
import { HInput } from 'components/helper';
import { companyFields, historyCompanyFields, recCompanyFields } from '../../../pages/OrderManage/Order/fields';
import styles from './index.less';

class AutoSearchInput extends React.PureComponent {
  static defaultProps = {
    dataLength: 10,
    defaultSearchValue: '',
    isAllowInput: false,
    scrollX: 1600
  };

  static getDerivedStateFromProps = nextProps => ({
    value: nextProps.value
  });

  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
      value: props.value,
      dataSource: [],
      isSelectResult: false
    };
    this.debounceRequest = debounce(this.debounceChange, 300);
  }

  componentDidMount() {
    window.addEventListener('click', this.handleClickOutside, false);
  }

  componentWillUnmount() {
    window.removeEventListener('click', this.handleClickOutside, false);
  }

  handleClickOutside = () => {
    this.setState({
      visible: false
    });
  }

  handleRow = record => ({
    onClick: () => {
      const { onChange, inputKey, onSelect } = this.props;
      const value = record[inputKey];
      if (record) {
        onChange && onChange(value, record);
        onSelect && onSelect(record);
        this.setState({
          visible: false,
          value,
          isSelectResult: true
        });
      }
    }
  })

  handleChange = (e) => {
    const { onChange, onSelect } = this.props;
    const value = e ? e.target.value : e;
    onChange && onChange(value);
    if (!value) onSelect && onSelect(null);
    this.setState({
      value,
      isSelectResult: false
    },
    () => {
      this.debounceRequest();
    });
  }

  debounceChange = async () => {
    const { onSearch, defaultSearchValue } = this.props;
    const { value } = this.state;
    this.setState({
      visible: false,
      loading: true
    });
    if (onSearch) {
      const dataSource = await onSearch(value || defaultSearchValue);
      this.setState({
        visible: true,
        loading: false,
        dataSource
      });
    }
  }

  handleBlur = () => {
    let val;
    this.timer = setTimeout(() => {
      const { isAllowInput, onChange, onSelect } = this.props;
      const { isSelectResult, value } = this.state;
      if (isAllowInput) {
        val = value;
      } else {
        val = isSelectResult ? value : '';
      }
      this.setState({
        visible: false,
        value: val
      }, () => {
        if (!isSelectResult) onSelect && onSelect(null);
        onChange && onChange(val);
        clearTimeout(this.timer);
      });
    }, 300);
  }

  handleClick = async () => {
    const { onSearch } = this.props;
    this.setState({
      visible: true,
      loading: true
    });
    if (onSearch) {
      this.debounceRequest();
    }
  }

  render() {
    const {
      columns,
      dropDownTableWidth,
      dataLength,
      placeholder,
      inputKey,
      disabled = false,
      scrollX,
      maxLength,
      type
    } = this.props;
    const { visible, loading, value, dataSource } = this.state;

    // 临时解决临时客户切换问题
    let columnDatas = [];
    if (inputKey === 'shipCompanyName') {
      columnDatas = historyCompanyFields;
    } else if (inputKey === 'companyName') {
      if (type === 'rec') {
        columnDatas = recCompanyFields;
      } else {
        columnDatas = companyFields;
      }
    } else {
      columnDatas = columns;
    }

    // 截取dataSource
    let datas = [...dataSource];
    if (dataSource.length >= dataLength) {
      datas = datas.slice(0, 8);
    }
    const width = dropDownTableWidth && !window.isNaN(dropDownTableWidth) ?
      `${dropDownTableWidth}px` : '100%';
    return (
      <React.Fragment>
        <div className={styles['auto-search-input']}>
          <HInput
            disabled={disabled}
            placeholder={placeholder}
            value={value}
            onChange={this.handleChange}
            ref={input => this.input = input}
            onBlur={this.handleBlur}
            onClick={this.handleClick}
            autoComplete="off"
            maxLength={maxLength}
          />
          <div
            className="wrapper-table-content"
            style={{
              width: `${width}`,
              display: visible ? 'block' : 'none'
            }}
          >
            <Table
              rowKey={() => Number(Math.random().toString().substr(3) + Date.now()).toString(36)}
              onRow={this.handleRow}
              pagination={false}
              loading={loading}
              columns={columnDatas}
              dataSource={datas}
              scroll={{ x: scrollX }}
              bordered
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default AutoSearchInput;
