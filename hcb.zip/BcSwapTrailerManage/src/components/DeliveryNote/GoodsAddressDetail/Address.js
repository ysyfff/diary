import React from 'react';
import { Form, Input, Col } from 'antd';

import styles from './address.less';

const FormItem = Form.Item;

const EL_COL_LAYOUT = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 12 }
};

const CARD_COL2_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 16 },
    lg: { span: 16 }
  }
};

const CARD_COL_ADDRESS_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 2 },
    xl: { span: 2 },
    lg: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 22 },
    xl: { span: 22 },
    lg: { span: 16 }
  }
};

class Address extends React.PureComponent {
  getInput = (element) => {
    const { props, type = 'input', render } = element;
    if (render) {
      const Component = element.render;
      return <Component {...props} />;
    }
    switch (type) {
      case 'input':
        return <Input {...props} />;
      default: return <Input {...props} />;
    }
  }

  getCurrentLabel = (label) => {
    // len记录数组长度，当前address组件index
    const { len: { length, index } } = this.props;
    if (length === 2) return `${label}${index + 1}`;
    return label;
  }

  getEl = () => {
    const { value, label } = this.props;
    return [{
      key: 'contact',
      label: this.getCurrentLabel('联系人'),
      type: 'autosearch',
      col: EL_COL_LAYOUT,
      props: {
        disabled: true,
      },
      itemCol: CARD_COL2_FORM_ITEM_LAYOUT,
      fields: {
        initialValue: value.contact
      }
    }, {
      key: 'contactPhone',
      label: this.getCurrentLabel('联系电话'),
      type: 'input',
      col: EL_COL_LAYOUT,
      props: {
        disabled: true,
      },
      itemCol: CARD_COL2_FORM_ITEM_LAYOUT,
      fields: {
        initialValue: value.contactPhone
      }
    }, {
      key: 'address',
      label: this.getCurrentLabel(label.address || '提货地址'),
      type: 'address',
      col: { span: 12 },
      props: {
        disabled: true,
      },
      itemCol: {
        ...CARD_COL2_FORM_ITEM_LAYOUT,
        style: { marginBottom: 0 }
      },
      fields: {
        initialValue: value.address
      }
    }, {
      key: 'addressDetail',
      label: ' ',
      type: 'autosearch',
      col: { span: 12 },
      props: {
        disabled: true,
      },
      itemCol: {
        ...CARD_COL_ADDRESS_FORM_ITEM_LAYOUT,
        required: false,
        colon: false,
        style: { marginBottom: 0 }
      },
      fields: {
        initialValue: value.addressDetail
      }
    }];
  }
  render() {
    const el = this.getEl();
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <div className={styles['address-row']}>
        {el.map((element) => {
          const {
            label,
            key,
            fields,
            col,
            itemCol
          } = element;
          return (
            <Col
              key={key}
              {...col}
              className="address-col"
            >
              <FormItem
                key={key}
                label={label}
                {...itemCol}
              >
                {getFieldDecorator(key, {
                  ...fields
                })(this.getInput(element))}
              </FormItem>
            </Col>
          );
        })}
      </div>
    );
  }
}

export default Form.create()(Address);
