import React from 'react';
import { Col, Row, Divider } from 'antd';
import Address from './Address';

import styles from './index.less';

class GoodsAddress extends React.PureComponent {
  render() {
    const { value, label = {} } = this.props;
    const length = (value || []).length;
    return (
      <Row className={styles['address-container']}>
        {value.map((val, index) => {
          const key = `address_${index}`;
          if (index === 0) {
            return (
              <Col key={key} span={24}>
                <Address
                  name={key}
                  value={val}
                  label={label}
                  len={{ length, index }}
                />
              </Col>
            );
          }
          return (
            <React.Fragment>
              <Divider style={{ display: 'inherit' }} />
              <Col key={key} span={24} className="mt10">
                <Address
                  name={key}
                  value={val}
                  label={label}
                  len={{ length, index }}
                />
              </Col>
            </React.Fragment>
          );
        })}
      </Row>
    );
  }
}

export default GoodsAddress;
