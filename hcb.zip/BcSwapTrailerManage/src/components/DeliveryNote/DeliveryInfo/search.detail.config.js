import { EL_COL_LAYOUT, CARD_COL2_FORM_ITEM_LAYOUT, CARD_COL1_FORM_ITEM_LAYOUT } from '../deliveryNoteConsts';

const fields = [{
  key: 'deliveryTime',
  label: '送货时间',
  col: { ...EL_COL_LAYOUT },
  el: {
    disabled: true
  },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'plateNumber',
  label: '送货挂车',
  el: {
    disabled: true
  },
  col: { ...EL_COL_LAYOUT },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'companyName',
  label: '收货公司',
  col: { span: 24 },
  formItem: {
    props: { ...CARD_COL1_FORM_ITEM_LAYOUT }
  },
  el: {
    placeholder: '请输入收货公司',
    disabled: true
  }
}
];

export default fields;
