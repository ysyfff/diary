import { boxType, transform2Object } from 'configs/constants';
import { EllipsisRecord } from 'components';

const _boxType = transform2Object(boxType);

const fields = [{
  key: 'cargoName',
  name: '货物品名',
  width: 140,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoPiece',
  name: '件数',
  width: 100,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  key: 'cargoWeight',
  name: '重量（千克）',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoVolume',
  name: '体积（方）',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoList',
  name: '随货清单',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoPackage',
  name: '包装',
  width: 120,
  render: record => <EllipsisRecord record={record ? _boxType[record] || '--' : '--'} row={2} />
}];

export default fields;
