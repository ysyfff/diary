import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';
import { EL_COL_LAYOUT, CARD_COL2_FORM_ITEM_LAYOUT, CARD_COL1_FORM_ITEM_LAYOUT } from '../deliveryNoteConsts';

const columns = [{
  title: '发货公司',
  dataIndex: 'shipCompanyName',
}];

const fields = [{
  key: 'pickUpTime',
  label: '提货时间',
  type: 'datepicker',
  col: { ...EL_COL_LAYOUT },
  el: {
    showTime: true,
    format: 'YYYY-MM-DD HH:mm'
  },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请选择提货时间'
      }]
    }
  }
}, {
  key: 'plateNumber',
  label: '提货挂车',
  type: 'select',
  el: {
    placeholder: '请选择提货挂车',
    showSearch: true,
    optionFilterProp: 'children',
    labelInValue: true
  },
  col: { ...EL_COL_LAYOUT },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        validator(rule, value, callback) {
          if (!value) {
            callback(['请选择提货挂车']);
            return;
          }
          const is = Object.values(value).some(val => !val);
          if (is) {
            callback(['请选择提货挂车']);
          } else {
            callback();
          }
        }
      }, { required: true, message: ' ' }]
    }
  }
}, {
  key: 'companyName',
  label: '发货公司',
  col: { span: 24 },
  formItem: {
    props: {
      ...CARD_COL1_FORM_ITEM_LAYOUT
    },
    options: {
      rules: [{
        required: true,
        message: '请输入发货公司'
      }]
    }
  },
  el: {
    placeholder: '请输入发货公司',
    maxLength: 50
  },
  render: ({ form, ...props }) => (
    <AutoSearchInput
      {...props}
      columns={columns}
      isAllowInput
      scrollX={false}
      inputKey="shipCompanyName"
    />
  )
}
];

export default fields;
