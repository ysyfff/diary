import { EL_COL_LAYOUT, CARD_COL2_FORM_ITEM_LAYOUT, CARD_COL1_FORM_ITEM_LAYOUT } from '../deliveryNoteConsts';

const fields = [{
  key: 'pickUpTime',
  label: '提货时间',
  col: { ...EL_COL_LAYOUT },
  el: {
    disabled: true
  },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'plateNumber',
  label: '提货挂车',
  el: {
    disabled: true
  },
  col: { ...EL_COL_LAYOUT },
  formItem: {
    props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'companyName',
  label: '发货公司',
  col: { span: 24 },
  formItem: {
    props: { ...CARD_COL1_FORM_ITEM_LAYOUT }
  },
  el: {
    placeholder: '请输入发货公司',
    disabled: true
  }
}
];

export default fields;
