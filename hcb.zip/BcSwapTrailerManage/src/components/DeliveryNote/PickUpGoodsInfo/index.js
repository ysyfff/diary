import { newBoxType } from 'configs/constants';

const goodsFields = [
  {
    title: '货物品名',
    dataIndex: 'cargoName',
    editable: true,
    align: 'center',
    width: '15%',
    fields: {
      type: 'input',
      props: {
        maxLength: 10,
        minLength: 1,
        placeholder: '请输入货物品名！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入货物品名！'
        }]
      }
    }
  },
  {
    title: '件数',
    dataIndex: 'cargoPiece',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        min: 1,
        max: 10000,
        placeholder: '请输入件数！'
      }
    }
  },
  {
    title: '重量（千克）',
    dataIndex: 'cargoWeight',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入重量！'
      }
    }
  },
  {
    title: '体积（方）',
    dataIndex: 'cargoVolume',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入体积！'
      }
    }
  },
  {
    title: '随货清单',
    dataIndex: 'cargoList',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        max: (10 ** 3) - 1,
        placeholder: '请输入清单！'
      },
    }
  },
  {
    title: '包装',
    dataIndex: 'cargoPackage',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'selectellipsis',
      props: {
        popoverStyle: { maxWidth: '100px' },
        ellipsis: true,
        optionLabelProp: 'label',
        placeholder: '请选择包装！',
        options: newBoxType
      }
    }
  }
];

const goodsDisabledFields = [
  {
    title: '货物品名',
    dataIndex: 'cargoName',
    editable: true,
    align: 'center',
    width: '15%',
    fields: {
      type: 'input',
      props: {
        disabled: true
      },
      validator: {
        rules: [{
          required: true
        }]
      }
    }
  },
  {
    title: '件数',
    dataIndex: 'cargoPiece',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        disabled: true
      }
    }
  },
  {
    title: '重量（千克）',
    dataIndex: 'cargoWeight',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        disabled: true
      }
    }
  },
  {
    title: '体积（方）',
    dataIndex: 'cargoVolume',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        disabled: true
      }
    }
  },
  {
    title: '随货清单',
    dataIndex: 'cargoList',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        disabled: true
      },
    }
  },
  {
    title: '包装',
    dataIndex: 'cargoPackage',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'select',
      props: {
        disabled: true
      }
    }
  }
];

export {
  goodsFields,
  goodsDisabledFields
};
