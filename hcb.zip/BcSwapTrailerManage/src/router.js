import { Router, Switch, Route } from 'dva/router';
import { LocaleProvider } from 'antd';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import { AuthoredContext } from 'components';
import { connect } from 'dva';
import layouts from './layouts';
import pages from './pages';
import { Paths } from './configs/constants';

@connect(({ login }) => ({
  userAuthority: login.userAuthority
}))
class RouterConfigs extends React.PureComponent {
  render() {
    const { history, userAuthority } = this.props;
    if (!userAuthority) {
      history.replace(Paths.LOGIN);
    }
    return (
      <LocaleProvider locale={zhCN}>
        <AuthoredContext.Provider value={{ userAuthority }}>
          <Router history={history}>
            <Switch>
              <Route path={Paths.LOGIN} component={pages.Login} />
              <Route path={Paths.PREVIEW_DELIVERY_NOTE} component={pages.PrintPreview} />
              <Route path={Paths.PREVIEW_DELIVERY_NOTE} component={pages.PrintPreview} />
              <Route path={Paths.PRINT_HANDOVER} component={pages.PrintHandOver} />
              <Route path={Paths.PRINT_WAYBILL} component={pages.PrintWaybill} />
              <Route path={Paths.PRINT_TAG} component={pages.PrintTag} />
              <Route path={Paths.PREVIEW_PICK_UP} component={pages.PrintPickUp} />
              <Route path="/" component={layouts.Layout} />
            </Switch>
          </Router>
        </AuthoredContext.Provider>
      </LocaleProvider>
    );
  }
}

export default RouterConfigs;
