import renderFormFactory from '../../../components/common/renderFormFactory';

const searchConfig = [{
  key: 'plateNumberLike',
  label: '车牌号',
  type: 'input',
  placeholder: '输入车牌号'
}, {
  key: 'carrierCompany',
  label: '车属单位',
  type: 'select',
  defaultValue: '',
  showSearch: true,
  optionFilterProp: 'children',
  options: []
}, {
  key: 'effective',
  label: '状态',
  type: 'select',
  placeholder: '请选择状态',
  defaultValue: '',
  options: [{
    key: '全部',
    value: ''
  }, {
    key: '启用',
    value: 1
  }, {
    key: '停用',
    value: 0
  }]
}];

export default renderFormFactory(searchConfig, null, { xl: { span: 8 } });
