import renderFormFactory from '../../../../components/common/renderFormFactory';

const plateNumberType = [{
  key: '黄牌',
  value: 0
}, {
  key: '蓝牌',
  value: 1
}, {
  key: '绿牌',
  value: 2
}, {
  key: '黄绿牌',
  value: 3
}, {
  key: '黑牌',
  value: 4
}, {
  key: '白牌',
  value: 5
}, {
  key: '蓝白渐变牌',
  value: 6
}];

const formConfig = [{
  key: 'id',
  label: '',
  type: 'hidden',
  layout: {
    span: 0
  }
}, {
  key: 'plateNumber',
  label: '车牌号',
  type: 'input',
  placeholder: '请输入车牌号(如:川A*****)',
  maxLength: 9,
  fields: {
    validateFirst: true,
    rules: [{
      required: true,
      message: '请输入车牌号'
    }, {
      pattern: new RegExp('^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川' +
        '宁琼使领a-zA-Z]{1}[a-zA-Z]{1}[a-zA-Z0-9]{3}[-]{0,1}[a-zA-Z0-9]{1,2}[a-zA-Z0-9挂学警港澳]{1}$'),
      message: '车牌号格式不正确'
    }]
  }
}, {
  key: 'frameNumber',
  label: '车架号',
  type: 'input',
  placeholder: '请输入车架号',
  maxLength: 17,
  fields: {
    validateFirst: true,
    rules: [{
      required: true,
      message: '请输入车架号'
    }, {
      len: 17,
      message: '请输入17位车架号'
    }]
  }
}, {
  key: 'plateNumberType',
  label: '车牌颜色',
  type: 'select',
  defaultValue: 0,
  placeholder: '请选择车牌颜色',
  options: plateNumberType,
  fields: {
    rules: [{
      required: true,
      message: '请选择车牌颜色'
    }]
  }
}, {
  key: 'carrierCompany',
  label: '车属单位',
  type: 'input',
  placeholder: '请输入车属单位',
  maxLength: 20,
  fields: {
    validateFirst: true,
  }
}, {
  key: 'truckBrand',
  label: '车辆品牌',
  type: 'input',
  placeholder: '请输入车辆品牌',
  maxLength: 10,
  fields: {
    validateFirst: true,
  }
}, {
  key: 'frameTyre',
  label: '骨架/轮胎',
  type: 'input',
  placeholder: '请输入骨架/轮胎',
  maxLength: 10,
  fields: {
    validateFirst: true,
  }
}, {
  key: 'truckLoad',
  label: '核定载重（t）',
  type: 'inputnumber',
  min: 0.01,
  max: 999.99,
  precision: 2,
  placeholder: '请输入核定载重',
  fields: {
    rules: [{
      required: true,
      message: '请输入核定载重'
    }]
  }
},
{
  key: 'truckLength',
  label: '挂车长（m）',
  type: 'select',
  placeholder: '请选择车长',
}, {
  key: 'truckVolumne',
  label: '挂车体积（m³）',
  type: 'inputnumber',
  placeholder: '请输入车载体积',
  min: 0.01,
  max: 999.99,
  precision: 2,
  fields: {
    validateFirst: true,
    rules: [{
      required: true,
      message: '请输入挂车体积'
    }]
  }
}, {
  key: 'trailerSize',
  label: '挂车尺寸（mm）',
  type: 'input',
  placeholder: '请输入挂车尺寸',
  minLength: 1,
  maxLength: 20
}, {
  key: 'insideDiameter',
  label: '车厢内径尺寸（m）',
  type: 'input',
  placeholder: '请输入车厢内径尺寸',
  minLength: 1,
  maxLength: 20
}, {
  key: 'inspectionDate',
  label: '年检有效日期',
  type: 'datepicker',
  placeholder: '请输入年检有效日期',
}, {
  key: 'spareTire',
  label: '备胎',
  type: 'input',
  placeholder: '请输入备胎',
  minLength: 1,
  maxLength: 10
}, {
  key: 'extinguisher',
  label: '灭火器',
  type: 'input',
  placeholder: '请输入灭火器',
  minLength: 1,
  maxLength: 10
}, {
  key: 'remark',
  label: '备注',
  type: 'textarea',
  placeholder: '请输入备注(1-20字符)',
  minLength: 1,
  maxLength: 20,
  layout: {
    xxl: { span: 24 },
    xl: { span: 24 },
    lg: { span: 24 },
    md: { span: 24 }
  },
  itemlayout: {
    labelCol: {
      xxl: { span: 3 },
      xl: { span: 3 },
      lg: { span: 3 },
      md: { span: 8 },
      sm: { span: 8 }
    },
    wrapperCol: {
      xxl: { span: 21 },
      xl: { span: 21 },
      lg: { span: 21 },
      md: { span: 16 },
      sm: { span: 16 }
    }
  }
}];

export default renderFormFactory(formConfig, (values) => {
  const { inspectionDate, ...rest } = values;
  let date = '';
  if (inspectionDate) {
    date = inspectionDate.format('YYYY-MM-DD');
  }
  return {
    inspectionDate: date,
    ...rest
  };
}, {
  xl: { span: 8 }
});
