import moment from 'moment';
import { EllipsisRecord } from '../../../components';

const effective = {
  1: '启用',
  0: '停用'
};

const plateNumberType = [{
  key: '黄牌',
  value: 0
}, {
  key: '蓝牌',
  value: 1
}, {
  key: '绿牌',
  value: 2
}, {
  key: '黄绿牌',
  value: 3
}, {
  key: '黑牌',
  value: 4
}, {
  key: '白牌',
  value: 5
}, {
  key: '蓝白渐变牌',
  value: 6
}];

const fields = [
  {
    key: 'plateNumber',
    name: '车牌号',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'action',
    name: '操作'
  },
  {
    key: 'effective',
    name: '状态',
    render: record => effective[record] || '--'
  },
  {
    key: 'carrierCompany',
    name: '车属单位',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'truckBrand',
    name: '车辆品牌',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'frameNumber',
    name: '车架号',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'frameTyre',
    name: '骨架/轮胎',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'truckLoad',
    name: '核定载重（t）'
  },
  {
    key: 'truckLength',
    name: '挂车长（m）',
  },
  {
    key: 'truckVolumne',
    name: '挂车体积（m³）'
  },
  {
    key: 'trailerSize',
    name: '挂车尺寸（mm）',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'insideDiameter',
    name: '车厢内径尺寸（mm）',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'plateNumberType',
    name: '车牌颜色',
    render: record => plateNumberType.filter(i => i.value === record)[0].key
  },
  {
    key: 'inspectionDate',
    name: '年检有效期',
    width: 140,
    render: (record) => {
      let r = '--';
      if (record) {
        r = moment(record).format('YYYY-MM-DD');
      }
      return <EllipsisRecord record={r} width={140} />;
    }
  },
  {
    key: 'spareTire',
    name: '备胎',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'extinguisher',
    name: '灭火器',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'createUserName',
    name: '添加人',
    width: 120,
  },
  {
    key: 'createTime',
    name: '添加时间',
    type: 'datetime',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  }, {
    key: 'remark',
    name: '备注',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  }
];

export default fields;
