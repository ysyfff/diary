/**
 * @author yang.huang3
 * @description 运力管理page
 * @since 2018.08.25
 */
import { HTable, HModal } from 'carno';
import bind from 'bind-decorator';
import { connect } from 'dva';
import { Icon, Popover, Row, Col, Button, message } from 'antd';
import QRCode from 'qrcode-react';
import moment from 'moment';
import {
  BaseComponent,
  BaseSearchBar,
  BaseModalForm
} from '../../../components';
import searchConfig from './search.config.js';
import render from './AddTransport/form.config';
import { exportTable } from './services';
import logo from './logo.base64';

import './index.less';

function fixType(type) {
  const _type = type.toLowerCase().replace(/jpg/i, 'jpeg');
  const r = _type.match(/png|jpeg|bmp|gif/)[0];
  return `image/${r}`;
}
// 下载二维码
function saveFile(data, filename) {
  const saveLink = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
  saveLink.href = data;
  saveLink.download = filename;
  const event = document.createEvent('MouseEvents');
  event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
  saveLink.dispatchEvent(event);
}

const baseItemLayout = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 6 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 18 },
    lg: { span: 18 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const QRCODE_SIZE = 350;

const modalItemLayout = {
  labelCol: { span: 9 },
  wrapperCol: { span: 14 }
};

@connect(({ transportManage }) => ({ ...transportManage }), dispatch => ({
  getTruckType() {
    return dispatch({ type: 'transportManage/getTruckType' });
  },
  async getTruckLength() {
    return dispatch({ type: 'transportManage/getTruckLength' });
  },
  getTruckList(param) {
    dispatch({ type: 'transportManage/updateSearch', payload: param });
    dispatch({ type: 'transportManage/getTruckList' });
  },
  addTruck(param) {
    return dispatch({ type: 'transportManage/addTruck', payload: param });
  },
  update(param) {
    return dispatch({ type: 'transportManage/update', payload: param });
  },
  enable(param) {
    return dispatch({ type: 'transportManage/enable', payload: param });
  },
  disable(param) {
    return dispatch({ type: 'transportManage/disable', payload: param });
  },
  async getCarrierCompany() {
    return dispatch({ type: 'transportManage/getCarrierCompany' });
  }
}))
class TransportManage extends BaseComponent {
  constructor(props) {
    super(props);
    this.bind(['getProps', 'getProps', 'handleAdd']);
    this.state = {
      visible: false,
      render,
      title: '',
      confirmVisible: false,
      content: '',
      searchConfig,
      qrcodeVisible: false,
      qrcodeValue: '',
      plateNumber: '' // 挂车号
    };
    this.initValueConfig = render.components.map(component => ({
      key: component.key,
      defaultValue: component.props.defaultValue === 0 ?
        0 : (component.props.defaultValue || undefined),
      disabled: false
    }));
    this.logo = logo;
  }

  async componentDidMount() {
    const { getCarrierCompany, getTruckLength } = this.props;
    const promiseType = Promise.resolve(getCarrierCompany());
    const promiseLength = Promise.resolve(getTruckLength());
    // 重新渲染select数据
    Promise.all([promiseType, promiseLength])
      .then(() => {
        this.setState({
          render: render.rerender([{
            key: 'truckLength',
            options: this.props.truckLength
          }]),
          searchConfig: searchConfig.rerender([
            {
              key: 'carrierCompany',
              options: this.props.carrierCompany
            }])
        });
      });
  }

  componentWillUnmount() {
    clearTimeout(this.timer);
  }

  @bind
  handleSearch(values) {
    // 搜索条件查询
    this.props.getTruckList({ ...values, pn: 1 });
  }

  @bind
  handleAdd() {
    // 弹出新增madal
    this.setState({
      visible: Symbol('add'),
      render: render.rerender(this.initValueConfig),
      action: 'add'
    });
  }

  @bind
  handlePageChange(values) {
    // 分页变化查询
    this.props.getTruckList(values);
  }

  @bind
  async handleOk(values) {
    const { action } = this.state;
    const { frameNumber, plateNumber } = values;
    let data = null;
    if (action === 'add') {
      data = await this.props.addTruck(values);
    } else {
      data = await this.props.update(values);
    }
    if (data && data.status === 'ERROR') {
      const error = action === 'add' ? '挂车新增失败' : '挂车修改失败';
      message.error(error);
      return null;
    }
    const success = action === 'add' ? '挂车新增成功' : '挂车修改成功';
    this.props.getTruckList();
    this.timer = setTimeout(() => {
      this.setState({
        qrcodeValue: frameNumber,
        plateNumber,
        qrcodeVisible: Symbol('visible')
      });
      clearTimeout(this.timer);
    }, 500);
    message.success(success);
    return 'OK';
  }

  @bind
  handleUpdate(datas) {
    // 车辆信息修改
    return () => {
      // rerender
      const nextConfig = Object.keys(datas).map((key) => {
        // 编辑时车牌号和车牌颜色不能修改
        let defaultValue;
        if (key === 'frameNumber') {
          return {
            key,
            defaultValue: datas[key],
            disabled: true
          };
        }
        // 格式化默认值
        if (key === 'inspectionDate') {
          defaultValue = datas.inspectionDate ? moment(datas.inspectionDate) : undefined;
        } else if (key === 'truckLength') {
          defaultValue = datas.truckLength === 0 ? undefined : datas[key];
        } else if (key === 'truckVolumne') {
          defaultValue = datas.truckVolumne === 0 ? null : datas[key];
        } else if (key === 'truckLoad') {
          defaultValue = datas.truckLoad === 0 ? null : datas[key];
        } else {
          defaultValue = datas[key];
        }
        return {
          key,
          defaultValue,
          disabled: false
        };
      });
      this.setState({
        visible: Symbol('update'),
        render: render.rerender(nextConfig),
        action: 'update'
      });
    };
  }

  @bind
  handelStop(datas) {
    return () => {
      if (datas.status === 'EMPTY') {
        const effect = datas.effective === 1 ? 0 : 1;
        const action = datas.effective === 1 ? '禁用' : '启用';
        this.setState({
          title: `${action}挂车`,
          content: `是否${action}挂车：${datas.plateNumber}`,
          confirmVisible: Symbol('confirmStatus'),
          effect,
          id: datas.id
        });
      }
    };
  }

  @bind
  async handleEffect() {
    const { effect, id } = this.state;
    if (effect === 0) {
      // 调用禁用
      await this.props.disable({ id });
      this.props.getTruckList();
      message.success('挂车禁用成功');
    } else {
      // 调用启用
      await this.props.enable({ id });
      this.props.getTruckList();
      message.success('挂车启用成功');
    }
  }
  // 生成二维码
  createQrcode = datas => () => {
    this.setState({
      qrcodeVisible: Symbol('qrcode'),
      qrcodeValue: datas.frameNumber,
      plateNumber: datas.plateNumber
    });
  }

  cancelModal = () => {
    this.setState({ qrcodeVisible: false });
  }

  downLoad = () => {
    const { plateNumber } = this.state;
    const qrcode = this.canvas.refs.canvas;
    const _canvas = document.createElement('canvas');
    const footerHeight = 60;
    const height = QRCODE_SIZE + footerHeight;
    _canvas.width = QRCODE_SIZE;
    _canvas.height = height;
    const context = _canvas.getContext('2d');
    context.fillStyle = '#fff';
    context.fillRect(0, 0, QRCODE_SIZE, height);
    const qrcodeimg = qrcode.toDataURL('image/png', 1.0);
    const img = document.createElement('img');
    img.setAttribute('crossorigin', 'anonymous');
    img.src = qrcodeimg;
    img.onload = () => {
      // 绘制二维码
      context.drawImage(img, 0, 0, QRCODE_SIZE, QRCODE_SIZE);
      // 绘制文字设置
      context.textAlign = 'center';
      context.font = 'bold 18px Arial';
      context.fillStyle = '#000';
      // 绘制挂车号
      context.fillText(`挂车号: ${plateNumber}`, QRCODE_SIZE / 2, QRCODE_SIZE + (footerHeight / 2) + 9);
      const type = 'png';
      let imgData = _canvas.toDataURL(type);
      imgData = imgData.replace(fixType(type), 'image/octet-stream');
      const filename = `挂车二维码_${+new Date()}.${type}`;
      saveFile(imgData, filename);
    };
  }

  getProps() {
    const {
      tableFields,
      search,
      total,
      list,
      loading,
    } = this.props;
    const { pn, ps } = search;
    const fields = [...tableFields];
    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => this.handlePageChange({ pn }),
      onShowSizeChange: (current, size) => this.handlePageChange({ ps: size, pn: 1 })
    };
    const extraFields = [{
      key: 'action',
      name: '操作',
      render: (record, datas) => (
        <Popover
          placement="right"
          overlayStyle={{ zIndex: 999 }}
          content={
            <ul className="table-operate-button">
              <li><a onClick={this.handleUpdate(datas)}>修改</a></li>
              {
                datas.status === 'EMPTY' &&
                datas.effective === 1 &&
                <li>
                  <a onClick={this.handelStop(datas)}>
                    禁用
                  </a>
                </li>
              }
              {
                datas.status === 'EMPTY' &&
                datas.effective === 0 &&
                <li>
                  <a onClick={this.handelStop(datas)}>
                    启用
                  </a>
                </li>
              }
              {
                datas.effective === 1 &&
                <li>
                  <a onClick={this.createQrcode(datas)}>
                    生成二维码
                  </a>
                </li>
              }
            </ul>
          }
        >
          <a><Icon type="menu-unfold" /></a>
        </Popover>
      )
    }];
    return {
      tableProps: {
        fields,
        extraFields,
        dataSource: list,
        loading: loading.track,
        search,
        scroll: { x: 2800 },
        pagination,
        locale: { emptyText: '暂无数据' },
        style: { marginTop: 16 },
      },
    };
  }
   // 导出表单
   handleExport = () => {
     exportTable({
       server: 'admin',
       url: '/web/e/compartment/export',
       params: this.props.search
     });
   }

   render() {
     const { tableProps } = this.getProps();
     const {
       visible,
       render,
       title,
       content,
       confirmVisible,
       action,
       searchConfig,
       qrcodeVisible,
       qrcodeValue,
       plateNumber
     } = this.state;
     const { loading } = this.props;
     const actionTitle = action === 'add' ? '新增挂车' : '修改挂车';
     const disabled = action === 'add' ? !!0 : !!1;
     return (
       <div>
         <BaseSearchBar
           render={searchConfig}
           onSearch={this.handleSearch}
           baseItemLayout={baseItemLayout}
         />
         <Row type="flex" justify="end">
           <Col>
             <div className="order-list-button">
               <Button
                 onClick={this.handleAdd}
                 style={{ margin: '20px 20px 10px 0' }}
                 type="primary"
               >
                新增挂车
               </Button>
               <Button
                 onClick={this.handleExport}
               >
                导出表单
               </Button>
             </div>
           </Col>
         </Row>
         <HTable {...tableProps} />
         <BaseModalForm
           title={actionTitle}
           width={1100}
           visible={visible}
           render={render}
           baseItemLayout={modalItemLayout}
           onOk={this.handleOk}
           loading={loading.addTruck}
           disabledOkButton={disabled}
         />
         <HModal
           title={title}
           visible={confirmVisible}
           onOk={this.handleEffect}
           centered
         >
           {content}
         </HModal>
         <HModal
           title={'生成挂车二维码'}
           visible={qrcodeVisible}
           centered
           width={650}
           footer={null}
         >
           <div className="qrcode-content">
             <div className="qrcode-content-tips">
               <i className="icon-warn" />
               <span className="tips-content">
                下载二维码打印，可用于贴在挂车上进行驿站换挂匹配
               </span>
             </div>
             <div className="qrcode" ref={el => this.el = el}>
               <QRCode
                 size={QRCODE_SIZE}
                 value={qrcodeValue}
                 logo={this.logo}
                 logoWidth={100}
                 logoHeight={100}
                 ref={canvas => this.canvas = canvas}
               />
               <p
                 className="plate-number"
                 style={{
                   fontWeight: 600,
                   fontSize: '18px'
                 }}
               >
                 <span name="plate-number">挂车号:</span>
                 <span>{plateNumber}</span>
               </p>
             </div>
             <Row style={{ margin: '24px 0 0 0', textAlign: 'center' }}>
               <Button
                 style={{ marginRight: '40px', padding: '0 40px' }}
                 type="primary"
                 onClick={this.downLoad}
               >下载
               </Button>
               <Button
                 style={{ padding: '0 40px' }}
                 onClick={this.cancelModal}
               >
                关闭
               </Button>
             </Row>
           </div>
         </HModal>
       </div>
     );
   }
}

export default TransportManage;
