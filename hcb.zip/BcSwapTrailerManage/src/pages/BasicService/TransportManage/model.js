import { Model } from 'carno/addons';
import { Paths, PAGE_SIZE } from 'configs/constants';
import { withLoading } from 'carno/utils';
import fields from './fields';
import {
  getTruckType,
  getTruckList,
  getTruckLength,
  addTruck,
  enable,
  disable,
  update,
  getCarrierCompany
} from './services';

const initalSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  effective: '',
  carrierCompany: ''
};

export default Model.extend({
  namespace: 'transportManage',
  state: {
    loading: { track: false, addTruck: false },
    search: initalSearch,
    tableFields: fields,
    list: [],
    truckType: [],
    truckLength: [],
    carrierCompany: [],
    total: 0
  },
  effects: {
    * getTruckList({ payload }, { select, call, update }) {
      const { search } = yield select(({ transportManage }) => transportManage);
      const { datas, tc } = yield call(withLoading(getTruckList, 'track'), search);
      return yield update({ list: datas, total: tc });
    },
    * getTruckType({ payload }, { call, update }) {
      const datas = yield call(getTruckType);
      const truckType = datas.map(data => ({ key: data, value: data }));
      yield update({ truckType });
    },
    * getTruckLength({ payload }, { call, update }) {
      const datas = yield call(getTruckLength);
      const truckLength = datas.map(data => ({ key: data, value: data }));
      yield update({ truckLength });
    },
    * addTruck({ payload }, { call }) {
      let datas;
      try {
        datas = yield call(withLoading(addTruck, 'addTruck'), payload);
      } catch (error) {
        datas = error;
      }
      return datas;
    },
    * enable({ payload }, { call }) {
      return yield call(enable, payload);
    },
    * disable({ payload }, { call }) {
      return yield call(disable, payload);
    },
    * update({ payload }, { call }) {
      let datas;
      try {
        datas = yield call(update, payload);
      } catch (error) {
        datas = error;
      }
      return datas;
    },
    * getCarrierCompany({ payload }, { call, update }) {
      const datas = yield call(getCarrierCompany);
      const array = [];
      let carrierCompany = (datas || []).forEach((data) => {
        if (data) {
          array.push({ key: data, value: data });
        }
      });
      carrierCompany = [{ key: '全部', value: '' }].concat(array);
      yield update({ carrierCompany });
    }
  },
  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    }
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.TRANSPORT_MANAGE, () => {
        // 初始化查询条件
        dispatch({ type: 'updateSearch', payload: initalSearch });
        dispatch({ type: 'getTruckList' });
      });
    }
  }
});

export { initalSearch };

