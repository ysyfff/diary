import http from 'utils/http';
import { getDeployEnv } from 'carno/utils';
import { qs, cookie } from 'carno/third-party';
import { servers as serverConfigs } from 'configs';

export function getServer(servers = serverConfigs) {
  return servers[getDeployEnv(process.env.DEPLOY_ENV)];
}

const { post } = http.create('admin');

// 查询车辆类
export function getTruckType() {
  return post('/web/e/common/config/truck-type');
}
// 查询车长
export function getTruckLength() {
  return post('/web/e/common/config/truck-length');
}
// 查询车厢列表
export function getTruckList(param) {
  return post('/web/e/compartment/list', param);
}
// 新增车辆
export function addTruck(param) {
  return post('/web/e/compartment/create', param);
}
// 车厢启用
export function enable(param) {
  return post('/web/e/compartment/enable', param);
}
// 车厢停用
export function disable(param) {
  return post('/web/e/compartment/disable', param);
}
// 车厢修改
export function update(param) {
  return post('/web/e/compartment/update', param);
}
// 查询车属单位
export function getCarrierCompany() {
  return post('/web/e/compartment/carrier-company');
}
// 导出表单
export function exportTable({ server, url, params }) {
  const qsparms = { ...params, sid: cookie.get('sid'), st: cookie.get('st') };
  const serverUrl = `${getServer()[server]}${url}?${qs.stringify({ ...qsparms })}`;
  window.open(serverUrl, '_blank');
}
