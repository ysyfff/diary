import http from 'utils/http';

const { post } = http.create('admin');

// 获取线路列表
export function getList(param) {
  return post('/web/m/siteline/list', param);
}

//  禁用线路
export function cancelWayBill(param) {
  return post('/web/m/siteline/disable', param);
}

// 启用线路
export function enableSite(param) {
  return post('/web/m/siteline/enable', param);
}

//  新增线路
export function creatSite(param) {
  return post('/web/m/siteline/create',
    param, {
      contentType: 'json'
    });
}

// 修改线路
export function editSite(param) {
  return post('/web/m/siteline/update',
    param, {
      contentType: 'json'
    });
}

// 获取站点信息
export function getSiteList(param) {
  return post('/web/e/site/search', param);
}
