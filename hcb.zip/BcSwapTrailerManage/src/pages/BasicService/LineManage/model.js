import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getList, cancelWayBill, creatSite, editSite, enableSite, getSiteList } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  code: '',
  startSite: '',
  endSite: '',
  effective: '',
};

const searchSite = {
  code: '',
  name: '',
  nameLike: '',
  codeLike: '',
};

export default Model.extend({
  namespace: 'LineManage',

  state: {
    loading: { list: false },
    tableFields,
    search: initialSearch,
    searchSite,
    total: 0,
    list: [],
    orderCounts: [],
    siteList: [],
    siteListCopy: [],
    isShowAddOrEditModal: false,
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.LINE_MANAGE, () => {
        dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
        dispatch({ type: 'getSiteList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ LineManage }) => LineManage);
      const { datas, tc } = yield call(withLoading(getList, 'list'), search);
      yield update({ list: datas, total: tc });
    },

    // 获取站点信息
    * getSiteList({ payload }, { call, update, select }) {
      const { searchSite } = yield select(({ LineManage }) => LineManage);
      const datas = yield call(withLoading(getSiteList, 'getSiteList'), searchSite);
      yield update({ siteList: datas || [], siteListCopy: datas || [] });
    },

    // 禁用线路
    * cancelWayBill({ payload }, { call, put }) {
      const id = payload;
      yield call(withLoading(cancelWayBill, { successMsg: '线路已禁用！', key: 'cancelWayBill' }), { id });
      yield put({ type: 'getList' });
    },
    // 启用线路
    * enableSite({ payload }, { call, put }) {
      const id = payload;
      yield call(withLoading(enableSite, { successMsg: '线路已启用！', key: 'enableSite' }), { id });
      yield put({ type: 'getList' });
    },

    //  新增线路
    * creatSite({ payload }, { call, put, select, update }) {
      const { siteListCopy } = yield select(({ LineManage }) => LineManage);
      yield call(withLoading(creatSite, { successMsg: '线路新增成功！', key: 'creatSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
      yield update({ siteList: [...siteListCopy] || [] });
    },

    //  修改线路
    * editSite({ payload }, { call, put, select, update }) {
      const { siteListCopy } = yield select(({ LineManage }) => LineManage);
      yield call(withLoading(editSite, { successMsg: '线路修改成功！', key: 'editSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
      yield update({ siteList: [...siteListCopy] || [] });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: initialSearch
      };
    },
    updataSiteList(state, { payload }) {
      return {
        ...state,
        siteList: payload,
      };
    },
  },
});
