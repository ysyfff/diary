import { Form, Row, Col, Modal, Input, Timeline, Icon, Select, Message, InputNumber } from 'antd';
import EllipsisRecord from 'components/common/EllipsisRecord';

const FormItem = Form.Item;
const Option = Select.Option;


// 格式化数据
const formatData = (values = {}) => {
  const catchValues = { ...values };
  const copyDatas = { ...values };
  delete copyDatas.minPrice;
  delete copyDatas.name;
  delete copyDatas.code;
  delete copyDatas.staetSite;
  delete copyDatas.endSite;

  catchValues.sites = Object.values(copyDatas).map((i, index) => ({
    siteId: i,
    index: index + 1,
    siteType: 'ROAD'
  }));
  catchValues.sites.unshift({
    siteId: catchValues.staetSite,
    index: 0,
    siteType: 'START'
  });
  catchValues.sites.push({
    siteId: catchValues.endSite,
    index: catchValues.sites.length,
    siteType: 'END'
  });
  delete catchValues.endSite;
  delete catchValues.staetSite;
  return {
    minPrice: catchValues.minPrice,
    name: catchValues.name,
    code: catchValues.code,
    sites: catchValues.sites
  };
};

class FormModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      lineList: [{
        siteId: '',
        index: 1,
        siteType: ''
      }],
      saveList: []
    };
  }

  componentWillReceiveProps = (_props) => {
    if (_props.visible === false) {
      const { resetFields } = _props.form;
      resetFields();
    }
    if (this.props.lineList !== _props.lineList) {
      this.setState({
        lineList: (_props.lineList.length === 0 && _props.title === '新增') ? [{
          siteId: '',
          index: 1,
          siteType: ''
        }]
          : _props.lineList
      });
    }
  }

  handleSubmit = () => {
    const { form, creatSite, editSite, title, siteMsg = {} } = this.props;
    const { validateFields } = form;
    validateFields((err, values) => {
      if (!err) {
        const data = formatData(values);
        if (title === '新增') {
          creatSite(data);
        } else if (title === '修改') {
          editSite({
            ...data,
            id: siteMsg.id
          });
        }
      }
    });
  }

  addLine = () => {
    const { lineList } = this.state;
    let maxIndex = lineList.length > 0 ? lineList[0].index : 0;
    if (lineList.length < 5) {
      const newData = lineList.map((item) => {
        if (item.index > maxIndex) { maxIndex = item.index; }
        return item;
      });
      newData.push({
        siteId: '',
        index: maxIndex + 1,
        siteType: ''
      });
      this.setState({
        lineList: newData
      });
    } else {
      Message.error('最多添加5个经停站点！');
    }
  }

  removeLine = (key) => {
    const { lineList } = this.state;
    const { updataSiteList, siteListCopy = [] } = this.props;
    const newData = lineList.filter((item, index) => index !== key);
    this.setState({ lineList: newData });
    updataSiteList(siteListCopy);
  }

  cancelModals = () => {
    const { cancel, form } = this.props;
    const { resetFields } = form;
    this.setState({
      lineList: [{
        siteId: '',
        index: 1,
        siteType: ''
      }],
    });
    resetFields();
    cancel();
  }

  updataSource = () => {
    const { updataSiteList, siteListCopy = [], form } = this.props;
    const { getFieldsValue } = form;
    const copyDatas = { ...getFieldsValue() };
    delete copyDatas.name;
    delete copyDatas.code;
    const {
      staetSite,
      endSite,
      ...resetValue
    } = copyDatas;
    const dataList = Object.values(resetValue);
    staetSite && dataList.push(staetSite);
    endSite && dataList.push(endSite);
    const newList = siteListCopy.filter(i => dataList.indexOf(i.id) === -1);
    updataSiteList(newList);
  }

  render() {
    const { form, visible, title, siteMsg = {}, siteList = [], loading } = this.props;
    const { lineList = [] } = this.state;
    const { getFieldDecorator } = form;

    return (
      <Modal
        width="60%"
        title={`${title}线路`}
        visible={visible}
        onCancel={this.cancelModals}
        maskClosable={false}
        onOk={this.handleSubmit}
        confirmLoading={title === '修改' ? loading.editSite : loading.creatSite}
        okButtonProps={{ disabled: title === '查看' }}
      >
        <Form layout="inline" >
          <Row gutter={24}>
            <Col span={12}>
              <FormItem
                label="线路名称"
              >
                {getFieldDecorator('name', {
                  placeholder: '',
                  initialValue: siteMsg.name,
                  rules: [{ required: true, message: '请输入线路名称！' }]
                })(
                  <Input
                    placeholder="请输入线路名称"
                    maxLength="20"
                    disabled={title === '查看' || title === '修改'}
                  />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="线路编码"
              >
                {getFieldDecorator('code', {
                  placeholder: '',
                  initialValue: siteMsg.code,
                  rules: [{ required: true, message: '请输入线路编码！' }]
                })(
                  <Input
                    placeholder="请输入线路编码"
                    maxLength="10"
                    disabled={title === '查看' || title === '修改'}
                  />
                )}
              </FormItem>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={24}>
              <FormItem
                label="最低通道运费"
              >
                {getFieldDecorator('minPrice', {
                  placeholder: '',
                  initialValue: siteMsg.minPrice,
                  rules: [{ required: true, message: '请输入最低通道运费！' }]
                })(
                  <InputNumber
                    placeholder="请输入最低通道运费"
                    precision={2}
                    min={0.01}
                    max={(10 ** 5) - 0.01}
                    disabled={title === '查看'}
                  />
                )}
              </FormItem>
            </Col>
          </Row>

          <Row gutter={24}>
            <Col span={24}>
              <div className="line-cotanier" >
                <Timeline>
                  <Timeline.Item color="green">
                    <FormItem
                      label="始发站点"
                    >
                      {getFieldDecorator('staetSite', {
                        placeholder: '请输入始发站点',
                        initialValue: siteMsg.startSite,
                        rules: [{ required: true, message: '请输入始发站点！' }]
                      })(
                        <Select
                          placeholder="请输入始发站点"
                          style={{ width: 170 }}
                          disabled={title === '查看'}
                          onDropdownVisibleChange={this.updataSource}
                        >
                          {
                            siteList.map(option => (
                              <Option
                                key={option.id}
                                value={option.id}
                              >
                                <EllipsisRecord record={option.name} width={150} />
                              </Option>
                            ))
                          }
                        </Select>
                      )}
                    </FormItem>
                  </Timeline.Item>
                  {
                    lineList.map((i, index) =>
                      <Timeline.Item
                        key={index}
                        dot={
                          <Icon
                            type="minus-circle"
                            theme="outlined"
                            style={{ color: 'red' }}
                            onClick={() => this.removeLine(index)}
                          />
                        }
                      >
                        <FormItem
                          label="经停站点"
                        >
                          {getFieldDecorator(`${i.index}`, {
                            // placeholder: ''
                            initialValue: i.siteId ? i.siteId : undefined,
                            rules: [{ required: true, message: '请输入经停站点！' }]
                          })(
                            <Select
                              placeholder="请输入经停站点"
                              style={{ width: 170 }}
                              disabled={title === '查看'}
                              onDropdownVisibleChange={this.updataSource}
                            >
                              {
                                siteList.map(option => (<Option
                                  key={option.id}
                                  value={option.id}
                                >
                                  <EllipsisRecord record={option.name} width={150} />
                                </Option>))
                              }
                            </Select>
                          )}
                        </FormItem>
                      </Timeline.Item>
                    )
                  }
                  <Timeline.Item
                    dot={
                      <Icon
                        type="plus-circle"
                        theme="outlined"
                        onClick={this.addLine}
                      />}
                    style={{ height: 50 }}
                  />
                  <Timeline.Item color="green">
                    <FormItem
                      label="目的站点"
                    >
                      {getFieldDecorator('endSite', {
                        placeholder: '',
                        initialValue: siteMsg.endSite,
                        rules: [{ required: true, message: '请输入目的站点！' }]
                      })(
                        <Select
                          placeholder="请输入目的站点"
                          style={{ width: 170 }}
                          onDropdownVisibleChange={this.updataSource}
                          disabled={title === '查看'}
                        >
                          {
                            siteList.map(option => (
                              <Option
                                key={option.id}
                                value={option.id}
                              >
                                <EllipsisRecord record={option.name} width={150} />
                              </Option>
                            ))
                          }
                        </Select>
                      )}
                    </FormItem>
                  </Timeline.Item>
                </Timeline>
              </div>
            </Col>
          </Row>
        </Form>
      </Modal>
    );
  }
}
export default Form.create()(FormModal);
