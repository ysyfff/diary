import { EllipsisRecord } from '../../../components';

export const tableFields = [
  {
    key: 'name',
    name: '线路名称',
    width: 150,
    render: record => <EllipsisRecord record={record || '__'} width={150} />
  },
  {
    key: 'buyerName',
    name: '操作',
    width: 80
  },
  {
    key: 'effective',
    name: '线路状态',
    width: 150,
    render: a => a ? '启用' : '禁用'
  },
  {
    key: 'code',
    name: '线路编码',
    width: 150,
    render: record => <EllipsisRecord record={record || '__'} width={150} />
  },
  {
    key: 'minPrice',
    name: '最低通道运费',
    width: 200,
  },
  {
    key: 'line',
    name: '线路',
    width: 500,
    render: (a, b) => <EllipsisRecord
      record={`${b.startSiteName}-
    ${b.sequence.filter(i => i.siteType === 'ROAD').map(j => j.siteName).join('-')}-${b.endSiteName}` || '__'}
      width={300}
    />
  }
];

