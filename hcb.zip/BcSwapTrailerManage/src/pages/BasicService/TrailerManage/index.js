import { connect } from 'dva';
import { Row, Col, Button, Popover, Icon, Modal } from 'antd';
import { HTable } from 'carno';
import { downFile } from 'utils/downloadFile';
import SearchBar from './common/SearchBar';
import FormModal from './common/FormModal';
import styles from './index.less';
import { exportTrailers } from './services';

const confirm = Modal.confirm;

@connect(({ TrailerManage }) => ({ ...TrailerManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'TrailerManage/updateSearch', payload: param });
    dispatch({ type: 'TrailerManage/getList' });
  },
  onReset() {
    dispatch({ type: 'TrailerManage/resetSearch' });
    dispatch({ type: 'TrailerManage/getList' });
  },
  cancelWayBill: (param) => {
    dispatch({ type: 'TrailerManage/cancelWayBill', payload: param });
  },
  creatSite: (param) => {
    dispatch({ type: 'TrailerManage/creatSite', payload: param });
  },
  editSite: (param) => {
    dispatch({ type: 'TrailerManage/editSite', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'TrailerManage/updateState', payload: param });
  },
  enableSite: (param) => {
    dispatch({ type: 'TrailerManage/enableSite', payload: param });
  },
  getSiteList: (param) => {
    dispatch({ type: 'TrailerManage/getSiteList', payload: param });
  }
}))
export default class TrailerManage extends React.Component {
  state = {
    visible: false,
    title: '',
    siteMsg: '',
    visiblepop: []
  }

  getProps() {
    const {
      tableFields, search, total, list, loading, getList, cancelWayBill, enableSite
    } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'buyerName',
            name: '操作',
            render: (record, data) => !(data.state === 'CANCEL' || data.state === 'TRANSPORTING') && <Popover
              placement="right"
              overlayStyle={{ zIndex: 999 }}
              content={
                <div >
                  <ul className="table-operate-button">
                    <li><a onClick={() => this.editSite('修改', data)}>修改</a></li>
                    <li>
                      <a onClick={() => confirm({
                        title: `是否${data.effective ? '禁用' : '启用'}该车辆，车牌号：${data.plateNumber}`,
                        content: '',
                        onOk() {
                          if (data.effective) {
                            cancelWayBill(data.id);
                          } else {
                            enableSite(data.id);
                          }
                        },
                        onCancel() {
                          console.log('Cancel'); // eslint-disable-line
                        },
                      })}
                      >{data.effective ? '禁用' : '启用'}</a>
                    </li>
                  </ul>
                </div>
              }
            ><a><Icon type="menu-unfold" /></a></Popover>
          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 3800 },
        pagination,
        locale: { emptyText: '暂无车辆信息' },
        style: { marginTop: 16 },
      },
    };
  }

  handleSearch(search) {
    this.props.getList(search);
  }

  addSite = (msg) => {
    const { updateState, getSiteList } = this.props;
    getSiteList();
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg,
      siteMsg: ''
    });
  }

  editSite = (msg, data) => {
    const { updateState } = this.props;
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg,
      siteMsg: data
    });
  }

  // 导出
  exportTrailers = () => {
    const { search } = this.props;
    downFile({ server: 'dapt', url: exportTrailers(), params: search });
  }

  closeModal = () => {
    const { updateState } = this.props;
    updateState({ isShowAddOrEditModal: false });
    this.setState({
      title: '',
      siteMsg: ''
    });
  }

  render() {
    const {
      getList, search, siteList, onReset, creatSite, editSite, isShowAddOrEditModal, loading, getSiteList
    } = this.props;
    const { title, siteMsg } = this.state;
    const { tableProps } = this.getProps();

    const SearchBarProps = {
      search,
      onSearch: getList,
      onReset
    };

    const ModalProps = {
      visible: isShowAddOrEditModal,
      title,
      cancel: this.closeModal,
      creatSite,
      siteMsg,
      editSite,
      loading,
      siteList,
      getSiteList
    };

    return (
      <div className={styles['waybill-manage']}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="end">
          <Col span={6} >
            <div className="order-list-button" style={{ textAlign: 'right' }}>
              <Button type="primary" onClick={() => this.addSite('新增')}>新增车辆</Button>
              <Button onClick={this.exportTrailers}>导出表单</Button>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
        <FormModal {...ModalProps} />
      </div>
    );
  }
}
