import http from 'utils/http';

const { post } = http.create('admin');

// 获取车辆列表
export function getList(param) {
  return post('/web/m/truck/list', param);
}

//  禁用车辆
export function cancelWayBill(param) {
  return post('/web/m/truck/disable', param);
}

// 启用车辆
export function enableSite(param) {
  return post('/web/m/truck/enable', param);
}

//  新增车辆
export function creatSite(param) {
  return post('/web/m/truck/create', param);
}

// 修改车辆
export function editSite(param) {
  return post('/web/m/truck/update', param);
}

// 获取站点信息
export function getSiteList(param) {
  return post('/web/e/site/search', param);
}

// 导出首页列表
export function exportTrailers() {
  return '/web/m/truck/export';
}
