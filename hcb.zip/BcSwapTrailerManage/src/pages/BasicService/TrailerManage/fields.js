import { driverTo, driverType } from 'configs/constants';
import { formatValue } from 'utils/formatValue';
import EllipsisRecord from 'components/common/EllipsisRecord';

const plateNumberType = {
  0: '黄牌',
  1: '蓝牌',
  2: '绿牌',
  3: '黄绿牌',
  4: '黑牌',
  5: '白牌',
  6: '蓝白渐变牌'
};

export const tableFields = [
  {
    key: 'plateNumber',
    name: '车牌号',
    render: formatValue
  },
  {
    key: 'buyerName',
    name: '操作',
  },
  {
    key: 'effective',
    name: '状态',
    render: a => a ? '启用' : '禁用'
  },
  {
    key: 'belongType',
    name: '车辆归属',
    render: (a) => {
      const type = a ? driverTo.filter(i => i.key === a) : [];
      return formatValue(type[0] && type[0].value);
    }
  },
  {
    key: 'plateNumberType',
    name: '车牌颜色',
    render: record => formatValue(plateNumberType[record])
  },
  {
    key: 'useLine',
    name: '线路',
    render: (a) => {
      const type = a ? driverType.filter(i => i.key === a) : [];
      return formatValue(type[0] && type[0].value);
    }
  },
  {
    key: 'gpsNo',
    name: 'GPS设备',
    render: formatValue
  },
  {
    key: 'createUserName',
    name: '添加人',
    render: formatValue
  },
  {
    key: 'createTime',
    name: '添加时间',
    render: formatValue
  },
  {
    key: 'truckBrand',
    name: '车头品牌',
    render: formatValue
  },
  {
    key: 'horsepower',
    name: '马力',
    render: formatValue
  },
  {
    key: 'steerType',
    name: '车辆类型',
    render: formatValue
  },
  {
    key: 'ownerName',
    name: '车主信息',
    render: (a, b) => {
      const ownerPhone = b.ownerPhone || '';
      let owner = '';
      if (a) {
        owner = a;
        if (ownerPhone) {
          owner += ` / ${ownerPhone}`;
        }
      } else {
        owner = ownerPhone || '--';
      }
      return owner;
    }
  },
  {
    key: 'driverName',
    name: '驾驶员信息',
    render: (a, b) => {
      const driverPhone = b.driverPhone || '';
      let driver = '';
      if (a) {
        driver = a;
        if (driverPhone) {
          driver += ` / ${driverPhone}`;
        }
      } else {
        driver = driverPhone || '--';
      }
      return driver;
    }
  },
  {
    key: 'reportSiteName',
    name: '报道场地',
    render: formatValue
  },
  {
    key: 'contractDate',
    name: '签约日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'tank',
    name: '油箱（L）',
    render: formatValue
  },
  {
    key: 'annualVerifyDate',
    name: '车辆年审日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'businessAnnualVerifyDate',
    name: '运营证年审日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'driverStatus',
    name: '司机状态',
    render: formatValue
  },
  {
    key: 'fleetReportDate',
    name: '车队报道日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'fleetDeliverDate',
    name: '车队交付日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'firstExecTaskDate',
    name: '车辆首次执行任务日期',
    render: a => formatValue((a ? a.split(' ')[0] : ''))
  },
  {
    key: 'remark',
    name: '备注',
    render: record => <EllipsisRecord record={record || '--'} width={150} />
  },
];

