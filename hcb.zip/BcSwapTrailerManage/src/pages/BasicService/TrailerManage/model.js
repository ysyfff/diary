import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getList, cancelWayBill, creatSite, editSite, enableSite, getSiteList } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  belongType: '',
  plateNumber: '',
  effective: '',
};

const searchSite = {
  pn: 1,
  ps: 1000,
  code: '',
  name: '',
  nameLike: '',
  codeLike: '',
};

export default Model.extend({
  namespace: 'TrailerManage',

  state: {
    loading: { list: false },
    tableFields,
    search: initialSearch,
    searchSite,
    total: 0,
    list: [],
    orderCounts: [],
    siteList: [],
    isShowAddOrEditModal: false
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.TRAILER_MANAGE, async () => {
        await dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ TrailerManage }) => TrailerManage);
      const { datas, tc } = yield call(withLoading(getList, 'list'), search);
      yield update({ list: datas, total: tc });
    },
    * getSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getSiteList, 'list'), payload);
      yield update({ siteList: datas });
    },
    // 禁用车辆
    * cancelWayBill({ payload }, { call, put }) {
      const truckId = payload;
      yield call(withLoading(cancelWayBill, { successMsg: '车辆已禁用！', key: 'cancelWayBill' }), { truckId });
      yield put({ type: 'getList' });
    },
    // 启用车辆
    * enableSite({ payload }, { call, put }) {
      const truckId = payload;
      yield call(withLoading(enableSite, { successMsg: '车辆已启用！', key: 'enableSite' }), { truckId });
      yield put({ type: 'getList' });
    },

    //  新增车辆
    * creatSite({ payload }, { call, put }) {
      yield call(withLoading(creatSite, { successMsg: '车辆新增成功！', key: 'creatSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },

    //  修改车辆
    * editSite({ payload }, { call, put }) {
      yield call(withLoading(editSite, { successMsg: '车辆修改成功！', key: 'editSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: initialSearch
      };
    },
  },
});
