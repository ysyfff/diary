import { Button, Form, Input, Select } from 'antd';
import { driverStatus, belongTypes } from 'configs/constants';

const FormItem = Form.Item;
const Option = Select.Option;


class SearchBar extends React.Component {
  state = {
    ...this.props.search,
  }

  componentWillReceiveProps = (props) => {
    this.setState({
      ...props.search
    });
  }

  // 查询
  handleSearch = () => {
    const { onSearch } = this.props;
    const search = this.state;
    onSearch({ ...search, pn: 1 });
  }
  // 重置
  handleReset = () => {
    const { onReset, form } = this.props;
    const { resetFields } = form;
    onReset();
    resetFields();
    this.setState({
      pn: 1,
      ps: 10,
      truckType: '',
      plateNumber: '',
      effective: '',
    });
  }

  handleChange(key) {
    return (value) => {
      let newValue = value;
      if (value && value.target) {
        newValue = value.target.value;
      }
      this.setState({ [key]: newValue });
    };
  }
  render() {
    const search = this.state;

    return (
      <div>
        <div className="searchBar">
          <Form layout="inline" >
            <FormItem label="车辆归属">
              <Select
                defaultValue=""
                style={{ width: 170 }}
                value={search.belongType}
                onChange={this.handleChange('belongType')}
              >
                <Option value="">全部</Option>
                {
                  belongTypes.map(option => (
                    <Option
                      key={option.key}
                      value={option.key}
                    >
                      {option.value}
                    </Option>
                  ))
                }
              </Select>
            </FormItem>
            <FormItem label="车牌号">
              <Input
                placeholder="输入车牌号查询"
                value={search.plateNumber}
                onChange={this.handleChange('plateNumber')}
              />
            </FormItem>
            <FormItem label="状态">
              <Select
                defaultValue=""
                style={{ width: 170 }}
                value={search.effective}
                onChange={this.handleChange('effective')}
              >
                <Option value="">全部</Option>
                {
                  driverStatus.map(option => (
                    <Option
                      key={option.key}
                      value={option.key}
                    >
                      {option.value}
                    </Option>
                  ))
                }
              </Select>
            </FormItem>
            <FormItem label="">
              <Button type="primary" onClick={this.handleSearch}>搜索</Button>
              <Button onClick={this.handleReset}>重置</Button>
            </FormItem>
          </Form>
        </div>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
