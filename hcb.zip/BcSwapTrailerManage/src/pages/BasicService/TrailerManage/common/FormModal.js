import { Form, Modal, Input, InputNumber, DatePicker, Select } from 'antd';
import { regPhone, belongTypes, driverType, steerType, plateNumberType } from 'configs/constants';
import moment from 'moment';

const { TextArea } = Input;
const FormItem = Form.Item;
const Option = Select.Option;


// 格式化数据
const formatData = (values = {}) => {
  const catchValues = { ...values };
  delete catchValues.regionId;
  return {
    ...catchValues,
  };
};

class FormModal extends React.Component {
  state = {
  }

  componentWillReceiveProps = (_props) => {
    if (_props.visible === false) {
      const { resetFields } = _props.form;
      resetFields();
    }
  }

  onBlurSite = () => {
    const { getSiteList } = this.props;
    getSiteList();
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, creatSite, editSite, title, siteMsg = {}, siteList = [] } = this.props;
    const { validateFields } = form;
    validateFields((err, values) => {
      if (!err) {
        const data = formatData(values);
        // 删除所有没有值的字段
        const keys = Object.keys(data);
        keys.forEach((key) => {
          if (data[key] === 0) return;
          if (!data[key]) delete data[key];
        });
        const site = (siteList || []).filter(item => item.name === data.reportSiteName)[0];
        if (site) data.reportSiteId = site.id;
        if (data.contractDate) {
          data.contractDate = data.contractDate.format('YYYY-MM-DD');
        }
        if (data.annualVerifyDate) {
          data.annualVerifyDate = data.annualVerifyDate.format('YYYY-MM-DD');
        }
        if (data.businessAnnualVerifyDate) {
          data.businessAnnualVerifyDate = data.businessAnnualVerifyDate.format('YYYY-MM-DD');
        }
        if (data.fleetReportDate) {
          data.fleetReportDate = data.fleetReportDate.format('YYYY-MM-DD');
        }
        if (data.fleetDeliverDate) {
          data.fleetDeliverDate = data.fleetDeliverDate.format('YYYY-MM-DD');
        }
        if (data.firstExecTaskDate) {
          data.firstExecTaskDate = data.firstExecTaskDate.format('YYYY-MM-DD');
        }
        if (title === '新增') {
          creatSite(data);
        } else if (title === '修改') {
          editSite({
            ...data,
            id: siteMsg.id
          });
        }
      }
    });
  }

  cancelModals = () => {
    const { cancel, form } = this.props;
    const { resetFields } = form;
    resetFields();
    cancel();
  }

  render() {
    const { form, visible, title, siteMsg = {}, loading, siteList = [], getSiteList } = this.props;
    const { getFieldDecorator } = form;

    const _siteList = [];
    (siteList || []).forEach((item) => {
      _siteList.push(<Option value={item.name} key={item.id}>{item.name}</Option>);
    });

    return (
      <Modal
        width={1100}
        title={`${title}车辆`}
        visible={visible}
        onCancel={this.cancelModals}
        maskClosable={false}
        onOk={this.handleSubmit}
        confirmLoading={title === '修改' ? loading.editSite : loading.creatSite}
      >
        <Form layout="inline" >
          <div className="trailer-manage" >
            <FormItem
              label="车牌号"
            >
              {getFieldDecorator('plateNumber', {
                placeholder: '',
                initialValue: siteMsg.plateNumber,
                rules: [
                  { required: true, message: '请输入车牌号！' },
                  {
                    pattern: new RegExp('^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川' +
                        '宁琼使领a-zA-Z]{1}[a-zA-Z]{1}[a-zA-Z0-9]{3}[-]{0,1}[a-zA-Z0-9]{1,2}[a-zA-Z0-9挂学警港澳]{1}$'),
                    message: '车牌号格式不正确'
                  }
                ]
              })(
                <Input disabled={title === '修改'} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车辆归属"
            >
              {getFieldDecorator('belongTypeEnum', {
                initialValue: siteMsg.belongType || 'PARTNER',
                rules: [
                  { required: true, message: '请选择车辆归属！' },
                ]
              })(
                <Select style={{ width: 171 }}>
                  {
                    belongTypes.map(option => (
                      <Option
                        key={option.key}
                        value={option.key}
                      >
                        {option.value}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <FormItem
              label="常用线路"
            >
              {getFieldDecorator('useLineEnum', {
                initialValue: siteMsg.useLine || '',
                rules: [
                  { required: true, message: '请选择常用线路！' },
                ]
              })(
                <Select style={{ width: 171 }}>
                  {
                    driverType.map(option => (
                      <Option
                        key={option.key}
                        value={option.key}
                      >
                        {option.value}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <FormItem
              label="车头品牌"
            >
              {getFieldDecorator('truckBrand', {
                placeholder: '',
                initialValue: siteMsg.truckBrand
              })(
                <Input maxLength={10} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="马力"
            >
              {getFieldDecorator('horsepower', {
                placeholder: '',
                initialValue: siteMsg.horsepower
              })(
                <InputNumber max={1000} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车辆类型"
            >
              {getFieldDecorator('steerType', {
                initialValue: siteMsg.steerType || '',
              })(
                <Select allowClear style={{ width: 171 }}>
                  {
                    steerType.map(option => (
                      <Option
                        key={option.key}
                        value={option.key}
                      >
                        {option.value}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <FormItem
              label="车主姓名"
            >
              {getFieldDecorator('ownerName', {
                placeholder: '',
                initialValue: siteMsg.ownerName
              })(
                <Input maxLength={10} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车主电话"
            >
              {getFieldDecorator('ownerPhone', {
                placeholder: '',
                initialValue: siteMsg.ownerPhone,
                rules: [
                  {
                    pattern: regPhone,
                    message: '请输入正确的联系电话！'
                  }
                ]
              })(
                <Input style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车牌颜色"
            >
              {getFieldDecorator('plateNumberType', {
                placeholder: '',
                initialValue: siteMsg.plateNumberType || 0,
                rules: [
                  { required: true, message: '请选择车牌颜色！' }
                ]
              })(
                <Select
                  disabled={title === '修改'}
                  style={{ width: 171 }}
                >
                  {
                    plateNumberType.map(option => (
                      <Option
                        key={option.value}
                        value={option.value}
                      >
                        {option.key}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <br />
            <FormItem
              label="司机姓名"
            >
              {getFieldDecorator('driverName', {
                placeholder: '',
                initialValue: siteMsg.driverName
              })(
                <Input maxLength={10} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="司机电话"
            >
              {getFieldDecorator('driverPhone', {
                placeholder: '',
                initialValue: siteMsg.driverPhone,
                rules: [
                  {
                    pattern: regPhone,
                    message: '请输入正确的联系电话！'
                  }
                ]
              })(
                <Input style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="GPS设备"
            >
              {getFieldDecorator('gpsNo', {
                placeholder: '',
                initialValue: siteMsg.gpsNo
              })(
                <Input maxLength={20} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="报道场地"
            >
              {getFieldDecorator('reportSiteName', {
                placeholder: '',
                initialValue: siteMsg.reportSiteName || '',
              })(
                <Select
                  allowClear
                  style={{ width: 171 }}
                  showSearch
                  onBlur={this.onBlurSite}
                  onSearch={value => getSiteList({ nameLike: value })}
                >
                  {_siteList}
                </Select>
              )}
            </FormItem>
            <FormItem
              label="油箱（L）"
            >
              {getFieldDecorator('tank', {
                placeholder: '',
                initialValue: siteMsg.tank
              })(
                <InputNumber max={9999} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="司机状态"
            >
              {getFieldDecorator('driverStatus', {
                placeholder: '',
                initialValue: siteMsg.driverStatus
              })(
                <Input maxLength={10} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="签约日期"
            >
              {getFieldDecorator('contractDate', {
                placeholder: '',
                initialValue: (siteMsg.contractDate ? moment(siteMsg.contractDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车辆年审日期"
            >
              {getFieldDecorator('annualVerifyDate', {
                placeholder: '',
                initialValue: (siteMsg.annualVerifyDate ? moment(siteMsg.annualVerifyDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <br />
            <FormItem
              label="运营证年审日期"
            >
              {getFieldDecorator('businessAnnualVerifyDate', {
                placeholder: '',
                initialValue: (siteMsg.businessAnnualVerifyDate ? moment(siteMsg.businessAnnualVerifyDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车队报道日期"
            >
              {getFieldDecorator('fleetReportDate', {
                placeholder: '',
                initialValue: (siteMsg.fleetReportDate ? moment(siteMsg.fleetReportDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <br />
            <FormItem
              label="车队交付日期"
            >
              {getFieldDecorator('fleetDeliverDate', {
                placeholder: '',
                initialValue: (siteMsg.fleetDeliverDate ? moment(siteMsg.fleetDeliverDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="车辆首次执行任务日期"
            >
              {getFieldDecorator('firstExecTaskDate', {
                placeholder: '',
                initialValue: (siteMsg.firstExecTaskDate ? moment(siteMsg.firstExecTaskDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <br />
            <FormItem
              label="备注"
            >
              {getFieldDecorator('remark', {
                placeholder: '',
                initialValue: siteMsg.remark,
              })(
                <TextArea maxLength="20" style={{ width: 845 }} />
              )}
            </FormItem>
          </div>
        </Form>
      </Modal>
    );
  }
}
export default Form.create()(FormModal);
