import http from 'utils/http';

const { post } = http.create('admin');

// 获取站点列表
export function getList(param) {
  return post('/web/e/site/list', param);
}

//  禁用站点
export function cancelWayBill(param) {
  return post('/web/e/site/remove', param);
}

// 启用站点
export function enableSite(param) {
  return post('/web/e/site/enable', param);
}

//  新增站点
export function creatSite(param) {
  return post('/web/e/site/create', param);
}

// 修改站点
export function editSite(param) {
  return post('/web/e/site/update', param);
}

