import { Form, Row, Col, Modal, Input } from 'antd';
import { HCityPicker, regionService } from 'carno';
import { _ } from 'carno/third-party';
import { reginIdSplit } from 'utils';


const FormItem = Form.Item;
const { getMapData } = regionService;
export const SITE = getMapData();


// 格式化数据
const formatData = (values = {}) => {
  const catchValues = { ...values };
  const { regionId } = values;
  delete catchValues.regionId;
  const { provinceId: province, cityId: city, countyId: county } = reginIdSplit(regionId[0].id);
  return {
    ...catchValues,
    province,
    city,
    county
  };
};

// 显示城市
const getRegionName = (id = '', step = '-', fullName = true) => {
  const idStr = id ? id.toString() : '';
  const fullNames = [];
  let name = '';

  if (idStr.length >= 2) {
    const provinceId = idStr.substr(0, 2);
    name = SITE[provinceId];
    fullNames.push(name);
  }
  if (idStr.length >= 4) {
    const cityId = idStr.substr(0, 4);
    name = SITE[cityId];
    fullNames.push(name);
  }
  if (idStr.length >= 6) {
    const countyId = idStr.substr(0, 6);
    name = SITE[countyId];
    countyId === '120119' && (name = '滨海新区');
    fullNames.push(name);
  }

  return fullName ? _.uniq(fullNames).join(step) : name;
};

class FormModal extends React.Component {
  state = {
  }

  componentWillReceiveProps = (_props) => {
    if (_props.visible === false) {
      const { resetFields } = _props.form;
      resetFields();
    }
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, creatSite, editSite, title, siteMsg = {} } = this.props;
    const { validateFields } = form;
    validateFields((err, values) => {
      if (!err) {
        const data = formatData(values);
        if (title === '新增') {
          creatSite(data);
        } else if (title === '修改') {
          editSite({
            ...data,
            id: siteMsg.id
          });
        }
      }
    });
  }

  cancelModals = () => {
    const { cancel, form } = this.props;
    const { resetFields } = form;
    resetFields();
    cancel();
  }

  render() {
    const { form, visible, title, siteMsg = {}, loading } = this.props;
    const { getFieldDecorator } = form;

    const fromId = siteMsg.county || siteMsg.city || siteMsg.province;
    const regionValue = [{ id: +fromId, name: getRegionName(fromId, '') }] || [];

    return (
      <Modal
        width="60%"
        title={`${title}站点`}
        visible={visible}
        onCancel={this.cancelModals}
        maskClosable={false}
        onOk={this.handleSubmit}
        confirmLoading={loading.creatSite}
      >
        <Form layout="inline" >
          <Row gutter={24}>
            <Col span={12}>
              <FormItem
                label="站点名称"
              >
                {getFieldDecorator('name', {
                  placeholder: '',
                  initialValue: siteMsg.name,
                  rules: [{ required: true, message: '请输入站点名称！' }]
                })(
                  <Input maxLength="20" />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                label="省市区"
              >
                {getFieldDecorator('regionId', {
                  placeholder: '',
                  initialValue: title === '修改' ? regionValue : [],
                  rules: [{ required: true, message: '请选择省市区！' }]
                })(
                  <HCityPicker
                    multiple={false}
                    provinceBatch={false}
                    cityBatch={false}
                    areaBatch={false}
                  />
                )}
              </FormItem>
            </Col>
          </Row>

          <Row gutter={24}>
            <Col span={12}>
              <FormItem
                label="站点编码"
              >
                {getFieldDecorator('code', {
                  placeholder: '',
                  initialValue: siteMsg.code,
                  rules: [{ required: true, message: '请输入站点编码！' }]
                })(
                  <Input maxLength="20" />
                )}
              </FormItem>
            </Col>
          </Row>

          <Row gutter={24}>
            <Col span={24}>
              <FormItem
                label="详细地址"
              >
                {getFieldDecorator('addrsss', {
                  placeholder: '',
                  initialValue: siteMsg.addrsss,
                  rules: [{ required: true, message: '请输入详细地址！' }]
                })(
                  <Input style={{ width: '300px' }} maxLength="50" />
                )}
              </FormItem>
            </Col>
          </Row>
        </Form>
      </Modal>
    );
  }
}
export default Form.create()(FormModal);
