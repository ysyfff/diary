import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getList, cancelWayBill, creatSite, editSite, enableSite } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  code: '',
  name: '',
  nameLike: '',
  codeLike: '',
};

const searchSite = {
  pn: 1,
  ps: 1000,
  code: '',
  name: '',
  nameLike: '',
  codeLike: '',
};

export default Model.extend({
  namespace: 'SiteManage',

  state: {
    loading: { list: false },
    tableFields,
    search: initialSearch,
    searchSite,
    total: 0,
    list: [],
    orderCounts: [],
    siteList: [],
    isShowAddOrEditModal: false
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.SITE_MANAGE, () => {
        dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ SiteManage }) => SiteManage);
      const { datas, tc } = yield call(withLoading(getList, 'list'), search);
      yield update({ list: datas, total: tc });
    },

    // 禁用站点
    * cancelWayBill({ payload }, { call, put }) {
      const id = payload;
      yield call(withLoading(cancelWayBill, { successMsg: '站点已禁用！', key: 'cancelWayBill' }), { id });
      yield put({ type: 'getList' });
    },
    // 启用站点
    * enableSite({ payload }, { call, put }) {
      const id = payload;
      yield call(withLoading(enableSite, { successMsg: '站点已启用！', key: 'enableSite' }), { id });
      yield put({ type: 'getList' });
    },

    //  新增站点
    * creatSite({ payload }, { call, put }) {
      yield call(withLoading(creatSite, { successMsg: '站点新增成功！', key: 'creatSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },

    //  修改站点
    * editSite({ payload }, { call, put }) {
      yield call(withLoading(editSite, { successMsg: '站点修改成功！', key: 'editSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: initialSearch
      };
    },
  },
});
