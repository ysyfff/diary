import { connect } from 'dva';
import { Row, Col, Button, Popover, Icon, Modal } from 'antd';
import { HTable } from 'carno';
import SearchBar from './common/SearchBar';
import FormModal from './common/FormModal';
import styles from './index.less';

const confirm = Modal.confirm;

@connect(({ SiteManage }) => ({ ...SiteManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'SiteManage/updateSearch', payload: param });
    dispatch({ type: 'SiteManage/getList' });
  },
  onReset() {
    dispatch({ type: 'SiteManage/resetSearch' });
    dispatch({ type: 'SiteManage/getList' });
  },
  cancelWayBill: (param) => {
    dispatch({ type: 'SiteManage/cancelWayBill', payload: param });
  },
  creatSite: (param) => {
    dispatch({ type: 'SiteManage/creatSite', payload: param });
  },
  editSite: (param) => {
    dispatch({ type: 'SiteManage/editSite', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'SiteManage/updateState', payload: param });
  },
  enableSite: (param) => {
    dispatch({ type: 'SiteManage/enableSite', payload: param });
  },
}))
export default class SiteManage extends React.Component {
  state = {
    visible: false,
    title: '',
    siteMsg: '',
    visiblepop: []
  }

  getProps() {
    const { tableFields, search, total, list, loading, getList, cancelWayBill, enableSite } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'buyerName',
            name: '操作',
            render: (record, data) => !(data.state === 'CANCEL' || data.state === 'TRANSPORTING') && <Popover
              placement="right"
              overlayStyle={{ zIndex: 999 }}
              content={
                <div>
                  <ul className="table-operate-button">
                    {/* <li><a onClick={() => this.editSite('修改', data)}>修改</a></li> */}
                    <li>
                      <a onClick={() => confirm({
                        title: `是否${data.effective ? '禁用' : '启用'}站点：${data.name}站, 站点编号：${data.code}`,
                        content: '',
                        onOk() {
                          if (data.effective) {
                            cancelWayBill(data.id);
                          } else {
                            enableSite(data.id);
                          }
                        },
                        onCancel() {
                          console.log('Cancel'); // eslint-disable-line
                        },
                      })}
                      >{data.effective ? '禁用' : '启用'}</a>
                    </li>
                  </ul>
                </div>
              }
            ><a><Icon type="menu-unfold" /></a></Popover>
          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 1200 },
        pagination,
        locale: { emptyText: '暂无站点信息' },
        style: { marginTop: 16 },
      },
    };
  }

  handleSearch(search) {
    this.props.getList(search);
  }

  addSite = (msg) => {
    const { updateState } = this.props;
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg
    });
  }

  editSite = (msg, data) => {
    const { updateState } = this.props;
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg,
      siteMsg: data
    });
  }

  closeModal = () => {
    const { updateState } = this.props;
    updateState({ isShowAddOrEditModal: false });
    this.setState({
      title: '',
      siteMsg: ''
    });
  }

  render() {
    const { getList, search, siteList, onReset, creatSite, editSite, isShowAddOrEditModal, loading } = this.props;
    const { title, siteMsg } = this.state;
    const { tableProps } = this.getProps();

    const SearchBarProps = {
      search,
      onSearch: getList,
      siteList,
      onReset
    };

    const ModalProps = {
      visible: isShowAddOrEditModal,
      title,
      cancel: this.closeModal,
      creatSite,
      siteMsg,
      editSite,
      loading
    };

    return (
      <div className={styles['waybill-manage']}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="end">
          <Col span={6} >
            <div className="order-list-button" style={{ textAlign: 'right' }}>
              <Button type="primary" onClick={() => this.addSite('新增')}>新增站点</Button>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
        <FormModal {...ModalProps} />
      </div>
    );
  }
}
