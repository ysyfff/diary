import { regionService } from 'carno';
import { _ } from 'carno/third-party';
import { Popover } from 'antd';

const defultKey = '--';

const formatValue = (value) => {
  if (value !== '' && value !== undefined && value !== null) {
    if (value.length > 10) {
      return (
        <Popover content={value}>
          <span>{`${value.substr(0, 10)}...`}</span>
        </Popover>
      );
    }
    return value;
  }
  return defultKey;
};

const { getMapData } = regionService;
export const SITE = getMapData();

// 显示城市
const getRegionName = (id = '', step = '-', fullName = true) => {
  const idStr = id ? id.toString() : '';
  const fullNames = [];
  let name = '';

  if (idStr.length >= 2) {
    const provinceId = idStr.substr(0, 2);
    name = SITE[provinceId];
    fullNames.push(name);
  }
  if (idStr.length >= 4) {
    const cityId = idStr.substr(0, 4);
    name = SITE[cityId];
    fullNames.push(name);
  }
  if (idStr.length >= 6) {
    const countyId = idStr.substr(0, 6);
    name = SITE[countyId];
    countyId === '120119' && (name = '滨海新区');
    fullNames.push(name);
  }

  return fullName ? _.uniq(fullNames).join(step) : name;
};

export const tableFields = [{
  key: 'code',
  width: 150,
  name: '站点编码',
}, {
  key: 'buyerName',
  width: 80,
  name: '操作',
},
{
  key: 'effective',
  name: '站点状态',
  width: 150,
  render: a => a ? '启用' : '禁用'
},
{
  key: 'name',
  name: '站点名称',
  render: formatValue
},
{
  key: 'state',
  name: '站点所属省/市/区',
  render: (a, b = {}) => {
    const fromId = b.county || b.city || b.province;
    const regionValue = [{ id: +fromId, name: getRegionName(fromId, '') }];
    return regionValue && regionValue[0].name;
  }
}, {
  key: 'addrsss',
  name: '站点详细地址',
  render: formatValue
}, {
  key: 'createUserName',
  name: '添加人',
}, {
  key: 'createTime',
  name: '添加时间',
}];

