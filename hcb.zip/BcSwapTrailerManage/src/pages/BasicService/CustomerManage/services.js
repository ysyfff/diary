import http from 'utils/http';

const { post } = http.create('dapt');

// 客户列表
export function getList(param) {
  // return post('/web/e/customer/list', param, { useMockProxyType: 1 });
  return post('/web/e/customer/list', param);
}

// 禁用
export function forbCustomer(param) {
  return post('/web/e/customer/remove', param);
}

// 启用
export function enableCustomer(param) {
  return post('/web/e/customer/enable', param);
}

// 客户新增
export function createCustomer(param) {
  return post('/web/e/customer/create', param, {
    contentType: 'json'
  });
}

export function updateCustomer(param) {
  return post('/web/e/customer/update', param, {
    contentType: 'json'
  });
}

// 充值记录
export function getRechHistory(param) {
  return post('/web/m/customer/rech/list', param);
}

// 充值记录保存
export function rechSave(param) {
  return post('/web/m/customer/rech/save', param);
}
// 合同线路列表
export function linepriceList(param) {
  return post('/web/m/lineprice/list', { ...param, ps: 1000 });
}

// 合同线路类型
export function linetypeList(param) {
  return post('/web/m/linetype/list', param);
}

