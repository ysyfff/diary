import { connect } from 'dva';
import {
  Row, Col, Button, Popover, Icon, Modal, Input,
  Form, DatePicker, InputNumber, Select, message, Radio
} from 'antd';
import moment from 'moment';
import { HTable, HCityPicker } from 'carno';
import { bind } from 'bind-decorator';
import _ from 'lodash';
import { getRegionName, reginIdSplit, downFile } from 'utils';
import { Link } from 'dva/router';
import { regPhone, Paths } from 'configs/constants';
import EllipsisRecord from 'components/common/EllipsisRecord';
import SearchBar from './SearchBar';
import styles from './index.less';

const confirm = Modal.confirm;
const FormItem = Form.Item;
const Option = Select.Option;

function range(start, end) {
  const result = [];
  for (let i = start; i < end; i += 1) {
    result.push(i);
  }
  return result;
}

@connect(({ customerManage }) => ({ ...customerManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'customerManage/updateSearch', payload: param });
    dispatch({ type: 'customerManage/getList' });
  },
  exportList() {
    dispatch({ type: 'customerManage/exportList' });
  },
  updateState(param) {
    dispatch({ type: 'customerManage/updateState', payload: param });
  },
  resetSearch() {
    dispatch({ type: 'customerManage/resetSearch' });
  },
  updateSearch(param) {
    dispatch({ type: 'customerManage/updateSearch', payload: param });
  },
  forbCustomer(param) {
    dispatch({ type: 'customerManage/forbCustomer', payload: param });
  },
  enableCustomer(param) {
    dispatch({ type: 'customerManage/enableCustomer', payload: param });
  },
  createCustomer(param) {
    return dispatch({ type: 'customerManage/createCustomer', payload: param });
  },
  updateCustomer(param) {
    return dispatch({ type: 'customerManage/updateCustomer', payload: param });
  },
  updateRechSearch(param) {
    dispatch({ type: 'customerManage/updateRechSearch', payload: param });
  },
  getRechHistory() {
    dispatch({ type: 'customerManage/getRechHistory' });
  },
  rechSave(param) {
    dispatch({ type: 'customerManage/rechSave', payload: param });
  },
  getLinepriceList(param) {
    dispatch({ type: 'customerManage/getLinepriceList', payload: param });
  },
}))
class CustomerManage extends React.Component {
  state = {
    nowAction: '新增',
    visiblepop: [],
    isShowRechargeHistoryModal: false,
    isShowRechargeModal: false,
    rechTime: moment().format('YYYY-MM-DD HH:mm:ss'),
    mount: '',
    customerId: ''
  }

  componentWillReceiveProps(a) {
    if (a.list) {
      this.setState({
        visiblepop: a.list.map(() => false)
      });
    }
  }

  onRechChange = (value) => {
    // debugger
    const rechTime = value.format('YYYY-MM-DD HH:mm:ss');
    this.setState({
      rechTime
    });
  }

  onChangeMount = (value) => {
    this.setState({
      mount: value
    });
  }


  onRechSave = () => {
    const { rechSave } = this.props;
    const { rechTime, mount, customerId } = this.state;
    if (!mount) {
      Modal.error({ title: '请填写充值金额' });
      return;
    }
    rechSave({ customerId, amount: mount, rechargeTime: rechTime });
    this.setState({
      isShowRechargeModal: false
    });
  }

  getProps() {
    const { rechTableFields, tableFields, search, rechSearch, total, rechTotal, list, rechList, loading,
      getList } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    const rechPagination = {
      current: rechSearch.pn,
      pageSize: rechSearch.ps,
      total: rechTotal,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => this.getRechHistory({ pn }),
      onShowSizeChange: (current, size) => this.getRechHistory({ ps: size, pn: 1 })
    };

    // const columns = {
    //   key: 'recharge',
    //   name: '充值',
    //   width: 100,
    //   render: (a, b) => <a onClick={() => this.showRechargeHistoryModal(b.id)}>查看明细</a>
    // };

    // const _tableFields = _.cloneDeep(tableFields);

    // _tableFields.splice(10, 0, columns);

    return {
      rechTableProps: {
        fields: rechTableFields,
        dataSource: rechList,
        loading: loading.list,
        search: rechSearch,
        pagination: rechPagination,
        locale: { emptyText: '暂无数据' },
        style: { marginTop: 16 },
      },
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'companyName',
            render: (v, row) => (
              <Link to={`/baseService/customerManage/detail/${row.id}`} target="_blank">
                <EllipsisRecord cursor="pointer" record={v || '--'} width={150} />
              </Link>
            )
          },
          {
            key: 'action',
            name: '操作',
            render: (a, b, i) => (<Popover
              placement="right"
              trigger="hover"
              visible={this.state.visiblepop[i]}
              onVisibleChange={() => this.changePop(i, false)}
              content={
                <div onClick={() => this.changePop(i, false)}>
                  <ul className="operate-button" >
                    <li>
                      {/* <a onClick={() => this.showAddOrEditModal(b, '编辑')}>修改</a></li> */}
                      <Link to={`/baseService/customerManage/create?id=${b.id}`} target="_blank">修改客户</Link></li>
                    <li>
                      <Link to={`/baseService/customerManage/detail/${b.id}`} target="_blank">客户详情</Link></li>
                    <li>
                      {
                        (b.effective === 0)
                          ? (<a onClick={() => this.changeCustomerStatus(b, 1)}>启用客户</a>)
                          : null
                      }
                      {
                        (b.effective === 1)
                          ? (<a onClick={() => this.changeCustomerStatus(b, 0)}>禁用客户</a>)
                          : null
                      }
                    </li>
                    <li>
                      <a onClick={() => this.showRechargeModal(b.id)}>客户充值</a>
                    </li>
                    <li>
                      <a onClick={() => this.showRechargeHistoryModal(b.id)}>充值明细</a>
                    </li>
                  </ul>
                </div>
              }
            ><a><Icon type="menu-unfold" onMouseOver={() => this.changePop(i, true)} /></a></Popover>
            )
          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 2700 },
        pagination,
        locale: { emptyText: '暂无数据' },
      },
    };
  }

  getRechHistory = (param = {}) => {
    const { getRechHistory, updateRechSearch, rechSearch } = this.props;
    updateRechSearch({ ...rechSearch, ...param });
    getRechHistory();
  }

  exportList = () => {
    const { search, pureParams } = this.props;

    downFile({
      server: 'admin',
      url: '/web/e/customer/export',
      params: pureParams(search)
    });
  }

  showRechargeHistoryModal = (customerId) => {
    const { updateRechSearch, getRechHistory } = this.props;
    updateRechSearch({ customerId });
    getRechHistory();
    this.setState({
      isShowRechargeHistoryModal: true
    });
  }

  cancelRechargeHistoryModal = () => {
    this.setState({
      isShowRechargeHistoryModal: false
    });
  }

  showRechargeModal = (customerId) => {
    this.setState({
      customerId,
      isShowRechargeModal: true
    });
  }

  cancelRechargeModal = () => {
    this.setState({
      mount: null,
      rechTime: moment().format('YYYY-MM-DD HH:mm:ss'),
      isShowRechargeModal: false
    });
  }

  @bind
  changeCustomerStatus(customer, stat) {
    const { forbCustomer, enableCustomer } = this.props;
    // const title = (stat === 0 ? '禁用' : (stat === 1 ? '启用' : ''));
    let title = '';
    if (stat === 0) {
      title = '禁用';
    } else if (stat === 1) {
      title = '启用';
    }
    confirm({
      title: `${title}客户`,
      content: `是否${title}该客户，客户编号${customer.code}`,
      okText: '确定',
      cancelText: '取消',
      onOk() {
        if (stat === 0) {
          forbCustomer({ id: customer.id });
        } else if (stat === 1) {
          enableCustomer({ id: customer.id });
        }
      },
      onCancel() { }
    });
  }

  @bind
  showAddOrEditModal(nowCheckCustomer, nowAction) {
    const { updateState } = this.props;
    updateState({ nowCheckCustomer, isShowAddOrEditModal: true });

    this.setState({
      nowAction
    });
  }

  @bind
  handleConfirm() {
    const { createCustomer, updateCustomer, form } = this.props;
    const { nowAction } = this.state;
    const { resetFields } = form;

    form.validateFields((err, value) => {
      if (!err) {
        const { linetypeList, nowCheckCustomer } = this.props;
        const { cityId, countyId, provinceId } = reginIdSplit(value.proviceId[0].id);
        const lineTypeName = _(linetypeList).find({ id: value.lineType });
        const param = {
          ...value,
          cityId,
          countyId,
          proviceId: provinceId,
          lineTypeName: lineTypeName.name,
          linePriceList: value.linePriceList.map(linePriceId => ({ linePriceId }))
        };
        delete param.provinceId;
        if (nowAction === '新增') {
          createCustomer(param).then(() => resetFields());
        } else if (nowAction === '编辑') {
          updateCustomer({ ...param, id: nowCheckCustomer.id }).then(() => resetFields());
        }
      }
    });
  }

  @bind
  handleCancel() {
    const { form, updateState } = this.props;
    const { resetFields } = form;
    updateState({ nowCheckCustomer: {}, isShowAddOrEditModal: false });
    resetFields();
  }


  @bind
  handleChangeCustomerType(e) {
    this.props.updateSearch({ lineType: e.target.value, pn: 1 });
    this.props.getList();
  }

  @bind
  handleChangeLinePrice(value = []) {
    // console.log(value);
    const { form } = this.props;
    if (value.length > 20) {
      message.error('最多选择20条线路');
      form.setFieldsValue({ linePriceList: value.slice(0, -1) });
    }
  }

  @bind
  handleChangeLineType() {
    const { form } = this.props;
    form.setFieldsValue({ linePriceList: [] });
  }

  @bind
  changePop(i, status) {
    const { visiblepop } = this.state;
    let _visiblepop = visiblepop.slice();
    _visiblepop = _visiblepop.map(() => false);
    _visiblepop.splice(i, 1, status);
    this.setState({
      visiblepop: _visiblepop
    });
  }

  disabledStartDate = current => current && current < moment().startOf('day')

  disabledStartTime = () => ({
    disabledHours: () => range(0, new Date().getHours()),
    disabledMinutes: () => range(0, new Date().getMinutes())
  })


  render() {
    const { getList, resetSearch, updateSearch, search, form, contractList, linetypeList, history } = this.props;
    const { getFieldDecorator, getFieldValue } = form;
    const SearchBarProps = {
      search,
      updateSearch,
      resetSearch,
      contractList,
      onSearch: getList
    };

    const { tableProps, rechTableProps } = this.getProps();
    const { nowCheckCustomer, isShowAddOrEditModal } = this.props;

    const fromId = nowCheckCustomer.countyId || nowCheckCustomer.cityId || nowCheckCustomer.proviceId;
    const loadValue = nowCheckCustomer.proviceId ? [{ id: +fromId, name: getRegionName(fromId, '') }] : [];

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
        offset: 2
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

    const formItemForNameLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };
    const formItemForshortNameLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
        offset: 1
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };


    return (
      <div className={styles.customer}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="space-between" style={{ marginBottom: 20 }}>
          <Col span={12} >
            <Form layout="inline" >
              <FormItem >
                <Radio.Group onChange={this.handleChangeCustomerType} value={search.lineType} buttonStyle="solid">

                  {
                    [{ id: '', name: '全部' }, ...linetypeList].map(({ id, name }) =>
                      <Radio.Button
                        key={id}
                        value={id}
                      >
                        {`${name}${id && '类客户'}`}
                      </Radio.Button>
                    )
                  }
                </Radio.Group>
              </FormItem>
            </Form>
          </Col>
          <Col span={12}>
            <div className="order-list-button" style={{ textAlign: 'right' }}>
              <Form layout="inline" >
                <FormItem>
                  {/* <Button type="primary" onClick={() => this.showAddOrEditModal({}, '新增')}>新建客户</Button> */}
                  <Button type="primary">
                    <Link to="/baseService/customerManage/create" target="_blank">新建客户</Link>
                  </Button>
                </FormItem>
                <FormItem>
                  <Button onClick={() => history.push(Paths.CONTRACT_PATH_MANAGE)}>合同线路管理</Button>
                </FormItem>
                <FormItem>
                  <Button onClick={this.exportList}>导出表单</Button>
                </FormItem>
              </Form>
            </div>
          </Col>
        </Row>

        <HTable {...tableProps} />

        <Modal
          title={`${this.state.nowAction}客户`}
          visible={isShowAddOrEditModal}
          onOk={this.handleConfirm}
          onCancel={this.handleCancel}
          width={700}
          maskClosable={false}
        >
          <Form layout="inline" >
            <FormItem label="发货公司" {...formItemLayout}>
              {
                getFieldDecorator('companyName', {
                  initialValue: nowCheckCustomer.companyName,
                  rules: [{ required: true, message: '请输入客户单位' }],
                })(
                  <Input
                    style={{ width: 180 }}
                    minLength={1}
                    maxLength={50}
                    placeholder="请输入客户单位"
                  />
                )}
            </FormItem>
            <FormItem label="客户编号" {...formItemLayout}>
              {
                getFieldDecorator('code', {
                  rules: [{ required: true, message: '请输入客户编号' }],
                  initialValue: nowCheckCustomer.code
                })(
                  <Input
                    style={{ width: 180 }}
                    disabled={this.state.nowAction === '编辑'}
                    minLength={1}
                    maxLength={20}
                    placeholder="请输入客户编号"
                  />
                )}
            </FormItem>
          </Form>
          <Form layout="inline" >
            <FormItem label="发货人姓名" {...formItemLayout}>
              {
                getFieldDecorator('name', {
                  rules: [{ required: true, message: '请输入发货人姓名' }],
                  initialValue: nowCheckCustomer.name
                })(
                  <Input
                    style={{ width: 180 }}
                    minLength={1}
                    maxLength={20}
                    placeholder="请输入发货人姓名"
                  />
                )}
            </FormItem>
            <FormItem label="公司简称" {...formItemForshortNameLayout}>
              {
                getFieldDecorator('shortName', {
                  initialValue: nowCheckCustomer.shortName
                })(
                  <Input
                    style={{ width: 180 }}
                    minLength={1}
                    maxLength={20}
                    placeholder="公司简称"
                  />
                )}
            </FormItem>
          </Form>
          <Form layout="inline" >
            <FormItem label="联系电话" {...formItemLayout}>
              {
                getFieldDecorator('phone', {
                  rules: [{
                    required: true, message: '请输入联系电话'
                  }, {
                    pattern: regPhone,
                    message: '手机号格式错误'
                  }],
                  initialValue: nowCheckCustomer.phone
                })(
                  <Input
                    style={{ width: 180 }}
                    minLength={1}
                    maxLength={11}
                    placeholder="请输入联系电话"
                  />
                )}
            </FormItem>
            <FormItem label="发票抬头" {...formItemLayout}>
              {
                getFieldDecorator('invoiceHead', {
                  rules: [{ required: true, message: '请输入发票抬头' }],
                  initialValue: nowCheckCustomer.invoiceHead
                })(
                  <Input
                    style={{ width: 180 }}
                    minLength={1}
                    maxLength={128}
                    placeholder="请输入发票抬头"
                  />
                )}
            </FormItem>
          </Form>
          <Form layout="inline" >
            <FormItem label="发货地址" {...formItemLayout}>
              {
                getFieldDecorator('proviceId', {
                  initialValue: loadValue,
                  rules: [{ required: true, message: '请输入客户地址' }],
                })(
                  <HCityPicker
                    provinceBatch={false}
                    cityBatch={false}
                    areaBatch={false}
                    style={{ width: 180 }}
                    placeholder="请选择省/市/区"
                    multiple={false}
                  />
                )}
            </FormItem>
            <FormItem label="详细地址" {...formItemLayout}>
              {
                getFieldDecorator('address', {
                  rules: [{ required: true, message: '请输入详细地址' }],
                  initialValue: nowCheckCustomer.address
                })(
                  <Input
                    style={{ width: 180 }}
                    maxLength={128}
                    placeholder="请输入详细地址"
                  />
                )}
            </FormItem>
          </Form>
          <Form layout="inline" >
            <FormItem label="客户类型" {...formItemLayout}>
              {
                getFieldDecorator('lineType', {
                  initialValue: nowCheckCustomer.lineType,
                  rules: [{ required: true, message: '请选择客户类型' }],
                })(
                  <Select
                    style={{ width: 180 }}
                    placeholder="请选择客户类型"
                    onChange={this.handleChangeLineType}
                  >
                    {
                      linetypeList.map(({ id, name }) => <Option value={id} key={name}>{name}类</Option>)
                    }
                  </Select>
                )}
            </FormItem>
          </Form>

          <Form layout="inline">
            <FormItem label="合同线路" {...formItemForNameLayout}>
              {
                getFieldDecorator('linePriceList', {
                  initialValue: (
                    nowCheckCustomer.linePrices
                      ? nowCheckCustomer.linePrices.map(({ linePriceId }) => linePriceId)
                      : []
                  ),
                  rules: [{ required: true, message: '至少选择1条线路' }],
                })(
                  <Select
                    style={{ width: 400 }}
                    mode="multiple"
                    placeholder="请选择路线"
                    onChange={this.handleChangeLinePrice}
                  >
                    {
                      contractList
                        .filter(({ lineType }) => lineType === getFieldValue('lineType'))
                        .map(({ lineName, id }) =>
                          <Option value={id} key={id}>{lineName}</Option>
                        )
                    }
                  </Select>
                )}
            </FormItem>
          </Form>
        </Modal>
        <Modal
          title="充值明细"
          visible={this.state.isShowRechargeHistoryModal}
          width={700}
          footer={null}
          onCancel={this.cancelRechargeHistoryModal}
        >
          <HTable {...rechTableProps} />
        </Modal>

        <Modal
          title="客户充值"
          onOk={this.onRechSave}
          visible={this.state.isShowRechargeModal}
          onCancel={this.cancelRechargeModal}
          afterClose={this.cancelRechargeModal}
          width={400}
          maskClosable={false}
        >
          <div>
            <span style={{ color: 'red' }}>*</span> 充值金额：
            <InputNumber
              placeholder="请输入充值金额"
              style={{ width: 200 }}
              value={this.state.mount}
              onChange={this.onChangeMount}
              max={99999}
              min={1}
            />
          </div>
          <div>
            <span style={{ color: 'red' }}>*</span> 充值时间：
            <DatePicker
              // disabledDate={this.disabledStartDate}
              // disabledTime={this.disabledStartTime}
              showTime
              allowClear={false}
              format="YYYY-MM-DD HH:mm:ss"
              placeholder="请选择充值时间"
              value={moment(this.state.rechTime, 'YYYY-MM-DD HH:mm:ss')}
              onChange={this.onRechChange}
              style={{ width: 200, marginTop: 10 }}
            />
          </div>
        </Modal>
      </div>
    );
  }
}

export default Form.create()(CustomerManage);
