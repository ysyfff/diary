import http from 'utils/http';

const { post } = http.create('dapt');

// 合同线路列表
export function linepriceList(param) {
  return post('/web/m/lineprice/list', param);
}

// 合同线路类型
export function linetypeList(param) {
  return post('/web/m/linetype/list', param);
}

// 合同线路新增
export function linetypeCreate(param) {
  return post('/web/m/lineprice/create', param);
}

// 合同线路修改
export function linetypeUpdate(param) {
  return post('/web/m/lineprice/update', param);
}

// 合同线路删除
export function linetypeRemove(param) {
  return post('/web/m/lineprice/remove', param);
}

// // 合同线路删除
// export function linetypeRemove(param) {
//   return post('/web/m/lineprice/remove', param);
// }
