import { bind } from 'bind-decorator';
import { Button, Form, Popconfirm, Radio } from 'antd';
import { connect } from 'dva';
import { HTable } from 'carno';
import { _ } from 'carno/third-party';
import ActionModal from './ActionModal';
import { tableFields } from './fields';

const FormItem = Form.Item;

@connect(({ contractPathManage }) => ({
  ...contractPathManage,
}), dispatch => ({
  getLinepriceList(param) {
    dispatch({ type: 'contractPathManage/getLinepriceList', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'contractPathManage/updateState', payload: param });
  },
  linetypeCreate(param) {
    dispatch({ type: 'contractPathManage/linetypeCreate', payload: param });
  },
  linetypeUpdate(param) {
    dispatch({ type: 'contractPathManage/linetypeUpdate', payload: param });
  },
  linetypeRemove(param) {
    dispatch({ type: 'contractPathManage/linetypeRemove', payload: param });
  },
  dispatch
}))
class ContractPathManage extends React.Component {
  state = {
    // search: { // 移到model中
    //   lineType: '',
    //   pn: 1,
    //   ps: 10
    // },
    editRowData: null
  }


  getFields() {
    const { linetypeList = [] } = this.props;
    return [{
      key: '_action',
      name: '操作',
      // 扩展字段的render支持自定义渲染
      render: (value, record) => (
        <div>
          <a onClick={() => this.handleEdit(record)}>编辑</a>
          <span className="ant-divider" />
          <Popconfirm
            title="是否删除线路？"
            okText="删除"
            cancelText="取消"
            onConfirm={() => this.props.linetypeRemove({ id: record.id })}
          >
            <a>删除</a>

          </Popconfirm>
        </div>
      )
    },
    {
      key: 'lineType',
      name: '线路类型',
      render: (value) => {
        const { name } = _.find(linetypeList, { id: value }) || {};

        return name || '-';
      }
    },
    ];
  }

  handleEdit(record) {
    this.setState({ editRowData: record });
    this.handleShowModal();
  }

  @bind
  handleChangeCustomerType(e) {
    this.updateSearch({ lineType: e.target.value, pn: 1 });
  }

  @bind
  handleShowModal() {
    this.props.updateState({ isShowModal: true });
  }

  @bind
  handleCancelModal() {
    this.props.updateState({ isShowModal: false });
    // return new Promise(resolve => this.setState({ editRowData: null }, resolve));
    this.setState({ editRowData: null });
  }

  updateSearch(param) {
    const { getLinepriceList, dispatch } = this.props;
    // const { search } = this.state;
    // const nextSearch = { ...search, ...param };
    // this.setState({ search: nextSearch });
    // updateSearch({ ...param });
    dispatch({ type: 'contractPathManage/updateSearch', payload: param });
    getLinepriceList(this.props.search);
  }


  render() {
    const { linetypeList = [], contractList = [], loading,
      total, isShowModal, linetypeCreate = [], linetypeUpdate } = this.props;
    const { editRowData } = this.state;
    const { search } = this.props;

    const pagination = {
      current: search.pn,
      pageSize: search.ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => this.updateSearch({ pn }),
      onShowSizeChange: (current, size) => this.updateSearch({ ps: size, pn: 1 })
    };

    const tableProps = {
      fields: tableFields,
      extraFields: this.getFields(),
      dataSource: search.lineType ? contractList.filter(({ lineType }) => lineType === search.lineType) : contractList,
      loading: loading.list,
      search: { ...search },
      pagination,
      locale: { emptyText: '暂无数据' },
      style: { marginTop: 16 },
      scroll: { x: 1400 }

    };

    const modalProsp = {
      editRowData,
      linetypeList,
      loading: loading.modalLoading,
      visible: isShowModal,
      onCancel: this.handleCancelModal,
      onOk: param => (editRowData ? linetypeUpdate : linetypeCreate)(param)
    };
    return (
      <div>
        <Form layout="inline" >
          <FormItem >
            <Radio.Group onChange={this.handleChangeCustomerType} value={search.lineType} buttonStyle="solid">

              {
                [{ id: '', name: '全部' }, ...linetypeList].map(({ id, name }) =>
                  <Radio.Button
                    key={id}
                    value={id}
                  >
                    {`${name}${id && '类线路'}`}
                  </Radio.Button>
                )
              }
            </Radio.Group>
          </FormItem>

          <FormItem className="fr">
            <Button
              type="primary"
              onClick={this.handleShowModal}
            >
              新建合同路线
            </Button>
          </FormItem>
        </Form>

        <HTable {...tableProps} />

        <ActionModal {...modalProsp} />
      </div>
    );
  }
}

export default ContractPathManage;
