// import { getRegionName } from 'utils';
import EllipsisRecord from 'components/common/EllipsisRecord';

const formatValue = width => value => <EllipsisRecord record={value || '--'} width={width} />;

export const tableFields = [
  {
    key: 'lineName',
    name: '合同线路名称',
    render: formatValue(150),
    // render: (value, record) => {
    //   const { cityName, endCityName, typeName } = record;
    //   return formatValue(200)(`${cityName}-${endCityName} ${typeName}`);
    // },
    width: 150
  },
  {
    key: '_action',
    name: '操作',
    width: 130
  },
  {
    key: 'lineType',
    name: '线路类型',
    width: 100
  },
  {
    key: 'cityName',
    name: '始发城市',
    width: 120
  },
  {
    key: 'endCityName',
    name: '到达城市',
    width: 120
  },
  {
    key: 'volumePrice',
    name: '通道价格',
    render: (value, record) => `${record.weightPrice}元/千克， ${value}元/方`,
    width: 250
  },

  {
    key: 'vehiclePrice',
    name: '整车价格',
    render: value => value ? `${value}元/车` : '-',

  }];
