import { Modal, Form, Input, InputNumber, Select } from 'antd';
import { Rule, Type } from 'carno/utils';
import { HCityPicker } from 'carno';
import { _ } from 'carno/third-party';

const FormItem = Form.Item;
const Option = Select.Option;


const inputStyle = { width: 220 };

const numberInputCheck = {
  min: 0.01,
  max: 99999.99
};

const inputNumberRule = Rule.validate(
  value => Type.isNumber(value) ? (value <= numberInputCheck.max && value >= numberInputCheck.min) : true,
  '运费范围0.01~99999.99元'
);

const initState = {
  startCityInfo: {},
  endCityInfo: {},
  isUpdate: true,
};

class ActionModal extends React.Component {
  state = {
    ...initState
  }

  static getDerivedStateFromProps(nextProps, state) {
    const { editRowData } = nextProps;
    if (editRowData && state.isUpdate) {
      const startCityInfo = {
        provinceName: editRowData.provinceName,
        cityName: editRowData.cityName,
        provinceId: editRowData.provinceId,
        cityId: editRowData.cityId
      };
      const endCityInfo = {
        provinceName: editRowData.endProvinceName,
        cityName: editRowData.endCityName,
        provinceId: editRowData.endProvinceId,
        cityId: editRowData.endCityId
      };
      return {
        startCityInfo,
        endCityInfo,
        isUpdate: false,
      };
    }
    return null;
  }


  handleOk = () => {
    const { form, onOk, linetypeList, editRowData } = this.props;
    const { startCityInfo, endCityInfo } = this.state;
    const { validateFields } = form;
    validateFields((err, value) => {
      if (!err) {
        const line = _(linetypeList).find({ id: value.lineType });
        const { provinceName, provinceId, cityId, cityName } = startCityInfo;
        const { provinceName: endProvinceName,
          provinceId: endProvinceId, cityId: endCityId, cityName: endCityName } = endCityInfo;
        const param = {
          ...value,
          provinceName,
          provinceId,
          cityId,
          cityName,
          endProvinceName,
          endProvinceId,
          endCityId,
          endCityName,
          typeName: line.name,
        };
        editRowData && (param.id = editRowData.id);
        delete param.starCity;
        delete param.endCity;
        onOk(param);
      }
    });
  }

  handleCityChange = key => (value) => {
    const [cityInfo] = value;
    const [provinceName, cityName] = cityInfo.name.split('-');
    this.setState({
      [key]: {
        provinceName,
        cityName,
        provinceId: cityInfo.parentId,
        cityId: cityInfo.id
      }
    });
  }

  handleCancel = () => {
    this.props.onCancel();
    this.setState({
      ...initState
    });
  }

  render() {
    const { visible, form, linetypeList = [], loading, editRowData } = this.props;
    const { getFieldDecorator } = form;
    const { startCityInfo, endCityInfo } = this.state;

    const cityPickerConf = {
      hierarchy: '2',
      provinceBatch: false,
      cityBatch: false,
      multiple: false,
      placeholder: '请选择关联城市',
      style: { ...inputStyle },
      disabled: !!editRowData
    };

    const { lineName = '', lineType = '', weightPrice = '', volumePrice = '', vehiclePrice = '' } = editRowData || {};

    return (
      <Modal
        title={editRowData ? '编辑' : '新增'}
        visible={visible}
        onOk={this.handleOk}
        width={700}
        onCancel={this.handleCancel}
        okButtonProps={{ loading }}
        maskClosable={false}
        afterClose={() => {
          form.resetFields();
          this.handleCancel();
        }}
      >
        <Form layout="inline">
          <FormItem label="线路名称">
            {
              getFieldDecorator('lineName', {
                initialValue: lineName,
                rules: [
                  Rule.required('请输入名称'),
                  Rule.maxLength(20, '最长$1位字符'),
                ]
              })(
                <Input
                  style={{ ...inputStyle }}
                  placeholder="请输入名称"
                />
              )
            }
          </FormItem>
          <FormItem label="线路类型">
            {
              getFieldDecorator('lineType', {
                initialValue: lineType,
                rules: [Rule.required('请选择类型')]
              })(
                <Select
                  style={{ ...inputStyle }}
                  placeholder="请选择类型"
                  disabled={!!editRowData}
                >
                  {
                    linetypeList.map(({ id, name }) => <Option key={id} value={id}>{name}</Option>)
                  }
                </Select>
              )
            }
          </FormItem>

          <FormItem label="始发城市">
            {
              getFieldDecorator('starCity', {
                initialValue: (
                  startCityInfo.cityId
                    ? [
                      {
                        id: `${startCityInfo.cityId}`,
                        name: `${startCityInfo.provinceName}-${startCityInfo.cityName}`
                      }
                    ]
                    : []
                ),
                rules: [Rule.required('请选择关联城市')]
              })(
                <HCityPicker
                  {...cityPickerConf}
                  onChange={this.handleCityChange('startCityInfo')}
                />
              )
            }
          </FormItem>

          <FormItem label="到达城市">
            {
              getFieldDecorator('endCity', {
                initialValue: (
                  endCityInfo.cityId
                    ? [{ id: `${endCityInfo.cityId}`, name: `${endCityInfo.provinceName}-${endCityInfo.cityName}` }]
                    : []
                ),
                rules: [Rule.required('请选择关联城市')]
              })(
                <HCityPicker
                  {...cityPickerConf}
                  onChange={this.handleCityChange('endCityInfo')}
                />
              )
            }
          </FormItem>

          <FormItem>
            <Input
              value={startCityInfo.cityName}
              style={{ width: 80, marginLeft: 80 }}
              disabled
            />
            <span className="ml10 mr10">到</span>

            <Input
              value={endCityInfo.cityName}
              style={{ width: 80 }}
              disabled
            />
          </FormItem>


        </Form>

        <Form layout="inline">

          <div>

            <FormItem label="重量运费单价">
              {
                getFieldDecorator('weightPrice', {
                  initialValue: weightPrice,
                  rules: [
                    Rule.required('请输重量运费单价'),
                    inputNumberRule
                  ]
                })(
                  <InputNumber
                    // {...inputNumberConf}
                    style={{ ...inputStyle }}
                    precision={2}
                    placeholder="请输重量运费单价"
                  />
                )
              }
              <span className="ml10"> 元/千克</span>
            </FormItem>
          </div>
          <div>

            <FormItem label="体积运费单价">
              {
                getFieldDecorator('volumePrice', {
                  initialValue: volumePrice,
                  rules: [Rule.required('请输入体积运费单价'), inputNumberRule]
                })(
                  <InputNumber
                    style={{ ...inputStyle }}
                    precision={2}
                    placeholder="请输入体积运费单价"
                  />
                )
              }
              <span className="ml10"> 元/方</span>
            </FormItem>
          </div>
          <div>

            <FormItem label="整车运费">
              {
                getFieldDecorator('vehiclePrice', {
                  initialValue: vehiclePrice,
                  rules: [inputNumberRule]
                })(

                  <InputNumber
                    style={{ ...inputStyle }}
                    precision={2}
                    placeholder="请输入整车运费"
                  />
                )
              }
              <span className="ml10"> 元/车</span>
            </FormItem>
          </div>
        </Form>

      </Modal>
    );
  }
}

export default Form.create()(ActionModal);
