import { Model } from 'carno/addons';
import { Paths } from 'configs/constants';
import { withLoading } from 'carno/utils';

// import { } from './fields';
import { linepriceList, linetypeList, linetypeCreate, linetypeUpdate, linetypeRemove } from './services';


export default Model.extend({
  namespace: 'contractPathManage',

  state: {
    isShowModal: false,
    total: 0,
    loading: {},
    contractList: [],
    linetypeList: [],
    search: {
      pn: 1,
      ps: 10,
      lineType: '',
    }
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.CONTRACT_PATH_MANAGE, () => {
        dispatch({ type: 'updateState', payload: { isShowModal: false } });
        dispatch({ type: 'getLinetypeList' });
        dispatch({ type: 'getLinepriceList' });
      });
    }
  },

  effects: {
    * getLinepriceList({ payload }, { call, update, select }) {
      const { search } = yield select(({ contractPathManage }) => contractPathManage);
      const { datas = [], tc } = yield call(withLoading(linepriceList, 'list'), { ...search });
      yield update({ contractList: datas, total: tc });
    },
    * linetypeCreate({ payload }, { call, update, put }) {
      yield call(withLoading(linetypeCreate, 'modalLoading'), payload);
      yield update({ isShowModal: false });
      yield put({ type: 'getLinepriceList' });
    },
    * linetypeUpdate({ payload }, { call, update, put }) {
      yield call(withLoading(linetypeUpdate, 'modalLoading', '修改成功'), payload);
      yield update({ isShowModal: false });
      yield put({ type: 'getLinepriceList' });
    },
    * linetypeRemove({ payload }, { call, update, put }) {
      yield call(withLoading(linetypeRemove, 'remove', '删除成功'), payload);
      yield update({ isShowModal: false });
      yield put({ type: 'getLinepriceList' });
    },
    * getLinetypeList({ payload }, { call, update }) {
      const list = yield call(linetypeList, payload);
      yield update({ linetypeList: (list || []).reverse() });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
