import { Button, Form, Input, Select, DatePicker } from 'antd';
import { bind } from 'bind-decorator';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;

class SearchBar extends React.Component {
  // 查询
  handleSearch = () => {
    const { onSearch, search } = this.props;
    // const { createTime, contractDate, ...otherSearch } = search;
    onSearch({
      ...search,
      pn: 1,
    });
  }

  handleChange(key) {
    const { updateSearch } = this.props;
    return (value) => {
      let newValue = value;
      if (value && value.target) {
        newValue = value.target.value;
      }
      updateSearch({ [key]: newValue });
    };
  }

  // 重置
  @bind
  handleReset() {
    const { resetSearch, onSearch } = this.props;
    resetSearch();
    onSearch({ pn: 1 });
  }

  render() {
    const { search, contractList } = this.props;

    return (
      <div>
        <div className="searchBar">
          <Form layout="inline" >
            <FormItem label="发货公司">
              <Input
                value={search.keyword}
                placeholder="请输入发货公司或助记码"
                onChange={this.handleChange('keyword')}
                style={{ width: 180 }}
                maxLength={20}
              />
            </FormItem>
            <FormItem label="发货人">
              <Input
                value={search.nameOrPhone}
                placeholder="请输入姓名或电话"
                onChange={this.handleChange('nameOrPhone')}
                style={{ width: 180 }}
                maxLength={20}
              />
            </FormItem>
            <FormItem label="客户编号">
              <Input
                value={search.codeLike}
                placeholder="请输入客户编号"
                onChange={this.handleChange('codeLike')}
                style={{ width: 180 }}
                maxLength={20}
              />
            </FormItem>
            <FormItem label="签约时间">
              <RangePicker
                value={search.contractDate}
                onChange={this.handleChange('contractDate')}
                style={{ width: '100%' }}
              // format="MM-DD HH:mm:ss"
              // showTime
              />
            </FormItem>
            <FormItem label="合同线路">
              <Select
                showSearch
                value={search.linePriceId}
                onChange={this.handleChange('linePriceId')}
                optionFilterProp="children"
                style={{ width: 180 }}
              >
                {
                  [{ id: '', lineName: '全部线路' }, ...contractList]
                    .map(({ id, lineName }) => <Option key={id} value={id}>{lineName}</Option>)
                }
              </Select>
            </FormItem>
            <FormItem label="新建时间">
              <RangePicker
                value={search.createTime}
                onChange={this.handleChange('createTime')}
                style={{ width: '100%' }}
              // format="MM-DD HH:mm:ss"
              // showTime
              />
            </FormItem>
            {/* <FormItem label="联系电话">
              <Input
                value={search.phone}
                onChange={this.handleChange('phone')}
                style={{ width: 180 }}
                maxLength={20}
              />
            </FormItem> */}
            <FormItem label="">
              <Button type="primary" onClick={this.handleSearch}>查询</Button>
              <Button onClick={this.handleReset}>重置</Button>
            </FormItem>
          </Form>
        </div>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
