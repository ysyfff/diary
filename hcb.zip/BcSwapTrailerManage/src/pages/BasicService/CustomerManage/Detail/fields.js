// import { reg } from 'configs/constants';
// import { Type } from 'carno/utils';

const EL_COL_LAYOUT = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 12 }
};
const EL_COL_LAYOUT_DOUBLE = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 6 }
};


const CARD_COL_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 8 },
    xl: { span: 10 },
    lg: { span: 8 }
  },
  wrapperCol: {
    xxl: { span: 16 },
    xl: { span: 14 },
    lg: { span: 16 }
  }
};

const CARD_COLSUM_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 4 },
    xl: { span: 5 },
    lg: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 20 },
    xl: { span: 19 },
    lg: { span: 20 }
  }
};

const fields = [{
  key: 'companyName',
  label: '发货公司',
  type: 'text',
  col: { ...EL_COL_LAYOUT },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'invoiceHead',
  label: '发票抬头',
  type: 'text',
  col: { ...EL_COL_LAYOUT },
  el: {
    maxLength: 50
  },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'name',
  label: '联系人',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'phone',
  label: '联系电话',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'taxIdCode',
  label: '纳税人识别号',
  type: 'text',
  col: { ...EL_COL_LAYOUT },
  el: {
    maxLength: 20
  },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'code',
  label: '客户编号',
  type: 'text',
  el: {
    maxLength: 50
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'lineTypeName',
  label: '客户类型',
  type: 'text',
  el: {
    placeholder: '请选择客户类型'
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'openBank',
  label: '开户银行',
  type: 'text',
  el: {
    maxLength: 20
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'bankCode',
  label: '银行账号',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'mnemonicCode',
  label: '助记码',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
  }
}, {
  key: 'contractDateStr',
  label: '签约时间',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'addr',
  label: '公司地址',
  type: 'text',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'address',
  label: '详细地址',
  type: 'text',
  el: {
    maxLength: 50
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
},
];

export default fields;

export const tableFields = [
  {
    key: 'lineName',
    name: '合同线路名称',
    width: 160
  },
  {
    key: 'lineType',
    name: '线路类型',
    width: 100,
  },
  {
    key: 'cityName',
    name: '始发城市',
    width: 100,
  },
  {
    key: 'endCityName',
    name: '到达城市',
    width: 100
  },
  {
    key: 'weightVolume',
    name: '通道价格',
    width: 120,
    render: (v, row) => <div>
      {`${row.weightPrice}元/千克`}<br />
      {`${row.volumePrice}元/方`}
    </div>
  },
  {
    key: 'vehiclePrice',
    name: '整车价格',
    width: 100,

  },
  {
    key: 'oper',
    name: '操作',
    width: 100,
    // render: v => `${v}元/车`
  },
];

