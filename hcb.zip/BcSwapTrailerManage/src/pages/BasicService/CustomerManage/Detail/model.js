import { Model } from 'carno/addons';
import { PAGE_SIZE, Paths } from 'configs/constants';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
// import { routerRedux } from 'dva/router';
import { tableFields } from './fields';

import { linetypeList, getCustomerDetail, updateCustomer } from '../Create/services';

const initialState = {
  selectedRows: [],
  selectedRowKeys: [],
};
let id;

export default Model.extend({
  namespace: 'customerDetail',
  state: {
    loading: { customerDetail: false },
    tableFields,
    dataSource: '',
    search: {
      pn: 1,
      ps: PAGE_SIZE
    },
    id: '',
    linetypeList: [],
    list: [],
    ...initialState
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.CUSTOMER_DETAIL, (params) => {
        // debugger
        id = params.params[0];
        dispatch({
          type: 'updateState',
          payload: { id }
        });
        dispatch({
          type: 'getLinetypeList'
        });
        dispatch({
          type: 'getCustomerDetail'
        });
        // dispatch({
        //   type: 'resetState',
        //   payload: { ...initialState }
        // });
      });
    }
  },
  effects: {
    * getLinetypeList({ payload }, { call, update }) {
      const list = yield call(linetypeList, payload);
      yield update({ linetypeList: (list || []).reverse() });
    },
    * getCustomerDetail({ payload }, { call, update, select }) {
      const { id } = yield select(({ customerDetail }) => customerDetail);
      const dataSource = yield call(withLoading(getCustomerDetail, 'customerDetail'), { id }) || {};
      // yield put(routerRedux.push(Paths.CUSTOMER_MANAGE));
      yield update({ dataSource, selectedRows: dataSource.linePrices });
    },
    * updateCustomer({ payload }, { call, put }) {
      yield call(withLoading(updateCustomer, 'updateCustomer', '调价成功'), { ...payload, id });
      yield put(routerRedux.push(Paths.CUSTOMER_MANAGE));
    }
  },
  reducers: {
    resetState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    },
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    }
  }
});
