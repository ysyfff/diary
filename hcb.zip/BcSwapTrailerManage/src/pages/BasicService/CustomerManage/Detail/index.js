import React from 'react';
import { Button, Row, Col, message } from 'antd';
import { SearchCard, HCard } from 'components/helper';
import { BaseHTable } from 'components';
import { connect } from 'dva';
import { getRegionName } from 'utils';
import { Type } from 'carno/utils';
// import { Type } from 'carno/utils';
import baseFields from './fields';
// import { connect } from 'http2';
import AddContractLine from '../Create/AddContractLine';
import AdjustPrice from '../Create/AdjustPrice';

let adjustItemId = 0;

@connect(({ customerDetail }) => ({ ...customerDetail }), dispatch => ({ dispatch }))
class Detail extends React.PureComponent {
  state = {
    visible: false,
    adjustPriceVisible: false,
    selectedRows: [],
    selectedRowKeys: [],
    editRowData: {}
  }

  componentDidMount() {

  }

  onPaginationSearch = () => {

  }

  getLineTypeName = (id) => {
    const lineTypeTmp = this.props.linetypeList.find(item => item.id === id) || {};
    return lineTypeTmp.name || '';
  }

  getExtraFields = () => ([{
    key: 'lineType',
    render: v => this.getLineTypeName(v)
  }, {
    key: 'oper',
    render: (v, row) => (
      <div>
        <div><a size="small" onClick={() => this.adjustPrice(row)}>调整价格</a></div>
        {/* <Popconfirm title="确认删除此线路吗？" onConfirm={() => this.deleteLine(row)}>
          <a href="#">删除线路</a>
        </Popconfirm> */}
      </div>
    )
  }, {
    key: 'vehiclePrice',
    render: v => Type.isNumber(v) ? `${v}元/车` : '--'
  }])

  getInfoExtraFields = () => (baseFields.map((item) => {
    const { key } = item;
    if (item.key === 'addr') {
      return {
        key,
        render: () => {
          const { dataSource } = this.props;
          // debugger
          const { cityId, countyId, provinceId } = dataSource;
          const cityName = getRegionName(countyId || cityId || provinceId);
          return (cityName ? `${cityName}` : '--');
        }
      };
    }
    return { key };
  }))

  adjustPrice = (rowData) => {
    // 记录编辑的条目id
    adjustItemId = rowData.id;
    this.setState({
      editRowData: rowData
    }, () => {
      this.setState({ adjustPriceVisible: true });
    });
  }

  deleteLine = (row) => {
    const { selectedRows, selectedRowKeys } = this.props;
    const selectedRowsTmp = [...selectedRows];
    const selectedRowKeysTmp = [...selectedRowKeys];
    selectedRowKeysTmp.splice(selectedRowKeys.findIndex(item => item === row.id), 1);
    selectedRowsTmp.splice(selectedRows.findIndex(item => item.id === row.id), 1);

    this.updateState({
      selectedRows: selectedRowsTmp,
      selectedRowKeys: selectedRowKeysTmp
    });
  }

  show = () => {
    // const { form } = this.props;
    const infoForm = this.info.props.helper.getForm();
    const lineType = infoForm.getFieldValue('lineType');
    // debugger
    if (lineType === undefined) {
      message.error('请先选择客户类型');
    } else {
      this.setState({ visible: true });
      // 做了删除以后，添加合同线路弹窗应该同步更新
      const { selectedRows, dispatch } = this.props;
      // cb(selectedRowKeys, selectedRows);
      dispatch({
        type: 'addContractLine/updateState',
        payload: {
          ignoreRows: selectedRows,
          // selectedRowKeys,
          // selectedRows,
          search: { pn: 1, lineType }
        }
      });
      this.contractLineRef.fetchList();
    }
  }

  hide = (cb = () => 1) => {
    const { selectedRowKeys, selectedRows } = this.props;
    this.setState({ visible: false });
    cb(selectedRowKeys, selectedRows);
  }

  updateState = (param) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'customerDetail/updateState',
      payload: { ...param }
    });
  }

  handleAddLine = (newSelectedRowKeys, newSelectedRows, cb = () => { }) => {
    this.hide();
    const { selectedRows, selectedRowKeys } = this.props;
    const tmpSelectedRows = selectedRows.concat(newSelectedRows);
    this.updateState({
      selectedRows: tmpSelectedRows,
      selectedRowKeys: selectedRowKeys.concat(newSelectedRowKeys),
    });
    cb();
  }

  handleSave = () => {
    // const infoForm = this.info.props.helper.getForm();
    const { dispatch, selectedRows, dataSource } = this.props;
    // infoForm.validateFields((errs, values) => {
    // if (!errs) {
    // const notMatch = selectedRows.find(item => item.lineType !== values.lineType);
    // if (notMatch === undefined) {
    const param = {
      ...dataSource,
      linePriceList: selectedRows.map(item => ({
        linePriceId: item.linePriceId,
        weightPrice: item.weightPrice,
        volumePrice: item.volumePrice,
        vehiclePrice: item.vehiclePrice
      }))
    };
    dispatch({
      type: 'customerDetail/updateCustomer',
      payload: param
    });
    // } else {
    //   message.error('某些合同线路和客户类型不符，请修正！');
    // }
    // }
    // });
  }

  handleCancelModal = () => {
    this.setState({
      adjustPriceVisible: false
    });
  }

  updatePriceInList = (param) => {
    this.handleCancelModal();
    const { selectedRows } = this.props;
    const { volumePrice, weightPrice, vehiclePrice } = param;
    const selectedRowKeysTmp = selectedRows.map((item) => {
      if (item.id === adjustItemId) {
        return {
          ...item,
          volumePrice,
          weightPrice,
          vehiclePrice,
        };
      }
      return item;
    });
    this.updateState({
      selectedRows: selectedRowKeysTmp
    });
  }

  render() {
    const extraFields = this.getExtraFields();
    const infoExtraFields = this.getInfoExtraFields();
    const { tableFields, search, loading, linetypeList, dataSource } = this.props;
    const { visible, adjustPriceVisible, editRowData } = this.state;
    const { selectedRows } = this.props;

    const modalProps = {
      editRowData,
      linetypeList,
      title: '调整价格',
      editPriceOnly: true,
      loading: loading.modalLoading,
      visible: adjustPriceVisible,
      onCancel: this.handleCancelModal,
      onOk: param => this.updatePriceInList(param)
    };

    const searchCardProps = {
      title: '基础信息',
      fields: baseFields,
      wrappedComponentRef: el => this.info = el,
      extraFields: infoExtraFields,
      dataSource
    };
    return (
      <div>
        <SearchCard {...searchCardProps} />
        <HCard title="合同线路">
          {/* <Button type="primary" onClick={this.show}>添加合同线路</Button> */}
          <BaseHTable
            extraFields={extraFields}
            calculateScrollX
            // onPaginationSearch={this.onPaginationSearch}
            tableFields={tableFields}
            search={search}
            loading={loading}
            list={selectedRows}
            pagination={false}
          />
        </HCard>
        <Row type="flex" justify="center">
          <Col >
            <Button
              type="primary"
              loading={loading.createOrder}
              className="mr10"
              onClick={this.handleSave}
            >保存</Button>
            <Button onClick={() => {
              window.close();
            }}
            >取消</Button>
          </Col>
        </Row>
        <AddContractLine
          visible={visible}
          onCancel={this.hide}
          onOk={this.handleAddLine}
          formatLineType={this.getLineTypeName}
          getRef={ref => this.contractLineRef = ref}
        />
        <AdjustPrice {...modalProps} />
      </div>
    );
  }
}

export default Detail;
// export default Form.create()(Create);
