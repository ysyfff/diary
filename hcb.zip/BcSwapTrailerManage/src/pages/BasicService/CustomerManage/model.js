import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields, searchFields, rechTableFields } from './fields';
import {
  getList, enableCustomer, forbCustomer, createCustomer, updateCustomer, getRechHistory,
  rechSave, linepriceList, linetypeList
} from './services';

const EFFECTIVE = 1;

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  codeLike: '',
  keyword: '',
  nameOrPhone: '',
  phone: '',
  linePriceId: '',
  lineType: '',
  createTime: '',
  createTimeStart: '',
  createTimeEnd: '',
  contractDateStart: '',
  contractDate: '',
  contractDateEnd: '',
};

const rechSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  customerId: ''
};

export default Model.extend({
  namespace: 'customerManage',

  state: {
    loading: { list: false },
    tableFields,
    rechTableFields,
    searchFields,
    rechSearch,
    search: { ...initialSearch },
    total: 0,
    rechTotal: 0,
    list: [],
    nowCheckCustomer: {},
    isShowAddOrEditModal: false,
    rechList: [],
    contractList: [],
    linetypeList: [],
    pureParams: (search) => {
      const _search = { ...search };

      Object.keys(search).forEach(key => search[key] === '' && delete _search[key]);
      const { createTime, contractDate, ...otherSearch } = _search;
      const time = {
        createTimeStart: createTime && createTime[0] ?
          createTime[0].startOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        createTimeEnd: createTime && createTime[1] ?
          createTime[1].endOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        contractDateStart: contractDate && contractDate[0] ?
          contractDate[0].startOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        contractDateEnd: contractDate && contractDate[1] ?
          contractDate[1].endOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
      };

      return {
        ...time,
        ...otherSearch
      };
    }
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.CUSTOMER_MANAGE, () => {
        dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
        dispatch({ type: 'getLinetypeList' });
        dispatch({ type: 'getLinepriceList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search, pureParams } = yield select(({ customerManage }) => customerManage);
      const params = pureParams(search);
      const { datas, tc } = yield call(withLoading(getList, 'list'), { ...params });
      yield update({ list: datas, total: tc });
    },
    * exportList({ payload }, { call, update, select }) {
      const { search } = yield select(({ customerManage }) => customerManage);
      const _search = { ...search };

      Object.keys(search).forEach(key => search[key] === '' && delete _search[key]);
      const { createTime, contractDate, ...otherSearch } = _search;
      const time = {
        createTimeStart: createTime ? createTime[0].startOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        createTimeEnd: createTime ? createTime[1].endOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        contractDateStart: contractDate ? contractDate[0].startOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
        contractDateEnd: contractDate ? contractDate[1].endOf('day').format('YYYY-MM-DD HH:mm:ss') : '',
      };
      const { datas, tc } = yield call(withLoading(getList, 'list'), { ...time, ...otherSearch });
      yield update({ list: datas, total: tc });
    },
    * forbCustomer({ payload }, { call, put }) {
      yield call(withLoading(forbCustomer, 'list', '禁用成功'), payload);
      yield put({ type: 'getList' });
    },
    * enableCustomer({ payload }, { call, put }) {
      yield call(withLoading(enableCustomer, 'list', '启用成功'), payload);
      yield put({ type: 'getList' });
    },
    * createCustomer({ payload }, { call, put }) {
      yield call(withLoading(createCustomer, 'list', '新增成功'), payload);
      yield put({ type: 'updateState', payload: { nowCheckCustomer: {}, isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },
    * updateCustomer({ payload }, { call, put }) {
      yield call(withLoading(updateCustomer, 'list', '修改成功'), payload);
      yield put({ type: 'updateState', payload: { nowCheckCustomer: {}, isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },
    * getRechHistory({ payload }, { call, update, select }) {
      const { rechSearch } = yield select(({ customerManage }) => customerManage);
      const { datas, tc } = yield call(withLoading(getRechHistory, 'list'), rechSearch);
      yield update({ rechList: datas, rechTotal: tc });
    },
    * rechSave({ payload }, { call, put }) {
      yield call(withLoading(rechSave, 'list', '充值成功'), payload);
      yield put({ type: 'getList' });
    },
    * getLinepriceList({ payload }, { call, update }) {
      const { datas = [] } = yield call(linepriceList, { ...payload, effective: EFFECTIVE });
      yield update({ contractList: datas });
    },
    * getLinetypeList({ payload }, { call, update }) {
      const list = yield call(linetypeList, payload);
      // debugger
      yield update({ linetypeList: (list || []).reverse() });
    },

  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    updateRechSearch(state, { payload }) {
      return {
        ...state,
        rechSearch: { ...state.rechSearch, ...payload },
      };
    },
    resetSearch(state, { payload }) {
      return {
        ...state,
        search: { ...initialSearch },
      };
    }
  }
});
