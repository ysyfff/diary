import React from 'react';
import { Modal } from 'antd';
import { connect } from 'dva';
import { BaseHTable } from 'components';
import { Type } from 'carno/utils';
/**
 * 异步翻译时，dataSource发生改变，selectedRows未做到和selectedRowKeys同步
 * 故，前端解决此问题
 */

let selectedRowsTmp = [];
// let currentPageAllRows = [];

// const getSelectedRows = selectedRowKeys => selectedRowKeys.map(item => JSON.parse(item));

@connect(({ addContractLine }) => ({ ...addContractLine }), dispatch => ({ dispatch }))
export default class AddContractLine extends React.PureComponent {
  onSearch = () => {

  }

  onConfirm = () => {

  }

  onSelect = (record, selected) => {
    const { dispatch } = this.props;
    // 去重
    const existed = selectedRowsTmp.find(item => item.id === record.id);
    if (selected && existed === undefined) {
      selectedRowsTmp.push(record);
    } else {
      selectedRowsTmp.splice(selectedRowsTmp.findIndex(item => item.id === record.id), 1);
    }
    dispatch({
      type: 'addContractLine/updateState',
      payload: {
        selectedRows: [...selectedRowsTmp]
      }
    });
  }

  onSelectChange = (selectedRowKeys) => {
    const { dispatch } = this.props;
    // selectedRowsTmp = selectedRowsTmp.concat(selectedRows);
    dispatch({
      type: 'addContractLine/updateState',
      payload: {
        selectedRowKeys
      }
    });
  }

  onSelectAll = (selected, selectedRows) => {
    const { dispatch, linepriceList } = this.props;
    if (selected) {
      // 去重
      const filterSelected = selectedRows.filter(item =>
        selectedRowsTmp.find(tmp =>
          tmp.id === item.id) === undefined);
      selectedRowsTmp = selectedRowsTmp.concat(filterSelected);
    } else {
      linepriceList.map(item =>
        selectedRowsTmp.splice(selectedRowsTmp.findIndex(tmp => tmp.id === item.id), 1)
      );
    }
    dispatch({
      type: 'addContractLine/updateState',
      payload: {
        selectedRows: [...selectedRowsTmp]
      }
    });
  }

  getExtraFields = () => ([{
    key: 'lineType',
    render: v => this.props.formatLineType(v)
  }, {
    key: 'vehiclePrice',
    render: v => Type.isNumber(v) ? `${v}元/车` : '--'
  }])


  fetchList = () => {
    const { dispatch } = this.props;
    // dispatch({
    //   type: 'addContractLine/updateState',
    //   payload: {
    //     search: { ...search, ...param }
    //   }
    // });
    dispatch({
      type: 'addContractLine/getLinepriceList',
    });
  }

  handlePageChange = ({ pn = 1, ps }) => {
    const { dispatch, search, selectedRows } = this.props;
    // 翻页的时候，处理selectedRows
    // 翻页的时候缓存之前的selectedRows
    selectedRowsTmp = [...selectedRows];
    dispatch({
      type: 'addContractLine/updateState',
      payload: {
        search: {
          ...search,
          pn,
          ps
        }
      }
    });
    dispatch({
      type: 'addContractLine/getLinepriceList',
    });
  }

  render() {
    const { tableFields, selectedRowKeys, ignoreRowKeys, selectedRows,
      loading, linepriceList, visible, onCancel, onOk, getRef, total, search } = this.props;
    getRef(this);
    // const realLinepriceList = linepriceList.filter(item => selectedRows.find(row => row.id === item.id))
    // debugger
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      onSelectAll: this.onSelectAll,
      onSelect: this.onSelect,
      onSelectInvert: this.onSelectInvert,
      getCheckboxProps: record => ({
        disabled: record.disabled,
        defaultChecked: record.disabled
      })
    };

    const linepriceListWithKeys = linepriceList.map(item => ({ ...item, key: JSON.stringify(item) }));
    // 隐藏ignore
    // const linepriceListWithKeysFiltered = linepriceListWithKeys.filter(item =>
    //   !ignoreRows.find(row => row.id === item.id)
    // );
    // 禁用ignore
    const linepriceListWithKeysFiltered = linepriceListWithKeys.map(
      item =>
        ({
          ...item,
          linePriceId: item.id,
          disabled: ignoreRowKeys.find(row => row === item.id)
        })
    );
    // console.log(total, total - ignoreRows.length, 'total');
    // const { pn, ps } = search;
    // const pagination = {
    //   total,
    //   defaultCurrent: 1,
    //   current: pn,
    //   pageSize: ps,
    //   onChange: this.handlePageChange
    // };

    return (
      <Modal
        width={900}
        title="选择合同线路"
        onCancel={() => {
          onCancel(() => {
            // 取消以后清空已选
            const { dispatch } = this.props;
            selectedRowsTmp.splice(0);
            dispatch({
              type: 'addContractLine/updateState',
              payload: { selectedRowKeys: [], selectedRows: [] }
            });
          });
        }}
        onOk={() => {
          // 确认以后清空已选
          onOk(selectedRowKeys, selectedRows, () => {
            const { dispatch } = this.props;
            selectedRowsTmp.splice(0);
            dispatch({
              type: 'addContractLine/updateState',
              payload: { selectedRowKeys: [], selectedRows: [] }
            });
          });
        }}
        visible={visible}
      >
        <BaseHTable
          extraFields={this.getExtraFields()}
          rowSelection={rowSelection}
          calculateScrollX
          onPaginationSearch={this.handlePageChange}
          tableFields={tableFields}
          // dataSource={dataSource}
          search={search}
          locale={{ emptyText: '暂无数据或已被选空' }}
          rowKey={record => record.linePriceId}
          // list={linepriceList.map(item => ({ ...item, key: item.id }))}
          list={linepriceListWithKeysFiltered}
          loading={loading.list}
          total={total}
        />
        {/* 使用antd的table，Htable改变了key值，且没有使用传入的key */}
        {/* <Table
          dataSource={linepriceListWithKeysFiltered}
          rowSelection={rowSelection}
          loading={loading.list}
          locale={{ emptyText: '暂无数据或已被选空' }}
          // pagination={pagination}
          rowKey={record => JSON.stringify(record)}
          columns={tableFields.map(item => ({ ...item, title: item.name, dataIndex: item.key }))}
        /> */}
      </Modal>
    );
  }
}
