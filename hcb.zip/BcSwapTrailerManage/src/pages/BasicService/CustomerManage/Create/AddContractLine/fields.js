export const tableFields = [
  {
    key: 'lineName',
    name: '合同线路名称',
    width: 160
  },
  {
    key: 'lineType',
    name: '线路类型',
    width: 100,
  },
  {
    key: 'cityName',
    name: '始发城市',
    width: 100,
    // render: (v) => {
    //   let color;
    //   let text;
    //   if (v) {
    //     color = pickUpStatusObj[v].color;
    //     text = pickUpStatusObj[v].value;
    //   } else {
    //     color = '';
    //     text = '--';
    //   }
    //   return (<span style={{ color }}>{text}</span>);
    // }
  },
  {
    key: 'endCityName',
    name: '到达城市',
    width: 100
  },
  {
    key: 'weightVolume',
    name: '通道价格',
    width: 120,
    render: (v, row) => <div>
      {`${row.weightPrice}元/千克`}<br />
      {`${row.volumePrice}元/方`}
    </div>
  },
  {
    key: 'vehiclePrice',
    name: '整车价格',
    width: 100,
    render: v => `${v}元/车`
  },
];

