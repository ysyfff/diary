import { Model } from 'carno/addons';
import { PAGE_SIZE } from 'configs/constants';
import { withLoading } from 'carno/utils';
import { tableFields } from './fields';
import { linepriceList } from '../services';

export default Model.extend({
  namespace: 'addContractLine',
  state: {
    loading: {},
    tableFields,
    selectedRowKeys: [],
    selectedRows: [],
    ignoreRows: [],
    ignoreRowKeys: [],
    dataSource: [],
    search: {
      pn: 1,
      ps: PAGE_SIZE,
      effective: 1
    },
    list: [],
    linepriceList: [],
    total: 0,
  },
  subscriptions: {
  },
  effects: {
    * getLinepriceList({ payload }, { call, update, select }) {
      const { search } = yield select(({ addContractLine }) => addContractLine);
      const { datas = [], tc } = yield call(withLoading(linepriceList, 'list'), { ...search });
      yield update({ linepriceList: datas, total: tc });
    },
  },
  reducers: {
    resetSearch(state) {
      return {
        ...state,
        // search: { ...initialSearch }
      };
    },
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    }
  }
});
