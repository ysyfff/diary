import { Model } from 'carno/addons';
import { PAGE_SIZE, Paths } from 'configs/constants';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
import { qs } from 'utils';
import { tableFields } from './fields';

import { linetypeList, createCustomer, getCustomerDetail, updateCustomer } from './services';

const id = qs('id');
const initialState = {
  selectedRows: [],
  selectedRowKeys: [],
};

export default Model.extend({
  namespace: 'createCustomer',
  state: {
    loading: { createCustomer: false },
    tableFields,
    search: {
      pn: 1,
      ps: PAGE_SIZE
    },
    linetypeList: [],
    list: [],
    ...initialState,
    dataSource: {}
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.CREATE_CUSTOMER, () => {
        dispatch({
          type: 'resetState',
          payload: { ...initialState }
        });
        dispatch({
          type: 'getLinetypeList'
        });
        // debugger
        if (id) {
          dispatch({
            type: 'getCustomerDetail',
            payload: { id }
          });
        }
      });
    }
  },
  effects: {
    * getLinetypeList({ payload }, { call, update }) {
      const list = yield call(linetypeList, payload);
      yield update({ linetypeList: (list || []).reverse() });
    },
    * createCustomer({ payload }, { call, put }) {
      yield call(withLoading(createCustomer, 'createCustomer', '新建客户成功'), { ...payload });
      yield put(routerRedux.push(Paths.CUSTOMER_MANAGE));
    },
    * getCustomerDetail({ payload }, { call, update }) {
      // const { id } = yield select(({ customerDetail }) => customerDetail);
      const dataSource = yield call(withLoading(getCustomerDetail, 'customerDetail'), { id }) || {};
      // yield put(routerRedux.push(Paths.CUSTOMER_MANAGE));
      yield update({ dataSource, selectedRows: dataSource.linePrices });
    },
    * updateCustomer({ payload }, { call, put }) {
      yield call(withLoading(updateCustomer, 'updateCustomer', '修改客户成功'), { ...payload });
      yield put(routerRedux.push(Paths.CUSTOMER_MANAGE));
    }
  },
  reducers: {
    resetState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    },
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    }
  }
});
