import { reg } from 'configs/constants';

const EL_COL_LAYOUT = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 12 }
};
const EL_COL_LAYOUT_DOUBLE = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 6 }
};


const CARD_COL_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 8 },
    xl: { span: 10 },
    lg: { span: 8 }
  },
  wrapperCol: {
    xxl: { span: 16 },
    xl: { span: 14 },
    lg: { span: 16 }
  }
};

const CARD_COLSUM_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 4 },
    xl: { span: 5 },
    lg: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 20 },
    xl: { span: 19 },
    lg: { span: 20 }
  }
};

const fields = [{
  key: 'companyName',
  label: '发货公司',
  col: { ...EL_COL_LAYOUT },
  el: {
    maxLength: 50,
    placeholder: '请输入发货公司'
  },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请输入发货公司'
      }]
    }
  }
}, {
  key: 'invoiceHead',
  label: '发票抬头',
  // type: 'input',
  col: { ...EL_COL_LAYOUT },
  el: {
    maxLength: 128,
    placeholder: '请输入发票抬头'
  },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: false,
      }]
    }
  }
}, {
  key: 'name',
  label: '联系人',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20,
    placeholder: '请输入联系人'
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请输入联系人'
      }]
    }
  }
}, {
  key: 'phone',
  label: '联系电话',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20,
    placeholder: '请输入联系电话'
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请输入联系电话',
      }]
    }
  }
}, {
  key: 'taxIdCode',
  label: '纳税人识别号',
  // el: {
  //   disabled: true,
  //   defaultValue: '张道人'
  // },
  col: { ...EL_COL_LAYOUT },
  el: {
    maxLength: 20,
    placeholder: '请输入纳税人识别号'
  },
  formItem: {
    props: { ...CARD_COLSUM_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        type: 'string',
        ...reg.charNumber,
      }]
    }
  }
}, {
  key: 'code',
  label: '客户编号',
  el: {
    maxLength: 50,
    placeholder: '请输入客户编号'
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请输入客户编号'
      }, {
        ...reg.charNumberMid
      }]
    }
  }
}, {
  key: 'lineType',
  label: '客户类型',
  type: 'select',
  el: {
    placeholder: '请选择客户类型'
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请选择客户类型'
      }]
    }
  }
}, {
  key: 'openBank',
  label: '开户银行',
  el: {
    maxLength: 20,
    placeholder: '请输入开户银行'
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'bankCode',
  label: '银行账号',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20,
    placeholder: '请输入银行账号'
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        type: 'string',
        ...reg.charNumber,
      }]
    }
  }
}, {
  key: 'mnemonicCode',
  label: '助记码',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  el: {
    maxLength: 20,
    placeholder: '请输入助记码'
  },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT },
    options: {
      rules: [{
        type: 'string',
        ...reg.charNumber,
      }]
    }
  }
}, {
  key: 'contractDate',
  label: '签约时间',
  type: 'datepicker',
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'addr',
  label: '公司地址',
  type: 'citypicker',
  el: {
    // placeholder: '请输入开户银行'
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
}, {
  key: 'address',
  label: '详细地址',
  el: {
    maxLength: 128,
    placeholder: '请输入详细地址',
  },
  col: { ...EL_COL_LAYOUT_DOUBLE },
  formItem: {
    props: { ...CARD_COL_FORM_ITEM_LAYOUT }
  }
},
];

export default fields;

export const tableFields = [
  {
    key: 'lineName',
    name: '合同线路名称',
    width: 160
  },
  {
    key: 'lineType',
    name: '线路类型',
    width: 100,
  },
  {
    key: 'cityName',
    name: '始发城市',
    width: 100,
  },
  {
    key: 'endCityName',
    name: '到达城市',
    width: 100
  },
  {
    key: 'weightVolume',
    name: '通道价格',
    width: 120,
    render: (v, row) => <div>
      {`${row.weightPrice}元/千克`}<br />
      {`${row.volumePrice}元/方`}
    </div>
  },
  {
    key: 'vehiclePrice',
    name: '整车价格',
    width: 100,
    render: v => `${v}元/车`
  },
  {
    key: 'oper',
    name: '操作',
    width: 100,
    // render: v => `${v}元/车`
  },
];

