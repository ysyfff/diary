import React from 'react';
import { Button, Row, Col, message, Popconfirm } from 'antd';
import { SearchCard, HCard } from 'components/helper';
import { BaseHTable } from 'components';
import { connect } from 'dva';
import { Type } from 'carno/utils';
import { reginIdSplit, qs, getRegionName } from 'utils';
// import { getRegionName } from 'utils';
// import { Type } from 'carno/utils';
import baseFields from './fields';
// import { connect } from 'http2';
import AddContractLine from './AddContractLine';
import AdjustPrice from './AdjustPrice';

const id = qs('id');
const isEdit = !Type.isEmpty(id);

let adjustItemId = 0;

@connect(({ createCustomer }) => ({ ...createCustomer }), dispatch => ({ dispatch }))
class Create extends React.PureComponent {
  state = {
    visible: false,
    adjustPriceVisible: false,
    selectedRows: [],
    selectedRowKeys: [],
    editRowData: {}
  }

  getLineTypeName = (id) => {
    const lineTypeTmp = this.props.linetypeList.find(item => item.id === id) || {};
    return lineTypeTmp.name || '';
  }

  getExtraFields = () => ([{
    key: 'lineType',
    render: v => this.getLineTypeName(v)
  }, {
    key: 'oper',
    render: (v, row) => (
      <div>
        <div><a size="small" onClick={() => this.adjustPrice(row)}>调整价格</a></div>
        <Popconfirm title="确认删除此线路吗？" onConfirm={() => this.deleteLine(row)}>
          <a href="#">删除线路</a>
        </Popconfirm>
      </div>
    )
  }, {
    key: 'vehiclePrice',
    render: v => Type.isNumber(v) ? `${v}元/车` : '--'
  }])

  getInfoExtraFields = () => {
    // debugger
    if (isEdit) {
      return this.handleEditExtra();
    }

    return ([
      {
        key: 'lineType',
        el: {
          options: this.props.linetypeList.map(
            item => ({ key: item.id, value: `${item.name}` }))
        }
      }
    ]);
  }

  handleEditExtra = () => {
    const { dataSource } = this.props;
    // const disabledList = ['companyName', 'code'];
    const disabledList = [];
    const { cityId, provinceId, countyId } = dataSource;
    const effectiveId = countyId || cityId || provinceId;
    return baseFields.map((item) => {
      const { key } = item;
      let initialValue;
      let options = {};
      // 处理地址初始值
      if (key === 'addr') {
        initialValue = cityId
          ? [{ id: effectiveId, name: getRegionName(effectiveId) }]
          : [];
      } else {
        initialValue = dataSource[key];
      }
      // 修复客户类型
      if (key === 'lineType') {
        options = this.props.linetypeList.map(
          item => ({ key: item.id, value: `${item.name}` }));
      }
      return {
        key,
        el: {
          disabled: disabledList.includes(key),
          options
        },
        formItem: {
          options: {
            initialValue
          }
        }
      };
    });
  }

  adjustPrice = (rowData) => {
    // 记录编辑的条目id
    adjustItemId = rowData.id;
    this.setState({
      editRowData: rowData
    }, () => {
      this.setState({ adjustPriceVisible: true });
    });
  }

  deleteLine = (row) => {
    const { selectedRows, selectedRowKeys } = this.props;
    const selectedRowsTmp = [...selectedRows];
    const selectedRowKeysTmp = [...selectedRowKeys];

    selectedRowKeysTmp.splice(selectedRowKeys.findIndex(item => item === row.id), 1);
    selectedRowsTmp.splice(selectedRows.findIndex(item => item.id === row.id), 1);

    this.updateState({
      selectedRows: selectedRowsTmp,
      selectedRowKeys: selectedRowKeysTmp
    });
  }

  show = () => {
    // const { form } = this.props;
    const infoForm = this.info.props.helper.getForm();
    const lineType = infoForm.getFieldValue('lineType');
    // debugger
    if (lineType === undefined) {
      message.error('请先选择客户类型');
    } else {
      this.setState({ visible: true });
      // 做了删除以后，添加合同线路弹窗应该同步更新
      const { selectedRows, dispatch } = this.props;
      // cb(selectedRowKeys, selectedRows);
      // debugger
      dispatch({
        type: 'addContractLine/updateState',
        payload: {
          ignoreRowKeys: selectedRows.map(item => item.linePriceId),
          // ignoreRowKeys: selectedRowKeys,
          // selectedRows,
          search: { pn: 1, lineType }
        }
      });
      this.contractLineRef.fetchList();
    }
  }

  hide = (cb = () => 1) => {
    const { selectedRowKeys, selectedRows } = this.props;
    this.setState({ visible: false });
    cb(selectedRowKeys, selectedRows);
  }

  updateState = (param) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'createCustomer/updateState',
      payload: { ...param }
    });
  }

  handleAddLine = (newSelectedRowKeys, newSelectedRows, cb = () => { }) => {
    this.hide();
    const { selectedRows, selectedRowKeys } = this.props;
    // const tmpSelectedRows = selectedRows.concat(newSelectedRows);
    // this.updateState({
    //   selectedRows: tmpSelectedRows,
    //   selectedRowKeys: selectedRowKeys.concat(newSelectedRowKeys),
    // });

    // selectedRowKeys是完整的，selectedRows要从selectedRowKeys中进行补充

    // 已有的项目不重复添加
    const tmpSelectedRows = selectedRows.concat(
      newSelectedRows.filter(
        oldItem => selectedRows.find(
          newItem => oldItem.linePriceId === newItem.linePriceId
        ) === undefined));

    // const tmpSelectedRows = selectedRows.concat(
    //   newSelectedRows.filter(
    //     oldItem => selectedRows.find(
    //       newItem => oldItem.linePriceId === newItem.linePriceId
    //     ) === undefined));
    this.updateState({
      selectedRows: tmpSelectedRows,
      selectedRowKeys: selectedRowKeys.concat(
        newSelectedRowKeys.filter(
          oldItem => selectedRowKeys.find(
            newItem => oldItem.linePriceId === newItem.linePriceId
          ) === undefined)),
    });
    cb();
  }

  handleSave = () => {
    const infoForm = this.info.props.helper.getForm();
    const { dispatch, selectedRows } = this.props;
    infoForm.validateFields((errs, values) => {
      const { addr = [{ id: '' }], ...restValues } = values;
      // debugger
      const { cityId, countyId, provinceId } = reginIdSplit(addr[0] ? addr[0].id : '');
      if (!errs) {
        if (selectedRows.length) {
          const notMatch = selectedRows.find(item => item.lineType !== values.lineType);
          if (notMatch === undefined) {
            const param = {
              ...restValues,
              lineTypeName: this.getLineTypeName(values.lineType),
              linePriceList: selectedRows.map(item => ({
                linePriceId: item.linePriceId,
                weightPrice: item.weightPrice,
                volumePrice: item.volumePrice,
                vehiclePrice: item.vehiclePrice
              })),
              provinceId,
              countyId,
              cityId
            };
            // console.log(param);
            if (isEdit) {
              param.id = id;
            }
            dispatch({
              type: `createCustomer/${isEdit ? 'updateCustomer' : 'createCustomer'}`,
              payload: param
            });
          } else {
            message.error('某些合同线路类型和客户类型不符，请修正！');
          }
        } else {
          message.error('请至少添加一条合同线路！');
        }
      }
    });
  }

  handleCancelModal = () => {
    this.setState({
      adjustPriceVisible: false
    });
  }

  updatePriceInList = (param) => {
    this.handleCancelModal();
    const { selectedRows } = this.props;
    const { volumePrice, weightPrice, vehiclePrice } = param;
    const selectedRowKeysTmp = selectedRows.map((item) => {
      if (item.id === adjustItemId) {
        return {
          ...item,
          volumePrice,
          weightPrice,
          vehiclePrice,
        };
      }
      return item;
    });
    this.updateState({
      selectedRows: selectedRowKeysTmp
    });
  }

  render() {
    const extraFields = this.getExtraFields();
    const infoExtraFields = this.getInfoExtraFields();
    const { tableFields, search, loading, linetypeList } = this.props;
    const { visible, adjustPriceVisible, editRowData } = this.state;
    const { selectedRows } = this.props;

    const modalProps = {
      editRowData,
      linetypeList,
      title: '调整价格',
      editPriceOnly: true,
      loading: loading.modalLoading,
      visible: adjustPriceVisible,
      onCancel: this.handleCancelModal,
      onOk: param => this.updatePriceInList(param)
    };
    return (
      <div>
        <SearchCard
          title="基础信息"
          wrappedComponentRef={el => this.info = el}
          fields={baseFields}
          extraFields={infoExtraFields}
        />
        <HCard title="合同线路">
          <Button type="primary" onClick={this.show}>添加合同线路</Button>
          <BaseHTable
            extraFields={extraFields}
            calculateScrollX
            // onPaginationSearch={this.onPaginationSearch}
            tableFields={tableFields}
            search={search}
            loading={loading}
            list={selectedRows}
            pagination={false}
          />
        </HCard>
        <Row type="flex" justify="center">
          <Col >
            <Button
              type="primary"
              loading={loading.createOrder}
              className="mr10"
              onClick={this.handleSave}
            >保存</Button>
            <Button onClick={() => {
              window.close();
            }}
            >取消</Button>
          </Col>
        </Row>
        <AddContractLine
          visible={visible}
          onCancel={this.hide}
          onOk={this.handleAddLine}
          formatLineType={this.getLineTypeName}
          getRef={ref => this.contractLineRef = ref}
        />
        <AdjustPrice {...modalProps} />
      </div>
    );
  }
}

export default Create;
// export default Form.create()(Create);
