import { getRegionName } from 'utils';
import EllipsisRecord from 'components/common/EllipsisRecord';
// import { HEllipsis } from 'carno';

const formatValue = width => value => <EllipsisRecord record={value || '--'} width={width} />;

export const tableFields = [
  {
    key: 'companyName',
    name: '发货公司',
    // render: formatValue(150),
    width: 150
  },
  {
    key: 'effective',
    name: '状态',
    render: (a) => {
      if (a === 0) return <span className="tips">禁用</span>;
      if (a === 1) return '启用';
      return '未知';
    },
    width: 100
  },
  {
    key: 'action',
    name: '操作',
    width: 80
  },
  {
    key: 'lineTypeName',
    name: '客户类型',
    render: formatValue(80),
    width: 80
  }, {
    key: 'name',
    name: '联系人',
    render: formatValue(100),
    width: 100
  }, {
    key: 'phone',
    name: '联系电话',
    render: formatValue(150),
    width: 150
  },
  {
    key: 'code',
    name: '客户编号',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'mnemonicCode',
    name: '助记码',
    render: formatValue(100),
    width: 100
  }, {
    key: 'linePrices',
    name: '合同线路',
    // render: formatValue(200),
    render: (value = []) => {
      const result = value.map(({ lineName }) => lineName);
      const width = result.length === 1 ? result.join('；').length * 14 : result.slice(0, 2).join('；').length * 13;
      return (
        <EllipsisRecord width={width} record={result.join('；')} />
      );
    },
    width: 240
  },
  {
    key: 'contractDateStr',
    name: '签约时间',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'invoiceHead',
    name: '发票抬头',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'taxIdCode',
    name: '纳税人识别号',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'openBank',
    name: '开户银行',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'bankCode',
    name: '银行账号',
    render: formatValue(120),
    width: 120
  },
  {
    key: 'address',
    name: '公司地址',
    render: (value, record) => {
      const { cityId, countyId, proviceId } = record;
      const cityName = getRegionName(countyId || cityId || proviceId);
      // debugger
      return formatValue(200)(cityName || value ? `${cityName} ${value}` : '');
    },
    width: 200
  }, {
    key: 'createUserName',
    name: '新建人',
    // render: formatValue(150)
  },
  {
    key: 'createTime',
    name: '新建时间'
  }
];


export const searchFields = [{
  key: 'name',
  name: '客户名称',
}, {
  key: 'code',
  name: '客户编号',
}];

export const rechTableFields = [{
  key: 'rechargeTime',
  name: '充值时间'
}, {
  key: 'amount',
  name: '充值金额'
}, {
  key: 'createTime',
  name: '系统记录时间'
}];
