import { Form, Modal, Row, Input, Select, InputNumber, DatePicker } from 'antd';
import { regPhone, belongTypes, driverType } from 'configs/constants';
import moment from 'moment';

const FormItem = Form.Item;
const { TextArea } = Input;
const Option = Select.Option;

class FormModal extends React.Component {
  state = {
  }

  componentWillReceiveProps = (_props) => {
    if (_props.visible === false) {
      const { resetFields } = _props.form;
      resetFields();
    }
  }

  onChangePlateNumber = (value) => {
    const { cardList = [], form } = this.props;
    if (!value) form.setFieldsValue({ truckType: '' });
    const plate = (cardList || []).filter(item => item.plateNumber === value)[0];
    if (plate) {
      const truckBrand = plate.truckBrand || '';
      const horsepower = plate.horsepower || '';
      let type = '';
      if (truckBrand) {
        type = truckBrand;
        if (horsepower) {
          type += ` / ${horsepower}`;
        }
      } else {
        type = horsepower || '';
      }
      form.setFieldsValue({
        truckType: type,
      });
    }
  }

  onBlurPlateNumber = () => {
    const { resetCardSearch, getCarList } = this.props;
    resetCardSearch();
    getCarList();
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, creatSite, editSite, title, siteMsg = {}, cardList = [] } = this.props;
    const { validateFields } = form;
    validateFields((err, values) => {
      if (!err) {
        const param = { ...values };
        delete param.truckType;
        if (param.firstLicensingDate) {
          param.firstLicensingDate = param.firstLicensingDate.format('YYYY-MM-DD');
        }

        // 删除所有没有值的字段
        const keys = Object.keys(param);
        keys.forEach((key) => {
          if (!param[key]) delete param[key];
        });

        if (title === '新增') {
          if (values.truckPlateNumber) {
            param.truckId = cardList.filter(i => i.plateNumber === values.truckPlateNumber)[0].id;
          }
          creatSite(param);
        } else if (title === '修改') {
          param.userId = siteMsg.userId;
          if (values.truckPlateNumber) {
            param.truckId = cardList.filter(i => i.plateNumber === values.truckPlateNumber).length > 0 ?
              cardList.filter(i => i.plateNumber === values.truckPlateNumber)[0].id : siteMsg.truckId;
          }
          editSite(param);
        }
      }
    });
  }

  cancelModals = () => {
    const { cancel, form } = this.props;
    const { resetFields } = form;
    resetFields();
    cancel();
  }

  render() {
    const { form, visible, title, siteMsg = {}, loading, cardList = [], getCarList } = this.props;
    const { getFieldDecorator } = form;

    const _cardList = [];
    (cardList || []).forEach((item) => {
      _cardList.push(<Option value={item.plateNumber} key={item.id}>{item.plateNumber}</Option>);
    });

    let truckStr = '';
    const truckBrand = siteMsg.truckBrand || '';
    const horsepower = siteMsg.horsepower || '';
    if (truckBrand) {
      truckStr = truckBrand;
      if (horsepower) truckStr += ` / ${horsepower} `;
    } else {
      truckStr = horsepower;
    }

    return (
      <Modal
        width={800}
        title={`${title}司机`}
        visible={visible}
        onCancel={this.cancelModals}
        maskClosable={false}
        onOk={this.handleSubmit}
        confirmLoading={title === '修改' ? loading.editSite : loading.creatSite}
      >
        <Form layout="inline" >
          <div className="trailer-manage" >
            <FormItem
              label="司机姓名"
            >
              {getFieldDecorator('userName', {
                placeholder: '',
                initialValue: siteMsg.userName,
                rules: [{ required: true, message: '请输入司机姓名！' }]
              })(
                <Input
                  style={{ width: 171 }}
                  maxLength="20"
                />
              )}
            </FormItem>
            <FormItem
              label="联系电话"
            >
              {getFieldDecorator('mobile', {
                placeholder: '',
                initialValue: siteMsg.mobile,
                rules: [
                  { required: true, message: '请输入联系电话！' },
                  {
                    pattern: regPhone,
                    message: '请输入正确的联系电话！'
                  }
                ]
              })(
                <Input
                  disabled={title === '修改'}
                  style={{ width: 171 }}
                />
              )}
            </FormItem>
            <FormItem
              label="司机归属"
            >
              {getFieldDecorator('belong', {
                initialValue: siteMsg.belongType || 'PARTNER',
                rules: [
                  { required: true, message: '请选择司机归属！' },
                ]
              })(
                <Select style={{ width: 171 }}>
                  {
                    belongTypes.map(option => (
                      <Option
                        key={option.key}
                        value={option.key}
                      >
                        {option.value}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <FormItem
              label="线路类别"
            >
              {getFieldDecorator('routeTypeEnum', {
                initialValue: siteMsg.driverType || '',
                rules: [
                  { required: true, message: '请选择线路类别！' },
                ]
              })(
                <Select allowClear style={{ width: 171 }}>
                  {
                    driverType.map(option => (
                      <Option
                        key={option.key}
                        value={option.key}
                      >
                        {option.value}
                      </Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
            <FormItem
              label="关联车辆"
            >
              {getFieldDecorator('truckPlateNumber', {
                placeholder: '',
                initialValue: siteMsg.truckPlateNumber || '',
              })(
                <Select
                  allowClear
                  style={{ width: 171 }}
                  onChange={this.onChangePlateNumber}
                  showSearch
                  onBlur={this.onBlurPlateNumber}
                  onSearch={value => getCarList({ plateNumber: value })}
                >
                  {_cardList}
                </Select>
              )}
            </FormItem>
            <FormItem
              label="车型及马力"
            >
              {getFieldDecorator('truckType', {
                placeholder: '请选择关联车辆',
                initialValue: truckStr,
              })(
                <Input disabled style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="驾龄"
            >
              {getFieldDecorator('drivingAge', {
                placeholder: '',
                initialValue: siteMsg.drivingAge
              })(
                <InputNumber max={100} min={1} precision={0} style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="档案号"
            >
              {getFieldDecorator('fileNo', {
                placeholder: '',
                initialValue: siteMsg.fileNo
              })(
                <Input maxLength="10" style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="身份证号"
            >
              {getFieldDecorator('icNo', {
                placeholder: '',
                initialValue: siteMsg.icNo,
                rules: [
                  {
                    pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
                    message: '请输入正确的身份证号！'
                  }
                ]
              })(
                <Input style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="所在地"
            >
              {getFieldDecorator('locus', {
                placeholder: '',
                initialValue: siteMsg.locus
              })(
                <Input maxLength="10" style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="初次领证时间"
            >
              {getFieldDecorator('firstLicensingDate', {
                placeholder: '',
                initialValue: (siteMsg.firstLicensingDate ? moment(siteMsg.firstLicensingDate) : '')
              })(
                <DatePicker style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="银行卡号"
            >
              {getFieldDecorator('bankCard', {
                placeholder: '',
                initialValue: siteMsg.bankCard
              })(
                <InputNumber maxLength="20" style={{ width: 171 }} />
              )}
            </FormItem>
            <FormItem
              label="驾驶证剩余积分"
            >
              {getFieldDecorator('surplusIntegral', {
                placeholder: '',
                initialValue: siteMsg.surplusIntegral
              })(
                <InputNumber max={12} min={0} precision={0} style={{ width: 171 }} />
              )}
            </FormItem>
            <Row>
              <FormItem
                label="司机住址"
              >
                {getFieldDecorator('address', {
                  placeholder: '',
                  initialValue: siteMsg.address,
                })(
                  <Input maxLength="50" style={{ width: 508 }} />
                )}
              </FormItem>
            </Row>
            <Row>
              <FormItem
                label="备注"
              >
                {getFieldDecorator('remark', {
                  placeholder: '',
                  initialValue: siteMsg.remark,
                })(
                  <TextArea maxLength="20" style={{ width: 508 }} />
                )}
              </FormItem>
            </Row>
          </div>
        </Form>
      </Modal>
    );
  }
}
export default Form.create()(FormModal);
