import http from 'utils/http';

const { post } = http.create('admin');

// 获取司机列表
export function getList(param) {
  return post('/web/m/driver/list', param);
}

//  禁用司机
export function cancelWayBill(param) {
  return post('/web/m/driver/disable', param);
}

// 启用司机
export function enableSite(param) {
  return post('/web/m/driver/enable', param);
}

//  新增司机
export function creatSite(param) {
  return post('/web/m/driver/create', param);
}

// 修改司机
export function editSite(param) {
  return post('/web/m/driver/update', param);
}

// 获取车辆列表
export function getCarList(param) {
  return post('/web/m/truck/list', param);
}


// 导出首页列表
export function exportDrivers() {
  return '/web/m/driver/export';
}
