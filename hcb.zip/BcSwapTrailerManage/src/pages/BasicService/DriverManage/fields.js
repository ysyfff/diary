import { driverTo, driverType } from 'configs/constants';

const showRedLine = (a, b) => {
  const _a = a || '--';
  if (b.surplusIntegral !== null && a !== undefined && b.surplusIntegral > -1 && (b.surplusIntegral <= 6)) {
    return (
      <span style={{ color: 'red' }}>{_a}</span>
    );
  }
  return _a || '--';
};

export const tableFields = [
  {
    key: 'userName',
    name: '司机姓名',
    render: showRedLine
  },
  {
    key: 'buyerName',
    name: '操作',
    width: 80
  },
  {
    key: 'effective',
    name: '状态',
    render: (a, b) => {
      const _a = a ? '启用' : '禁用';
      return showRedLine(_a, b);
    }
  },
  {
    key: 'truckPlateNumber',
    name: '关联车辆',
    render: showRedLine
  },
  {
    key: 'driverType',
    name: '线路类别',
    render: (a, b) => {
      const type = driverType.filter(item => item.key === a)[0];
      if (type) return showRedLine(type.value, b);
      return showRedLine('', b);
    }
  },
  {
    key: 'truckType',
    name: '车型及马力',
    render: (a, b) => {
      const truckBrand = b.truckBrand || '';
      const horsepower = b.horsepower || '';
      let type = '';
      if (truckBrand) {
        type = truckBrand;
        if (horsepower) {
          type += ` / ${horsepower}`;
        }
      } else {
        type = horsepower || '--';
      }
      return showRedLine(type, b);
    }
  },
  {
    key: 'belongType',
    name: '司机归属',
    render: (a, b) => {
      const type = a ? driverTo.filter(i => i.key === a) : [];
      return showRedLine(((type[0] && type[0].value) || ''), b);
    }
  },
  {
    key: 'icNo',
    name: '身份证号',
    render: showRedLine
  },
  {
    key: 'bankCard',
    name: '银行卡号',
    render: showRedLine
  },
  {
    key: 'address',
    name: '司机住址',
    render: showRedLine
  },
  {
    key: 'mobile',
    name: '联系电话',
    render: showRedLine
  },
  {
    key: 'surplusIntegral',
    name: '驾驶证剩余积分',
    render: (a) => {
      if (a !== null && a !== undefined && a > -1 && a <= 6) {
        return <span style={{ color: 'red' }}>{a}</span>;
      }
      return a || '--';
    }
  },
  {
    key: 'fileNo',
    name: '档案号',
    render: showRedLine
  },
  {
    key: 'firstLicensingDate',
    name: '初次领证日期',
    render: (a, b) => showRedLine((a ? a.split(' ')[0] : ''), b)
  },
  {
    key: 'drivingAge',
    name: '驾龄',
    render: showRedLine
  },
  {
    key: 'locus',
    name: '所在地',
    render: showRedLine
  },
  {
    key: 'createUserName',
    name: '添加人',
    render: showRedLine
  },
  {
    key: 'createTime',
    name: '添加时间',
    render: showRedLine
  },
  {
    key: 'remark',
    name: '备注',
    render: showRedLine
  },
];

