import { connect } from 'dva';
import { Row, Col, Button, Popover, Icon, Modal } from 'antd';
import { HTable } from 'carno';
import { downFile } from 'utils/downloadFile';
import SearchBar from './common/SearchBar';
import FormModal from './common/FormModal';
import styles from './index.less';
import { exportDrivers } from './services';

const confirm = Modal.confirm;

@connect(({ DriverManage }) => ({ ...DriverManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'DriverManage/updateSearch', payload: param });
    dispatch({ type: 'DriverManage/getList' });
  },
  onReset() {
    dispatch({ type: 'DriverManage/resetSearch' });
    dispatch({ type: 'DriverManage/getList' });
  },
  cancelWayBill: (param) => {
    dispatch({ type: 'DriverManage/cancelWayBill', payload: param });
  },
  creatSite: (param) => {
    dispatch({ type: 'DriverManage/creatSite', payload: param });
  },
  editSite: (param) => {
    dispatch({ type: 'DriverManage/editSite', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'DriverManage/updateState', payload: param });
  },
  enableSite: (param) => {
    dispatch({ type: 'DriverManage/enableSite', payload: param });
  },
  getCarList: (param) => {
    dispatch({ type: 'DriverManage/updateCardSearch', payload: param });
    dispatch({ type: 'DriverManage/getCarList' });
  },
  resetCardSearch: () => {
    dispatch({ type: 'DriverManage/resetCardSearch' });
  }
}))
export default class DriverManage extends React.Component {
  state = {
    visible: false,
    title: '',
    siteMsg: {},
    visiblepop: []
  }


  getProps() {
    const { tableFields, search, total, list, loading, getList, cancelWayBill, enableSite } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'buyerName',
            name: '操作',
            render: (record, data) => !(data.state === 'CANCEL' || data.state === 'TRANSPORTING') && <Popover
              placement="right"
              overlayStyle={{ zIndex: 999 }}
              content={
                <div>
                  <ul className="table-operate-button">
                    <li><a onClick={() => this.editSite('修改', data)}>修改</a></li>
                    <li>
                      <a onClick={() => confirm({
                        title: `是否${data.effective ? '禁用' : '启用'}司机：${data.userName}`,
                        content: '',
                        onOk() {
                          if (data.effective) {
                            cancelWayBill(data.userId);
                          } else {
                            enableSite(data.userId);
                          }
                        }
                      })}
                      >{data.effective ? '禁用' : '启用'}</a>
                    </li>
                  </ul>
                </div>
              }
            ><a><Icon type="menu-unfold" /></a></Popover>
          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 3200 },
        pagination,
        locale: { emptyText: '暂无司机信息' },
        style: { marginTop: 16 },
      },
    };
  }

  handleSearch(search) {
    this.props.getList(search);
  }

  addSite = (msg) => {
    const { updateState, getCarList } = this.props;
    getCarList();
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg,
      siteMsg: {}
    });
  }

  editSite = (msg, data) => {
    const { updateState, getCarList } = this.props;
    getCarList();
    updateState({ isShowAddOrEditModal: true });
    this.setState({
      title: msg,
      siteMsg: data
    });
  }

  closeModal = () => {
    const { updateState, resetCardSearch } = this.props;
    updateState({ isShowAddOrEditModal: false });
    resetCardSearch();
    this.setState({
      title: '',
      siteMsg: {}
    });
  }

  // 导出
  exportDrivers = () => {
    const { search } = this.props;
    downFile({ server: 'dapt', url: exportDrivers(), params: search });
  }

  render() {
    const {
      getList,
      search,
      siteList = [],
      onReset,
      creatSite,
      editSite,
      isShowAddOrEditModal,
      cardList,
      getCarList,
      loading,
      resetCardSearch } = this.props;
    const { title, siteMsg } = this.state;
    const { tableProps } = this.getProps();

    const SearchBarProps = {
      search,
      onSearch: getList,
      siteList,
      onReset
    };

    const ModalProps = {
      visible: isShowAddOrEditModal,
      title,
      cancel: this.closeModal,
      resetCardSearch,
      creatSite,
      siteMsg,
      editSite,
      cardList,
      getCarList,
      loading
    };

    return (
      <div className={styles['waybill-manage']}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="end">
          <Col span={6} >
            <div className="order-list-button" style={{ textAlign: 'right' }}>
              <Button type="primary" onClick={() => this.addSite('新增')}>新增司机</Button>
              <Button onClick={this.exportDrivers}>导出表单</Button>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
        <FormModal {...ModalProps} />
      </div>
    );
  }
}
