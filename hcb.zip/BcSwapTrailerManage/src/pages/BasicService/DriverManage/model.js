import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getList, cancelWayBill, creatSite, editSite, enableSite, getCarList } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  driverName: '',
  mobile: '',
  effective: '',
  locus: '',
  belongType: '',
  routeTypeEnum: ''
};

const searchCard = {
  // truckType: '',
  plateNumber: '',
  effective: '1',
  ps: 50,
  pn: 1
};

export default Model.extend({
  namespace: 'DriverManage',

  state: {
    loading: { list: false },
    tableFields,
    search: initialSearch,
    searchCard,
    total: 0,
    list: [],
    orderCounts: [],
    cardList: [],
    isShowAddOrEditModal: false
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.DRIVER_MANAGE, async () => {
        await dispatch({ type: 'resetSearch' });
        dispatch({ type: 'resetCardSearch' });
        dispatch({ type: 'getList' });
        // dispatch({ type: 'getCarList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ DriverManage }) => DriverManage);
      const { datas, tc } = yield call(withLoading(getList, 'list'), search);
      yield update({ list: datas, total: tc });
    },

    // 获取车辆列表
    * getCarList({ payload }, { call, update, select }) {
      const { searchCard } = yield select(({ DriverManage }) => DriverManage);
      const { datas } = yield call(withLoading(getCarList, 'getCarList'), searchCard);
      yield update({ cardList: datas });
    },
    // 禁用司机
    * cancelWayBill({ payload }, { call, put }) {
      const userId = payload;
      yield call(withLoading(cancelWayBill, { successMsg: '司机已禁用！', key: 'cancelWayBill' }), { userId });
      yield put({ type: 'getList' });
    },
    // 启用司机
    * enableSite({ payload }, { call, put }) {
      const userId = payload;
      yield call(withLoading(enableSite, { successMsg: '司机已启用！', key: 'enableSite' }), { userId });
      yield put({ type: 'getList' });
    },

    //  新增司机
    * creatSite({ payload }, { call, put }) {
      yield call(withLoading(creatSite, { successMsg: '司机新增成功！', key: 'creatSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },

    //  修改司机
    * editSite({ payload }, { call, put }) {
      yield call(withLoading(editSite, { successMsg: '司机修改成功！', key: 'editSite' }), payload);
      yield put({ type: 'updateState', payload: { isShowAddOrEditModal: false } });
      yield put({ type: 'getList' });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    updateCardSearch(state, { payload }) {
      return {
        ...state,
        searchCard: { ...state.searchCard, ...payload },
      };
    },
    resetCardSearch(state, { payload }) {
      return {
        ...state,
        searchCard,
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: initialSearch
      };
    },
  },
});
