import { Button, Form, Input, Row, Col, DatePicker, Select } from 'antd';
import { mainType, payWayType, appreciationTypeAll, signingType } from 'configs/constants';

const FormItem = Form.Item;
const { RangePicker } = DatePicker;
const Option = Select.Option;

class SearchBar extends React.Component {
  state = {
    ...this.props.search,
    createTime: ''
  }

  componentWillReceiveProps = (nextProps) => {
    if (this.state.ps !== nextProps.search.ps) {
      this.setState({
        ps: nextProps.search.ps
      });
    }
  }

  // 查询
  handleSearch = () => {
    const { onSearch } = this.props;
    const search = this.state;

    if (search.createTime.length > 0) {
      search.startTime = search.createTime[0].format('YYYY-MM-DD HH:mm:ss');
      search.endTime = search.createTime[1].format('YYYY-MM-DD HH:mm:ss');
    } else {
      search.createTime = '';
      search.startTime = '';
      search.endTime = '';
    }
    const data = Object.assign({}, search);
    delete data.createTime;
    onSearch({ ...data, pn: 1 });
  }
  // 重置
  handleReset = () => {
    const { onReset, form } = this.props;
    const { resetFields } = form;
    resetFields();
    onReset();
    this.setState({
      pn: 1,
      ps: 10,
      waybillNo: '',
      fromSite: '',
      toSite: '',
      startTime: '',
      endTime: '',
      status: 'ALL',
      mainBusiness: '',
      sortType: '',
      payType: '',
      startCargoCompany: '',
      receiveCargoCompany: '',
      valueAddedServiceList: [],
      signedType: ''
    });
  }
  // 重置
  handleVerify() {
    const { updateState } = this.props;
    updateState({ verifyResult: {}, VerifyModalVisible: true });
  }

  handleChange(key) {
    return (value) => {
      let newValue = value;
      if (value && value.target) {
        newValue = value.target.value;
      }
      this.setState({ [key]: newValue });
    };
  }
  render() {
    const search = this.state;
    const { siteList = [] } = this.props;

    const searchLayout = {
      xxl: { span: 6 },
      xl: { span: 8 },
      lg: { span: 12 }
    };

    return (
      <div>
        <div className="searchBar">
          <Form layout="inline" >
            <Row gutter={24} >

              <Col {...searchLayout}>
                <FormItem label="运单号">
                  <Input
                    placeholder="输入运单号查询"
                    value={search.waybillNo}
                    onChange={this.handleChange('waybillNo')}
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="主营服务">
                  <Select
                    value={search.mainBusiness}
                    onChange={this.handleChange('mainBusiness')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      mainType.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="付款方式">
                  <Select
                    value={search.payType}
                    onChange={this.handleChange('payType')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      payWayType.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="发站">
                  <Select
                    value={search.fromSite}
                    onChange={this.handleChange('fromSite')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      siteList.map(option => (
                        <Option
                          key={option.id}
                        >
                          {option.name}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="发货公司">
                  <Input
                    placeholder="输入发货公司"
                    value={search.startCargoCompany}
                    onChange={this.handleChange('startCargoCompany')}
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="签收方式">
                  <Select
                    value={search.signedType}
                    onChange={this.handleChange('signedType')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      signingType.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="下单时间">
                  <RangePicker
                    value={search.createTime}
                    onChange={this.handleChange('createTime')}
                    style={{ width: '100%' }}
                    format="MM-DD HH:mm:ss"
                    showTime
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="到站">
                  <Select
                    value={search.toSite}
                    onChange={this.handleChange('toSite')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      siteList.map(option => (
                        <Option
                          key={option.id}
                        >
                          {option.name}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="收货公司">
                  <Input
                    placeholder="输入收货公司"
                    value={search.receiveCargoCompany}
                    onChange={this.handleChange('receiveCargoCompany')}
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="增值服务">
                  <Select
                    mode="multiple"
                    value={search.valueAddedServiceList}
                    onChange={this.handleChange('valueAddedServiceList')}
                    placeholder="请选择增值服务"
                  >
                    {/* <Option
                      value=""
                    >
                     全部
                    </Option> */}
                    {
                      appreciationTypeAll.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

            </Row>
            <Row type="flex" justify="end">
              <Col span={4}>
                <FormItem label="">
                  <Button type="primary" onClick={this.handleSearch}>搜索</Button>
                  <Button onClick={this.handleReset}>重置</Button>
                </FormItem>
              </Col>
            </Row>
          </Form>
        </div>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
