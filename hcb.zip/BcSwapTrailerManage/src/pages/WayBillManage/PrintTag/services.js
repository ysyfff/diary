import http from 'utils/http';

const { post } = http.create('admin');

export function getDetail(param) {
  return post('/web/m/waybill/get', {
    ...param
  });
}

//  查询配置信息
export function getStowage(param) {
  return post('/dapt/web/m/stowage/waybill/query', {
    ...param
  });
}

