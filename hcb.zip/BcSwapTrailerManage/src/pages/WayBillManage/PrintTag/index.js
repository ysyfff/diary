import React from 'react';
import { connect } from 'dva';
import { Button } from 'antd';
import { qs } from 'utils';
import moment from 'moment';
import JsBarcode from 'jsbarcode';

import styles from './index.less';
import logo from './logo.gif';

@connect(({ PrintTag }) => ({ ...PrintTag }))
class PrintTag extends React.PureComponent {
  state = {
    showButton: true
  }

  componentDidMount() {
    const beforePrint = () => {

    };
    const afterPrint = () => {
      this.setState({ showButton: true });
    };

    if (window.matchMedia) {
      this.mediaQueryList = window.matchMedia('print');
      this.mql = (mql) => {
        if (mql.matches) {
          beforePrint();
        } else {
          afterPrint();
        }
      };
      this.mediaQueryList.addListener(this.mql);
    }
    // 打印操作监听
    window.onbeforeprint = beforePrint;
    window.onafterprint = afterPrint;
  }

  componentWillReceiveProps = (props) => {
    const nums = [];
    for (let i = 0; i < qs('num'); i += 1) {
      nums.push(i);
    }
    const { waybillDetail = {} } = props;
    const { sheetNo, waybillCargoCreateDTOList = [] } = waybillDetail;
    if (sheetNo) {
      const num = waybillCargoCreateDTOList.map(i => i.cargoPiece).reduce((a, b) => a + b);
      this.printBarcode(sheetNo, 1, num);
      nums.forEach((element, index) => {
        this.printBarcode(sheetNo, index + 1, num);
      });
    }
  }

  componentWillUnmount() {
    this.mediaQueryList.removeListener(this.mql);
  }

  printBarcode = (sheetNo, index, num) => {
    JsBarcode(`#print-${index}`, `${sheetNo}--${index}--${num}`, {
      textPosition: 'top',
      width: 5,
      fontSize: 50,
      textMargin: 20
    });
  }

  print = () => {
    this.setState({ showButton: false }, () => {
      window.print();
    });
  }

  back = () => {
    const { history } = this.props;
    history.go(-1);
  }

  render() {
    const nums = [];
    for (let i = 0; i < qs('num'); i += 1) {
      nums.push(i);
    }
    const { showButton } = this.state;
    const { waybillDetail = {} } = this.props;
    const {
      fromSiteName,
      toSiteName,
      waybillCargoCreateDTOList = [],
      waybillCreateTime,
    } = waybillDetail;
    return (
      <div className={styles['print-preview-delivery']}>
        {
          nums.map((i, index) => [
            <div className="print-contanier" key={index}>

              <div className="print-hearder">
                <div className="print-logo">
                  <img src={logo} alt="" />
                </div>
                <div className="print-contact" >专线助理: 95006</div>
              </div>

              <div className="print-msg">
                <div className="print-address">
                  <div className="print-item">发站： {fromSiteName}</div>
                  <div className="print-item">到站： {toSiteName}</div>
                </div>
                <div className="print-address">品名： {waybillCargoCreateDTOList.map(i => i.cargoName).join('/')}</div>
                <div className="print-address">发货日期： {moment(waybillCreateTime).format('YYYY-MM-DD')}</div>
              </div>

              <svg className="print-barcode" id={`print-${index + 1}`} />
            </div>,
            <div className="page-next" />]
          )
        }
        <style type="text/css" media="print">
          {
            `@page {
              size: landscape;
              margin: 0;
            }
            .print-contanier {
                width: 100%;
                height: 5cm;
                color: #000;
            }
            .print-address {
              height: .7cm !important;
              line-height: .7cm;
            }
            `
          }
        </style>
        <Button
          type="primary"
          style={{ display: showButton ? 'inline' : 'none', marginTop: 10 }}
          onClick={this.print}
        >打印</Button>
        <Button
          type="primary"
          style={{
            display: showButton ? 'inline' : 'none',
            marginTop: 10,
            marginLeft: '12px',
          }}
          onClick={this.back}
        >返回</Button>
      </div>
    );
  }
}

export default PrintTag;
