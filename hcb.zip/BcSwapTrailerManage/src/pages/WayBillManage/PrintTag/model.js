import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { getDetail, getStowage } from './services';


export default Model.extend({
  namespace: 'PrintTag',

  state: {
    waybillDetail: {},
    stowageDetail: [],
  },

  subscriptions: {
    setupSubscriber({ listen, dispatch }) {
      listen('/waybillManage/PrintTag/:waybillNo', ({ params }) => {
        const waybillNo = params[0];
        dispatch({ type: 'fetchDetail', payload: { waybillNo } });
      });
    }
  },

  effects: {
    * fetchDetail({ payload }, { call, update }) {
      const { waybillNo } = payload;
      const waybillDetail = yield call(withLoading(getDetail, 'getDetail'), { waybillNo });
      yield update({ waybillDetail });
    },
    * fetchStowage({ payload }, { call, update }) {
      const { waybillNo } = payload;
      const stowageDetail = yield call(withLoading(getStowage, 'getStowage'), { waybillNo });
      yield update({ stowageDetail });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
      };
    },
    resetSearch(state) {
      return {
        ...state,
      };
    },
  }
});
