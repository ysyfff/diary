import { connect } from 'dva';
import { Radio, Row, Col, Button, Popover, Icon, Modal } from 'antd';
import { HTable } from 'carno';
import { Link } from 'dva/router';
import { waybillStatus } from 'configs/maps';
import { downFile } from 'utils';
import { AuthortyWarpper } from 'components';
import SearchBar from './SearchBar';
import styles from './index.less';

const confirm = Modal.confirm;

@connect(({ waybillManage }) => ({ ...waybillManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'waybillManage/updateSearch', payload: param });
    dispatch({ type: 'waybillManage/getList' });
  },
  onReset() {
    dispatch({ type: 'waybillManage/resetSearch' });
    dispatch({ type: 'waybillManage/getList' });
  },
  exportData: (params) => {
    downFile({
      server: 'admin',
      url: '/web/m/waybill/export',
      params
    });
  },
  cancelWayBill: (param) => {
    dispatch({ type: 'waybillManage/cancelWayBill', payload: param });
  },
  isWayBillLoading: (param) => {
    dispatch({ type: 'waybillManage/isWayBillLoading', payload: param });
  },
}))
export default class WayBillManage extends React.Component {
  state = {
    visiblepop: []
  }

  getProps() {
    const { tableFields, search, total, list, loading, getList, cancelWayBill, permission } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'sheetNo',
            name: '运单号',
            render: (recor, data) =>
              <Link target="_blank" to={`/waybillManage/detailWaybill/${data.waybillNo}`} >{recor}</Link>
          },
          {
            key: 'buyerName',
            name: '操作',
            render: (record, data) => !(data.state === 'CANCEL' || data.state === 'SIGNED')
              ? <Popover
                placement="right"
                overlayStyle={{ zIndex: 999 }}
                content={
                  <div>
                    <ul className="table-operate-button">
                      {
                        data.state === 'UN_LOAD' &&
                        <AuthortyWarpper code={permission.waybill.modify}>
                          <li>
                            <a onClick={() => this.testWayBill(data)}>修改运单</a>
                          </li>
                        </AuthortyWarpper>
                      }

                      {
                        data.state === 'UN_LOAD' &&
                        <AuthortyWarpper code={permission.waybill.cancel}>
                          <li>
                            <a onClick={() => confirm({
                              title: `是否取消运单：${data.sheetNo}`,
                              content: '',
                              width: 420,
                              onOk() {
                                cancelWayBill(data.waybillNo);
                              },
                            })}
                            >取消运单</a>
                          </li>
                        </AuthortyWarpper>
                      }
                      {
                        data.state !== 'SIGNED' &&
                        <li>
                          <Link target="_blank" to={`/abnormalManage/AbnormalManageDetails/create/${data.waybillNo}`} >
                            登记异常
                          </Link>
                        </li>
                      }
                      <li><Link target="_blank" to={`/waybillManage/detailWaybill/${data.waybillNo}`} >查看详情</Link></li>
                    </ul>
                  </div>
                }
              ><a><Icon type="menu-unfold" /></a>
              </Popover>
              : <Popover
                placement="right"
                overlayStyle={{ zIndex: 999 }}
                content={
                  <div>
                    <ul className="table-operate-button">
                      <li><Link target="_blank" to={`/waybillManage/detailWaybill/${data.waybillNo}`} >查看详情</Link></li>
                    </ul>
                  </div>
                }
              ><a><Icon type="menu-unfold" /></a></Popover>

          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 3900 },
        pagination,
        locale: { emptyText: '暂无运单' },
        style: { marginTop: 16 },
      },
    };
  }

  handleSearch(search) {
    this.props.getList(search);
  }

  showStatus = (key) => {
    this.props.getList({ ...this.props.search, status: key.target.value, pn: 1 });
  }

  exportData = () => {
    this.props.exportData(this.props.search);
  }

  testWayBill = (value) => {
    const { isWayBillLoading } = this.props;
    isWayBillLoading(value.waybillNo);
  }

  render() {
    const { getList, search, siteList, onReset, permission } = this.props;
    const { tableProps } = this.getProps();

    const SearchBarProps = {
      search,
      onSearch: getList,
      siteList,
      onReset
    };

    return (
      <div className={styles['waybill-manage']}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="space-between">
          <Col span={18} style={{ paddingTop: 14 }}>
            <Radio.Group buttonStyle="solid" value={search.status} onChange={this.showStatus}>
              {
                waybillStatus.map(i => (
                  <Radio.Button key={i.key} value={i.key}>{i.name}</Radio.Button>
                ))
              }
            </Radio.Group>
          </Col>
          <Col span={6}>
            <div className="order-list-button">
              <AuthortyWarpper code={permission.waybill.create}>
                <Link to="/waybillManage/addWaybill" target="_blank">
                  <Button type="primary">新建运单</Button>
                </Link>
              </AuthortyWarpper>
              <AuthortyWarpper code={permission.waybill.export}>
                <Button onClick={this.exportData}>导出表单</Button>
              </AuthortyWarpper>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
      </div>
    );
  }
}
