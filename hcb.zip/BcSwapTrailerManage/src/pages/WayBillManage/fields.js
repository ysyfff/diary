import { waybillStatus } from 'configs/maps';
import { boxType, mainType, payWayType, sendWays, signingType, appreciationTypeAll } from 'configs/constants';
// import { Popover } from 'antd';
import { EllipsisRecord } from 'components';

// const defultKey = '--';

// const formatValue = (value) => {
//   if (value !== '' && value !== undefined && value !== null) {
//     if (value.length > 14) {
//       return (
//         <Popover content={value} style={{ width: 200 }}>
//           <span>{`${value.substr(0, 14)}...`}</span>
//         </Popover>
//       );
//     }
//     return value;
//   }
//   return defultKey;
// };

export const tableFields = [
  {
    key: 'sheetNo',
    name: '运单号',
    width: 160
  },
  {
    key: 'buyerName',
    name: '操作',
    width: 80
  },
  {
    key: 'state',
    name: '状态',
    width: 100,
    render: record => record && waybillStatus.filter(i => i.key === record)[0].name
  },
  {
    key: 'mainBusiness',
    name: '主营服务',
    width: 100,
    render: record => record ? mainType.filter(i => i.key === record)[0].value : '--'
  },
  {
    key: 'dispatchType',
    name: '产品时效',
    width: 100,
    render: record => record ? sendWays.filter(i => i.key === record)[0].value : '--'
  },
  {
    key: 'valueAddedService',
    name: '增值服务',
    width: 100,
    render: record => record ? appreciationTypeAll.filter(i => i.key === record)[0].value : '--'
  },
  {
    key: 'signedType',
    name: '签收方式',
    width: 100,
    render: record => record ? signingType.filter(i => i.key === record)[0].value : '--'
  },
  {
    key: 'waybillCreateTime',
    name: '下单时间',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'fromSiteName',
    name: '发站',
    width: 80,
    render: record => <EllipsisRecord record={record || '--'} width={80} />
  },
  {
    key: 'toSiteName',
    name: '到站',
    width: 80,
    render: record => <EllipsisRecord record={record || '--'} width={80} />
  },
  {
    key: 'startCargoCompany',
    name: '发货公司',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'receiveCargoCompany',
    name: '收货公司',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'cargoName',
    name: '货物品名',
    width: 100,
    render: record => record && <EllipsisRecord record={record.join('/') || '--'} width={100} />
  },
  {
    key: 'cargoPackage',
    name: '货物包装',
    width: 100,
    render: record => record && <EllipsisRecord
      record={record.map(i => boxType.filter(j => j.key === i)[0].value).join('/') || '--'}
      width={100}
    />


  },
  {
    key: 'cargoPiece',
    name: '总件数',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'cargoWeight',
    name: '总重量（千克）',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  }, {
    key: 'cargoVolume',
    name: '总体积（方）',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'freightAmount',
    name: '费用合计',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'vehicleFreight',
    name: '整车运费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'weightFreight',
    name: '重量运费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'volumeFreight',
    name: '体积运费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'pickupTruckFee',
    name: '提货用车费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'deliveryFee',
    name: '送货用车费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'additionalFee',
    name: '附加费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'payType',
    name: '付款方式',
    width: 100,
    render: record => record ? payWayType.filter(i => i.key === record)[0].value : '--'
  },
  {
    key: 'remarks',
    name: '备注',
    width: 120,
    render: record => <EllipsisRecord record={record || '--'} width={120} />
  }
];

export const searchFields = [{
  key: 'oilTypeId',
  name: '油品类型',
}, {
  key: 'oilNumId',
  name: '标号',
}, {
  key: 'oilSpecId',
  name: '规格',
}, {
  key: 'time',
  name: '下单时间',
  type: 'dateRange',
}];
