import React from 'react';
import { Button } from 'antd';
import moment from 'moment';
import nzhcn from 'nzh/cn';
import { connect } from 'dva';
import { boxType } from 'configs/constants';

import styles from './index.less';

@connect(({ PrintWaybill, layout }) => ({ ...PrintWaybill, ...layout }))
class PrintWaybill extends React.PureComponent {
  state = {
    showButton: true
  }

  componentDidMount() {
    const beforePrint = () => {

    };
    const afterPrint = () => {
      this.setState({ showButton: true });
    };

    if (window.matchMedia) {
      this.mediaQueryList = window.matchMedia('print');
      this.mql = (mql) => {
        if (mql.matches) {
          beforePrint();
        } else {
          afterPrint();
        }
      };
      this.mediaQueryList.addListener(this.mql);
    }
    // 打印操作监听
    window.onbeforeprint = beforePrint;
    window.onafterprint = afterPrint;
  }

  componentWillUnmount() {
    this.mediaQueryList.removeListener(this.mql);
  }

  print = () => {
    this.setState({ showButton: false }, () => {
      window.print();
    });
  }

  back = () => {
    const { history, prevPath } = this.props;
    if (prevPath === '/waybillManage/addWaybill') {
      history.push('/waybillManage');
    } else {
      history.go(-1);
    }
  }

  render() {
    const { showButton } = this.state;
    const { waybillDetail = {} } = this.props;
    const {
      fromSiteName,
      toSiteName,
      // waybillNo,
      waybillCreateName,
      waybillCreateTime,
      waybillCreateNameMobile,
      remarks,
      // freightAmountStr,
      freightAmount,
      weightFreight,
      volumeFreight,
      vehicleFreight,
      pickupTruckFee,
      statementValue,
      insuranceFee,
      // returnForm,
      mainBusiness,
      valueAddedService,
      payType,
      deliveryFee,
      entrustInfoCreateDTO = {},
      recipientInfoCreateDTO = {},
      waybillCargoCreateDTOList = [],
      waybillAdditionalFeeList = []
    } = waybillDetail;

    const {
      entrustInfoAddressList = []
    } = entrustInfoCreateDTO;

    const {
      recipientInfoAddressList = []
    } = recipientInfoCreateDTO;

    return (
      <div className={styles['print-preview-delivery']}>
        <div className="print-contanier">

          {/* 订单打印头部 */}
          <div className="print-hearder">
            <div className="print-address">
              <div className="print-address-item">{fromSiteName}</div>
              <div className="print-address-item">{toSiteName}</div>
              <div className="print-address-item">{''}</div>
              <div className="print-address-item">{''}</div>
            </div>
            <div className="print-waybillNo">{''}</div>
          </div>

          {/* 订单打印主体 */}
          <div className="print-body">
            <div className="print-body-left">

              <div className="print-body-desc1" />
              <div className="print-body-msg1">
                <div className="print-msg1-item">{entrustInfoCreateDTO.companyName}</div>
                <div className="print-msg1-item">{entrustInfoAddressList.length > 0 &&
                   entrustInfoAddressList[0].contactPhone}</div>
              </div>

              <div className="print-body-desc1" />
              <div className="print-body-msg1">
                <div className="print-msg1-item">{recipientInfoCreateDTO.companyName}</div>
                <div className="print-msg1-item">{recipientInfoAddressList.length > 0 &&
                   recipientInfoAddressList[0].contactPhone}</div>
              </div>

              <div className="print-body-desc1" />
              <div className="print-body-msg2">
                <div className="print-msg1-items">
                  <div className="msg1-item">{waybillCargoCreateDTOList.map(i => i.cargoName).join('/')}</div>
                  <div className="msg1-item">{waybillCargoCreateDTOList.map(i => i.cargoPiece).join('/')}</div>
                  <div className="msg1-item">{waybillCargoCreateDTOList.map(i => i.cargoWeight).join('/')}</div>
                </div>
                <div className="print-msg1-items">
                  <div className="msg1-item">
                    { waybillCargoCreateDTOList.map(i =>
                      boxType.filter(j => j.key === i.cargoPackage)[0].value).join('/')}
                  </div>
                  <div className="msg1-item">
                    {waybillCargoCreateDTOList.map(i => i.cargoList).join('/')}
                  </div>
                  <div className="msg1-item">{waybillCargoCreateDTOList.map(i => i.cargoVolume).join('/')}</div>
                </div>
              </div>

            </div>

            <div className="print-body-right">

              <div className="print-body-desc1" />
              <div className="print-body-msg1">
                <div className="print-msg1-item" />
                <div className="print-msg1-item" />
                <div className="print-msg1-item" />
                <div className="print-msg1-item">
                  <i
                    style={{ marginLeft: mainBusiness === 'CHANNELSERVICE' ? '1.1cm' : '2.2cm', fontWeight: 'bolder' }}
                  >√</i>
                </div>
                <div className="print-msg1-item">
                  {
                    (valueAddedService === 'ALL' || valueAddedService === 'DELIVERYCAR') &&
                    <i style={{ marginLeft: '1.1cm', fontWeight: 'bolder' }}>√</i>
                  }
                  {
                    (valueAddedService === 'ALL' || valueAddedService === 'DELIVERYVEHICLE') &&
                    <i
                      style={{ marginLeft: valueAddedService === 'DELIVERYVEHICLE' ? '2.2cm' : '1.1cm',
                        fontWeight: 'bolder' }}
                    >√</i>
                  }
                </div>
                <div className="print-msg1-item">
                  <i style={{ marginLeft: payType === 'RECHARGE' ? '1cm' : '2cm', fontWeight: 'bolder' }}>√</i>
                </div>
              </div>

              <div className="print-body-desc1" />
              <div className="print-body-msg1">
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{weightFreight}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{volumeFreight}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{vehicleFreight}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{pickupTruckFee}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{deliveryFee}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >
                    {waybillAdditionalFeeList.map(i => `${i.costCategory}:${i.freightAmount}`).join('/')}
                  </div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{statementValue}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >{insuranceFee}</div>
                </div>
                <div className="print-msg2-items" >
                  <div className="msg2-item" >
                    {''}</div>
                </div>
              </div>

              <div className="print-body-desc1" />
              <div className="print-body-msg2">
                <div className="print-num">{freightAmount}</div>
                <div className="print-num">{freightAmount && nzhcn.toMoney(freightAmount, { outSymbol: false })}</div>
                <div className="print-body-desc1" />
                <div className="print-remark">{remarks}</div>
                <div className="print-pepple">
                  <div className="print-people-item">{''}</div>
                  <div className="print-people-item">{''}</div>
                </div>
              </div>

            </div>
          </div>

          {/* 订单打印底部 */}
          <div className="print-footer">
            <div className="print-footer-item" >{fromSiteName}</div>
            <div className="print-footer-item" >{waybillCreateName}</div>
            <div className="print-footer-item" >{moment(waybillCreateTime).format('YYYY-MM-DD HH:mm:ss')}</div>
            <div className="print-footer-item" >{waybillCreateNameMobile}</div>
          </div>
        </div>
        <style type="text/css" media="print">
          {
            `@page {
              size: landscape;
              margin: 0 0 0 1cm;
              }
              .print-contanier {
                width: 100%;
                height: 14cm;
                color: #000;
              }
              `
          }
        </style>
        <Button
          type="primary"
          style={{ display: showButton ? 'inline' : 'none', marginTop: 10 }}
          onClick={this.print}
        >打印</Button>
        <Button
          type="primary"
          style={{
            marginLeft: '12px',
            display: showButton ? 'inline' : 'none',
            marginTop: 10
          }}
          onClick={this.back}
        >返回</Button>
      </div>
    );
  }
}

export default PrintWaybill;
