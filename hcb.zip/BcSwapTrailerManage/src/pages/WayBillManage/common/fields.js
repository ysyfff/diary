import { Popover } from 'antd';

const defultKey = '--';

const formatValue = (value) => {
  if (value !== '' && value !== undefined && value !== null) {
    if (value.length > 14) {
      return (
        <Popover content={value}>
          <span>{`${value.substr(0, 10)}...`}</span>
        </Popover>
      );
    }
    return value;
  }
  return defultKey;
};

// 其他费用弹出框表格配置
export const tableFields = [{
  title: '费用名称',
  dataIndex: 'costCategory',
  editable: true,
  align: 'center',
  width: '40%',
  fields: {
    type: 'input',
    props: {
      maxLength: 20,
      minLength: 1,
      placeholder: '请输入费用名称'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用名称'
      }]
    }
  }
}, {
  title: '费用金额',
  dataIndex: 'freightAmount',
  editable: true,
  align: 'center',
  width: '30%',
  fields: {
    type: 'inputnumber',
    props: {
      precision: 2,
      min: 0.01,
      max: 99999.99,
      placeholder: '请输入费用金额'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用金额'
      }]
    }
  }
}];

const requiredTitle = values => <span><i style={{ color: 'red' }}>*</i> {values}</span>;

// 货物表格配置
export const goodsFields = [
  {
    title: requiredTitle('货物品名'),
    dataIndex: 'cargoName',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'input',
      props: {
        maxLength: 10,
        minLength: 1,
        placeholder: '请输入货物品名！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入货物品名！'
        }]
      }
    }
  },
  {
    title: requiredTitle('货物包装'),
    dataIndex: 'cargoPackage',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'select',
      props: {
        placeholder: '请选择包装！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请选择包装！'
        }]
      }
    }
  },
  {
    title: '货物清单',
    dataIndex: 'cargoList',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        max: (10 ** 3) - 1,
        placeholder: '请输入清单！'
      },
    }
  },
  {
    title: requiredTitle('体积（方）'),
    dataIndex: 'cargoVolume',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入体积！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入体积！'
        }]
      }
    }
  },
  {
    title: requiredTitle('件数（件）'),
    dataIndex: 'cargoPiece',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        min: 1,
        max: 10000,
        placeholder: '请输入件数！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入件数！'
        }]
      }
    }
  },
  {
    title: requiredTitle('重量（吨）'),
    dataIndex: 'cargoWeight',
    editable: true,
    align: 'center',
    width: '12%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入重量！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入重量！'
        }]
      }
    }
  },
];

// 客户信息
export const customerFields = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    width: 200,
    render: formatValue
  },
  {
    title: '客户编号',
    dataIndex: 'code',
    key: 'code',
    width: 200,
    render: formatValue
  },
  {
    title: '联系电话',
    dataIndex: 'phone',
    key: 'phone',
    width: 200,
    render: formatValue
  },
];
