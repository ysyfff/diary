import { Input, InputNumber, Form, Select } from 'antd';
import {
  boxType,
} from 'configs/constants';
import EditableContext from './EditableContext';

const FormItem = Form.Item;
const Option = Select.Option;


class EditableCell extends React.PureComponent {
  getInput = () => {
    const { type, fields } = this.props;
    switch (type) {
      case 'input':
        return <Input {...fields.props} />;
      case 'inputnumber':
        return <InputNumber {...fields.props} />;
      case 'select':
        return (<Select style={{ width: '100px' }}>
          {
            boxType.map(option => (
              <Option
                value={option.key}
                key={option.key}
              >
                {option.value}
              </Option>
            ))
          }
        </Select>);
      default:
        return <Input {...fields.props} />;
    }
  };

  render() {
    const {
      editing,
      dataIndex,
      record,
      fields,
      ...restProps
    } = this.props;
    return (
      <EditableContext.Consumer>
        {({ form }) => {
          const { getFieldDecorator } = form;
          return (
            <td {...restProps} title="">
              {editing ? (
                <FormItem style={{ margin: 0 }}>
                  {getFieldDecorator(dataIndex, {
                    ...fields.validator,
                    initialValue: record[dataIndex],
                  })(this.getInput())}
                </FormItem>
              ) : restProps.children}
            </td>
          );
        }}
      </EditableContext.Consumer>
    );
  }
}

export default EditableCell;
