import http from 'utils/http';

const { post } = http.create('admin');

// 获取运单列表
export function getList(param) {
  return post('/web/m/waybill/list', param,
    {
      contentType: 'json'
    }
  );
}

// 获取站点列表
export function getSiteList(param) {
  return post('/web/e/site/list', param);
}

//  作废运单
export function cancelWayBill(param) {
  return post('/web/m/waybill/cancel', param);
}

// 检验运单是否装载中
export function isWayBillLoading(param) {
  return post('/web/m/waybill/is-waybill-loading', param);
}

