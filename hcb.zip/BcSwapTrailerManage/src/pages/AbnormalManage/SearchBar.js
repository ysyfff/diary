import { Button, Form, Input, Row, Col, DatePicker, Select } from 'antd';
import SelectDepartment from 'components/SelectDepartment';

const FormItem = Form.Item;
const { RangePicker } = DatePicker;
const Option = Select.Option;

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    this.initlizeState = this.props.search;
    this.state = {
      ...this.initlizeState,
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      ...this.state,
      ps: nextProps.search.ps,
    });
  }

  handleSearch = () => {
    const { registerTime, dealTime } = this.state;
    const params = this.state;
    if (registerTime) {
      params.createStartTime = registerTime[0].format('YYYY-MM-DD HH:mm:ss');
      params.createEndTime = registerTime[1].format('YYYY-MM-DD HH:mm:ss');
    }
    if (dealTime) {
      params.processStartTime = dealTime[0].format('YYYY-MM-DD HH:mm:ss');
      params.processEndTime = dealTime[1].format('YYYY-MM-DD HH:mm:ss');
    }
    this.props.onSearch(params);
  }

  handleChange = key => (e) => {
    let newValue = e;
    if (e && e.target) {
      newValue = e.target.value;
    }
    this.setState({ [key]: newValue });
  };

  handleReset = () => {
    this.setState({
      ...this.initlizeState
    }, () => {
      this.props.form.resetFields();
      this.props.onReset();
    });
  }

  render() {
    const searchLayout = {
      xxl: { span: 6 },
      xl: { span: 8 },
      lg: { span: 12 }
    };
    const { abnormityTypeList } = this.props;
    const itemValue = this.state;
    return (
      <div className="searchBar">
        <Form layout="inline">
          <Row>
            <Col {...searchLayout}>
              <FormItem label="异常单号">
                <Input
                  placeholder="请输入异常单号"
                  value={itemValue.abnormityNo}
                  onChange={this.handleChange('abnormityNo')}
                />
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="登记部门">
                <SelectDepartment value={itemValue.createDept} onChange={this.handleChange('createDept')} />
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="处理部门">
                <SelectDepartment value={itemValue.processDept} onChange={this.handleChange('processDept')} />
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="运单号">
                <Input
                  placeholder="请输入运单号"
                  value={itemValue.waybillNo}
                  onChange={this.handleChange('waybillNo')}
                />
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="异常类型">
                <Select
                  value={itemValue.abnormityType}
                  onChange={this.handleChange('abnormityType')}
                >
                  <Option
                    value=""
                  >
                    全部
                  </Option>
                  {
                    abnormityTypeList.map(option => (
                      <Option
                        key={option.code}
                      >
                        {option.name}
                      </Option>
                    ))
                  }
                </Select>
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="登记时间">
                <RangePicker
                  showTime={{ format: 'HH:mm' }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={this.handleChange('registerTime')}
                  value={itemValue.registerTime}
                  style={{ width: '100%' }}
                />
              </FormItem>
            </Col>

            <Col {...searchLayout}>
              <FormItem label="处理时间">
                <RangePicker
                  showTime={{ format: 'HH:mm' }}
                  format="YYYY-MM-DD HH:mm"
                  onChange={this.handleChange('dealTime')}
                  value={itemValue.dealTime}
                  style={{ width: '100%' }}
                />
              </FormItem>
            </Col>
          </Row>
          <Row type="flex" justify="end">
            <Col span={4}>
              <FormItem label="">
                <Button type="primary" onClick={this.handleSearch}>查询</Button>
                <Button onClick={this.handleReset}>重置</Button>
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
