import http from 'utils/http';

const { post } = http.create('admin');

// 获取异常列表
export function getList(params) {
  return post('/web/m/waybill-abnormity/list', params);
}

export function cancelRegister(params) {
  return post('/web/m/waybill-abnormity/cancel', params);
}

export function getAbnormityType() {
  return post('/web/m/abnormity-type/list');
}
