import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';
import { getList, cancelRegister, getAbnormityType } from './services';

const initialSearchParams = {
  pn: 1,
  ps: PAGE_SIZE,
  abnormityNo: null,
  abnormityType: null,
  createDept: null,
  waybillNo: '',
  processDept: null,
  createStartTime: null,
  createEndTime: null,
  processStartTime: null,
  processEndTime: null,
  dealTime: null,
  registerTime: null,
  status: '',
};

export default Model.extend({
  namespace: 'abnormityManage',

  state: {
    loading: { list: false },
    search: initialSearchParams,
    list: [],
    abnormityTypeList: [],
    total: null,
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.ABNORMAL_MANAGE, () => {
        dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
        dispatch({ type: 'getAbnormityType' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ abnormityManage }) => abnormityManage);
      const data = yield call(withLoading(getList, 'list'), search);
      const { datas, tc } = data;
      yield update({ list: datas, total: tc });
    },
    * cancelRegister({ payload }, { call, update, select }) {
      const { search } = yield select(({ abnormityManage }) => abnormityManage);
      yield call(withLoading(cancelRegister, 'list', '取消成功', '取消失败'), payload);
      const dataList = yield call(withLoading(getList, 'list'), search);
      const { datas, tc } = dataList;
      yield update({ list: datas, total: tc });
    },
    * getAbnormityType({ payload }, { call, update }) {
      const type = yield call(withLoading(getAbnormityType, 'list'));
      yield update({ abnormityTypeList: type });
    }
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: {
          ...state.search,
          ...payload,
        }
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: initialSearchParams
      };
    }
  },
});
