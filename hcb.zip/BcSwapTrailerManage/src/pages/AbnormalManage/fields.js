import { Popover } from 'antd';

const CommonPopover = (record, length) => (
  <Popover content={record}>
    <span>{`${record.substring(0, length)}...`}</span>
  </Popover>
);

export const tableFields = [{
  key: 'serialNumber',
  name: '序号',
  width: 80,
}, {
  key: 'abnormityNo',
  name: '异常单号',
  width: 170
}, {
  key: 'status',
  name: '状态',
  width: 100,
  render: (record, data) =>
    data.status === 'WAIT_PROCESS' ? <span className="pending">待处理</span> : <span className="processed">已处理</span>
}, {
  key: 'operation',
  name: '操作',
  width: 80,
}, {
  key: 'waybillNo',
  name: '运单号',
  width: 170,
}, {
  key: 'abnormityName',
  name: '异常类型',
  width: 160
}, {
  key: 'abnormityTypeName',
  name: '异常名称',
  width: 160
}, {
  key: 'abnormityNumber',
  name: '异常件数',
  width: 100,
}, {
  key: 'createTime',
  name: '登记时间',
  width: 200
}, {
  key: 'createDept',
  name: '登记部门',
  width: 160
}, {
  key: 'createUserName',
  name: '登记人',
  width: 100
}, {
  key: 'createDescription',
  name: '问题描述',
  width: 260,
  render: record => record && record.length > 18 ? CommonPopover(record, 18) : record
}, {
  key: 'processTime',
  name: '处理时间',
  width: 200
}, {
  key: 'processDeptName',
  name: '处理部门',
  width: 160,
}, {
  key: 'processUserName',
  name: '处理人',
  width: 100
}, {
  key: 'processDescription',
  name: '处理意见',
  width: 260,
  render: record => record && record.length > 18 ? CommonPopover(record, 18) : record
}];
