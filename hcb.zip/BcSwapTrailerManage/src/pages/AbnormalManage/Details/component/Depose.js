import React from 'react';
import { connect } from 'dva';
import { Button, Modal } from 'antd';
import bind from 'bind-decorator';
import { AbnormalStatus } from 'configs/constants';
import { waybillStatus } from 'configs/maps';
import { SearchCard } from 'components/helper';
import UploadImg from 'components/UploadImg';
import {
  waybillFromFields,
  abnormalFromFields,
  disposelFromFields
} from './configs';

const confirm = Modal.confirm;


@connect(
  ({ abnormalManageDetails }) => ({ ...abnormalManageDetails }),
  dispatch => ({
    getRegisterabnormityList: waybillNo => (
      dispatch({ type: 'abnormalManageDetails/registerabnormityList', payload: { waybillNo } })
    ),
    abnormityProcess: payload => (
      dispatch({ type: 'abnormalManageDetails/abnormityProcess', payload })
    ),
    getNameList: payload => (
      dispatch({ type: 'abnormalManageDetails/getNameList', payload })
    ),
    getDetail: payload => (
      dispatch({ type: 'abnormalManageDetails/getDetail', payload })
    ),
  })
)
class Detail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      waybillExtraFields: [],
      abnormalExtraFields: [],
      disposelExtraFields: [],
      abnormalFileList: [],
      disposelFileList: [],
      detail: { waybill: {} }
    };
  }


  componentWillMount() {
    this.extraFields();
  }

  componentDidMount() {
    this.waybillFormHelper = this.waybillForm.props.helper;
    this.abnormalFormHelper = this.abnormalForm.props.helper;
    this.disposelFormFormHelper = this.disposelForm.props.helper;
    this.getDetail();
  }

  @bind
  onUploadChange(disposelFileList) {
    this.setState({ disposelFileList });
  }

  @bind
  async onSubmit() {
    const { abnormityNo, abnormityProcess } = this.props;
    const { processDescription } = await this.validateFields();
    const params = {
      abnormityNo,
      processDescription,
      processStroeIds: this.state.disposelFileList.map(({ uid }) => uid)
    };
    abnormityProcess(params);
  }


  async getDetail() {
    const { abnormityNo, getNameList } = this.props;

    const datas = await this.props.getDetail({ abnormityNo });
    const { waybill, createAttends } = datas;
    // 货物数据转换
    const cargoParams = waybill.cargos.reduce((prev, { cargoName, cargoNumber, cargoVolume, cargoWeight }) => ({
      cargoName: prev.cargoName.concat(cargoName),
      cargoPiece: prev.cargoPiece + cargoNumber,
      cargoWeight: prev.cargoWeight + cargoWeight,
      cargoVolume: prev.cargoVolume + cargoVolume,
    }), {
      cargoName: [],
      cargoPiece: 0,
      cargoWeight: 0,
      cargoVolume: 0
    });

    const waybillData = {
      ...waybill,
      ...cargoParams,
      state: (waybillStatus.find(({ key }) => key === waybill.waybillStatus) || {}).name
    };
    getNameList({ abnormityType: datas.abnormityType });
    this.waybillFormHelper.setFieldsValues({ ...waybillData });
    this.abnormalFormHelper.setFieldsValues({ ...datas, processDept: datas.processDeptName });
    const abnormalFileList = createAttends.map(({ url, stroeId }) => ({ url, uid: stroeId }));
    this.setState({ abnormalFileList, detail: datas });
  }

  validateFields() {
    const disposelForm = this.disposelFormFormHelper.getForm();
    return new Promise((resolve, reject) => {
      const values = {};

      const valuedate = (err, value) => {
        if (!err) {
          Object.assign(values, value);
        } else {
          reject();
        }
      };

      disposelForm.validateFields(valuedate);

      resolve(values);
    });
  }

  extraFields() {
    const { detail } = this.state;
    const waybillExtraFields = [
      {
        key: 'waybillNo',
        type: 'input',
        el: {
          disabled: true
        },
        render: null
      },
      {
        key: 'more',
        el: {
          waybillNo: detail.waybill.waybillNo
        },
      }
    ];

    const abnormalExtraFields = [
      {
        key: 'abnormityType',
        el: {
          disabled: true
        }
      },
      {
        key: 'processDept',
        el: {
          disabled: true
        }
      },
      {
        key: 'abnormityNameNo',
        el: {
          disabled: true
        }
      },
      {
        key: 'abnormityNumber',
        el: {
          disabled: true
        }
      },
      {
        key: 'createDescription',
        el: {
          disabled: true
        }
      },
      {
        key: 'storeId',
        render: () => (
          <UploadImg
            config={{ maxCount: 10 }}
            disabled
            value={this.state.abnormalFileList}
            onRemove={() => false}
          />
        )
      },
    ];

    const disposelExtraFields = [

      {
        key: 'processDescription',
        el: {
          disabled: false
        },

      },
      {
        key: 'storeId',
        render: () => (
          <UploadImg
            config={{ maxCount: 10 }}
            value={this.state.disposelFileList}
            onChange={this.onUploadChange}
            onRemove={() => (
              new Promise((resolve, reject) => {
                confirm({
                  title: '删除',
                  content: '确认删除该附件',
                  okText: '确认',
                  cancelText: '取消',
                  onOk() {
                    resolve();
                  },
                  onCancel() {
                    reject();
                  },
                });
              })
            )}
          />
        )
      },
    ];
    return {
      waybillExtraFields, abnormalExtraFields, disposelExtraFields
    };
  }

  render() {
    const { typeList, nameList, abnormityNo } = this.props;
    const { detail } = this.state;
    const extraFields = this.extraFields();
    const status = (AbnormalStatus.find(({ key }) => key === detail.status) || {}).value;

    const extraFieldsForAbonrmal = [
      ...this.state.abnormalExtraFields,
      ...extraFields.abnormalExtraFields,
      {
        key: 'abnormityType',
        el: {
          options: typeList.map(({ name, code }) => ({ key: code, value: name }))
        }
      },
      {
        key: 'abnormityNameNo',
        el: {
          options: nameList.map(({ name, code }) => ({ key: code, value: name }))
        }
      }
    ];

    return (
      <React.Fragment>
        <div className="header">
          <span>异常单号：{abnormityNo}</span>
          <span className="statu">{status} </span>
        </div>
        <SearchCard
          fields={waybillFromFields}
          title="运单信息"
          extraFields={[...extraFields.waybillExtraFields, ...this.state.waybillExtraFields]}
          wrappedComponentRef={el => this.waybillForm = el}
        />
        <SearchCard
          fields={abnormalFromFields}
          title="异常信息"
          extraFields={extraFieldsForAbonrmal}
          wrappedComponentRef={el => this.abnormalForm = el}
        />
        <SearchCard
          fields={disposelFromFields}
          title="处理信息"
          extraFields={[...extraFields.disposelExtraFields, ...this.state.disposelExtraFields]}
          wrappedComponentRef={el => this.disposelForm = el}

        />
        <div className="footer">
          <Button type="primary" onClick={this.onSubmit}>保存</Button>
          <Button className="ml20" onClick={() => window.close()}>取消</Button>
        </div>
      </React.Fragment>
    );
  }
}


export default Detail;
