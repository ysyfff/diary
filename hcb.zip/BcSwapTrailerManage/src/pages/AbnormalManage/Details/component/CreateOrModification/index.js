import { bind } from 'bind-decorator';
import { Rule } from 'carno/utils';
import { cookie } from 'carno/third-party';
import React from 'react';
import { connect } from 'dva';
import { withRouter } from 'dva/router';
import { Button, Modal, Input } from 'antd';
import { HSelect } from 'carno';
import { SearchCard } from 'components/helper';
import UploadImg from 'components/UploadImg';
import { Paths, detailPageType, createWaybillNo } from 'configs/constants';
import { waybillStatus } from 'configs/maps';
import {
  waybillFromFields,
  abnormalFromFields,
} from '../configs';

const confirm = Modal.confirm;
const customCode = 'QTL'; // 异常类型其它类型的Code


@withRouter
@connect(
  ({ abnormalManageDetails }) => ({ ...abnormalManageDetails }),
  dispatch => ({
    getRegisterabnormityList: waybillNo => (
      dispatch({ type: 'abnormalManageDetails/registerabnormityList', payload: { waybillNo } })
    ),
    getNameList: payload => (
      dispatch({ type: 'abnormalManageDetails/getNameList', payload })
    ),
    abnormityAdd: payload => (
      dispatch({ type: 'abnormalManageDetails/abnormityAdd', payload })
    ),
    abnormityUpdate: payload => (
      dispatch({ type: 'abnormalManageDetails/abnormityUpdate', payload })
    ),
    getDetail: payload => (
      dispatch({ type: 'abnormalManageDetails/getDetail', payload })
    ),
    getUserDetail: () =>
      dispatch({ type: 'abnormalManageDetails/userDetail', payload: { userId: cookie.get('uid') } })
  })
)
class CreateOrModification extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      waybillExtraFields: [],
      abnormalExtraFields: [],
      detail: { waybill: {} },
      fileList: [],
      isCustomCode: false
    };
    this.waybillData = {};
    this.selectDepartmentData = {};
  }


  componentDidMount() {
    const { pageType, waybillNo } = this.props;
    this.waybillFormHelper = this.waybillForm.props.helper;
    this.abnormalFormHelper = this.abnormalForm.props.helper;
    if (pageType === detailPageType.modification) {
      this.getDetail();
    }
    // 有运单号时主动获取运单数据
    if (waybillNo && createWaybillNo !== waybillNo) {
      this.getWaybillDataThenSet(waybillNo);
    }

    this.getUserDetail();
  }

  @bind
  onUploadChange(fileList) {
    this.setState({ fileList });
  }

  @bind
  onAbnormityTypeChange(abnormityType) {
    const abnormalForm = this.abnormalFormHelper.getForm();

    this.props.getNameList({ abnormityType });

    if (this.state.isCustomCode) { // 不是其它类型
      this.setState({ isCustomCode: false });
      const abnormalExtraFields = [
        {
          key: 'abnormityNameNo',
          type: 'select',
          el: {
            placeholder: '请选择',
          },
          formItem: {
            options: {
              rules: [
                { required: true, message: '请选择异常名称' }
              ]
            }
          }
        }
      ];
      this.setState({ isCustomCode: false, abnormalExtraFields });
      abnormalForm.setFieldsValue({ abnormityNameNo: '' });
    }


    if (abnormityType === customCode) {
      const abnormalExtraFields = [
        {
          key: 'abnormityNameNo',
          type: 'input',
          el: {
            placeholder: '请输入',
          },
          formItem: {
            options: {
              rules: [
                { required: true, message: '请输入异常名称' },
                Rule.maxLength(20, '请输入最多$1位字符'),
              ]
            }
          }
        }
      ];
      this.setState({ isCustomCode: true, abnormalExtraFields });
      abnormalForm.setFieldsValue({ abnormityNameNo: '' });
    }
  }

  @bind
  async onSubmit() {
    const { nameList, pageType, abnormityNo } = this.props;
    const { detail } = this.state;
    const values = await this.validateFields();
    const {
      waybillNo, abnormityType,
      abnormityNumber, processDept, createDescription, abnormityNameNo
    } = values;


    const params = {
      processDeptName: this.selectDepartmentData.title,
      waybillNo,
      abnormityType,
      abnormityNumber,
      processDept,
      createDescription,
      sheetNo: this.waybillData.sheetNo,
      storeIds: this.state.fileList.map(({ uid }) => uid)
    };

    if (this.state.isCustomCode) {
      Reflect.set(params, 'abnormityName', abnormityNameNo);
    } else {
      const { name: abnormityName } = nameList.find(({ code }) => code === abnormityNameNo);
      Reflect.set(params, 'abnormityNameNo', abnormityNameNo);
      Reflect.set(params, 'abnormityName', abnormityName);
    }
    if (pageType === detailPageType.modification) {
      this.props.abnormityUpdate(
        {
          ...params,
          abnormityNo,
          sheetNo: detail.waybill.sheetNo,
        }
      );
    } else {
      this.props.abnormityAdd(params);
    }
  }


  async getDetail() {
    const { abnormityNo, getNameList } = this.props;

    const datas = await this.props.getDetail({ abnormityNo });

    const { waybill, createAttends, processAttends } = datas;
    // 货物数据转换
    const cargoParams = waybill.cargos.reduce((prev, { cargoName, cargoNumber, cargoVolume, cargoWeight }) => ({
      cargoName: prev.cargoName.concat(cargoName),
      cargoPiece: prev.cargoPiece + cargoNumber,
      cargoWeight: prev.cargoWeight + cargoWeight,
      cargoVolume: prev.cargoVolume + cargoVolume,
    }), {
      cargoName: [],
      cargoPiece: 0,
      cargoWeight: 0,
      cargoVolume: 0
    });

    const waybillData = {
      ...waybill,
      ...cargoParams,
      state: waybill.waybillStatus,
    };
    // 保存部门数据
    this.selectDepartmentData = {
      title: datas.processDeptName,
      code: datas.processDept
    };


    getNameList({ abnormityType: datas.abnormityType });
    this.waybillFormHelper.setFieldsValues({ ...waybillData });
    this.abnormalFormHelper.setFieldsValues({ ...datas });

    this.disposelFormFormHelper && this.disposelFormFormHelper.setFieldsValues({ ...datas });

    const abnormalFileList = createAttends.map(({ url, stroeId }) => ({ url, uid: stroeId }));
    const disposelFileList = processAttends.map(({ url, stroeId }) => ({ url, uid: stroeId }));
    this.setState({ abnormalFileList, disposelFileList, detail: datas });
  }

  async getUserDetail() {
    const { orgName, realName } = await this.props.getUserDetail();
    this.abnormalFormHelper.setFieldsValues({
      processDeptName: orgName,
      createUserName: realName
    });
  }

  // 获取可以登记的运单列表
  @bind
  async getRegisterabnormityList(waybillNo) {
    const list = await this.props.getRegisterabnormityList(waybillNo);
    return list || [];
  }
  // 主动获取运单数据
  async getWaybillDataThenSet(waybillNo) {
    const [waybillData] = await this.getRegisterabnormityList(waybillNo);
    this.setWaybillInfo(waybillData);
  }
  // 设置获取到的运单信息
  @bind
  setWaybillInfo(wabillData) {
    if (!wabillData) {
      this.waybillFormHelper.resetFields();
      this.waybillData = {};
      return;
    }
    this.waybillFormHelper.setFieldsValues({
      ...wabillData,
      state: waybillStatus.find(({ key }) => key === wabillData.state).name
    });
    this.waybillData = wabillData;
  }

  validateFields() {
    const waybillForm = this.waybillFormHelper.getForm();
    const abnormalForm = this.abnormalFormHelper.getForm();
    return new Promise((resolve, reject) => {
      const values = {};

      const valuedate = (err, value) => {
        if (!err) {
          Object.assign(values, value);
        } else {
          reject();
        }
      };

      waybillForm.validateFields(valuedate);
      abnormalForm.validateFields(valuedate);

      resolve(values);
    });
  }


  extraFields() {
    const { pageType, waybillNo } = this.props;
    const { detail } = this.state;
    const isCreate = pageType === detailPageType.create;

    const moreField = {
      key: 'more',
      el: {
        waybillNo: isCreate ? this.waybillData.waybillNo : detail.waybill.waybillNo
      },
    };

    if (isCreate) {
      moreField.render = () => '';
    }

    const waybillDisabled = (
      pageType === detailPageType.modification ||
      (!!waybillNo && createWaybillNo !== waybillNo)
    );

    const waybillExtraFields = [
      {
        key: 'waybillNo',
        el: {
          onSearch: this.getRegisterabnormityList,
          onSelect: this.setWaybillInfo,
          // 修改登记 或者指定运单号时不能输入运单号
          disabled: waybillDisabled
        }
      },
      moreField
    ];


    const abnormalExtraFields = [
      {
        key: 'abnormityType',
        el: {
          disabled: false,
          onSelect: this.onAbnormityTypeChange
        }
      },
      {
        key: 'abnormityNameNo',
        el: {
          disabled: false
        }
      },
      {
        key: 'processDept',
        el: {
          extraChange: extraVal => this.selectDepartmentData = extraVal
        }
      },
      {
        key: 'storeId',
        render: () => (
          <UploadImg
            config={{ maxCount: 10 }}
            value={this.state.fileList}
            onChange={this.onUploadChange}
            onRemove={() => (
              new Promise((resolve, reject) => {
                confirm({
                  title: '删除',
                  content: '确认删除该附件',
                  okText: '确认',
                  cancelText: '取消',
                  onOk() {
                    resolve();
                  },
                  onCancel() {
                    reject();
                  },
                });
              })
            )}
          />
        )
      },
    ];
    return {
      waybillExtraFields,
      abnormalExtraFields
    };
  }


  render() {
    const { typeList, nameList, history, loading } = this.props;
    const extraFields = this.extraFields();
    const extraFieldsForAbonrmal = [
      ...this.state.abnormalExtraFields,
      ...extraFields.abnormalExtraFields,
      {
        key: 'abnormityType',
        el: {
          options: typeList.map(({ name, code }) => ({ key: code, value: name }))
        }
      },
      {
        key: 'abnormityNameNo',
        // el: {
        //   options: nameList.map(({ name, code }) => ({ key: code, value: name }))
        // },
        render: ({ form, ...props }) =>
          !this.state.isCustomCode
            ? <HSelect {...props} options={nameList.map(({ name, code }) => ({ value: code, label: name }))} />
            : <Input {...props} />
      }
    ];

    return (
      <React.Fragment >
        <SearchCard
          fields={waybillFromFields}
          title="运单信息"
          extraFields={[...this.state.waybillExtraFields, ...extraFields.waybillExtraFields]}
          wrappedComponentRef={el => this.waybillForm = el}
        />
        <SearchCard
          fields={abnormalFromFields}
          title="异常信息"
          extraFields={extraFieldsForAbonrmal}
          wrappedComponentRef={el => this.abnormalForm = el}
        />

        <div className="footer">
          <Button type="primary" loading={loading.submit} onClick={this.onSubmit}>保存</Button>
          <Button className="ml20" onClick={() => history.push(Paths.ABNORMAL_MANAGE)}>取消</Button>
        </div>
      </React.Fragment>
    );
  }
}


export default CreateOrModification;
