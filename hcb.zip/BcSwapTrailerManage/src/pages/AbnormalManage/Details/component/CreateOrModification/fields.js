import { waybillStatus } from 'configs/maps';
import { dispatchType, mainType } from 'configs/constants';


export default [
  {
    title: '运单号',
    dataIndex: 'waybillNo',
    key: 'waybillNo'
  },
  {
    title: '状态',
    dataIndex: 'state',
    key: 'state',
    render: value => value ? waybillStatus.find(({ key }) => key === value).name : '--'
  },
  {
    title: '主营服务',
    dataIndex: 'mainBusiness',
    key: 'mainBusiness',
    render: value => value ? mainType.find(({ key }) => key === value).value : '--'
  },
  {
    title: '产品时效',
    dataIndex: 'dispatchType',
    key: 'dispatchType',
    render: value => value ? dispatchType.find(({ key }) => key === value).value : '--'
  },
  {
    title: '下单时间',
    dataIndex: 'waybillCreateTime',
    key: 'waybillCreateTime'
  },
  {
    title: '发站',
    dataIndex: 'fromSiteName',
    key: 'fromSiteName'
  },
  {
    title: '到站',
    dataIndex: 'toSiteName',
    key: 'toSiteName'
  },
  {
    title: '货物名称',
    dataIndex: 'cargoName',
    key: 'cargoName',
    render: (value = []) => value.join(',')
  },
  {
    title: '货物包装',
    dataIndex: 'cargoPackage',
    key: 'cargoPackage',
    render: (value = []) => value.join(',')
  },
  {
    title: '件数(件)',
    dataIndex: 'cargoPiece',
    key: 'cargoPiece'
  },
  {
    title: '重量(千克)',
    dataIndex: 'cargoWeight',
    key: 'cargoWeight'
  },
  {
    title: '体积(方)',
    dataIndex: 'cargoVolume',
    key: 'cargoVolume'
  },
];
