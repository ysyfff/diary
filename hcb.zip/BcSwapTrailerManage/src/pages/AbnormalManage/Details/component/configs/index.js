import waybillFromFields from './base.waybill.config';
import abnormalFromFields from './base.abnormal.config';
import disposelFromFields from './base.dispose.config';

export {
  waybillFromFields,
  abnormalFromFields,
  disposelFromFields
}
;
