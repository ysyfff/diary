import { Rule } from 'carno/utils';
import SelectDepartment from 'components/SelectDepartment';

const COL = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};


const FORM_ITEM_COL_LAYOUT_LARGE = {
  labelCol: {
    xxl: { span: 2 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};


export default [
  {
    key: 'abnormityType',
    label: '异常类型',
    type: 'select',
    el: {
      placeholder: '请选择',
    },

    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择异常类型' }
        ]
      }
    }
  },
  {
    key: 'abnormityNameNo',
    label: '异常名称',
    type: 'select',
    el: {
      placeholder: '请选择',
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择异常名称' }
        ]
      }
    }
  },
  {
    key: 'abnormityNumber',
    label: '异常件数',
    type: 'inputnumber',
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请输入异常数量' },
          Rule.inRange(0, 10000, '请输入$1-$2之间的整数'),
        ]
      }
    }
  },
  {
    key: 'processDeptName', //-------------------
    label: '登记部门',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'createUserName', //-------------------
    label: '登记人',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'createTime', //-------------------
    label: '登记时间',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'processDept',
    label: '处理部门',
    type: 'input',
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择处理部门' }
        ]
      }
    },
    render: ({ form, ...props }) => (
      <SelectDepartment {...props} />
    )
  },
  {
    key: 'createDescription',
    label: '问题描述',
    type: 'textarea',
    el: {
      // disabled: true
    },
    col: { span: 18 },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT_LARGE },
      options: {
        rules: [
          { required: true, message: '请输入问题描述' }
        ]
      }
    }
  },
  {
    key: 'storeId',
    label: '附件',
    col: { span: 24 },
    formItem: {
      props: { labelCol: { span: 2 } },
    },

  },
];
