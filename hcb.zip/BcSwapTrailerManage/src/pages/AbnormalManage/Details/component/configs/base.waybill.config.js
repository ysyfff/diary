import { Link } from 'dva/router';
import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';
import tableFields from '../CreateOrModification/fields';

const COL = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

export default [
  {
    key: 'waybillNo',
    label: '运单号',
    type: 'input',
    el: {
      placeholder: '请选择输入运单号',
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择输入运单号' }
        ]
      }
    },
    render: ({ form, ...props }) => (
      <AutoSearchInput
        {...props}
        inputKey="waybillNo"
        columns={tableFields}
        dropDownTableWidth={1190}
        defaultSearchValue=""
        scrollX={false}
      />
    )
  },
  {
    key: 'state',
    label: '运单状态',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'fromSiteName',
    label: '发站',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'toSiteName',
    label: '到站',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'cargoName',
    label: '货物品名',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'cargoPiece',
    label: '件数(件)',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'cargoWeight',
    label: '重量(千克)',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'cargoVolume',
    label: '体积(方)',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'cargoPackage',
    label: '包装',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'waybillCreateTime',
    label: '开单时间',
    type: 'input',
    el: {
      disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  // 占位
  {
    key: 'placeholder',
    label: '',
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    },
    render: () => ''
  },
  {
    key: 'more',
    type: 'input',
    col: { ...COL },
    formItem: {
      props: {
        labelCol: {
          span: 0
        },
        wrapperCol: {
          span: 18
        }
      },
    },
    render: ({ waybillNo }) =>
      <div style={{ textAlign: 'right' }}>
        <Link target="_blank" to={`/waybillManage/detailWaybill/${waybillNo}`}>查看更多</Link>
      </div>
  },
];
