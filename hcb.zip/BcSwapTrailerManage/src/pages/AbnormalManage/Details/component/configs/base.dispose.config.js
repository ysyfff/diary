import { Rule } from 'carno/utils';

const COL = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const FORM_ITEM_COL_LAYOUT_LARGE = {
  labelCol: {
    xxl: { span: 2 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};


export default [
  {
    key: 'processUserName',
    label: '处理人',
    type: 'input',
    el: {
      placeholder: '请选择',
      disabled: true
    },

    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },
  {
    key: 'createTime',
    label: '处理时间',
    type: 'input',
    el: {
      placeholder: '请选择', disabled: true
    },
    col: { ...COL },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT },
    }
  },

  {
    key: 'processDescription',
    label: '处理意见',
    type: 'textarea',
    el: {
      disabled: true
    },
    col: { span: 18 },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT_LARGE },
      options: {
        rules: [
          { required: true, message: '请填写处理意见' },
          Rule.maxLength(512, '请输入最多$1位字符'),
        ]
      }
    }
  },
  {
    key: 'storeId',
    label: '附件',
    // type: 'input',
    el: {
      disabled: true
    },
    col: { span: 18 },
    formItem: {
      props: { ...FORM_ITEM_COL_LAYOUT_LARGE },
    },
    // render: () => (
    //   <UploadImg />
    // )
  },
];
