import React from 'react';
import { connect } from 'dva';
import { HLogic } from 'carno';
import bind from 'bind-decorator';
import { SearchCard } from 'components/helper';
import UploadImg from 'components/UploadImg';
import { AbnormalStatus } from 'configs/constants';
import { waybillStatus } from 'configs/maps';
import {
  waybillFromFields,
  abnormalFromFields,
  disposelFromFields
} from './configs';

const { If } = HLogic;
const [, complete] = AbnormalStatus;

@connect(
  ({ abnormalManageDetails }) => ({ ...abnormalManageDetails }),
  dispatch => ({
    getDetail: payload => (
      dispatch({ type: 'abnormalManageDetails/getDetail', payload })
    ),
    getNameList: payload => (
      dispatch({ type: 'abnormalManageDetails/getNameList', payload })
    ),
  })
)
class Detail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      waybillExtraFields: [],
      abnormalExtraFields: [],
      disposelExtraFields: [],
      abnormalFileList: [],
      disposelFileList: [],
      detail: { waybill: {} }
    };
  }

  componentDidMount() {
    this.waybillFormHelper = this.waybillForm.props.helper;
    this.abnormalFormHelper = this.abnormalForm.props.helper;
    // this.disposelFormFormHelper
    this.getDetail();
  }

  @bind
  onUploadChange(fileList) {
    this.setState({ fileList });
  }

  async getDetail() {
    const { abnormityNo, getNameList } = this.props;

    const datas = await this.props.getDetail({ abnormityNo });
    const { waybill, createAttends, processAttends } = datas;
    // 货物数据转换
    const cargoParams = waybill.cargos.reduce((prev, { cargoName, cargoNumber, cargoVolume, cargoWeight }) => ({
      cargoName: prev.cargoName.concat(cargoName),
      cargoPiece: prev.cargoPiece + cargoNumber,
      cargoWeight: prev.cargoWeight + cargoWeight,
      cargoVolume: prev.cargoVolume + cargoVolume,
    }), {
      cargoName: [],
      cargoPiece: 0,
      cargoWeight: 0,
      cargoVolume: 0
    });

    const waybillData = {
      ...waybill,
      ...cargoParams,
      state: (waybillStatus.find(({ key }) => key === waybill.waybillStatus) || {}).name
    };

    this.waybillFormHelper.setFieldsValues({ ...waybillData });
    this.abnormalFormHelper.setFieldsValues({ ...datas, processDept: datas.processDeptName });

    getNameList({ abnormityType: datas.abnormityType });
    const abnormalFileList = createAttends.map(({ url, stroeId }) => ({ url, uid: stroeId }));
    const disposelFileList = processAttends.map(({ url, stroeId }) => ({ url, uid: stroeId }));
    this.setState({ abnormalFileList, disposelFileList, detail: datas }, () => {
      if (this.disposelForm) {
        this.disposelFormFormHelper = this.disposelForm.props.helper;
        this.disposelFormFormHelper && this.disposelFormFormHelper.setFieldsValues({ ...datas });
      }
    });
  }


  extraFields() {
    const { detail } = this.state;
    const waybillExtraFields = [
      {
        key: 'waybillNo',
        type: 'input',
        el: {
          disabled: true
        },
        render: null
      },
      {
        key: 'more',
        el: {
          waybillNo: detail.waybill.waybillNo
        },
      }
    ];

    const abnormalExtraFields = [
      {
        key: 'abnormityType',
        el: {
          disabled: true
        }
      },
      {
        key: 'processDept',
        el: {
          disabled: true
        }
      },
      {
        key: 'abnormityNameNo',
        el: {
          disabled: true
        }
      },
      {
        key: 'abnormityNumber',
        el: {
          disabled: true
        }
      },
      {
        key: 'createDescription',
        el: {
          disabled: true
        }
      },
      {
        key: 'storeId',
        render: () => (
          <UploadImg
            config={{ maxCount: 10 }}
            value={this.state.abnormalFileList}
            disabled
            onRemove={() => false}
          />
        )
      },
    ];

    const disposelExtraFields = [
      {
        key: 'storeId',
        render: () => (
          <UploadImg
            config={{ maxCount: 10 }}
            value={this.state.disposelFileList}
            disabled
            onRemove={() => false}
          />
        )
      },
    ];

    return {
      waybillExtraFields, abnormalExtraFields, disposelExtraFields
    };
  }

  render() {
    const { typeList, nameList, abnormityNo } = this.props;
    const { detail } = this.state;
    const extraFields = this.extraFields();
    const status = (AbnormalStatus.find(({ key }) => key === detail.status) || {}).value;

    const extraFieldsForAbonrmal = [
      ...this.state.abnormalExtraFields,
      ...extraFields.abnormalExtraFields,
      {
        key: 'abnormityType',
        el: {
          options: typeList.map(({ name, code }) => ({ key: code, value: name }))
        }
      },
      {
        key: 'abnormityNameNo',
        el: {
          options: nameList.map(({ name, code }) => ({ key: code, value: name }))
        }
      }
    ];

    return (
      <React.Fragment>
        <div className="header">
          <span>异常单号：{abnormityNo}</span>
          <span className="statu">{status} </span>
        </div>
        <SearchCard
          fields={waybillFromFields}
          title="运单信息"
          extraFields={[...this.state.waybillExtraFields, ...extraFields.waybillExtraFields]}
          wrappedComponentRef={el => this.waybillForm = el}
        />
        <SearchCard
          fields={abnormalFromFields}
          title="异常信息"
          extraFields={extraFieldsForAbonrmal}
          wrappedComponentRef={el => this.abnormalForm = el}
        />
        <If when={detail.status === complete.key}>
          <SearchCard
            fields={disposelFromFields}
            title="处理信息"
            extraFields={[...this.state.disposelExtraFields, ...extraFields.disposelExtraFields]}
            wrappedComponentRef={(el) => { this.disposelForm = el; }}
          />
        </If>
      </React.Fragment>
    );
  }
}


export default Detail;
