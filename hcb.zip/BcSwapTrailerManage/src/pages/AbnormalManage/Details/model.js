import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, detailPageType } from 'configs/constants';

import {
  abnormityAdd, registerabnormityList, userDetail,
  typeList, nameList, detail, abnormityUpdate, abnormityProcess
} from './services';

const delay = time => new Promise(resolve => setTimeout(resolve, time));

const wayillMaxLength = 8;
export default Model.extend({
  namespace: 'abnormalManageDetails',

  state: {
    pageType: 'string',
    loading: {
      add: false,
      detail: false
    },
    typeList: [],
    nameList: [],
    abnormityNo: '',
    waybillNo: ''
  },

  subscriptions: {
    setup({ listen, dispatch }) {
      // 获取页面类型
      /**
     * pageType 详情页面类型
     * detail 详情页
     * create 登记异常
     * dispose 处理异常
     * modification  修改异常
     */
      const onListen = ({ params, pathname }) => {
        const [abnormityNo] = params;
        const pageType = pathname.split('/').slice(0, 4).pop();
        const payload = {
          pageType
        };
        if (pageType === detailPageType.create) {
          payload.waybillNo = abnormityNo;
          payload.abnormityNo = '';
        } else {
          payload.abnormityNo = abnormityNo;
          payload.waybillNo = '';
        }
        dispatch({ type: 'updateState', payload });
        dispatch({ type: 'getTypeList' });
      };

      listen({
        [Paths.ABNORMITY_Detail]: onListen,
        [Paths.ABNORMITY_Creat]: onListen,
        [Paths.ABNORMITY_Dispose]: onListen,
        [Paths.ABNORMITY_Modification]: onListen,
      });
    }
  },

  effects: {
    * abnormityAdd({ payload }, { call }) {
      yield call(withLoading(abnormityAdd, 'submit', '登记成功'), { ...payload });
      yield delay(1000);
      window.close();
    },
    * abnormityUpdate({ payload }, { call }) {
      yield call(withLoading(abnormityUpdate, 'submit', '修改成功'), { ...payload });
      yield delay(1000);
      window.close();
    },
    * abnormityProcess({ payload }, { call }) {
      yield call(withLoading(abnormityProcess, 'submit', '处理成功'), { ...payload });
      yield delay(1000);
      window.close();
    },
    * getDetail({ payload }, { call }) {
      const data = yield call(withLoading(detail, 'detail'), { ...payload });
      return data;
    },
    * registerabnormityList({ payload }, { call }) {
      const list = yield call(registerabnormityList, { ...payload });
      return (list || []).slice(0, wayillMaxLength);
    },
    * getTypeList({ payload }, { call, update }) {
      const typeListData = yield call(typeList);
      yield update({ typeList: typeListData });
    },
    * getNameList({ payload }, { call, update }) {
      const nameListData = yield call(nameList, { ...payload });
      yield update({ nameList: nameListData });
    },
    * userDetail({ payload }, { call }) {
      const detail = yield call(userDetail, { ...payload });
      return detail;
    },
  },

  reducers: {

  }
});
