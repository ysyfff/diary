import { connect } from 'dva';
import { detailPageType } from 'configs/constants';
import { Spin } from 'antd';
import styles from './index.less';
import CreateOrModification from './component/CreateOrModification';
import Depose from './component/Depose';
import Detail from './component/Detail';

const renderMap = {
  [detailPageType.detail]: Detail,
  [detailPageType.create]: CreateOrModification,
  [detailPageType.modification]: CreateOrModification,
  [detailPageType.dispose]: Depose,
};

@connect(
  ({ abnormalManageDetails }) => ({ ...abnormalManageDetails }),
)
export default class Details extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  render() {
    const { pageType, loading } = this.props;
    const Current = renderMap[pageType];

    return (
      <div className={styles.details}>
        <Spin spinning={loading.detail}>
          {Current && <Current />}
        </Spin>
      </div>
    );
  }
}
