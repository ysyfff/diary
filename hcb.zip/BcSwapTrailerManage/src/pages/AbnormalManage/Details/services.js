import http from 'utils/http';

const { post } = http.create('admin');
const { post: uc } = http.create('uc');

// 查询可登记异常的运单列表
/**
 *
 * @param {waybillNo} 运单号
 */
export function registerabnormityList(param) {
  return post('/web/m/waybill/registerabnormity-list', param);
}

// 新增异常
export function abnormityAdd(param) {
  return post('/web/m/waybill-abnormity/add', param);
}
// 修改异常
export function abnormityUpdate(param) {
  return post('/web/m/waybill-abnormity/edit', param);
}
// 处理异常
export function abnormityProcess(param) {
  return post('/web/m/waybill-abnormity/process', param);
}


// 异常详情
/**
 *
 * @param {abnormityNo} 异常编号
 */
export function detail(param) {
  return post('/web/m/waybill-abnormity/detail', param);
}

// 异常类型列表
export function typeList(param) {
  return post('/web/m/abnormity-type/list', param);
}

// 异常名称列表
export function nameList(param) {
  return post('/web/m/abnormity-name/list', param);
}

// 查询用户详情
export function userDetail(param) {
  return uc('/web/e/user/detail', param);
}
