import { connect } from 'dva';
import { Row, Col, Radio, Button, Popover, Icon, Modal } from 'antd';
import { Link } from 'dva/router';
import { HTable } from 'carno';
import { abnormalStatus } from 'configs/maps';
import { downFile } from 'utils';
import { Paths, detailPageType, createWaybillNo } from 'configs/constants';
import { AuthortyWarpper } from 'components';
import { tableFields } from './fields';
import SearchBar from './SearchBar';
import styles from './index.less';

const confirm = Modal.confirm;

const getDetailsPath = (type, abnormityNo) => (
  `${Paths.ABNORMITY_Creat.split('/').slice(0, 3).join('/')}/${type}${abnormityNo ? `/${abnormityNo}` : ''}`
);

@connect(({ abnormityManage }) => ({ ...abnormityManage }), dispatch => ({
  getList(params) {
    dispatch({ type: 'abnormityManage/updateSearch', payload: params });
    dispatch({ type: 'abnormityManage/getList' });
  },
  exportData: (params) => {
    downFile({
      server: 'admin',
      url: '/web/m/waybill-abnormity/export',
      params
    });
  },
  onReset() {
    dispatch({ type: 'abnormityManage/resetSearch' });
    dispatch({ type: 'abnormityManage/getList' });
  },
  onSearch(params) {
    dispatch({ type: 'abnormityManage/updateSearch', payload: params });
    dispatch({ type: 'abnormityManage/getList' });
  },
  cancelRegister(params) {
    dispatch({ type: 'abnormityManage/cancelRegister', payload: params });
  }
}))
export default class AbnormalManage extends React.PureComponent {
  getProps() {
    const { getList, total, list, search, loading, cancelRegister, permission } = this.props;
    const { pn, ps } = search;
    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ pn: 1, ps: size })
    };

    return {
      tableProps: {
        fields: tableFields,
        loading: loading.list,
        extraFields: [
          {
            key: 'serialNumber',
            name: '序号',
            render: (record, data, index) => <span>{(index + 1) + ((pn - 1) * ps)}</span>
          },
          {
            key: 'abnormityNo',
            name: '异常单号',
            render: record => <Link target="_blank" to={getDetailsPath(detailPageType.detail, record)}>{record}</Link>
          },
          {
            key: 'waybillNo',
            name: '运单号',
            render: record =>
              <Link
                style={{ color: '#0000CD' }}
                target="_blank"
                to={`/waybillManage/detailWaybill/${record}`}
              >
                {record}
              </Link>
          },
          {
            key: 'operation',
            name: '操作',
            render: (record, data) =>
              <Popover
                placement="right"
                overlayStyle={{ zIndex: 999 }}
                content={
                  <ul className="table-operate-button">
                    {
                      (data.status === 'WAIT_PROCESS')
                        ?
                        (
                          <div>
                            <AuthortyWarpper code={permission.abnormity.process} renderLine >
                              <li>
                                <Link
                                  target="_blank"
                                  to={getDetailsPath(detailPageType.dispose, data.abnormityNo)}
                                >处理</Link>
                              </li>
                            </AuthortyWarpper>
                            <AuthortyWarpper code={permission.abnormity.modify} renderLine >
                              <li>
                                <Link
                                  target="_blank"
                                  to={getDetailsPath(detailPageType.modification, data.abnormityNo)}
                                >修改</Link>
                              </li>
                            </AuthortyWarpper>
                            <AuthortyWarpper code={permission.abnormity.cancel} renderLine >
                              <li>
                                <a onClick={() => confirm({
                                  title: '取消',
                                  content: '确认取消登记？',
                                  width: 420,
                                  onOk() {
                                    cancelRegister({ abnormityNo: data.abnormityNo });
                                  },
                                })}
                                >取消</a>
                              </li>
                            </AuthortyWarpper>
                            <li>
                              <Link
                                target="_blank"
                                to={getDetailsPath(detailPageType.detail, data.abnormityNo)}
                              >查看</Link>
                            </li>
                          </div>
                        )
                        : (
                          <Link
                            target="_blank"
                            to={getDetailsPath(detailPageType.detail, data.abnormityNo)}
                          >查看</Link>
                        )
                    }
                  </ul>}
              >
                <a><Icon type="menu-unfold" /></a>
              </Popover>
          },
        ],
        dataSource: list,
        scroll: { x: 2500 },
        pagination,
        locale: { emptyText: '暂无运单' },
        style: { marginTop: 16 },
        search,
      }
    };
  }

  changeStatus = (e) => {
    const type = { status: e.target.value };
    this.props.getList(type);
  }
  render() {
    const { tableProps } = this.getProps();
    const { onSearch, onReset, search, exportData, abnormityTypeList, permission } = this.props;
    const searchProps = {
      onReset,
      onSearch,
      search,
      abnormityTypeList,
    };

    return (
      <div className={styles['abnormal-manage']}>
        <SearchBar {...searchProps} />
        <Row type="flex" justify="space-between">
          <Col span={18} style={{ paddingTop: 14 }}>
            <Radio.Group buttonStyle="solid" value={search.status} onChange={this.changeStatus}>
              {
                abnormalStatus.map(i => (
                  <Radio.Button key={i.key} value={i.status}>{i.name}</Radio.Button>
                ))
              }
            </Radio.Group>
          </Col>
          <Col span={6}>
            <div className="order-list-button">
              <AuthortyWarpper code={permission.abnormity.create} renderLine >
                <Link
                  target="_blank"
                  to={getDetailsPath(detailPageType.create, createWaybillNo)}
                >
                  <Button type="primary">登记异常</Button>
                </Link>
              </AuthortyWarpper>
              <AuthortyWarpper code={permission.abnormity.export} renderLine >
                <Button onClick={() => { exportData(search); }}>导出表单</Button>
              </AuthortyWarpper>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
      </div>
    );
  }
}
