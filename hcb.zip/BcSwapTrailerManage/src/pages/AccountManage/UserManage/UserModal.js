import { Form } from 'antd';
import { HModal, HForm } from 'carno';
import { Regex } from 'carno/utils';

const HFormItem = HForm.FormItem;

const layout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 16 },
};

function UserModal({
  form,
  visible,
  confirmLoading,
  fields,
  user = {},
  onOk,
  onCancel,
}) {
  const { id } = user;

  const modalProps = {
    title: `${id ? '修改' : '添加'}用户`,
    confirmLoading,
    visible,
    form,
    onOk: values => onOk({ id, ...values }),
    onCancel,
  };

  const rules = {
    name: [{ required: true, message: '请输入姓名' }],
    account: [{ required: true, message: '请输入账号(手机号)' }, { pattern: Regex.Phone, message: '请输入正确的手机号' }],
  };

  return (
    <HModal {...modalProps}>
      <HForm
        form={form}
        fields={fields}
        rules={rules}
        initialValue={user}
        {...layout}
      >
        <HFormItem itemKey="account" inputProps={{ maxLength: 11 }} />
        <HFormItem itemKey="name" inputProps={{ maxLength: 10 }} />
        <HFormItem itemKey="roleId" />
      </HForm>
    </HModal>
  );
}

export default Form.create()(UserModal);
