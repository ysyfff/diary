import http from 'utils/http';

const { get, post, put, del } = http.create('admin');

// 获取用户列表
export function getList(param) {
  return get('/admin/enterprise/user/list', param);
}

// 添加用户
export function createUser(param) {
  return post('/admin/enterprise/user/save', param);
}

// 修改用户
export function updateUser(param) {
  return put('/admin/enterprise/user/update', param);
}

// 删除用户
export function deleteUser() {
  return del('/admin/enterprise/user/del');
}

