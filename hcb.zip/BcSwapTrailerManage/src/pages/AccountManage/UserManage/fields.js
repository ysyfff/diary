const ROLES = [
  { label: '财务', value: '1' },
  { label: '销售', value: '2' },
];

export const tableFields = [{
  key: 'name',
  name: '姓名',
}, {
  key: 'account',
  name: '账号',
}, {
  key: 'roleId',
  name: '角色',
  enums: ROLES,
}];

export const modalFields = [{
  key: 'account',
  name: '账号(手机号)',
}, {
  key: 'name',
  name: '姓名',
}, {
  key: 'roleId',
  name: '角色',
  enums: ROLES,
}];
