import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { getList, createUser, updateUser, deleteUser } from './services';
import { tableFields, modalFields } from './fields';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
};

export default Model.extend({
  namespace: 'userManage',

  state: {
    tableFields,
    modalFields,
    search: initialSearch,
    list: [],
    total: 0,
  },

  subscriptions: {
    setup({ listen, dispatch }) {
      listen(Paths.USER_MANAGE, () => {
        dispatch({ type: 'getList' });
      });
    }
  },

  effects: {
    // 获取用户列表
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ userManage }) => userManage);
      const { list, total } = yield call(withLoading(getList, 'list'), search);
      yield update({ list, total });
    },

    // 保存用户
    * saveUser({ payload: param }, { call, put }) {
      yield call(withLoading(param.id ? updateUser : createUser, { key: 'confirm', withDone: true }), param);
      yield put({ type: 'getList' });
    },

    // 删除用户
    * deleteUser({ payload: id }, { call, put }) {
      yield call(deleteUser, id);
      yield put({ type: 'getList' });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
