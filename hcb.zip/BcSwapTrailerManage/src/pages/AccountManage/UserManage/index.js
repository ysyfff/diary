import { connect } from 'dva';
import { Button, Popconfirm, Divider } from 'antd';
import { HTable } from 'carno';
import bind from 'bind-decorator';

import UserModal from './UserModal';

@connect(({ userManage }) => ({ ...userManage }), dispatch => ({
  // 获取用户列表
  getList(param) {
    dispatch({ type: 'userManage/updateSearch', payload: param });
    dispatch({ type: 'userManage/getList' });
  },
  // 保存用户数据
  saveUser(param) {
    dispatch({ type: 'userManage/saveUser', payload: param });
  },
  // 删除用户
  deleteUser(id) {
    dispatch({ type: 'userManage/deleteUser', payload: id });
  },
}))
export default class UserManage extends React.Component {
  state = {
    visible: false,
    user: {},
  }

  getProps() {
    const { visible, user } = this.state;
    const { tableFields, modalFields, search, total, list, loading } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => this.handleSearch({ pn }),
    };

    return {
      tableProps: {
        fields: tableFields,
        operateField: this.getOperateField(),
        dataSource: list,
        loading: loading.list,
        search,
        pagination,
        locale: { emptyText: '未添加用户' },
      },
      modalProps: {
        confirmLoading: loading.confirm,
        user,
        fields: modalFields,
        visible,
        onOk: this.props.saveUser,
        onCancel: this.clearUser,
      },
    };
  }

  getOperateField() {
    return {
      name: '操作',
      width: '15%',
      render: (text, record) => (
        <div>
          <a onClick={() => this.handleModal(record)}>修改</a>
          <Divider type="vertical" />
          <Popconfirm
            placement="top"
            title="是否删除此用户？"
            onConfirm={() => this.props.deleteUser(record.id)}
            okText="是"
            cancelText="否"
          >
            <a>删除</a>
          </Popconfirm>
        </div>
      )
    };
  }

  @bind
  handleSearch(search) {
    this.props.getList(search);
  }

  handleModal(user = {}) {
    this.setState({ visible: Symbol(''), user });
  }

  render() {
    const { tableProps, modalProps } = this.getProps();

    return (
      <div>
        <div className="actions">
          <Button type="primary" onClick={() => this.handleModal({})}>添加用户</Button>
        </div>
        <HTable {...tableProps} />
        <UserModal {...modalProps} />
      </div>
    );
  }
}

