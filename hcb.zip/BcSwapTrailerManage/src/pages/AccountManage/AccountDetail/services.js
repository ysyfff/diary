import http from 'utils/http';

const { get } = http.create('admin');

// 获取账户信息
export function getAccount() {
  return get('/admin/enterprise/user/account/info');
}
