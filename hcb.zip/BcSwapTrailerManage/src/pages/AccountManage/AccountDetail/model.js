import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';

import descriptionFields from './fields';
import { getAccount } from './services';

export default Model.extend({
  namespace: 'accountDetail',

  state: {
    descriptionFields,
    accountDetail: {},
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.ACCOUNT_DETAIL, () => {
        dispatch({ type: 'getAccount' });
      });
    }
  },

  effects: {
    // 获取账户信息
    * getAccount({ payload }, { call, update }) {
      const accountDetail = yield call(withLoading(getAccount, 'spin'));

      yield update({ accountDetail });
    },
  },

  reducers: {}
});
