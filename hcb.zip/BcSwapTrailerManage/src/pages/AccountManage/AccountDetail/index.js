import { connect } from 'dva';
import { Spin } from 'antd';
import { HDescriptionList } from 'carno';
import { UploadImg } from 'components';

import styles from './index.less';

const { Description } = HDescriptionList;

@connect(({ accountDetail }) => ({ ...accountDetail }))
export default class AccountDetail extends React.Component {
  render() {
    const { accountDetail, loading, descriptionFields } = this.props;
    const { attachmentList = [] } = accountDetail;

    return (
      <Spin spinning={loading.spin}>
        <HDescriptionList size="large" col="2">
          {descriptionFields.map(({ key, name, render }) => (
            <Description key={key} term={name}>
              {render ? render(accountDetail[key], accountDetail) : (accountDetail[key] || '-')}
            </Description>
          ))}
        </HDescriptionList>
        <HDescriptionList size="large" col="2" layout="vertical" className={styles.list}>
          {attachmentList.map(({ id, name, url }) => (
            <Description key={id} term={name} className={styles.description}>
              <UploadImg
                disabled
                value={[{ url, thumbUrl: url, uid: id, status: 'done' }]}
                config={{ showUploadList: { showRemoveIcon: false } }}
              />
            </Description>
          ))}
        </HDescriptionList>
      </Spin>
    );
  }
}
