export default [
  { key: 'account', name: '账号' },
  { key: 'types', name: '企业类型' },
  { key: 'name', name: '企业名称' },
  { key: 'shortName', name: '企业简称' },
  { key: 'mainBusiness', name: '主营服务' },
  { key: 'creditCode', name: '统一社会信用代码' },
  { key: 'legalPerson', name: '企业法人' },
  { key: 'idCard', name: '身份证号' },
  {
    key: 'provinceName',
    name: '企业地址',
    render(text, { cityName, countyName }) {
      return [text, cityName, countyName].filter(x => x).join('/') || '-';
    }
  },
  { key: 'address', name: '详细街道' },
];
