import Login from './Login';
import OrderManage from './OrderManage';
import AccountDetail from './AccountManage/AccountDetail';
import UserManage from './AccountManage/UserManage';
import WayBillManage from './WayBillManage';
import StowageManage from './SendStation/StowageManage';
import StowageDetail from './SendStation/StowageManage/StowageDetail';
import AddStowage from './SendStation/StowageManage/AddStowage';
import AddSharing from './SendStation/StowageManage/AddSharing';
import EditStowage from './SendStation/StowageManage/EditStowage';
import EditSharing from './SendStation/StowageManage/EditSharing';
import Home from './Home';
import TransportManage from './BasicService/TransportManage';
import SiteManage from './BasicService/SiteManage';
import CustomerManage from './BasicService/CustomerManage';
import ContractPathManage from './BasicService/CustomerManage/ContractPathManage';
import ArriveManage from './ToSiteManage/ArriveManage';
import PickupList from './SendStation/Pickup/List';
import PickupAdd from './SendStation/Pickup/Add';
import PickupEdit from './SendStation/Pickup/Edit';
import PickupDetail from './SendStation/Pickup/Detail';
import AbnormalManage from './AbnormalManage';
import AbnormalManageDetails from './AbnormalManage/Details';
// import SendStationList from './SendStation/Pickup/List';
// import SendStationDetail from './SendStation/Pickup/Detail';
import ArriveStock from './ToSiteManage/ArriveStock';
import DeliveryManage from './ToSiteManage/DeliveryManage';
import AddDeliveryNote from './ToSiteManage/DeliveryManage/DeliveryNoteAdd';
import DeliveryNoteDetail from './ToSiteManage/DeliveryManage/DeliveryNoteDetail';
import TruckSend from './SendStation/TruckSend';
import LineManage from './BasicService/LineManage';
import DriverManage from './BasicService/DriverManage';
import TrailerManage from './BasicService/TrailerManage';
import TruckDetail from './SendStation/TruckSend/TruckDetail';
import SignSelf from './ToSiteManage/SignManage/SignSelf';
import SignOther from './ToSiteManage/SignManage/SignOther';
import UpdateTruck from './SendStation/TruckSend/UpdateTruck';
import TruckDispatch from './SendStation/TruckSend/TruckDispatch';
import AddTruck from './SendStation/TruckSend/AddTruck';
import ArriveDetail from './ToSiteManage/ArriveManage/ArriveDetail';
import DeliveryNoteEdit from './ToSiteManage/DeliveryManage/DeliveryNoteEdit';
import GoodsStock from './SendStation/GoodsStock';
import PrintPreview from './ToSiteManage/DeliveryManage/PrintPreview';
import PrintWaybill from './WayBillManage/PrintWaybill';
import PrintHandOver from './common/PrintHandOver';
import PrintTag from './WayBillManage/PrintTag';
import PrintPickUp from './SendStation/Pickup/PrintPreview';
import Order from './OrderManage/Order';
import OrderEdit from './OrderManage/OrderEdit';
import OrderDetail from './OrderManage/OrderDetail';
import WayBillAdd from './WayBillManage/WayBillAdd';
import WayBillDetail from './WayBillManage/WayBillDetail';
import WayBillEdit from './WayBillManage/WayBillEdit';
import CreateCustomer from './BasicService/CustomerManage/Create';
import CustomerDetail from './BasicService/CustomerManage/Detail';
import Role from './Permission/Role/List';
import Employee from './Permission/Employee';
// import CreateAbnormity from './AbnormalManage/CreateAbnormity';
import DepartmentManage from './Permission/DepartmentManage/';

export default {
  Login,
  OrderManage,
  Order,
  OrderEdit,
  OrderDetail,
  AccountDetail,
  UserManage,
  WayBillManage,
  WayBillAdd,
  WayBillDetail,
  WayBillEdit,
  StowageManage,
  StowageDetail,
  AddStowage,
  AddSharing,
  EditStowage,
  EditSharing,
  Home,
  TransportManage,
  SiteManage,
  CustomerManage,
  ContractPathManage,
  ArriveManage,
  PickupList,
  // SendStationList,
  // SendStationDetail,
  ArriveStock,
  DeliveryManage,
  AddDeliveryNote,
  DeliveryNoteDetail,
  PickupAdd,
  PickupEdit,
  PickupDetail,
  TruckSend,
  LineManage,
  DriverManage,
  TrailerManage,
  TruckDetail,
  SignSelf,
  SignOther,
  UpdateTruck,
  TruckDispatch,
  AddTruck,
  ArriveDetail,
  DeliveryNoteEdit,
  GoodsStock,
  PrintPreview,
  PrintWaybill,
  PrintHandOver,
  PrintTag,
  PrintPickUp,
  CreateCustomer,
  CustomerDetail,
  Role,
  Employee,
  AbnormalManage,
  AbnormalManageDetails,
  // CreateAbnormity,
  DepartmentManage
};
