import { Type } from 'carno/utils';

export const _span = ({ spanNumber, type, value }) => {
  const result = {
    children: value,
    props: {}
  };
  if (type === 'row') {
    result.props.rowSpan = spanNumber;
  } else {
    result.props.colSpan = spanNumber;
  }
  return result;
};

export const columns = [{
  title: '序号',
  dataIndex: 'key1',
  render: (value, row, index) => {
    const iindex = index + 1;
    if (row.isTotal) {
      return _span({ spanNumber: 2, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 1, type: 'col', value });
    }
    return iindex;
  },
}, {
  title: '运单号',
  dataIndex: 'sheetNo',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 0, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 13, type: 'col', value });
    }
    return value;
  },
}, {
  title: '收货人',
  dataIndex: 'contact',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 3, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  },

}, {
  title: '收货人电话',
  dataIndex: 'contactPhone',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 0, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  },
}, {
  title: '品名',
  dataIndex: 'cargoName',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 0, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  },
}, {
  title: '件数',
  dataIndex: 'packages',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '送货费',
  dataIndex: 'key7',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '现付',
  dataIndex: 'key8',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '提付',
  dataIndex: 'key9',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '回单付',
  dataIndex: 'key10',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '体积',
  dataIndex: 'cubage',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '重量',
  dataIndex: 'weight',
  render: (value, row) => {
    if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  }
}, {
  title: '交接方式',
  dataIndex: 'valueAddedService',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 2, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  },
}, {
  title: '备注',
  dataIndex: 'remarks',
  width: '15%',
  render: (value, row) => {
    if (row.isTotal) {
      return _span({ spanNumber: 0, type: 'col', value });
    } else if (row.isRemark) {
      return _span({ spanNumber: 0, type: 'col', value });
    }
    return value;
  },
}];

export const driverColumns = [
  {
    title: '车牌号码',
    dataIndex: 'plateNumber',
    render(v) {
      return Type.isEmpty(v) ? <div>&nbsp;</div> : v;
      // return v;
    }
  },
  {
    title: '司机姓名',
    dataIndex: 'driverName',
  },
  {
    title: '联系电话',
    dataIndex: 'driverMobile',
  },
  {
    title: '发车里程',
    dataIndex: 'key4',
  },
  {
    title: '到达里程',
    dataIndex: 'key5',
  },
  {
    title: '是否满油',
    dataIndex: 'key6',
  },
  {
    title: '加油地点',
    dataIndex: 'key7',
  },
  {
    title: '配载员',
    dataIndex: 'key8',
  },
  {
    title: '发货方',
    dataIndex: 'key9',
  },
  {
    title: '调度',
    dataIndex: 'key10',
  },
  {
    title: '收货方',
    dataIndex: 'key11',
  },
];
