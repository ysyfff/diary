import React from 'react';
import { Button, Table, Row, Col } from 'antd';
import { connect } from 'dva';
// import NP from 'number-precision';
import { appreciationTypeAll, transform2Object } from 'configs/constants';
import styles from './index.less';

const appreciationTypeObject = transform2Object(appreciationTypeAll);

const buildPZData = ({ stowage = {}, splitPrintDTOList = [] }) => {
  const effSplitPrintDTOList = splitPrintDTOList || [];
  const {
    sealNo,
    totalCubage,
    totalPackages,
    totalWeight
  } = stowage;
  const list = effSplitPrintDTOList.map((item) => {
    const {
      cargoName,
      waybillNo,
      sheetNo,
      waybillDetailDTO,
      cubage,
      packages,
      weight
    } = item;
    const {
      recipientInfoCreateDTO = {},
      // entrustInfoCreateDTO = {},
      valueAddedService,
      remarks
    } = waybillDetailDTO;
    // const {
    //   contact,
    //   contactPhone,
    // } = recipientInfoCreateDTO;
    const {
      recipientInfoAddressList = []
    } = recipientInfoCreateDTO;

    const {
      contact,
      contactPhone
    } = recipientInfoAddressList[0] || {};
    return {
      sheetNo,
      waybillNo,
      contact,
      contactPhone,
      cargoName,
      cubage,
      packages,
      weight,
      valueAddedService: appreciationTypeObject[valueAddedService],
      remarks
    };
  });

  list.push({
    key1: '合计',
    isTotal: true,
    contact: `共${effSplitPrintDTOList.length}票`,
    packages: totalPackages,
    cubage: totalCubage,
    weight: totalWeight
  });

  list.push({
    key1: '备注',
    isRemark: true,
    sheetNo: sealNo ? `封签号：${sealNo}` : ''
  });

  return list;
};


// @connect(({ stowageDetail }) => ({ ...stowageDetail }))
@connect(({ truckDetail }) => ({ ...truckDetail }))
@connect(({ printHandOver }) => ({ ...printHandOver }))
class PrintHandOver extends React.PureComponent {
  state = {
    showButton: true
  }

  componentDidMount() {
    // const { history } = this.props;
    const beforePrint = () => {

    };
    const afterPrint = () => {
      this.setState({ showButton: true });
      // debugger
      // history.go(-1);
    };

    if (window.matchMedia) {
      this.mediaQueryList = window.matchMedia('print');
      this.mql = (mql) => {
        if (mql.matches) {
          beforePrint();
        } else {
          afterPrint();
        }
      };
      this.mediaQueryList.addListener(this.mql);
    }
    // 打印操作监听
    window.onbeforeprint = beforePrint;
    window.onafterprint = afterPrint;
    // setTimeout(() => {
    //   window.print();
    // }, 0);
  }

  componentWillUnmount() {
    this.mediaQueryList.removeListener(this.mql);
  }

  print = () => {
    this.setState({ showButton: false }, () => {
      window.print();
    });
  }

  render() {
    // /PZ100249000511/GX100252000464
    const { showButton } = this.state;
    const { columns, driverColumns, stowageDetail, dispatchDetail, dispatchNo } = this.props;
    // console.log(driverColumns, '666')
    // debugger
    const { stowage = {} } = stowageDetail;
    const { siteLineRangeName } = stowage;
    const { arterys = [] } = dispatchDetail;
    const { planDepartureDate = '' } = arterys[0] || {};
    return (
      <div className={styles['print-preview-delivery']}>
        <div className="preview-delivery">
          <h1 className="print-preview-title">贵阳货车帮聚英盟项目部交接清单</h1>
          <div className="tool-bar">
            <div className="site-range">
              <span htmlFor="fromtime">运行区间：</span>
              <span name="fromtime">{siteLineRangeName}</span>
            </div>
            <div className="from-time">
              <span htmlFor="fromtime">发车时间：</span>
              <span name="fromtime">{planDepartureDate}</span>
            </div>
            <div className="to-time">
              <span htmlFor="fromtime">发车批次：</span>
              <span name="fromtime">{dispatchNo}</span>
            </div>
          </div>
          <div className="print-table-container">
            <Table
              columns={columns}
              bordered
              dataSource={buildPZData(stowageDetail)}
              pagination={false}
            />
          </div>

          <div className="print-table-container pt10">
            <Table
              columns={driverColumns}
              bordered
              dataSource={arterys || []}
              pagination={false}
            />
          </div>
        </div>
        <style media="print">
          {
            `@page {
              size: 23cm auto;
              margin: 0.5cm;
            }`
          }
        </style>
        <Row type="flex" justify="center" className="mt20">
          <Col >
            <Button
              type="primary"
              style={{ display: showButton ? 'inline' : 'none', marginLeft: 10 }}
              onClick={this.print}
            >打印</Button>
            <Button
              style={{ display: showButton ? 'inline' : 'none', marginLeft: 10 }}
              onClick={() => {
                // window.history.go(-1); // 返回列表页
                window.close();
              }}
            >取消</Button>
          </Col>
        </Row>
      </div>
    );
  }
}

export default PrintHandOver;
