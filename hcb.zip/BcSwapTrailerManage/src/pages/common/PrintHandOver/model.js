import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
// import { routerRedux } from 'dva/router';
import { columns, driverColumns } from './fields';
import { getStowageDetail } from './services';
// import { getRelateOrderList, getTruckList, getTrailerList, createOrder } from '../services';

// debugger
export default Model.extend({
  namespace: 'printHandOver',
  state: {
    columns,
    driverColumns,
    loading: { list: false },
    stowageDetail: '',
    stowageNo: '',
    dispatchNo: '',
    goBackStep: 1
  },
  subscriptions: {
    setupSubscriber({ listen, dispatch }) {
      listen('/sendStation/printHandOver/:stowageNo/:dispatchNo/:goBackStep', ({ params }) => {
        const stowageNo = params[0];
        const dispatchNo = params[1];
        const goBackStep = params[2];
        dispatch({ type: 'updateState', payload: { stowageNo, dispatchNo, goBackStep } });
        dispatch({ type: 'getStowageDetail', payload: { stowageNo } });
        dispatch({ type: 'truckDetail/getDispatchDetail', payload: { dispatchNo } });
      });
    }
  },
  effects: {
    * getStowageDetail({ payload }, { call, update }) {
      const stowageDetail = yield call(withLoading(getStowageDetail, 'list'), { ...payload });
      yield update({
        stowageDetail
      });
    }
    // * getRelateOrderList({ payload }, { call, update }) {
    //   const yundanDatas = yield call(withLoading(getRelateOrderList, 'getRelateOrderList'), { ...payload });

    //   yield update({
    //     yundanDatas
    //   });
    // },
    // * getTruckList({ payload }, { call, update }) {
    //   const { datas } = yield call(withLoading(getTruckList, 'getTruckList'), { ...payload });
    //   yield update({
    //     truckList: datas
    //   });
    // },
    // * getTrailerList({ payload }, { call, update }) {
    //   const { datas } = yield call(withLoading(getTrailerList, 'getTrailerList'), { ...payload });
    //   yield update({
    //     trailerList: datas
    //   });
    // },
    // * createOrder({ payload }, { call, put }) {
    //   yield call(withLoading(createOrder, { successMsg: '提货派车单新增成功！', key: 'createOrder' }), { ...payload });
    //   yield put(routerRedux.push('/sendStation/pickup'));
    // }
  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    },
  }
});
