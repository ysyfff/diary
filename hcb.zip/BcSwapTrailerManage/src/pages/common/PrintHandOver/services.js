import http from 'utils/http';

const { post } = http.create('dapt');

// 查询配载单，只适用于打印
export function getStowageDetail(params) {
  return post('/web/m/stowage/detail', params);
}
