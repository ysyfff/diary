import { Link } from 'dva/router';

const StepAction = (props) => {
  const { title, icon, imgClassName, to } = props;
  const Component = to !== null && typeof to === 'object' ?
    (
      <Link className="step-action" to={to}>
        <img className={imgClassName || ''} src={icon} alt={title} />
        <p className="title">{title}</p>
      </Link>
    ) :
    (
      <a className="step-action">
        <img className={imgClassName || ''} src={icon} alt={title} />
        <p className="title">{title}</p>
      </a>
    );
  return Component;
};

export default StepAction;
