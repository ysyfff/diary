
import { connect } from 'dva';
import { Paths } from 'configs/constants';
import StepTag from './StepTag';
import StepAction from './StepAction';
import './index.less';

@connect(({ login }) => ({ ...login }))
export default class Home extends React.Component {
  render() {
    return (
      <div className="home">
        <div className="home-main">
          <div className="action-border from-site-action">
            <div className="action-tag">
              <StepTag title="发站操作" />
            </div>
            <div className="step-container">
              <div className="customer-orders">
                <StepAction
                  icon={require('./images/customer.png')}
                  title="客户订单"
                  to={{ pathname: Paths.ORDER_MANAGE }}
                />
              </div>
              <div className="dashed-line-arrow" />
              <div className="step-many-container">
                <div className="t-truck">
                  <StepAction
                    icon={require('./images/hang.png')}
                    title="提货派车"
                    to={{ pathname: Paths.SEND_STATION_PICKUP }}
                  />
                  <div className="dashed-line-arrow vertical-line" />
                </div>
                <StepAction
                  icon={require('./images/yundan.png')}
                  title="创建运单"
                  to={{ pathname: Paths.WAYBILL_MANAGE }}
                />
              </div>
              <div className="solid-line-arrow" />
              <StepAction
                icon={require('./images/stock.png')}
                title="发货库存"
                to={{ pathname: Paths.GOODS_STOCK }}
              />
              <div className="solid-line-arrow" />
              <StepAction
                icon={require('./images/peizai.png')}
                title="配载管理"
                to={{ pathname: Paths.STOWAGE_MANAGE }}
              />
              <div className="solid-line-arrow" />
              <StepAction
                icon={require('./images/hang.png')}
                title="干线派车"
                to={{ pathname: Paths.TRUCK_SEND }}
              />
            </div>
          </div>
          <div className="arrow-container">
            <div className="solid-line-arrow" />
          </div>
          <div className="action-border from-site-action">
            <div className="action-tag">
              <StepTag title="到站操作" />
            </div>
            <div className="step-container">
              <StepAction
                imgClassName="icon-track"
                icon={require('./images/track.png')}
                title="到车管理"
                to={{ pathname: Paths.ARRIVE_MANAGE }}
              />
              <div className="solid-line-arrow" />
              <div className="stock">
                <StepAction
                  icon={require('./images/stock.png')}
                  title="到货库存"
                  to={{ pathname: Paths.ARRIVE_STOCK }}
                />
              </div>
              <div className="dashed-line-arrow" />
              <div className="step-many-container">
                <div className="t-truck">
                  <StepAction
                    icon={require('./images/yundan.png')}
                    title="自提签收"
                    to={{ pathname: Paths.SIGN_SELF }}
                  />
                  <div className="dashed-line-arrow vertical-line" />
                </div>
                <StepAction
                  icon={require('./images/hang.png')}
                  title="送货派车"
                  to={{ pathname: Paths.DELIVERY_MANAGE }}
                />
              </div>
              <div className="dashed-line-arrow" />
              <StepAction
                icon={require('./images/yundan.png')}
                title="送货签收"
                to={{ pathname: Paths.SIGN_OTHER }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
