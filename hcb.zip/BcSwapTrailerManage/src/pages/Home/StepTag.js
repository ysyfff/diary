const StepTag = (props) => {
  const { title } = props;
  return (
    <div className="home-step-tag">
      <div className="title-tag title-tag-top">
        <strong className="title">{title}</strong>
      </div>
      <div className="title-tag title-tag-middle" />
      <div className="title-tag title-tag-bottom" />
    </div>
  );
};

export default StepTag;
