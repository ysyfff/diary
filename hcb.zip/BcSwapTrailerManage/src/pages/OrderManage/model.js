import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields, searchFields } from './fields';
import { getList, cancelOrder } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  orderNo: '',
  mainBusiness: '',
  takeTime: '',
  shipCompanyName: '',
  createTime: '',
  valueAddedService: [],
  signWay: '',
  sendWay: '',
  recCompanyName: '',
  operateStatus: ''
};

export default Model.extend({
  namespace: 'orderManage',

  state: {
    loading: { list: false },
    tableFields,
    searchFields,
    search: initialSearch,
    total: 0,
    list: [],
    orderCounts: [],
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.ORDER_MANAGE, () => {
        dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ orderManage }) => orderManage);
      const { datas, tc } = yield call(withLoading(getList, 'list'), {
        ...search,
        valueAddedService: search.valueAddedService.join(',')
      });

      yield update({ list: datas, total: tc });
    },

    // 作废订单
    * cancelOrder({ payload }, { call, put }) {
      const orderNo = payload;
      yield call(withLoading(cancelOrder, { successMsg: '订单已取消！', key: 'cancelOrder' }), { orderNo });
      yield put({ type: 'getList' });
    },
  },

  reducers: {
    resetSearch(state) {
      return {
        ...state,
        search: { ...initialSearch }
      };
    },
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
