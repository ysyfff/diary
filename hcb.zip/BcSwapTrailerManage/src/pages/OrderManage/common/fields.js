import { Popover } from 'antd';

const defultKey = '--';

const formatValue = (value) => {
  if (value !== '' && value !== undefined && value !== null) {
    if (value.length > 14) {
      return (
        <Popover content={value}>
          <span>{`${value.substr(0, 10)}...`}</span>
        </Popover>
      );
    }
    return value;
  }
  return defultKey;
};

const requiredTitle = values => <span><i style={{ color: 'red' }}>*</i> {values}</span>;

// 货物表格配置
export const tableFields = [
  {
    title: requiredTitle('货物品名'),
    dataIndex: 'name',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'input',
      props: {
        maxLength: 10,
        minLength: 1,
        placeholder: '请输入货物品名！'
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入货物品名！'
        }]
      }
    }
  },
  {
    title: '件数（件）',
    dataIndex: 'num',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        min: 1,
        max: 10000,
        placeholder: '请输入货物件数！'
      },
    }
  },
  {
    title: '重量（吨）',
    dataIndex: 'weight',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入货物重量！'
      },
    }
  },
  {
    title: '体积（方）',
    dataIndex: 'volume',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入货物体积！'
      },
    }
  }
];

// 客户信息
export const customerFields = [
  {
    title: '姓名',
    dataIndex: 'name',
    key: 'name',
    width: 200,
    render: formatValue
  },
  {
    title: '客户编号',
    dataIndex: 'code',
    key: 'code',
    width: 200,
    render: formatValue
  },
  {
    title: '联系电话',
    dataIndex: 'phone',
    key: 'phone',
    width: 200,
    render: formatValue
  },
];

// 客户信息
export const codeFields = [
  {
    title: '客户编号',
    dataIndex: 'code',
    key: 'code',
    width: 300,
    render: formatValue
  }
];
