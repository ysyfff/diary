import React from 'react';
import { Table, Button, Tooltip } from 'antd';
import { TweenOneGroup } from 'rc-tween-one';
import NP from 'number-precision';
import EditableFormRow from './EditableFormRow';
import EditableCell from './EditableCell';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';
import { EllipsisRecord } from '../../../../../components';

import './index.less';

const EmptyText = props => (
  <Button
    style={{ width: '100%' }}
    onClick={props.onAdd}
    type="dashed"
    icon="plus"
  >添加
  </Button>
);

class EditableTable extends React.PureComponent {
  static defaultProps = {
    className: 'extra-cost-table-enter-leave'
  }

  constructor(props) {
    super(props);
    // 表格新增进入动画
    this.enterAnim = [
      {
        opacity: 0, x: -50, backgroundColor: '#fffeee', duration: 0,
      },
      {
        height: 0,
        duration: 250,
        type: 'from',
        delay: 200,
        ease: 'easeOutQuad',
        onComplete: this.onEnd,
      },
      {
        opacity: 1, x: 0, duration: 200, ease: 'easeOutQuad',
      },
      { delay: 500, backgroundColor: '#fff' },
    ];
    // 表格离开动画
    this.leaveAnim = [
      { duration: 200, opacity: 0 },
      { height: 0, duration: 200, ease: 'easeOutQuad' },
    ];
    // 保存表单对象
    this.form = {};
    this.columns = [{
      title: '操作',
      dataIndex: 'operation',
      align: 'center',
      width: '20%',
      render: (text, record) => (
        <EditableContext.Consumer>
          {({ form }) => {
            this.form = { ...this.form, [record.key]: form };
            return (
              <div style={{ padding: '9px 0' }}>
                <span>
                  <ExtraCostContext.Consumer>
                    {({ dataSource }) => (
                      <a
                        onClick={this.handleDelete(dataSource, record.key)}
                        style={{ marginRight: 8 }}
                      >
                        移除
                      </a>
                    )}
                  </ExtraCostContext.Consumer>
                  <ExtraCostContext.Consumer>
                    {({ dataSource }) => (
                      <React.Fragment>
                        {
                          dataSource.length >= this.props.maxAddLength &&
                          (<Tooltip
                            title={this.props.maxAddMessage}
                            placement="top"
                            trigger="click"
                          >
                            <a>添加</a>
                          </Tooltip>)
                        }
                        {
                          dataSource.length < this.props.maxAddLength &&
                            (<a onClick={this.handleAdd(dataSource, record.key)}>添加</a>)
                        }
                      </React.Fragment>

                    )}
                  </ExtraCostContext.Consumer>
                </span>
              </div>
            );
          }}
        </EditableContext.Consumer>
      )
    }];
  }
  componentDidMount() {
    this.updateForm();
  }

  componentDidUpdate() {
    this.updateForm();
  }
  // 移除表格一条记录
  handleDelete = (dataSource, key) => () => {
    const nextDataSouce = [...dataSource];
    const { changeStateWhileDelete } = this.props;
    changeStateWhileDelete({
      forms: this.form,
      dataSource: nextDataSouce.filter(item => item.key !== key),
      key
    }, () => {
      const { changeForms } = this.props;
      if (this.form[key]) {
        delete this.form[key];
      }
      changeForms(this.form);
    });
  }

  updateForm = () => {
    const { changeForms } = this.props;
    changeForms(this.form);
  }
  // 新增一条数据
  handleAdd = (dataSource, key) => (e) => {
    e.persist();
    const { changeDataSource } = this.props;
    // 拷贝dataSource
    const copyDataSource = [...dataSource];
    // 获取对应key在数组中的位置
    let position = 0;
    // 获取最大index值
    let maxIndex = copyDataSource[0].index;
    for (let index = 0; index < copyDataSource.length; index += 1) {
      const data = copyDataSource[index];
      if (data.index > maxIndex) {
        maxIndex = data.index;
      }
      if (data.key === key) {
        position = index;
      }
    }
    maxIndex += 1;
    const addValue = {
      key: `record-${maxIndex}`,
      index: maxIndex,
      ...this.initalDataSource
    };
    copyDataSource.splice(position + 1, 0, addValue);
    changeDataSource(copyDataSource);
    // 更新form, 并将滚动条置底
    this.timer = setTimeout(() => {
      this.updateForm();
      try {
        // 调整表格视图
        const rows = document.querySelectorAll('.delivery-cost-editable-row');
        rows[position].scrollIntoView();
      } catch (e) {
        if (e) { clearTimeout(this.timer); }
      }
      clearTimeout(this.timer);
    }, 0);
  }

  // 添加一条新的费用信息
  handleNew = initalDataSource => () => {
    const { changeDataSource } = this.props;
    changeDataSource([{ ...initalDataSource, key: 'record-1', index: 1 }]);
    this.timer = setTimeout(() => {
      this.updateForm();
      clearTimeout(this.timer);
    }, 0);
  }
  // 渲染table footer
  footerRender = (fields, dataSource) => () => {
    let sum = 0.00;
    let sum1 = 0.00;
    let sum2 = 0.00;


    const { calculateKey = [] } = this.props;
    const num0 = calculateKey[0];
    const num1 = calculateKey[1];
    const num2 = calculateKey[2];

    Object.keys(fields).forEach((key) => {
      sum = NP.plus(sum, (fields[key][num0] &&
        fields[key][num0].value) || 0
      );
      sum1 = NP.plus(sum1, (fields[key][num1] &&
        fields[key][num1].value) || 0
      );
      sum2 = NP.plus(sum2, (fields[key][num2] &&
        fields[key][num2].value) || 0
      );
    });

    return (
      <React.Fragment>
        {dataSource.length > 0 ? (
          <div className="cost-footer">
            <ul className="cost-footer-list" >
              <li className="cost-item cost-all">
                <p>合计</p>
              </li>
              <li className="cost-item cost-amount">
                <EllipsisRecord record={sum.toFixed(2)} width={167} />
              </li>
              <li className="cost-item cost-amount">
                <EllipsisRecord record={sum1.toFixed(2)} width={167} />
              </li>
              <li className="cost-item cost-amount">
                <EllipsisRecord record={sum2.toFixed(2)} width={167} />
              </li>
              <li className="cost-item cost-empty" />
            </ul>
          </div>
        ) : null}
      </React.Fragment>
    );
  }

  render() {
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell,
        wrapper: props => (
          <TweenOneGroup
            component="tbody"
            {...props}
            className={props.className || ''}
            enter={this.enterAnim}
            leave={this.leaveAnim}
            appear={false}
            exclusive
          >
            {props.children}
          </TweenOneGroup>
        )
      },
    };
    return (
      <ExtraCostContext.Consumer>
        {({ intial, fields, dataSource, tableFields = [] }) => {
          const styles = [];
          const { footerRender, className } = this.props;
          // table footer
          const footer = (footerRender && footerRender(fields, dataSource)) ||
            this.footerRender(fields, dataSource);
          const columns = tableFields.concat(this.columns).map((col, index) => {
            // 设置表格td宽度
            const style = `.${className}-table .ant-table-thead > tr > th:nth-child(${index + 1}),
              .${className}-table .ant-table-tbody > tr > td:nth-child(${index + 1}) {
                width: ${col.width}
              }`;
            styles.push(style);
            if (!col.editable) {
              return col;
            }
            return {
              ...col,
              onCell: record => ({
                record,
                type: col.fields.type || 'input',
                dataIndex: col.dataIndex,
                title: col.title,
                fields: col.fields,
                editing: true
              }),
            };
          });
          return (
            <React.Fragment>
              <Table
                className={`${className}-table delivery-cost-table`}
                components={components}
                rowClassName={() => 'delivery-cost-editable-row'}
                dataSource={dataSource}
                columns={columns}
                pagination={false}
                locale={{ emptyText: <EmptyText onAdd={this.handleNew(intial)} /> }}
                footer={footer}
                // scroll={{ y: 200 }}
              />
              <style type="text/css">
                {styles}
              </style>
            </React.Fragment>
          );
        }}
      </ExtraCostContext.Consumer>
    );
  }
}

export default EditableTable;
