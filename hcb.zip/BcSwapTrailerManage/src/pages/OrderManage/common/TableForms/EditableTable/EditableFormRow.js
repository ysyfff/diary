import { Form } from 'antd';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';

function createFields(props) {
  const key = props['data-row-key'];
  const fields = {};
  const field = props.fields[key];
  if (field) {
    Object.keys(field).forEach((fieldKey) => {
      fields[fieldKey] = Form.createFormField(field[fieldKey]);
    });
  }
  return fields;
}

const EditableRow = ({ form, index, dataSource, ...props }) => (
  <EditableContext.Provider value={{ form, index, dataSource }}>
    <tr {...props} />
  </EditableContext.Provider>
);

const EditableFormRow = Form.create({
  onFieldsChange(props, changedFields) {
    const { onFieldsChange, calculatekey } = props;
    const key = props['data-row-key'];
    const calculateValue = changedFields[calculatekey];
    if (calculateValue && calculateValue.value && window.isNaN(calculateValue.value)) return;
    onFieldsChange && onFieldsChange(changedFields, key);
  },
  mapPropsToFields(props) {
    return createFields(props);
  }
})(EditableRow);

const EditableFormRowWrapper = props => (
  <ExtraCostContext.Consumer>
    {({ dataSource, onFieldsChange, fields, calculateKey }) => (
      <EditableFormRow
        {...props}
        dataSource={dataSource}
        onFieldsChange={onFieldsChange}
        fields={fields}
        calculatekey={calculateKey}
      />
    )}
  </ExtraCostContext.Consumer>
);
export default EditableFormRowWrapper;
