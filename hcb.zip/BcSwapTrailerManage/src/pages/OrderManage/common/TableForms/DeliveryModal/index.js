import React from 'react';
import { Modal } from 'antd';
import EditableTable from '../EditableTable';
import ExtraCostContext from '../ExtraCostContext';

import './index.less';

class DeliveryModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.visible !== nextProps.visible) {
      this.setState({ visible: true });
    }
  }

  componentWillUnmount() {
    clearTimeout(this.timer);
  }

  handleCancel = (forms, prevFields, prevDataSource) => () => {
    const { changeStateWhileClickCancelButton } = this.props;
    this.setState({ visible: false }, () => {
      this.timer = setTimeout(() => {
        changeStateWhileClickCancelButton({
          fields: prevFields,
          dataSource: prevDataSource
        });
        Object.keys(forms).forEach((key) => {
          forms[key].resetFields();
        });
        clearTimeout(this.timer);
      }, 300);
    });
  }

  handleOk = (forms, fields, dataSource) => () => {
    const { changeStateWhileClickOkButton, format, onChange } = this.props;
    const keys = Object.keys(forms);
    // 表单校验数组
    const errors = [];
    // 新增数据验证
    for (let i = 0; i < keys.length; i += 1) {
      const form = forms[keys[i]];
      form.validateFieldsAndScroll((error) => {
        if (!error) {
          errors.push(0);
        } else {
          errors.push(1);
        }
      });
    }
    // 判断是否验证通过
    const isError = errors.some(error => error === 1);
    if (!isError) {
      // 修改父级state
      changeStateWhileClickOkButton({
        value: format(fields),
        prevFields: fields,
        prevDataSource: dataSource
      });
      // 格式化fields输出
      const values = Object.keys(fields).map((key) => {
        const field = fields[key];
        const data = {};
        Object.keys(field).forEach((key) => {
          data[key] = field[key].value || '';
        });
        return data;
      });
      onChange && onChange(values);
      this.setState({ visible: false });
    }
  }

  render() {
    const { visible } = this.state;
    const { modalProps, ...restProps } = this.props;
    return (
      <ExtraCostContext.Consumer>
        {({ dataSource, forms, fields, prevFields, prevDataSource }) => (
          <Modal
            className="delivery-modal"
            {...modalProps}
            visible={visible}
            onCancel={this.handleCancel(forms, prevFields, prevDataSource)}
            centered
            onOk={this.handleOk(forms, fields, dataSource)}
          >
            <EditableTable {...restProps} />
          </Modal>
        )}
      </ExtraCostContext.Consumer>
    );
  }
}

export default DeliveryModal;
