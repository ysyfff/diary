/**
 * @author yang.huang3
 * @description 其他费用组件
 * @since 2018.09.13
 */
import React from 'react';
import { _ } from 'carno/third-party';
import EditableTable from './EditableTable';
import ExtraCostContext from './ExtraCostContext';

// 获取初始值fields用于双向绑定
function getDefaultValues(dataSource = []) {
  const fields = {};
  dataSource.forEach((data) => {
    const { key, index, ...restData } = data;
    const field = {};
    Object.keys(restData).forEach((restKey) => {
      if (!index) return;
      let value = restData[restKey];
      value = typeof value === 'undefined' ? undefined : value;
      field[restKey] = { value };
    });
    fields[key] = field;
  });
  return fields;
}

// 初始化dataSource
function initDataSource(source) {
  return source.map((data, index) => ({
    ...data,
    index: index + 1,
    key: `record-${index + 1}`
  }));
}

class ExtraCostInput extends React.PureComponent {
  static defaultProps = {
    source: [],
    tableFields: [],
    euxuChange: false,
    maxAddLength: 20,
    modalTitle: '',
    maxAddMessage: '已达到最大添加条数',
    format(field) {
      return field;
    }
  };

  constructor(props) {
    super(props);
    const { source, format, tableFields } = props;
    const intial = {};
    // 获取一个初始化状态
    tableFields.forEach((field) => {
      intial[field.dataIndex] = undefined;
    });
    let dataSource = initDataSource(source);
    if (dataSource.length === 0) {
      dataSource = [{ ...intial, key: 'record-1', index: 1 }];
    }
    const fields = getDefaultValues(dataSource);

    this.state = {
      value: format(fields), // 输入框value
      visible: Symbol('visible'),
      dataSource,
      forms: {},
      fields, // 绑定表单
      prevFields: fields, // 上一个fields状态
      prevDataSource: dataSource, // 上一个dataSource状态
      intial
    };
  }

  componentDidMount() {
    const { source, onChange, euxuChange } = this.props;
    !euxuChange && onChange && onChange(source);
  }

  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(this.props.source, nextProps.source)) {
      const dataSource = initDataSource(nextProps.source);
      const fields = getDefaultValues(dataSource);
      this.setState({
        fields,
        prevFields: fields,
        value: nextProps.format(fields),
        dataSource,
        prevDataSource: dataSource
      }, () => {
        const { fields, value } = this.state;
        const { onChange, euxuChange } = nextProps;
        let values = [];
        if (value) {
          // 格式化fields
          values = Object.keys(fields).map((key) => {
            const field = fields[key];
            const data = {};
            Object.keys(field).forEach((key) => {
              data[key] = field[key].value || '';
            });
            return data;
          });
        }
        !euxuChange && onChange && onChange(values);
      });
    }
  }

  onFieldsChange = (changedFields, key) => {
    const keys = Object.keys(changedFields);
    // 判断是否是重置操作
    const isRest = keys.length > 0 && keys
      .every(key => !Object.prototype.hasOwnProperty.call(changedFields[key], 'value'));
    // 防止表单验证时validating = true时重复更新组件
    if (!isRest) {
      const validating = changedFields.validating || false;
      if (validating) return;
    }
    this.setState(({ fields, prevFields }) => ({
      fields: isRest ? prevFields : { ...fields, [key]: { ...fields[key], ...changedFields } }
    }));
  }
  // 输入框点击事件
  handleClick = () => {
    this.setState(({ dataSource, intial }) => ({
      visible: Symbol('visible'),
      dataSource: dataSource.length === 0 ? [{ ...intial, key: 'record-1', index: 1 }] : dataSource
    }));
    const { onClick } = this.props;
    onClick && onClick();
  }
  // 更新dataSource
  changeDataSource = (dataSource) => {
    this.setState({ dataSource });
  }
  // 更新forms
  changeForms = (forms) => {
    this.setState({ forms }, () => {
      const { updateForm } = this.props;
      updateForm && updateForm(forms);
    });
  }
  // 更新fields
  changeFields = (fields) => {
    this.setState({ fields });
  }
  // 删除时更新state
  changeStateWhileDelete = ({ dataSource, key }, callback) => {
    const fields = { ...this.state.fields };
    delete fields[key];
    this.setState({ dataSource, fields }, callback);
  }
  // change state when handleOk
  changeStateWhileClickOkButton = ({ value, prevFields, prevDataSource }) => {
    this.setState({ value, prevFields, prevDataSource });
  }
  // change state when handleCancel
  changeStateWhileClickCancelButton = ({ fields, dataSource }) => {
    this.setState({ fields, dataSource });
  }

  render() {
    const {
      dataSource,
      forms,
      fields,
      prevFields,
      prevDataSource,
      intial
    } = this.state;
    const {
      tableFields,
      source,
      footerRender,
      calculateKey,
      maxAddLength,
      maxAddMessage
    } = this.props;
    return (
      <div>
        <ExtraCostContext.Provider
          value={{
            dataSource,
            forms,
            source,
            onFieldsChange: this.onFieldsChange,
            fields,
            tableFields,
            prevFields,
            prevDataSource,
            calculateKey,
            intial
          }}
        >
          <EditableTable
            maxAddMessage={maxAddMessage}
            maxAddLength={maxAddLength}
            calculateKey={calculateKey}
            changeForms={this.changeForms}
            changeDataSource={this.changeDataSource}
            footerRender={footerRender}
            changeStateWhileDelete={this.changeStateWhileDelete}
          />
        </ExtraCostContext.Provider>
      </div>
    );
  }
}

export default ExtraCostInput;
