import { mainType, sendWays, appreciationTypeAll, signingType } from 'configs/constants';
import { EllipsisRecord } from 'components';

export const tableFields = [
  {
    key: 'orderNo',
    name: '订单号',
    width: 150
  }, {
    key: 'buyerName',
    name: '操作',
    width: 80
  },
  {
    key: 'operateStatusDesc',
    name: '状态',
    width: 100,
  },
  {
    key: 'mainBusiness',
    name: '主营服务',
    render: record => record ? mainType.filter(i => i.key === record)[0].value : '--',
    width: 100
  },
  {
    key: 'sendWay',
    name: '产品时效',
    render: record => record ? sendWays.filter(i => i.key === record)[0].value : '--',
    width: 100
  },
  {
    key: 'valueAddedService',
    name: '增值服务',
    render: record => record ? appreciationTypeAll.filter(i => i.key === record)[0].value : '--',
    width: 100
  },
  {
    key: 'signWay',
    name: '签收方式',
    render: record => record ? signingType.filter(i => i.key === record)[0].value : '--',
    width: 100
  },
  {
    key: 'takeTimeStr',
    name: '提货时间',
    width: 120,
    render: record => <EllipsisRecord record={record || '--'} width={120} />
  },
  {
    key: 'createTimeStr',
    name: '下单时间',
    width: 120,
    render: record => <EllipsisRecord record={record || '--'} width={120} />
  },
  {
    key: 'shipCompanyName',
    name: '发货公司',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'recCompanyName',
    name: '收货公司',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'cargoName',
    name: '货物品名',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
    // render: record => record.split('/').map((i, index) =>
    //   <div key={index}><EllipsisRecord record={i || '--'} width={200} /></div>
    // )
  },
  {
    key: 'totalNum',
    name: '总件数（件）',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'totalWeight',
    name: '总重量（千克）',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'totalVolume',
    name: '总体积（方）',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'remark',
    name: '备注',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  }];

export const searchFields = [{
  key: 'oilTypeId',
  name: '油品类型',
}, {
  key: 'oilNumId',
  name: '标号',
}, {
  key: 'oilSpecId',
  name: '规格',
}, {
  key: 'time',
  name: '下单时间',
  type: 'dateRange',
}];
