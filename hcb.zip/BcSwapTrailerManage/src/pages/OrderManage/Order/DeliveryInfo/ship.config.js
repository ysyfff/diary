import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';

// const EL_COL_LAYOUT = {
//   xxl: { span: 12 },
//   xl: { span: 12 },
//   lg: { span: 12 }
// };

// const CARD_COL2_FORM_ITEM_LAYOUT = {
//   labelCol: {
//     xxl: { span: 6 },
//     xl: { span: 8 },
//     lg: { span: 6 }
//   },
//   wrapperCol: {
//     xxl: { span: 18 },
//     xl: { span: 16 },
//     lg: { span: 16 }
//   }
// };
const CARD_COL2_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 4 },
    xl: { span: 4 },
    lg: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 20 },
    xl: { span: 20 },
    lg: { span: 20 }
  }
};

const companyFields = [
  {
    title: '发货公司',
    dataIndex: 'companyName',
    key: 'companyName',
    width: 300,
  },
  {
    title: '助记码',
    dataIndex: 'mnemonicCode',
    key: 'mnemonicCode',
    width: 300,
  }
];

// const shipCustomerFields = [
//   {
//     title: '发货联系人',
//     dataIndex: 'contact',
//     key: 'contact',
//     width: 200,
//   },
//   {
//     title: '联系电话',
//     dataIndex: 'contactPhone',
//     key: 'contactPhone',
//     width: 200,
//   }
// ];

// const shipAddressFields = [
//   {
//     title: '行政区域',
//     dataIndex: 'addressName',
//     key: 'addressName',
//     width: 200,
//   },
//   {
//     title: '详细地址',
//     dataIndex: 'address',
//     key: 'address',
//     width: 200,
//   }
// ];


const fields = [
  {
    key: 'shipCompanyName',
    label: '发货公司',
    col: {
      xxl: 18,
      xl: 16,
      lg: 12
    },
    el: {
      maxLength: 50,
      placeholder: '请输入发货公司'
    },
    formItem: {
      props: {
        labelCol: {
          xxl: { span: 4 },
          xl: { span: 6 },
          lg: { span: 6 }
        },
        wrapperCol: {
          xxl: { span: 20 },
          xl: { span: 18 },
          lg: { span: 16 }
        }
      },
      options: {
        rules: [
          { required: true, message: '请选择发货公司' }
        ]
      }
    },
    render: ({ form, ...props }) => (
      <AutoSearchInput
        inputKey="companyName"
        columns={companyFields}
        scrollX={false}
        isAllowInput={false}
        maxLength={20}
        {...props}
      />
    )
  },
  {
    key: 'flag',
    label: ' ',
    col: {
      xxl: 6,
      xl: 8,
      lg: 10
    },
    el: {
      name: '临时客户',
      style: {
        marginLeft: '10px'
      },
    },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT, colon: false }
    },
    type: 'checkbox'
  },
  // {
  //   key: 'contact',
  //   label: '发货人',
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
  //     options: {
  //       rules: [
  //         { required: true, message: '请选择发货人' }
  //       ]
  //     }
  //   },
  //   render: ({ form, ...props }) => (
  //     <AutoSearchInput
  //       inputKey="contact"
  //       columns={shipCustomerFields}
  //       scrollX={false}
  //       isAllowInput
  //       maxLength={20}
  //       {...props}
  //     />
  //   )
  // },
  // {
  //   key: 'contactPhone',
  //   label: '联系电话',
  //   el: {
  //   },
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
  //     options: {
  //       rules: [
  //         { required: true, message: '请选择联系电话' }
  //       ]
  //     }
  //   }
  // },
  // {
  //   key: 'address1',
  //   label: '提货地址1',
  //   col: { ...EL_COL_LAYOUT },
  //   type: 'citypicker',
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
  //     options: {
  //       rules: [
  //         { required: true, message: '请选择提货地址1' }
  //       ]
  //     }
  //   }
  // },
  // {
  //   key: 'addressDetail',
  //   label: ' ',
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
  //     options: {
  //       rules: [
  //         { required: true, message: '请选择提货地址1' }
  //       ]
  //     }
  //   },
  //   render: ({ form, ...props }) => (
  //     <AutoSearchInput
  //       inputKey="address"
  //       columns={shipAddressFields}
  //       scrollX={false}
  //       isAllowInput
  //       maxLength={20}
  //       {...props}
  //     />
  //   )
  // }
];

export default fields;
