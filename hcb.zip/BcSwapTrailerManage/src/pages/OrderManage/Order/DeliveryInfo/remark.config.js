const CARD_COL1_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 0 },
    xl: { span: 0 },
    lg: { span: 0 }
  },
  wrapperCol: {
    xxl: { span: 24 },
    xl: { span: 24 },
    lg: { span: 24 }
  }
};

const fields = [{
  key: 'remark',
  label: '',
  type: 'textarea',
  col: { span: 24 },
  el: {
    maxLength: 125,
    placeholder: '请输入备注（不超过125字符）'
  },
  formItem: {
    props: { ...CARD_COL1_FORM_ITEM_LAYOUT },
  }
}];

export default fields;
