
const requiredTitle = values => <span><i style={{ color: 'red' }}>*</i> {values}</span>;

export const fields = [
  {
    title: requiredTitle('货物品名'),
    dataIndex: 'name',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'input',
      props: {
        maxLength: 10,
        minLength: 1,
        placeholder: '请输入货物品名！',
      },
      validator: {
        rules: [{
          required: true,
          message: '请输入货物品名！'
        }]
      }
    }
  },
  {
    title: '件数（件）',
    dataIndex: 'num',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 0,
        min: 1,
        max: 10000,
        placeholder: '请输入货物件数！'
      },
    }
  },
  {
    title: '重量（千克）',
    dataIndex: 'weight',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 99999.99,
        placeholder: '请输入货物重量！'
      },
    }
  },
  {
    title: '体积（方）',
    dataIndex: 'volume',
    editable: true,
    align: 'center',
    width: '20%',
    fields: {
      type: 'inputnumber',
      props: {
        precision: 2,
        min: 0.01,
        max: 999.99,
        placeholder: '请输入货物体积！'
      },
    }
  },
];

export default {
  tableFormFields: fields,
};
