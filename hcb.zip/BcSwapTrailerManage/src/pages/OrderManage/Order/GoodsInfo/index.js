import React from 'react';
import { Row } from 'antd';
import { createFormFields } from 'components/helper';

class DeliveryNoteFooter extends React.PureComponent {
  render() {
    return (
      <Row>{this.props.children}</Row>
    );
  }
}

export default createFormFields()(DeliveryNoteFooter);
