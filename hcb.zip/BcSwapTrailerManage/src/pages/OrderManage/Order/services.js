import http from 'utils/http';

const { post } = http.create('admin');

// 获取历史发货公司
export function getOldShipCompany(param) {
  return post('/web/m/order/company-list', param);
}

// 获取发货公司
export function getShipCompany(param) {
  return post('/web/e/customer/search', param);
}

// 获取收货公司
export function getrecCompany(param) {
  return post('/web/m/order/receive-company-list', param);
}

// 获取联系人信息
export function getCustomer(param) {
  return post('/web/m/order/refer-contact-list', param);
}

//  获取历史地址
export function getAddress(param) {
  return post('/web/m/order/refer-address-list', param);
}

// 新增订单
export function creatOrder(param) {
  return post('/web/m/order/create',
    param,
    {
      contentType: 'json'
    }
  );
}
