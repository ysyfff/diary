import React from 'react';
import { connect } from 'dva';
import { Link } from 'dva/router';
import { SearchCard } from 'components/helper';
import { Row, Col, Button, Message } from 'antd';
import { reginIdSplit } from 'utils';
import { Type } from 'carno/utils';
import { validateForms } from 'components/DeliveryNote/utils';
import GoodsAddress from 'components/DeliveryNote/GoodsAddress';
import { companyFields, historyCompanyFields } from './fields';
import GoodsInfo from './GoodsInfo';
import shipFields from './DeliveryInfo/ship.config';
import serverFields from './DeliveryInfo/server.config';
import receiptFields from './DeliveryInfo/receipt.config';
import remarkFields from './DeliveryInfo/remark.config';
import GoodsFields from './GoodsInfo/search.config';
import styles from './index.less';

const DeliveryCardColLayout = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 24 },
  md: { span: 24 },
  sm: { span: 24 }
};

//  格式化地址信息
const formatData = props => props.map((i) => {
  const copyShipAddress = { ...i };
  delete copyShipAddress.citypicker;

  const {
    citypicker = []
  } = i;

  const {
    provinceId: province,
    cityId: city,
    countyId: county
  } = citypicker.length > 0 && reginIdSplit(citypicker[0].id);
  const shipData = {
    ...copyShipAddress,
    province,
    city,
    county,
    addressName: citypicker[0].name
  };
  return shipData;
});

// 校验货物信息
const testTableForm = (forms) => {
  const keys = Object.keys(forms);
  // 表单校验数组
  const errors = [];
  const datas = [];
  // 新增数据验证
  for (let i = 0; i < keys.length; i += 1) {
    const form = forms[keys[i]];
    form.validateFieldsAndScroll((error, values) => {
      if (!error) {
        errors.push(0);
        if (Object.keys(values).length !== 0) {
          datas.push(values);
        }
      } else {
        errors.push(1);
      }
    });
  }
  // 判断是否验证通过
  const error = errors.some(error => error === 1);
  return {
    error,
    value: datas
  };
};

@connect(
  ({ order }) => ({ ...order }),
  dispatch => ({ dispatch })
)
class DeliveryNote extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      shipCustomerId: '',
      serverInfoExtraFields: [
        {
          key: 'valueAddedService',
          el: {
            onValueChange: (value) => {
              this.setState({ serverInfoExtraFields: [{
                key: 'takeTime',
                hidden: value === 'DELIVERYVEHICLE' || value === 'NO' || false
              }] });
            }
          }
        }],
      shipInfoExtraFields: [
        {
          key: 'shipCompanyName',
          el: {
            onSearch: this.getShipCompany,
            onSelect: this.selectShipCompany
          }
        },
        {
          key: 'flag',
          el: {
            onValueChange: this.changeType
          }
        },
      ],
      receiptInfoExtraFields: [
        {
          key: 'recCompanyName',
          el: {
            onSearch: this.getrecCompany
          }
        }
      ]
    };
    this.customedForms = {};
  }

  componentDidMount = () => {
    // 服务
    this.serverHpler = this.server.props.helper;
    // 委托公司
    this.shipHpler = this.ship.props.helper;
    // 收货公司
    this.receiptHpler = this.receipt.props.helper;
    // 货物信息
    this.goodsHpler = this.goods.props.helper;
    // 备注信息
    this.remarkHpler = this.remark.props.helper;
  }

  // 货物信息初始化
  getExtraFields = () => ({
    footerExtraFields: [{
      key: 'cargoList',
      el: {
        onFormsChange: (forms) => {
          this.customedForms = forms;
        }
      }
    }]
  });

  // 获取发货公司
  getShipCompany = (value) => {
    const { getFieldsValue } = this.ship.props.helper.getForm();
    const { dispatch } = this.props;

    const { flag = false } = getFieldsValue();

    return flag ? dispatch({
      type: 'order/getOldShipCompany',
      payload: { shipCompanyName: value } })
      : dispatch({
        type: 'order/getShipCompany',
        payload: { keyword: value } });
  }

  // 获取发货人信息
  getShipCustomer = (value) => {
    const { getFieldsValue } = this.ship.props.helper.getForm();
    const { shipCompanyName } = getFieldsValue();

    const { dispatch } = this.props;
    if (shipCompanyName) {
      return dispatch({
        type: 'order/getCustomer',
        payload: { shipCompanyName, recCompanyName: '', contact: value, type: 'FROM' } });
    }
    return Promise.resolve([]);
  }

  // 获取收货人信息
  getRecCustomer = (value) => {
    const { shipCompanyName } = this.ship.props.helper.getForm().getFieldsValue();
    const { recCompanyName } = this.receipt.props.helper.getForm().getFieldsValue();
    const { dispatch } = this.props;
    if (recCompanyName && shipCompanyName) {
      return dispatch({
        type: 'order/getCustomer',
        payload: { shipCompanyName, recCompanyName, contact: value, type: 'TO' } });
    }
    return Promise.resolve([]);
  }

  //  获取发货地址
  getShipAddress = (value, province, city, county) => {
    const { getFieldsValue } = this.ship.props.helper.getForm();
    const { shipCompanyName } = getFieldsValue();
    const { dispatch } = this.props;

    return dispatch({
      type: 'order/getAddress',
      payload: {
        companyName: shipCompanyName,
        province,
        city,
        county,
        address: value,
        type: 'FROM' } });
  }

  // 获取收货地址
  getRecAddress = (value, province, city, county) => {
    const { getFieldsValue } = this.receipt.props.helper.getForm();
    const { recCompanyName } = getFieldsValue();
    const { dispatch } = this.props;

    return dispatch({
      type: 'order/getAddress',
      payload: {
        companyName: recCompanyName,
        province,
        city,
        county,
        address: value,
        type: 'TO' } });
  }

  // 获取收货公司
  getrecCompany = (value) => {
    const { getFieldsValue } = this.ship.props.helper.getForm();
    const { shipCompanyName } = getFieldsValue();

    const { dispatch } = this.props;
    if (shipCompanyName) {
      return dispatch({
        type: 'order/getrecCompany',
        payload: { shipCompanyName, recCompanyName: value } });
    }
    return Promise.resolve([]);
  }

  // 选择发货公司
  selectShipCompany = (value) => {
    // value && this.setState({
    //   shipCustomerId: value.id
    // });
    if (value) {
      this.shipCustomerId = value.id;
    }
  }


  // 选择发货人
  selectCustomer = (value) => {
    if (value) {
      const { contactPhone } = value;
      const { setFieldsValue } = this.ship.props.helper.getForm();
      setFieldsValue({
        contactPhone
      });
    }
  }

  // 选择发货地址
  selectAddress = (value) => {
    if (value) {
      const { addressCode = [] } = value;
      const { setFieldsValue } = this.ship.props.helper.getForm();
      setFieldsValue({
        address1: addressCode
      });
    }
  }

  // 更新客户类型
  changeType = async (e) => {
    const { shipCompanyName } = this.shipHpler.getFieldsValues();
    const { dispatch } = this.props;

    this.setState({
      shipInfoExtraFields: [{
        key: 'shipCompanyName',
        el: {
          isAllowInput: e,
          columns: e ? historyCompanyFields : companyFields,
          inputKey: e ? 'shipCompanyName' : 'companyName'
        }
      }],
    });
    if (e) {
      this.shipCustomerId = '';
    }
    if (!e && shipCompanyName) {
      const datas = await dispatch({
        type: 'order/getShipCompany',
        payload: { keyword: shipCompanyName } });
      if (!Type.isEmpty(datas)) {
        this.shipCustomerId = datas[0].id;
      } else {
        this.shipHpler.setFieldsValues({
          shipCompanyName: ''
        });
      }
    }
  }

  //  创建订单
  handleSave = () => {
    const { dispatch } = this.props;
    // const { shipCustomerId } = this.state;
    // 校验
    const error = [];
    // 服务
    const serverData = this.serverHpler.getFieldsValues(true);
    error.push(serverData.error);
    // 委托公司
    const shipData = this.shipHpler.getFieldsValues(true);
    error.push(shipData.error);
    // 收货公司
    const receiptData = this.receiptHpler.getFieldsValues(true);
    error.push(receiptData.error);
    // 备注信息
    const remarkData = this.remarkHpler.getFieldsValues(true);
    error.push(remarkData.error);
    // 委托人信息
    const shipManData = validateForms(this.shipAddress.forms, true);
    error.push(shipManData.error);
    // 收货人信息
    const receiptManData = validateForms(this.recAddress.forms, true);
    error.push(receiptManData.error);
    // 货物信息
    const goodsData = testTableForm(this.customedForms);
    error.push(goodsData.error);

    // 校验通过
    const isOk = error.some(i => i === true);
    if (!isOk) {
      if (goodsData.value.length === 0) {
        Message.error('请填写至少一条货物信息!');
      } else {
        const datas = {
          takeTime: '',
          shipCustomerId: this.shipCustomerId,
          cargoList: goodsData.value,
          shipAddresses: formatData(shipManData.value),
          recAddresses: formatData(receiptManData.value),
          ...serverData.value,
          ...shipData.value,
          ...receiptData.value,
          ...remarkData.value,
        };
        const copyData = { ...datas };
        delete copyData.flag;
        dispatch({
          type: 'order/addOrder',
          payload: copyData
        });
      }
    }
  }

  render() {
    const { key, loading } = this.props;
    const { serverInfoExtraFields, shipInfoExtraFields, receiptInfoExtraFields } = this.state;
    const { footerExtraFields } = this.getExtraFields();
    return (
      <div key={key} className={styles.order}>
        <Row >
          <Col span={24}>
            <SearchCard
              style={{ padding: '0 12px' }}
              extraFields={serverInfoExtraFields}
              title="服务信息"
              fields={serverFields}
              wrappedComponentRef={el => this.server = el}
            />
          </Col>
        </Row>
        <Row className="desc-item">
          <Col {...DeliveryCardColLayout} >
            <SearchCard
              extraFields={shipInfoExtraFields}
              title="委托信息"
              fields={shipFields}
              wrappedComponentRef={el => this.ship = el}
              extraContent={<GoodsAddress
                onSearch={this.getShipCustomer}
                onSearchAddress={(value, province, city, county) => this.getShipAddress(value, province, city, county)}
                ref={address => this.shipAddress = address}
              />}
            />
          </Col>
          <Col {...DeliveryCardColLayout}>
            <SearchCard
              extraFields={receiptInfoExtraFields}
              title="收货信息"
              fields={receiptFields}
              wrappedComponentRef={el => this.receipt = el}
              extraContent={<GoodsAddress
                label={{ citypicker: '收货地址' }}
                onSearch={this.getRecCustomer}
                onSearchAddress={(value, province, city, county) => this.getRecAddress(value, province, city, county)}
                ref={address => this.recAddress = address}
              />}
            />
          </Col>
        </Row>
        <Row>
          <Col {...DeliveryCardColLayout}>
            <GoodsInfo
              title="货物信息"
              fields={GoodsFields}
              extraFields={footerExtraFields}
              wrappedComponentRef={el => this.goods = el}
            />
          </Col>
          <Col {...DeliveryCardColLayout}>
            <SearchCard
              title="备注信息"
              style={{ padding: '0 12px' }}
              fields={remarkFields}
              wrappedComponentRef={el => this.remark = el}
            />
          </Col>
        </Row>
        <Row type="flex" justify="center">
          <Button type="primary" onClick={this.handleSave} loading={loading.addOrder}>保存</Button>
          <Link to="/orderManage" className="ml20">
            <Button >取消</Button>
          </Link>
        </Row>
      </div>
    );
  }
}

export default DeliveryNote;
