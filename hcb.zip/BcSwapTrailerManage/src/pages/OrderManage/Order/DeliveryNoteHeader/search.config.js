const fields = [{
  key: 'waybillNos',
  label: '关联运单'
}, {
  key: 'business',
  label: '主营服务',
  type: 'select',
  el: {
    placeholder: '请选择主营服务',
    options: []
  }
}, {
  key: 'sx',
  label: '产品时效',
  type: 'select',
  el: {
    placeholder: '请选择产品时效',
    options: []
  }
}];

export default fields;
