// 发货公司
export const companyFields = [
  {
    title: '发货公司',
    dataIndex: 'companyName',
    key: 'companyName',
    width: 300,
  },
  {
    title: '助记码',
    dataIndex: 'mnemonicCode',
    key: 'mnemonicCode',
    width: 300,
  }
];

// 历史发货公司
export const historyCompanyFields = [
  {
    title: '发货公司',
    dataIndex: 'shipCompanyName',
    key: 'shipCompanyName',
    width: 300,
  },
];

// 收货公司
export const recCompanyFields = [
  {
    title: '收货公司',
    dataIndex: 'companyName',
    key: 'companyName',
    width: 300,
  }
];
