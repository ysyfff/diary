/**
 * @author yang.huang3
 * @description 其他费用组件
 * @since 2018.09.13
 */
import React from 'react';
import { Form } from 'antd';
import { Type } from 'carno/utils';
import { _ } from 'carno/third-party';
import { HCard } from 'components/helper';
import EditableTable from './EditableTable';
import ExtraCostContext from './ExtraCostContext';

const resolveValueToDatasource = (values, columnsKeys) => {
  if (!Type.isArray(values)) throw new Error('value must be array');
  const fields = {};
  if (values.length === 0) {
    return {
      dataSource: [{ key: 'record-1', index: 1 }],
      fields
    };
  }
  const dataSource = values.map((value, index) => {
    const order = index + 1;
    const key = `record-${order}`;
    fields[key] = {};
    columnsKeys.forEach((columnsKey) => {
      fields[key][columnsKey] = Form.createFormField({ value: value[columnsKey] || undefined });
    });
    return {
      key,
      index: order
    };
  });
  return {
    dataSource,
    fields
  };
};

const getColumnsKeys = (tableFields) => {
  const keys = [];
  tableFields.forEach((field) => {
    const { editable, dataIndex } = field;
    if (editable) keys.push(dataIndex);
  });
  return keys;
};

class CustomedTableForm extends React.PureComponent {
  static defaultProps = {
    showAction: true,
    showOrder: false, // 是否显示序号
    tableFields: [], // 表格columns
    orderCellWidth: '5%',
    actionCellWidth: '10%',
    maxRows: 5,
    maxRowTips: '已达到最大添加条数'
  };

  constructor(props) {
    super(props);
    const { tableFields } = props;
    const columnsKeys = getColumnsKeys(tableFields);
    const value = props.value || [];
    const result = resolveValueToDatasource(value, columnsKeys);
    this.state = {
      value,
      output: value, // 向form表单输出的值
      columnsKeys,
      forms: {},
      ...result
    };
    this.elKeyMap = {};
  }

  componentWillReceiveProps = (nextProps) => {
    const { value } = nextProps;
    const { columnsKeys, output } = this.state;
    // 去除空对象
    let copyOutput = [...output];
    copyOutput = copyOutput.filter(value => Object.keys(value).length !== 0);
    if (!_.isEqual(value, copyOutput)) {
      this.setState({
        ...resolveValueToDatasource(value, columnsKeys),
        output: value,
        value
      });
    }
  }

  onFieldsChange = (changedFields, key) => {
    const keys = Object.keys(changedFields || {});
    // 是否是重置操作
    const isRest = keys.length > 0 && keys
      .every(key => !Object.prototype.hasOwnProperty.call(changedFields[key], 'value'));
    if (!isRest) {
      const validating = changedFields[keys[0]].validating || false;
      if (keys.length !== 1 || validating) return;
    }
    this.setState(({ fields }) => ({
      fields: {
        ...fields,
        [key]: { ...fields[key], [keys[0]]: Form.createFormField({ value: changedFields[keys[0]].value }) }
      }
    }));
  }

  onValuesChange = (changedValues, key) => {
    const { onChange } = this.props;
    const { output } = this.state;
    let copyOutput = [...output];
    const index = this.elKeyMap[key];
    copyOutput[index] = { ...copyOutput[index], ...changedValues };
    this.setState({ output: copyOutput }, () => {
      onChange && onChange(copyOutput.filter(value => Object.keys(value).length !== 0));
      copyOutput = null;
    });
  }
  // 更新dataSource
  changeDataSource = (dataSource, key, index) => {
    const { output } = this.state;
    const copyOutput = [...output];
    // 新增列
    if (key && index) {
      copyOutput.splice(index, 0, {});
      this.setState({ output: copyOutput });
    }
    this.setState({ dataSource });
  }
  // 更新fields
  changeFields = (fields) => {
    this.setState({ fields });
  }
  // 更新forms
  changeForms = (forms) => {
    this.setState({ forms });
  }

  changeElKeyMap = ({ key, index }) => {
    this.elKeyMap = { ...this.elKeyMap, [key]: index };
  }

  deleteRow = (key) => {
    const { onChange } = this.props;
    const { output, fields } = this.state;
    const copyOutput = [...output];
    if (key in fields) delete fields[key];
    if (key in this.elKeyMap) {
      const index = this.elKeyMap[key];
      copyOutput.splice(index, 1);
      delete this.elKeyMap[key];
    }
    this.setState({ fields, output: copyOutput }, () => {
      onChange && onChange(copyOutput.filter(value => Object.keys(value).length !== 0));
    });
  }

  render() {
    const {
      dataSource,
      fields,
      forms
    } = this.state;
    const {
      tableFields = [],
      maxRows,
      maxRowTips,
      showOrder,
      orderCellWidth,
      actionCellWidth,
      showAction,
      title
    } = this.props;
    return (
      <HCard title={title}>
        <ExtraCostContext.Provider
          value={{
            dataSource,
            forms,
            onValuesChange: this.onValuesChange,
            onFieldsChange: this.onFieldsChange,
            fields,
            changeForms: this.changeForms,
            elKeyMap: this.elKeyMap,
            changeElKeyMap: this.changeElKeyMap
          }}
        >
          <EditableTable
            showAction={showAction}
            orderCellWidth={orderCellWidth}
            actionCellWidth={actionCellWidth}
            tableFields={tableFields}
            maxAddMessage={maxRowTips}
            maxAddLength={maxRows}
            changeDataSource={this.changeDataSource}
            deleteRow={this.deleteRow}
            showOrder={showOrder}
          />
        </ExtraCostContext.Provider>
      </HCard>
    );
  }
}

export default CustomedTableForm;
