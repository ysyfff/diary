import React from 'react';
import { Table, Button, Tooltip } from 'antd';
import EditableFormRow from './EditableFormRow';
import EditableCell from './EditableCell';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';

const EmptyText = props => (
  <Button
    style={{ width: '100%' }}
    onClick={props.onAdd}
    type="dashed"
    icon="plus"
  >添加
  </Button>
);

class EditableTable extends React.PureComponent {
  constructor(props) {
    super(props);
    // 保存表单对象
    this.form = {};
    const { orderCellWidth, actionCellWidth } = props;
    this.columnOrder = [{
      title: '序号',
      dataIndex: '__order__',
      width: orderCellWidth,
      align: 'center',
      render: (text, record) => (
        <ExtraCostContext.Consumer>
          {({ elKeyMap }) => (
            <React.Fragment>{elKeyMap[record.key] + 1}</React.Fragment>
          )
          }
        </ExtraCostContext.Consumer>
      )
    }];
    this.columns = [{
      title: '操作',
      dataIndex: '__action__',
      align: 'center',
      width: actionCellWidth,
      render: (text, record) => (
        <EditableContext.Consumer>
          {() => (
            <div style={{ padding: '9px 0' }}>
              <span>
                <ExtraCostContext.Consumer>
                  {({ dataSource }) => (
                    <a
                      onClick={this.handleDelete(dataSource, record.key)}
                      style={{ marginRight: 8 }}
                    >
                      移除
                    </a>
                  )}
                </ExtraCostContext.Consumer>
                <ExtraCostContext.Consumer>
                  {({ dataSource }) => (
                    <React.Fragment>
                      {
                        dataSource.length >= this.props.maxAddLength &&
                        (<Tooltip
                          title={this.props.maxAddMessage}
                          placement="top"
                          trigger="click"
                        >
                          <a>添加</a>
                        </Tooltip>)
                      }
                      {
                        dataSource.length < this.props.maxAddLength &&
                          (<a onClick={this.handleAdd(dataSource, record.key)}>添加</a>)
                      }
                    </React.Fragment>

                  )}
                </ExtraCostContext.Consumer>
              </span>
            </div>
          )}
        </EditableContext.Consumer>
      )
    }];
  }

  onRow = changeElKeyMap => (record, index) => {
    const { key } = record;
    changeElKeyMap({ key, index });
  }

  // 移除表格一条记录
  handleDelete = (dataSource, key) => () => {
    const { deleteRow, changeDataSource } = this.props;
    const nextDataSouce = [...dataSource];
    changeDataSource(nextDataSouce.filter(item => item.key !== key));
    deleteRow(key);
  }

  // 新增一条数据
  handleAdd = (dataSource, key) => (e) => {
    e.persist();
    // 拷贝dataSource
    const copyDataSource = [...dataSource];
    // 获取对应key在数组中的位置
    let position = 0;
    // 获取最大index值
    let maxIndex = copyDataSource[0].index;
    for (let index = 0; index < copyDataSource.length; index += 1) {
      const data = copyDataSource[index];
      if (data.index > maxIndex) {
        maxIndex = data.index;
      }
      if (data.key === key) {
        position = index;
      }
    }
    maxIndex += 1;
    const _key = `record-${maxIndex}`;
    const addValue = {
      key: _key,
      index: maxIndex
    };
    copyDataSource.splice(position + 1, 0, addValue);
    this.props.changeDataSource(copyDataSource, _key, position + 1);
  }

  // 添加一条新的费用信息
  handleNew = () => {
    this.props.changeDataSource([{ key: 'record-1', index: 1 }]);
  }

  render() {
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell
      },
    };
    const { tableFields, showOrder, showAction } = this.props;
    return (
      <ExtraCostContext.Consumer>
        {({ dataSource, changeElKeyMap }) => {
          let columns = [];
          if (showOrder) columns = columns.concat(this.columnOrder);
          columns = columns.concat(tableFields);
          if (showAction) columns = columns.concat(this.columns);
          const _columns = columns.map((col) => {
            const { fields = {}, dataIndex, title } = col;
            if (!col.editable) {
              return {
                ...col,
                onCell: record => ({
                  record,
                  dataIndex,
                  title,
                  fields
                }),
              };
            }
            return {
              ...col,
              onCell: record => ({
                record,
                type: fields.type || 'input',
                dataIndex,
                title,
                fields,
                editing: true
              }),
            };
          });
          return (
            <React.Fragment>
              <Table
                rowKey={record => record.key}
                components={components}
                rowClassName={() => 'delivery-cost-editable-row'}
                dataSource={dataSource}
                columns={_columns}
                pagination={false}
                onRow={this.onRow(changeElKeyMap)}
                locale={{ emptyText: <EmptyText onAdd={this.handleNew} /> }}
              />
            </React.Fragment>
          );
        }}
      </ExtraCostContext.Consumer>
    );
  }
}

export default EditableTable;
