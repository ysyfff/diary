import { Input, InputNumber, Form } from 'antd';
import { HSelect } from 'components/helper';
import { Type } from 'carno/utils';
import ExtraCostInput from '../../ExtraCostInput';
import EditableContext from './EditableContext';

const FormItem = Form.Item;


class EditableCell extends React.PureComponent {
  getInput = () => {
    const { type, fields } = this.props;
    switch (type) {
      case 'input':
        return <Input {...fields.props} />;
      case 'inputnumber':
        return <InputNumber {...fields.props} />;
      case 'select':
        return <HSelect {...fields.props} />;
      case 'extracost':
        return <ExtraCostInput {...fields.props} />;
      default:
        return <Input {...fields.props} />;
    }
  };

  render() {
    const {
      editing,
      dataIndex,
      record,
      fields = {},
      ...restProps
    } = this.props;
    return (
      <EditableContext.Consumer>
        {({ form }) => {
          const { getFieldDecorator } = form;
          const { render } = fields;
          let Component = null;
          if (render && Type.isFunction(render)) {
            Component = render;
          }
          Component = Component ? <Component form={form} /> : restProps.children;
          return (
            <td
              {...restProps}
              title={dataIndex}
            >
              {editing ? (
                <FormItem style={{ margin: 0 }}>
                  {getFieldDecorator(dataIndex, {
                    ...fields.validator
                  })(this.getInput())}
                </FormItem>
              ) : Component}
            </td>
          );
        }}
      </EditableContext.Consumer>
    );
  }
}

export default EditableCell;
