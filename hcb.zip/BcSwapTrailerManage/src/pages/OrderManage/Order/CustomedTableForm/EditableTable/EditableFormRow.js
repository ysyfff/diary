import React from 'react';
import { Form } from 'antd';
import EditableContext from './EditableContext';
import ExtraCostContext from '../ExtraCostContext';

class EditableRow extends React.PureComponent {
  componentWillMount() {
    this.changeFormsByType('add');
  }

  componentWillUnmount() {
    this.changeFormsByType('delete');
  }

  changeFormsByType = (type) => {
    const key = this.props['data-row-key'];
    const { forms, changeForms, form } = this.props;
    // 新增form
    if (type === 'add') {
      changeForms({ ...forms, [key]: form });
    } else if (type === 'delete') {
      // 删除form
      const copyForms = { ...forms };
      if (key in copyForms) delete copyForms[key];
      changeForms(copyForms);
    }
  }

  render() {
    const {
      form,
      index,
      changeForms,
      onFieldsChange,
      onValuesChange,
      ...props
    } = this.props;
    return (
      <EditableContext.Provider value={{ form, index }}>
        <tr {...props} />
      </EditableContext.Provider>
    );
  }
}

const EditableFormRow = Form.create({
  onFieldsChange(props, changedFields) {
    const { onFieldsChange } = props;
    const key = props['data-row-key'];
    onFieldsChange && onFieldsChange(changedFields, key);
  },
  onValuesChange(props, changedValues) {
    const { onValuesChange } = props;
    const key = props['data-row-key'];
    onValuesChange && onValuesChange(changedValues, key);
  },
  mapPropsToFields(props) {
    const key = props['data-row-key'];
    if (props.fields) return props.fields[key] || {};
    return {};
  }
})(EditableRow);

const EditableFormRowWrapper = props => (
  <ExtraCostContext.Consumer>
    {({ forms, onValuesChange, onFieldsChange, changeForms, fields }) => (
      <EditableFormRow
        {...props}
        onFieldsChange={onFieldsChange}
        onValuesChange={onValuesChange}
        fields={fields}
        forms={forms}
        changeForms={changeForms}
      />
    )}
  </ExtraCostContext.Consumer>
);
export default EditableFormRowWrapper;
