const format = values => values.map(value => Object.values(value).join('：')).join('；');

export {
  format
};
