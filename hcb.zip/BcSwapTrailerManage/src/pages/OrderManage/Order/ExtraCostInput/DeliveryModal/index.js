import React from 'react';
import { Modal } from 'antd';
import EditableTable from '../EditableTable';
import ExtraCostContext from '../ExtraCostContext';
import { format } from '../utils';

import './index.less';

class DeliveryModal extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.visible !== nextProps.visible) {
      this.setState({ visible: true });
    }
  }

  componentWillUnmount() {
    clearTimeout(this.timer);
  }

  handleCancel = (forms, prevFields, prevDataSource) => () => {
    const { handleClickCancelButton } = this.props;
    this.setState({ visible: false }, () => {
      this.timer = setTimeout(() => {
        handleClickCancelButton({ prevFields, prevDataSource });
        Object.keys(forms).forEach((key) => {
          forms[key].resetFields();
        });
        clearTimeout(this.timer);
      }, 300);
    });
  }

  handleOk = (forms, fields, values, dataSource) => () => {
    const { handleClickOkButton } = this.props;
    const keys = Object.keys(forms);
    // 表单校验数组
    const errors = [];
    // 新增数据验证
    for (let i = 0; i < keys.length; i += 1) {
      const form = forms[keys[i]];
      form.validateFieldsAndScroll((error) => {
        if (!error) {
          errors.push(0);
        } else {
          errors.push(1);
        }
      });
    }
    // 判断是否验证通过
    const isError = errors.some(error => error === 1);
    if (!isError) {
      // 修改父级state
      handleClickOkButton({
        inputValue: format(values),
        prevValue: values,
        prevFields: fields,
        prevDataSource: dataSource
      });
      this.setState({ visible: false });
    }
  }

  render() {
    const { visible } = this.state;
    const { modalProps, ...restProps } = this.props;
    return (
      <ExtraCostContext.Consumer>
        {({
          dataSource,
          forms,
          value,
          fields,
          prevFields,
          prevDataSource
        }) => (
          <Modal
            className="delivery-modal"
            {...modalProps}
            visible={visible}
            onCancel={this.handleCancel(forms, prevFields, prevDataSource)}
            centered
            onOk={this.handleOk(forms, fields, value, dataSource)}
          >
            <EditableTable {...restProps} />
          </Modal>
        )}
      </ExtraCostContext.Consumer>
    );
  }
}

export default DeliveryModal;
