/**
 * @author yang.huang3
 * @description 其他费用组件
 * @since 2018.09.13
 */
import React from 'react';
import { Input } from 'antd';
import { Form } from 'antd';
import { _ } from 'carno/third-party';
import { Type } from 'carno/utils';
import DeliveryModal from './DeliveryModal';
import ExtraCostContext from './ExtraCostContext';
import { format } from './utils';

const resolveValueToDatasource = (values, columnsKeys) => {
  if (!Type.isArray(values)) throw new Error('value must be array');
  const fields = {};
  if (values.length === 0) {
    return {
      dataSource: [{ key: 'record-1', index: 1 }],
      fields
    };
  }
  const dataSource = values.map((value, index) => {
    const order = index + 1;
    const key = `record-${order}`;
    fields[key] = {};
    columnsKeys.forEach((columnsKey) => {
      fields[key][columnsKey] = Form.createFormField({ value: value[columnsKey] || undefined });
    });
    return {
      key,
      index: order
    };
  });
  return {
    dataSource,
    fields
  };
};

const getColumnsKeys = (tableFields) => {
  const keys = [];
  tableFields.forEach((field) => {
    const { editable, dataIndex } = field;
    if (editable) keys.push(dataIndex);
  });
  return keys;
};

class ExtraCostInput extends React.PureComponent {
  static defaultProps = {
    tableFields: [],
    maxRows: 5,
    maxRowsTips: '已达到最大添加条数',
    modalTitle: '',
  };

  constructor(props) {
    super(props);
    const { tableFields } = props;
    const columnsKeys = getColumnsKeys(tableFields);
    const value = props.value || [];
    const result = resolveValueToDatasource(value, columnsKeys);
    const { dataSource, fields } = result;
    this.state = {
      value, // form表单value
      output: value, // form表单像外输出值
      inputValue: format(value), // 输入框value
      visible: Symbol('visible'),
      forms: {},
      columnsKeys,
      dataSource,
      fields,
      prevValue: value, // 上一个value
      prevFields: fields, // 上一个fields状态
      prevDataSource: dataSource, // 上一个dataSource状态
    };
    this.elKeyMap = {};
  }

  componentWillReceiveProps = (nextProps) => {
    const { value = [] } = nextProps;
    const { columnsKeys, output } = this.state;
    // 去除空对象
    let copyOutput = [...output];
    copyOutput = copyOutput.filter(value => Object.keys(value).length !== 0);
    if (!_.isEqual(value, copyOutput)) {
      const { dataSource, fields } = resolveValueToDatasource(value, columnsKeys);
      console.log('fields', fields);
      this.setState({
        dataSource,
        fields,
        prevDataSource: dataSource,
        prevFields: fields,
        output: value,
        value,
        inputValue: format(value)
      });
    } else {
      this.setState({ value });
    }
  }

  onFieldsChange = (changedFields, key) => {
    const keys = Object.keys(changedFields || {});
    // 是否是重置操作
    const isRest = keys.length > 0 && keys
      .every(key => !Object.prototype.hasOwnProperty.call(changedFields[key], 'value'));
    if (!isRest) {
      const validating = changedFields[keys[0]].validating || false;
      if (keys.length !== 1 || validating) return;
    }
    this.setState(({ fields }) => ({
      fields: {
        ...fields,
        [key]: { ...fields[key], [keys[0]]: Form.createFormField({ value: changedFields[keys[0]].value }) }
      }
    }));
  }

  onValuesChange = (changedValues, key) => {
    const { onChange } = this.props;
    const { output } = this.state;
    let copyOutput = [...output];
    const index = this.elKeyMap[key];
    copyOutput[index] = { ...copyOutput[index], ...changedValues };
    this.setState({ output: copyOutput }, () => {
      onChange && onChange(copyOutput.filter(value => Object.keys(value).length !== 0));
      copyOutput = null;
    });
  }

  // 更新forms
  changeForms = (forms) => {
    this.setState({ forms });
  }

  changeElKeyMap = ({ key, index }) => {
    this.elKeyMap = { ...this.elKeyMap, [key]: index };
  }

  deleteRow = (key) => {
    const { onChange } = this.props;
    const { output, fields } = this.state;
    const copyOutput = [...output];
    const copyFields = { ...fields };
    if (key in copyFields) delete copyFields[key];
    if (key in this.elKeyMap) {
      const index = this.elKeyMap[key];
      copyOutput.splice(index, 1);
      delete this.elKeyMap[key];
    }
    this.setState({ fields: copyFields, output: copyOutput }, () => {
      onChange && onChange(copyOutput.filter(value => Object.keys(value).length !== 0));
    });
  }

  // 输入框点击事件
  handleClick = () => {
    this.setState(({ dataSource }) => ({
      visible: Symbol('visible'),
      dataSource: dataSource.length === 0 ? [{ key: 'record-1', index: 1 }] : dataSource
    }));
  }
  // 更新dataSource
  changeDataSource = (dataSource, key, index) => {
    const { output } = this.state;
    const copyOutput = [...output];
    // 新增列
    if (key && index) {
      copyOutput.splice(index, 0, {});
      this.setState({ output: copyOutput });
    }
    this.setState({ dataSource });
  }

  // 更新fields
  changeFields = (fields) => {
    this.setState({ fields });
  }

  // 当点击ok按钮时
  handleClickOkButton = ({ inputValue, prevValue, prevFields, prevDataSource }) => {
    this.setState({
      inputValue,
      prevValue,
      prevFields,
      prevDataSource
    });
  }

  // 当点击ok按钮时
  handleClickCancelButton = ({ prevFields, prevDataSource }) => {
    const { prevValue } = this.state;
    this.setState({
      value: prevValue,
      fields: prevFields,
      dataSource: prevDataSource
    });
  }

  render() {
    const {
      visible,
      dataSource,
      forms,
      fields,
      value,
      inputValue,
      prevFields,
      prevDataSource,
      columnsKeys
    } = this.state;
    const {
      inputProps,
      ...restProps
    } = this.props;
    return (
      <div>
        <Input
          readOnly
          onClick={this.handleClick}
          value={inputValue}
          {...inputProps}
        />
        <ExtraCostContext.Provider
          value={{
            dataSource,
            forms,
            onFieldsChange: this.onFieldsChange,
            onValuesChange: this.onValuesChange,
            changeForms: this.changeForms,
            changeElKeyMap: this.changeElKeyMap,
            fields,
            prevFields,
            prevDataSource,
            value,
            calculateKey: restProps.calculateKey
          }}
        >
          <DeliveryModal
            {...restProps}
            visible={visible}
            columnsKeys={columnsKeys}
            changeDataSource={this.changeDataSource}
            changeFields={this.changeFields}
            deleteRow={this.deleteRow}
            handleClickOkButton={this.handleClickOkButton}
            handleClickCancelButton={this.handleClickCancelButton}
          />
        </ExtraCostContext.Provider>
      </div>
    );
  }
}

export default ExtraCostInput;
