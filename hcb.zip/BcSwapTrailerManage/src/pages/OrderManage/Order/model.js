import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
import { getRegionName } from 'utils';

// import { Paths, PAGE_SIZE } from 'configs/constants';

import {
  getOldShipCompany,
  getShipCompany,
  getrecCompany,
  getCustomer,
  getAddress,
  creatOrder
} from './services';

// 字段初始化
const initShipCompany = {
  code: '',
  name: '',
  nameLike: '',
  codeLike: '',
  lineType: '',
  companyName: '',
  phone: '',
  keyword: '',
  nameOrPhone: '',
  createTimeStart: '',
  createTimeEnd: ''
};

// 地址回现
const addressName = (province, city, county) => {
  const addressId = county || city || province;
  const addressName = getRegionName(addressId, '');
  const addressCode = province ? [{ id: +addressId, name: getRegionName(addressId, '') }] : [];
  return {
    addressName,
    addressCode
  };
};

export default Model.extend({
  namespace: 'order',

  state: {
    loading: { list: false },
    searchShipCompany: initShipCompany,
    total: 0,
    list: [],
    orderCounts: [],
    shipCompanyName: [],
    oldShipCompanyName: []
  },

  subscriptions: {
  },

  effects: {
    //  获取历史发货公司
    * getOldShipCompany({ payload }, { call }) {
      const datas = yield call(withLoading(getOldShipCompany, 'getOldShipCompany'), payload);
      const companyList = datas || [];
      return companyList.map(company => ({
        shipCompanyName: company
      }));
    },
    // 获取发货公司
    * getShipCompany({ payload }, { call }) {
      const data = yield call(withLoading(getShipCompany, 'getShipCompany'), payload);
      return data || [];
    },
    //  获取收货公司
    * getrecCompany({ payload }, { call }) {
      const datas = yield call(withLoading(getrecCompany, 'getrecCompany'), payload);
      const companyList = datas || [];
      return companyList.map(company => ({
        companyName: company
      }));
    },
    //  获取联系人信息
    * getCustomer({ payload }, { call }) {
      const datas = yield call(withLoading(getCustomer, 'getCustomer'), payload);
      return datas || [];
    },
    // 获取历史地址
    * getAddress({ payload }, { call }) {
      const datas = yield call(withLoading(getAddress, 'getAddress'), payload);
      const addressList = datas || [];
      return addressList.map(i => ({
        address: i.address,
        ...addressName(i.province, i.city, i.county)
      }));
    },
    // 创建订单
    * addOrder({ payload }, { call, put }) {
      yield call(withLoading(creatOrder, { successMsg: '新建订单成功！', key: 'addOrder' }), { ...payload });
      yield put(routerRedux.push('/orderManage'));
    },
  },

  reducers: {
    resetSearch(state) {
      return {
        ...state,
        search: { ...initShipCompany }
      };
    },
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
