import { connect } from 'dva';
import { Row, Col, Button, Popover, Icon, Modal, Radio } from 'antd';
import { Link } from 'dva/router';
import { HTable } from 'carno';
import { AuthortyWarpper } from 'components';
import { qs } from 'carno/third-party';
import { downFile } from 'utils';
import SearchBar from './SearchBar';
import styles from './index.less';

const confirm = Modal.confirm;

const takeUrl = '/sendStation/pickup/add?';

@connect(({ orderManage }) => ({ ...orderManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'orderManage/updateSearch', payload: param });
    dispatch({ type: 'orderManage/getList' });
  },
  onReset: () => {
    dispatch({ type: 'orderManage/resetSearch' });
    dispatch({ type: 'orderManage/getList' });
  },
  exportData: (params) => {
    downFile({
      server: 'admin',
      url: '/web/m/order/export',
      params
    });
  },
  cancelOrder: (param) => {
    dispatch({ type: 'orderManage/cancelOrder', payload: param });
  },
}))
export default class OrderManage extends React.Component {
  getProps() {
    const { tableFields, search, total, loading, list, getList, cancelOrder, permission } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: tableFields,
        extraFields: [
          {
            key: 'orderNo',
            name: '订单号',
            render: record => <Link target="_blank" to={`/orderManage/detailOrder/${record}`}>{record}</Link>
          },
          {
            key: 'buyerName',
            name: '操作',
            render: (record, data) => <Popover
              placement="right"
              overlayStyle={{ zIndex: 999 }}
              content={

                <ul className="table-operate-button">
                  {/* 含有提货派车 */}
                  {
                    (data.valueAddedService === 'ALL' || data.valueAddedService === 'DELIVERYCAR') &&
                    <div>
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.modify}>

                          <li>
                            <Link target="_blank" to={`/orderManage/editOrder/${data.orderNo}`}>编辑订单</Link>
                          </li>
                        </AuthortyWarpper>
                      }
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.pickup}>
                          <li>
                            <Link
                              to={
                                `${takeUrl}${this.pickUpParam(data)}`
                              }
                            >提货派车</Link>
                          </li>
                        </AuthortyWarpper>
                      }
                      {
                        data.status === 'TAKED' &&
                        <AuthortyWarpper code={permission.order.orderToWaybill}>
                          <li><Link
                            target="_blank"
                            to={`/waybillManage/addWaybill?orderNo=${data.orderNo}`}
                          >转运单</Link></li>
                        </AuthortyWarpper>
                      }
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.cancel}>
                          <li>
                            <a onClick={() => confirm({
                              title: `确定取消订单[${data.orderNo}]吗？`,
                              content: '',
                              onOk() {
                                cancelOrder(data.orderNo);
                              },
                              onCancel() {
                                console.log('Cancel');
                              },
                            })}
                            >取消订单</a>
                          </li>
                        </AuthortyWarpper>
                      }
                      <li>
                        <Link target="_blank" to={`/orderManage/detailOrder/${data.orderNo}`}>查看详情</Link>
                      </li>
                    </div>
                  }

                  {/* 不含有提货派车 */}
                  {
                    (data.valueAddedService === null ||
                    data.valueAddedService === 'DELIVERYVEHICLE' ||
                    data.valueAddedService === 'NO') &&
                    <div>
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.modify}>
                          <li>
                            <Link target="_blank" to={`/orderManage/editOrder/${data.orderNo}`}>编辑订单</Link>
                          </li>
                        </AuthortyWarpper>
                      }
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.orderToWaybill}>
                          <li><Link
                            target="_blank"
                            to={`/waybillManage/addWaybill?orderNo=${data.orderNo}`}
                          >转运单</Link></li>
                        </AuthortyWarpper>
                      }
                      {
                        data.status === 'NORMAL' &&
                        <AuthortyWarpper code={permission.order.cancel}>
                          <li>
                            <a onClick={() => confirm({
                              title: `确定取消订单[${data.orderNo}]吗？`,
                              content: '',
                              onOk() {
                                cancelOrder(data.orderNo);
                              },
                            })}
                            >取消订单</a>
                          </li>
                        </AuthortyWarpper>
                      }
                      <li>
                        <Link to={`/orderManage/detailOrder/${data.orderNo}`} target="_blank">查看详情</Link>
                      </li>
                    </div>
                  }

                  {/* {
                  data.status === 'NORMAL' && <li>
                    <Link to={`/orderManage/editOrder/${data.orderNo}`}>编辑订单</Link>
                  </li>
                }
                <li>
                  <Link to={`/sendStation/pickup/add?type=${data.mainBusiness}
                  &orderNo=${data.orderNo}&pickUpTime=${data.takeTimeStr}`}
                  >提货</Link>
                </li>
                <li><Link to={`/waybillManage/addWaybill?orderNo=${data.orderNo}`}>转运单</Link></li> */}

                </ul>}
            ><a><Icon type="menu-unfold" /></a></Popover>
          }],
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 2300 },
        pagination,
        locale: { emptyText: '暂无订单' },
        style: { marginTop: 16 },
      },
    };
  }

  pickUpParam = data =>
    // console.log(data.shipAddress)
    qs.stringify({
      orderNo: data.orderNo
    })

  showStatus = (key) => {
    this.props.getList({ ...this.props.search, operateStatus: key.target.value, pn: 1 });
  }

  handleSearch(search) {
    this.props.getList(search);
  }

  exportData = () => {
    this.props.exportData(this.props.search);
  }

  render() {
    const { getList, search, onReset, permission } = this.props;
    const { tableProps } = this.getProps();

    const SearchBarProps = {
      search,
      onSearch: getList,
      onReset
    };

    return (
      <div className={styles['order-list']}>
        <SearchBar {...SearchBarProps} />
        <Row type="flex" justify="space-between">
          <Col span={18} style={{ paddingTop: 14 }}>
            <Radio.Group buttonStyle="solid" value={search.operateStatus} onChange={this.showStatus}>
              <Radio.Button value="">全部</Radio.Button>
              <Radio.Button value="1">待提货</Radio.Button>
              <Radio.Button value="2">待转运单</Radio.Button>
            </Radio.Group>
          </Col>
          <Col span={6}>
            <div className="order-list-button">
              <AuthortyWarpper code={permission.order.create}>
                <Link to="/orderManage/addOrder" target="_blank">
                  <Button type="primary">新建订单</Button>
                </Link>
              </AuthortyWarpper>
              <AuthortyWarpper code={permission.order.export}>
                <Button onClick={this.exportData}>导出表单</Button>
              </AuthortyWarpper>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />
      </div>
    );
  }
}
