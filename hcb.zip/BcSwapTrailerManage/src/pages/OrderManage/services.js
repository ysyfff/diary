import http from 'utils/http';

const { post } = http.create('admin');

export function getList(param) {
  return post('/web/m/order/list', param);
}

//  作废订单
export function cancelOrder(param) {
  return post('/web/m/order/cancel', param);
}

