import { Button, Form, Input, Row, Col, DatePicker, Select } from 'antd';
import { mainType, sendWays, appreciationTypeAll, signingType } from 'configs/constants';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const Option = Select.Option;

class SearchBar extends React.Component {
  state = {
    ...this.props.search
  }

  componentWillReceiveProps = (nextProps) => {
    if (this.state.ps !== nextProps.search.ps) {
      this.setState({
        ps: nextProps.search.ps
      });
    }
  }

  // 查询
  handleSearch = () => {
    const { onSearch } = this.props;
    const data = Object.assign({}, this.state);
    data.createTime = data.createTime.length > 0 ?
      data.createTime.map(i => i.format('YYYY-MM-DD HH:mm:ss')).join(',') : '';
    data.takeTime = data.takeTime.length > 0 ?
      data.takeTime.map(i => i.format('YYYY-MM-DD HH:mm:ss')).join(',') : '';
    onSearch({ ...data, pn: 1 });
  }
  // 重置
  handleReset = () => {
    const { onReset, form } = this.props;
    form.resetFields();
    onReset();
    this.setState({
      pn: 1,
      ps: 10,
      orderNo: '',
      mainBusiness: '',
      takeTime: '',
      shipCompanyName: '',
      createTime: '',
      valueAddedService: [],
      signWay: '',
      sendWay: '',
      recCompanyName: '',
      operateStatus: ''
    });
  }
  // 重置
  handleVerify() {
    const { updateState } = this.props;
    updateState({ verifyResult: {}, VerifyModalVisible: true });
  }

  handleChange(key) {
    return (value) => {
      let newValue = value;
      if (value && value.target) {
        newValue = value.target.value;
      }
      this.setState({ [key]: newValue });
    };
  }
  render() {
    const search = this.state;

    const searchLayout = {
      xxl: { span: 6 },
      xl: { span: 8 },
      lg: { span: 12 }
    };

    return (
      <div>
        <div className="searchBar">
          <Form layout="inline" onSubmit={this.handleSubmit}>
            <Row>

              <Col {...searchLayout}>
                <FormItem label="订单号" >
                  <Input
                    placeholder="输入订单号查询"
                    value={search.orderNo}
                    onChange={this.handleChange('orderNo')}
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="主营服务">
                  <Select
                    value={search.mainBusiness}
                    onChange={this.handleChange('mainBusiness')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      mainType.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="提货时间">
                  <RangePicker
                    value={search.takeTime}
                    onChange={this.handleChange('takeTime')}
                    style={{ width: '100%' }}
                    format="MM-DD HH:mm:ss"
                    showTime
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="发货公司">
                  <Input
                    placeholder="输入发货公司"
                    value={search.shipCompanyName}
                    onChange={this.handleChange('shipCompanyName')}
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="下单时间">
                  <RangePicker
                    value={search.createTime}
                    onChange={this.handleChange('createTime')}
                    style={{ width: '100%' }}
                    format="MM-DD HH:mm:ss"
                    showTime
                  />
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="增值服务">
                  <Select
                    mode="multiple"
                    value={search.valueAddedService}
                    onChange={this.handleChange('valueAddedService')}
                    placeholder="请选择增值服务"
                  >
                    {/* <Option
                      value=""
                    >
                     全部
                    </Option> */}
                    {
                      appreciationTypeAll.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="签收方式">
                  <Select
                    value={search.signWay}
                    onChange={this.handleChange('signWay')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      signingType.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="产品时效">
                  <Select
                    value={search.sendWay}
                    onChange={this.handleChange('sendWay')}
                  >
                    <Option
                      value=""
                    >
                     全部
                    </Option>
                    {
                      sendWays.map(option => (
                        <Option
                          key={option.key}
                        >
                          {option.value}
                        </Option>
                      ))
                    }
                  </Select>
                </FormItem>
              </Col>

              <Col {...searchLayout}>
                <FormItem label="收货公司">
                  <Input
                    placeholder="输入收货公司"
                    value={search.recCompanyName}
                    onChange={this.handleChange('recCompanyName')}
                  />
                </FormItem>
              </Col>
            </Row>

            <Row type="flex" justify="end">
              <FormItem label="">
                <Button type="primary" onClick={this.handleSearch}>搜索</Button>
                <Button onClick={this.handleReset}>重置</Button>
              </FormItem>
            </Row>
          </Form>
        </div>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
