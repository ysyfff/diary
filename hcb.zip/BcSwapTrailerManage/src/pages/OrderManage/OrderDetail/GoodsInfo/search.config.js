import CustomedTableForm from 'components/DeliveryNote/CustomedTableForm';
import tableFields from './tableFields';

const fields = [{
  key: 'cargoList',
  render: ({ form, ...props }) => (
    <CustomedTableForm
      {...props}
      title="货物信息"
      tableFields={tableFields.tableFormFields}
      actionCellWidth={'20%'}
    />
  )
}];

export default fields;
