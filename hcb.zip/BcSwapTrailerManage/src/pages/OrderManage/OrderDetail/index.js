import React from 'react';
import { connect } from 'dva';
import { SearchCard, HCard } from 'components/helper';
import { Row, Col, Spin } from 'antd';
import { HTable } from 'carno';
import { getRegionName } from 'utils';
import GoodsAddress from 'components/DeliveryNote/GoodsAddress';
import { tableFields } from './fields';
import shipFields from './DeliveryInfo/ship.config';
import serverFields from './DeliveryInfo/server.config';
import receiptFields from './DeliveryInfo/receipt.config';
import remarkFields from './DeliveryInfo/remark.config';
import styles from './index.less';

const DeliveryCardColLayout = {
  xxl: { span: 12 },
  xl: { span: 12 },
  lg: { span: 24 },
  md: { span: 24 },
  sm: { span: 24 }
};

// 地址回现
const addressName = (province, city, county) => {
  const addressId = county || city || province;
  const addressCode = province ? [{ id: +addressId, name: getRegionName(addressId, '') }] : [];
  return addressCode;
};
// 转换地址
const transformAddressToComponent = (address = []) => address.map((addr) => {
  const { address, contact, contactPhone, province, city, county } = addr;
  return {
    addressDetail: address,
    contact,
    contactPhone,
    address: addressName(province, city, county)
  };
});

@connect(
  ({ OrderDetail }) => ({ ...OrderDetail }),
  dispatch => ({ dispatch })
)
class DeliveryNote extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      shipCustomerId: '',
      shipAddresses: [],
      recAddresses: [],
      cargoList: [],
      orderNo: '',
      id: '',
      loading: true
    };
  }

  componentDidMount = () => {
    // 服务
    this.serverHpler = this.server.props.helper;
    // 委托公司
    this.shipHpler = this.ship.props.helper;
    // 收货公司
    this.receiptHpler = this.receipt.props.helper;
    // 货物信息
    // this.goodsHpler = this.goods.props.helper;
    // 备注信息
    this.remarkHpler = this.remark.props.helper;

    const { dispatch, match } = this.props;
    const { params } = match;
    const { orderNo } = params;

    dispatch({
      type: 'OrderDetail/fetchDetail',
      payload: { orderNo }
    }).then((res) => {
      const {
        id,
        orderNo,
        mainBusiness,
        signWay,
        sendWay,
        valueAddedService,
        takeTime,
        cargoList,
        remark,
        shipCompanyName,
        shipCustomerId,
        recCompanyName,
        shipAddresses,
        recAddresses,
      } = res;
      this.serverHpler.setFieldsValues({
        mainBusiness,
        signWay,
        sendWay,
        valueAddedService,
        takeTime
      });
      // this.goodsHpler.setFieldsValues({
      //   cargoList
      // });
      this.remarkHpler.setFieldsValues({
        remark
      });
      this.shipHpler.setFieldsValues({
        shipCompanyName,
        flag: !shipCustomerId
      });
      this.receiptHpler.setFieldsValues({
        recCompanyName
      });
      // 设置显示提货时间
      this.setState({
        serverInfoExtraFields: [
          {
            key: 'takeTime',
            hidden: valueAddedService === 'DELIVERYVEHICLE' || valueAddedService === 'NO' || false
          }
        ],
        shipAddresses: transformAddressToComponent(shipAddresses),
        recAddresses: transformAddressToComponent(recAddresses),
        orderNo,
        id,
        cargoList,
        loading: false
      });
    });
  }

  render() {
    const { key } = this.props;
    const {
      serverInfoExtraFields,
      shipInfoExtraFields,
      receiptInfoExtraFields,
      remarkExtraFields,
      shipAddresses,
      recAddresses } = this.state;

    const tableProps = {
      fields: tableFields,
      total: 4,
      search: { pn: 1, ps: 10 },
      dataSource: this.state.cargoList,
      pagination: false
    };
    return (
      <div key={key} className={styles.order}>
        <Spin spinning={this.state.loading}>
          <Row type="flex" justify="start" className="ml10">
          订单号：
            <span>{this.state.orderNo}</span>
          </Row>
          <Row >
            <Col span={24}>
              <SearchCard
                extraFields={serverInfoExtraFields}
                title="服务信息"
                fields={serverFields}
                wrappedComponentRef={el => this.server = el}
              />
            </Col>
          </Row>
          <Row className="desc-item">
            <Col {...DeliveryCardColLayout} >
              <SearchCard
                extraFields={shipInfoExtraFields}
                title="委托信息"
                fields={shipFields}
                wrappedComponentRef={el => this.ship = el}
                extraContent={<GoodsAddress
                  value={shipAddresses}
                  disabled
                  onSearch={this.getShipCustomer}
                  onSearchAddress={(value, province, city, county) =>
                    this.getShipAddress(value, province, city, county)}
                  ref={address => this.shipAddress = address}
                />}
              />
            </Col>
            <Col {...DeliveryCardColLayout}>
              <SearchCard
                extraFields={receiptInfoExtraFields}
                title="收货信息"
                fields={receiptFields}
                wrappedComponentRef={el => this.receipt = el}
                extraContent={<GoodsAddress
                  label={{ citypicker: '收货地址', placeholder: false }}
                  value={recAddresses}
                  disabled
                  onSearch={this.getRecCustomer}
                  onSearchAddress={(value, province, city, county) => this.getRecAddress(value, province, city, county)}
                  ref={address => this.recAddress = address}
                />}
              />
            </Col>
          </Row>
          <Row>
            <Col {...DeliveryCardColLayout}>
              <HCard
                title="货物信息"
              >
                <HTable
                  {...tableProps}
                />
              </HCard>
            </Col>
            <Col {...DeliveryCardColLayout}>
              <SearchCard
                title="备注信息"
                fields={remarkFields}
                extraFields={remarkExtraFields}
                wrappedComponentRef={el => this.remark = el}
              />
            </Col>
          </Row>
        </Spin>
      </div>
    );
  }
}

export default DeliveryNote;
