// 发货公司
export const companyFields = [
  {
    title: '发货公司',
    dataIndex: 'companyName',
    key: 'companyName',
    width: 300,
  },
  {
    title: '助记码',
    dataIndex: 'mnemonicCode',
    key: 'mnemonicCode',
    width: 300,
  }
];

// 历史发货公司
export const historyCompanyFields = [
  {
    title: '发货公司',
    dataIndex: 'shipCompanyName',
    key: 'shipCompanyName',
    width: 300,
  },
];

export const tableFields = [
  {
    key: 'name',
    name: '货物品名',
    width: '25%',
  },
  {
    key: 'num',
    name: '件数（件）',
    width: '25%',
  },
  {
    key: 'weight',
    name: '重量（千克）',
    width: '25%',
  },
  {
    key: 'volume',
    name: '体积（方）',
    width: '25%',
  }
];

