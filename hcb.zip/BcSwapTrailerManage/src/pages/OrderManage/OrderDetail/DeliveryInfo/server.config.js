import {
  sendWays,
  mainType,
  signingType,
  appreciationTypeAll,
} from 'configs/constants';

const EL_COL_LAYOUT = {
  xxl: { span: 12, offset: 0 },
  xl: { span: 12, offset: 0 },
  lg: { span: 12, offset: 0 }
};

const EL_COL_LAYOUT2 = {
  xxl: { span: 6, offset: 0 },
  xl: { span: 6, offset: 0 },
  lg: { span: 6, offset: 0 }
};


const CARD_COL2_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 3 },
    xl: { span: 4 },
    lg: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 9 },
    xl: { span: 8 },
    lg: { span: 8 }
  }
};

const CARD_COL2_FORM_ITEM_LAYOUT2 = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 7 },
    lg: { span: 7 }
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 17 },
    lg: { span: 17 }
  }
};

const fields = [
  {
    key: 'mainBusiness',
    label: '主营服务',
    type: 'select',
    el: {
      placeholder: '请选择主营服务',
      options: mainType,
      disabled: true
    },
    col: { ...EL_COL_LAYOUT },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择主营服务' }
        ]
      }
    }
  },
  {
    key: 'signWay',
    label: '签收方式',
    type: 'select',
    el: {
      placeholder: '请选择签收方式',
      options: signingType,
      disabled: true
    },
    col: { ...EL_COL_LAYOUT },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择签收方式' }
        ]
      }
    }
  },
  {
    key: 'sendWay',
    label: '产品时效',
    type: 'select',
    el: {
      placeholder: '请选择产品时效',
      options: sendWays,
      disabled: true
    },
    col: { ...EL_COL_LAYOUT },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择产品时效' }
        ]
      }
    }
  },
  {
    key: 'valueAddedService',
    label: '增值服务',
    type: 'select',
    el: {
      placeholder: '请选择增值服务',
      options: appreciationTypeAll,
      disabled: true
    },
    col: { ...EL_COL_LAYOUT2 },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT2 },
      options: {
        rules: [
          { required: true, message: '请选择增值服务' }
        ]
      }
    }
  },
  {
    key: 'takeTime',
    label: '提货时间',
    type: 'datepicker',
    el: {
      placeholder: '请输入提货时间',
      formatType: 'datetime',
      showTime: true,
      disabled: true,
      format: 'YYYY-MM-DD HH:mm'
    },
    col: { ...EL_COL_LAYOUT2 },
    formItem: {
      props: { ...CARD_COL2_FORM_ITEM_LAYOUT2 },
      options: {
        rules: [
          { required: true, message: '请输入提货时间' }
        ]
      }
    }
  },
];

export default fields;
