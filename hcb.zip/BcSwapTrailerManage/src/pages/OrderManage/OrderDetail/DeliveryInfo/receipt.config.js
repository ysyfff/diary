import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';

// const EL_COL_LAYOUT = {
//   xxl: { span: 12 },
//   xl: { span: 12 },
//   lg: { span: 12 }
// };

// const CARD_COL2_FORM_ITEM_LAYOUT = {
//   labelCol: {
//     xxl: { span: 6 },
//     xl: { span: 8 },
//     lg: { span: 6 }
//   },
//   wrapperCol: {
//     xxl: { span: 18 },
//     xl: { span: 16 },
//     lg: { span: 16 }
//   }
// };

const CARD_COL1_FORM_ITEM_LAYOUT = {
  labelCol: {
    xxl: { span: 3 },
    xl: { span: 4 },
    lg: { span: 3 }
  },
  wrapperCol: {
    xxl: { span: 21 },
    xl: { span: 20 },
    lg: { span: 20 }
  }
};

const companyFields = [
  {
    title: '发货公司',
    dataIndex: 'companyName',
    key: 'companyName',
    width: 300,
  }
];

const fields = [
  {
    key: 'recCompanyName',
    label: '收货公司',
    col: { span: 24 },
    el: {
      disabled: true
    },
    formItem: {
      props: { ...CARD_COL1_FORM_ITEM_LAYOUT },
      options: {
        rules: [
          { required: true, message: '请选择收货公司' }
        ]
      }
    },
    render: ({ form, ...props }) => (
      <AutoSearchInput
        inputKey="companyName"
        columns={companyFields}
        scrollX={false}
        isAllowInput
        {...props}
      />
    )
  },
  // {
  //   key: 'deveryUser',
  //   label: '收货人',
  //   el: {
  //     defaultValue: ''
  //   },
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  //   }
  // }, {
  //   key: 'phoneNumber',
  //   label: '联系电话',
  //   el: {
  //   },
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  //   }
  // }, {
  //   key: 'deliveryAddress1',
  //   label: '收货地址1',
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  //   }
  // }, {
  //   key: 'deliveryAddress2',
  //   label: '收货地址1',
  //   col: { ...EL_COL_LAYOUT },
  //   formItem: {
  //     props: { ...CARD_COL2_FORM_ITEM_LAYOUT }
  //   }
  // }
];

export default fields;
