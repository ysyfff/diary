import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
import { getRegionName } from 'utils';

import {
  getOldShipCompany,
  getShipCompany,
  getrecCompany,
  getCustomer,
  getAddress,
  updateOrder,
  getDetail
} from './services';

// 地址回现
const addressName = (province, city, county) => {
  const addressId = county || city || province;
  const addressName = getRegionName(addressId, '');
  const addressCode = province ? [{ id: +addressId, name: getRegionName(addressId, '') }] : [];
  return {
    addressName,
    addressCode
  };
};

export default Model.extend({
  namespace: 'OrderEdit',

  state: {
    loading: { list: false },
    shipCompanyName: []
  },

  subscriptions: {
    // setup({ dispatch, listen }) {
    //   listen(Paths.EDIT_ORDER, ({ params }) => {
    //     const orderNo = params[0];
    //     dispatch({ type: 'fetchDetail', payload: { orderNo } });
    //   });
    // }
  },

  effects: {
    // 获取订单详情
    * fetchDetail({ payload }, { call }) {
      const { orderNo } = payload;
      const orderDetail = yield call(withLoading(getDetail, 'getDetail'), { orderNo });
      return orderDetail || {};
    },
    //  获取历史发货公司
    * getOldShipCompany({ payload }, { call }) {
      const datas = yield call(withLoading(getOldShipCompany, 'getOldShipCompany'), payload);
      const companyList = datas || [];
      return companyList.map(company => ({
        shipCompanyName: company
      }));
    },
    // 获取发货公司
    * getShipCompany({ payload }, { call }) {
      const data = yield call(withLoading(getShipCompany, 'getShipCompany'), payload);
      return data || [];
    },
    //  获取收货公司
    * getrecCompany({ payload }, { call }) {
      const datas = yield call(withLoading(getrecCompany, 'getrecCompany'), payload);
      const companyList = datas || [];
      return companyList.map(company => ({
        companyName: company
      }));
    },
    //  获取联系人信息
    * getCustomer({ payload }, { call }) {
      const datas = yield call(withLoading(getCustomer, 'getCustomer'), payload);
      return datas || [];
    },
    // 获取历史地址
    * getAddress({ payload }, { call }) {
      const datas = yield call(withLoading(getAddress, 'getAddress'), payload);
      const addressList = datas || [];
      return addressList.map(i => ({
        address: i.address,
        ...addressName(i.province, i.city, i.county)
      }));
    },
    // 编辑订单
    * updateOrder({ payload }, { call, put }) {
      yield call(withLoading(updateOrder, { successMsg: '编辑订单成功！', key: 'updateOrder' }), { ...payload });
      yield put(routerRedux.push('/orderManage'));
    },
  },

  reducers: {
  }
});
