import http from 'utils/http';
import { getDeployEnv } from 'carno/utils';
import { qs, cookie } from 'carno/third-party';
import { servers as serverConfigs } from 'configs';

export function getServer(servers = serverConfigs) {
  return servers[getDeployEnv(process.env.DEPLOY_ENV)];
}

const { post } = http.create('admin');

// 查询站点列表
export function getSites(param) {
  return post('/web/e/site/list', param);
}

// 查询库存列表
export function getList(param) {
  return post('/web/m/stock/list', param);
}
// 转库操作
export function changeStock(param) {
  return post('/web/m/stock/change', param);
}
// 库存导出
export function exportTable({ server, url, params }) {
  const qsparms = { ...params, sid: cookie.get('sid'), st: cookie.get('st') };
  const serverUrl = `${getServer()[server]}${url}?${qs.stringify({ ...qsparms })}`;
  window.open(serverUrl, '_blank');
}
