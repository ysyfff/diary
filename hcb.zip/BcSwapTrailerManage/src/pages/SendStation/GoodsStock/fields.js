import { Link } from 'dva/router';
import { waybillStatus } from 'configs/maps';
import { mainType, payWayType, sendWays, signingType, appreciationTypeAll } from 'configs/constants';
import { EllipsisRecord } from '../../../components';

export const tableFields = [{
  key: 'waybillNo',
  name: '运单号',
  width: 160,
  render: (record, r) => <Link
    target="_blank"
    rel="noopener noreferrer"
    to={`/waybillManage/detailWaybill/${record}`}
  >
    {r.sheetNo}</Link>
}, {
  key: 'action',
  name: '操作',
  width: 50
}, {
  key: 'waybillStatus',
  name: '状态',
  width: 100,
  render: record => record && waybillStatus.filter(i => i.key === record)[0].name
}, {
  key: 'mainBusiness',
  name: '主营服务',
  width: 100,
  render: record => record ? mainType.filter(i => i.key === record)[0].value : '--'
}, {
  key: 'dispatchType',
  name: '产品时效',
  width: 100,
  render: record => record ? sendWays.filter(i => i.key === record)[0].value : '--'
}, {
  key: 'putTime',
  name: '入库时间',
  type: 'datetime',
  width: 180,
  render: record => record || '--'
}, {
  key: 'putDayNum',
  name: '在库时长',
  width: 100,
  render: record => `${record || 0}小时`
}, {
  key: 'valueAddedService',
  name: '增值服务',
  width: 140,
  render: record => record ? appreciationTypeAll.filter(i => i.key === record)[0].value : '--'
}, {
  key: 'signedType',
  name: '签收方式',
  width: 140,
  render: record => record ? signingType.filter(i => i.key === record)[0].value : '--'
}, {
  key: 'waybillCreateTime',
  name: '下单时间',
  width: 180,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'fromSite',
  name: '发站',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'toSite',
  name: '到站',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'startCargoCompany',
  name: '发货公司',
  width: 140,
  render: record => <EllipsisRecord record={record || '--'} width={140} />
}, {
  key: 'receiveCargoCompany',
  name: '收货公司',
  width: 140,
  render: record => <EllipsisRecord record={record || '--'} width={140} />
}, {
  key: 'cargoName',
  name: '货物名称',
  width: 140,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoPackage',
  name: '货物包装',
  width: 140,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoPiece',
  name: '总件数（件）',
  width: 100,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  key: 'cargoResidualPiece',
  name: '剩余件数（件）',
  width: 120,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  key: 'cargoWeight',
  name: '总重量（千克）',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'cargoVolume',
  name: '总体积（方）',
  width: 100,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'freightAmount',
  name: '费用合计（元）',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'vehicleFreight',
  name: '整车运费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'weightFreight',
  name: '重量运费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'volumeFreight',
  name: '体积运费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'pickupTruckFee',
  name: '提货用车费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'deliveryFee',
  name: '送货用车费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'additionalFee',
  name: '附加费',
  width: 100,
  render: record => <EllipsisRecord record={record === 0 || record ? record.toFixed(2) : '--'} row={2} />
}, {
  key: 'payType',
  name: '付款方式',
  width: 100,
  render: record => record ? payWayType.filter(i => i.key === record)[0].value : '--'
}, {
  key: 'remark',
  name: '备注',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} width="120" />
}];

