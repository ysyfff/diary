import renderFormFactory from '../../../components/common/renderFormFactory';

const searchConfig = [{
  key: 'waybillNo',
  label: '运单号',
  type: 'input',
  placeholder: '输入运单号'
}, {
  key: 'mainBusiness',
  label: '主营服务',
  type: 'select',
  defaultValue: '',
  options: [{
    key: '全部',
    value: ''
  }, {
    key: '整车服务',
    value: 'VEHICLESERVICE'
  }, {
    key: '通道服务',
    value: 'CHANNELSERVICE'
  }]
}, {
  key: 'stockTime',
  label: '入库时间',
  type: 'rangepicker',
  showTime: true,
  format: 'MM-DD HH:mm:ss'
}, {
  key: 'from',
  label: '发站',
  type: 'select',
  placeholder: '选择发站查询',
  defaultValue: '',
  options: [],
  showSearch: true,
  optionFilterProp: 'children'
}, {
  key: 'startCargoCompany',
  label: '发货公司',
  type: 'input',
  placeholder: '请输入发货公司'
}, {
  key: 'signedType',
  label: '签收方式',
  type: 'select',
  defaultValue: '',
  options: [
    {
      value: '',
      key: '全部'
    },
    {
      value: 'SELF_SIGNED',
      key: '自提签收'
    },
    {
      value: 'DELIVERY_SIGNED',
      key: '送货签收'
    }
  ]
}, {
  key: 'dispatchType',
  label: '产品时效',
  type: 'select',
  defaultValue: '',
  options: [{
    key: '全部',
    value: ''
  }, {
    key: '急件',
    value: 'EMERGENCYW'
  }, {
    key: '慢件',
    value: 'SLOW'
  }]
}, {
  key: 'to',
  label: '到站',
  type: 'select',
  options: [],
  defaultValue: '',
  placeholder: '选择到站查询',
  showSearch: true,
  optionFilterProp: 'children'
}, {
  key: 'receiveCargoCompany',
  label: '收货公司',
  type: 'input',
  placeholder: '请输入收货公司'
}, {
  key: 'valueAddedService',
  label: '增值服务',
  type: 'select',
  defaultValue: [],
  mode: 'multiple',
  placeholder: '请选择增值服务',
  options: [
    {
      value: 'DELIVERYCAR',
      key: '提货'
    },
    {
      value: 'DELIVERYVEHICLE',
      key: '送货'
    },
    {
      value: 'ALL',
      key: '提货+送货',
    }, {
      value: 'NO',
      key: '无增值服务'
    }
  ]
}];

export default renderFormFactory(searchConfig, (values) => {
  const { stockTime, valueAddedService, ...otherValues } = values;
  const rangeValues = stockTime || ['', ''];
  const putStartTime = rangeValues[0] && rangeValues[0].format('YYYY-MM-DD HH:mm:ss');
  const putEndTime = rangeValues[1] && rangeValues[1].format('YYYY-MM-DD HH:mm:ss');
  return { putStartTime, putEndTime, valueAddedService: (valueAddedService || []).join(','), ...otherValues };
}, { xxl: { span: 6 }, xl: { span: 8 }, lg: { span: 12 }, md: { span: 12 } });
