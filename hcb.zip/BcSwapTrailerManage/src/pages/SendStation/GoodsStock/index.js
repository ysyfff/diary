/**
 * @author yang.huang3
 * @description 到货库存
 * @since 2018.09.06
 */
import React from 'react';
import { Row, Col, Radio, Button, Popover, Icon, message } from 'antd';
import { connect } from 'dva';
import { _ } from 'carno/third-party';
import { AuthortyWarpper } from 'components';
import { HModal } from 'carno';
import moment from 'moment';
import { BaseSearchBar, BaseHTable } from '../../../components';
import render from './search.config';
import { exportTable } from './services';

const baseItemLayout = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 6 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 18 },
    lg: { span: 18 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

// 获取rangepick默认值
function getRangepickerConfig(key, search, startKey, endKey) {
  const startTime = search[startKey];
  const endTime = search[endKey];
  let defaultValue = null;
  if (startTime && endTime) {
    defaultValue = [moment(startTime), moment(endTime)];
  } else {
    defaultValue = undefined;
  }
  return { key, defaultValue };
}


@connect(({ goodsStock }) => ({ ...goodsStock }), dispatch => ({ dispatch }))
class ArriveStock extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      render,
      modalVisible: false,
      waybillNo: ''
    };
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const payload = { pn: 1, ps: 999999999, codeLike: '' };
    await dispatch({ type: 'goodsStock/getSites', payload });
  }

  componentWillReceiveProps(nextProps) {
    if (_.isEqual(this.props.search, nextProps.search)) {
      this.rerender(nextProps);
    }
  }

  getExtraFields= () => (
    [{
      key: 'action',
      name: '操作',
      width: 80,
      render: (data, record) => {
        const { permission, search } = this.props;
        return (
          <React.Fragment>
            {
              record.cargoPiece === record.cargoResidualPiece ?
                (<AuthortyWarpper
                  code={permission.stock.change}
                  renderLine
                >
                  <Popover
                    placement="right"
                    overlayStyle={{ zIndex: 999 }}
                    content={
                      <ul className="table-operate-button">
                        {
                          search.stockType === 'NORMAL' &&
                          (<li><a onClick={this.handleToException(record)}>转异常库</a></li>)
                        }
                        {
                          search.stockType === 'ABNORMAL' &&
                          (<li><a onClick={this.handleToNormal(record)}>转正常库</a></li>)
                        }
                      </ul>
                    }
                  >
                    <a><Icon type="menu-unfold" /></a>
                  </Popover>
                </AuthortyWarpper>) : '--'
            }
          </React.Fragment>
        );
      }
    }]
  )

  // 带参数的查询方法
  getListByValues = (param) => {
    this.updateSearch(param);
    this.getList();
  }

  // 查询列表（不带参数）
  getList = () => {
    const { dispatch } = this.props;
    dispatch({ type: 'goodsStock/getList' });
  }

  handleStatusChange = (e) => {
    this.getListByValues({ stockType: e.target.value, pn: 1 });
  }

  handleToException = record => () => {
    this.setState({
      modalVisible: Symbol('modalVisible'),
      waybillNo: record.waybillNo
    });
  }

  handleToNormal = record => () => {
    this.setState({
      modalVisible: Symbol('modalVisible'),
      waybillNo: record.waybillNo
    });
  }
  // 更新search
  updateSearch = (param) => {
    const { dispatch } = this.props;
    dispatch({ type: 'goodsStock/updateSearch', payload: param });
  }

  rerender = (nextProps) => {
    const { search } = nextProps;
    const searchBarConfig = [{
      key: 'from',
      options: nextProps.sites,
      defaultValue: search.from || ''
    }, {
      key: 'to',
      options: nextProps.sites,
      defaultValue: search.to || ''
    }, {
      key: 'waybillNo',
      defaultValue: search.waybillNo || ''
    }, {
      key: 'signedType',
      defaultValue: search.signedType || ''
    }, {
      key: 'valueAddedService',
      defaultValue: search.valueAddedService ? search.valueAddedService.split(',') : []
    }, {
      key: 'mainBusiness',
      defaultValue: search.mainBusiness || ''
    }, {
      key: 'startCargoCompany',
      defaultValue: search.startCargoCompany || ''
    }, {
      key: 'receiveCargoCompany',
      defaultValue: search.receiveCargoCompany || ''
    }, {
      key: 'dispatchType',
      defaultValue: search.dispatchType || ''
    }, getRangepickerConfig(
      'stockTime',
      search,
      'putStartTime',
      'putEndTime'
    )];
    // rerender到站、发站select
    this.setState({
      render: render.rerender(searchBarConfig)
    });
  }

  handleSearch = (values) => {
    this.getListByValues({ ...values, pn: 1 });
  }
  // 分页查询
  handlePaginationSeach = (values) => {
    this.getListByValues(values);
  }

  // search bar值改变监听
  searchBarValuesChange = (values) => {
    this.updateSearch(values);
  }
  // 导出表单
  export = () => {
    exportTable({
      server: 'admin',
      url: '/web/m/stock/list/export',
      params: this.props.search
    });
  }
  // 转库操作
  handleEffect = async () => {
    const { dispatch, search } = this.props;
    const { waybillNo } = this.state;
    const stockStatus = search.stockType;
    const targetType = stockStatus === 'ABNORMAL' ? 'NORMAL' : 'ABNORMAL';
    await dispatch({ type: 'goodsStock/changeStock', payload: { targetType, waybillNo } });
    message.success('转库操作成功');
    this.getList();
  }

  render() {
    const { search, permission } = this.props;
    const extraFields = this.getExtraFields();
    const { modalVisible } = this.state;
    const stockStatus = search.stockType;
    const content = `是否将该运单转到${stockStatus === 'ABNORMAL' ? '正常' : '异常'}库`;
    return (
      <div>
        <BaseSearchBar
          baseItemLayout={baseItemLayout}
          render={this.state.render}
          onSearch={this.handleSearch}
          onValuesChange={this.searchBarValuesChange}
        />
        <div>
          <Row type="flex" justify="space-between">
            <Col className="arrive-namage-tool-bar">
              <Radio.Group onChange={this.handleStatusChange} value={search.stockType} buttonStyle="solid">
                <Radio.Button value="NORMAL">正常库区</Radio.Button>
                <Radio.Button value="ABNORMAL">异常库区</Radio.Button>
              </Radio.Group>
            </Col>
            <Col>
              <div className="arrive-namage-tool-bar">
                <AuthortyWarpper code={permission.stock.export}>
                  <Button
                    onClick={this.export}
                    style={{ margin: '0 20px' }}
                  >
                    导出表单
                  </Button>
                </AuthortyWarpper>
              </div>
            </Col>
          </Row>
          <BaseHTable
            extraFields={extraFields}
            scrollX={4110}
            onPaginationSearch={this.handlePaginationSeach}
            {...this.props}
          />
          <HModal
            title="转库确认"
            visible={modalVisible}
            onOk={this.handleEffect}
            centered
          >
            {content}
          </HModal>
        </div>
      </div>
    );
  }
}

export default ArriveStock;
