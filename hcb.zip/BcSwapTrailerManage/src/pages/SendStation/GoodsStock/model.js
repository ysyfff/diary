import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE, boxType, transform2Object } from 'configs/constants';
import { tableFields } from './fields';
import { getList, getSites, changeStock } from './services';

const BoxType = transform2Object(boxType);
const initalSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  mainBusiness: '',
  waybillNo: '',
  putStartTime: '',
  putEndTime: '',
  valueAddedService: '',
  signedType: '',
  from: '',
  to: '',
  startCargoCompany: '',
  receiveCargoCompany: '',
  dispatchType: '',
  stockType: 'NORMAL'
};

export default Model.extend({
  namespace: 'goodsStock',
  state: {
    tableFields,
    sites: [],
    loading: { goodsStock: false },
    search: initalSearch,
    list: [],
    total: 0
  },
  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ goodsStock }) => goodsStock);
      const { datas, tc } = yield call(withLoading(getList, 'goodsStock'), search);
      const transformDatas = (datas || []).map((data) => {
        const { cargoList } = data;
        const cargoName = [];
        const cargoPackage = [];
        (cargoList || []).forEach((cargo) => {
          if (cargo.cargoName) cargoName.push(cargo.cargoName);
          if (cargo.cargoPackage) cargoPackage.push(BoxType[cargo.cargoPackage]);
        });
        data.cargoName = cargoName.length === 0 ? '--' : cargoName.join('/');
        data.cargoPackage = cargoPackage.length === 0 ? '--' : cargoPackage.join('/');
        return data;
      });
      yield update({ list: transformDatas, total: tc });
    },
    * getSites({ payload }, { call, update }) {
      const { datas = [] } = yield call(getSites, payload);
      let sites = datas.map((data) => {
        const { name, id } = data;
        return { key: name, value: id };
      });
      sites = [{ key: '全部', value: '' }].concat(sites);
      yield update({ sites });
    },
    * changeStock({ payload }, { call }) {
      yield call(changeStock, payload);
    }
  },
  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    initalSearch(state, { payload }) {
      return {
        ...state,
        search: {
          pn: 1,
          ps: PAGE_SIZE,
          waybillNo: '',
          putStartTime: '',
          putEndTime: '',
          from: '',
          to: '',
          stockType: 'NORMAL'
        }
      };
    }
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.GOODS_STOCK, () => {
        dispatch({
          type: 'global/changeSearch',
          payload: {
            action: { type: 'goodsStock/initalSearch' },
            noClearSearchPaths: [
              'waybillManage/detailWaybill'
            ]
          }
        });
        dispatch({ type: 'getList' });
      });
    }
  },
});
