import { Button, Form, Input, Select, DatePicker } from 'antd';
import { bind } from 'bind-decorator';
// import moment from 'moment';
import { STOWAGE_TYPE } from 'configs/maps';
import { downFile } from 'utils/downloadFile';
import _ from 'lodash';
import { exportStowage } from './services';

const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;

class SearchBar extends React.Component {
  state = {
    endValue: null
  }

  componentDidMount() {
    this.props.onRef(this);
  }

  @bind
  disabledStartDate(startValue) {
    const endValue = this.state.endValue;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }

  // 重置
  @bind
  handleReset() {
    const { resetSearch, getList } = this.props;
    resetSearch();
    getList();
  }

  @bind
  exportStowage() {
    const { search } = this.props;
    delete search.rangeTime;
    downFile({ server: 'dapt', url: exportStowage(), params: search });
  }

  // 查询
  handleSearch = () => {
    const { onSearch, search } = this.props;
    const _search = _.cloneDeep(search);
    const rangeTime = search.rangeTime.length > 0 ?
      _search.rangeTime.map((i, index) => i.format('YYYY-MM-DD HH:mm:ss', index === 0)) : [];
    _search.startTime = rangeTime[0];
    _search.endTime = rangeTime[1];
    delete _search.rangeTime;
    onSearch({ ..._search, pn: 1 });
  }

  handleChange = (e, key) => {
    const { updateSearch } = this.props;
    const value = e.target.value;
    updateSearch({ [key]: value });
  }

  handleChangeRadio = (value, key) => {
    const { updateSearch } = this.props;
    updateSearch({ [key]: value });
  }

  render() {
    const { siteList, search, siteLineList } = this.props;
    const sites = [];
    const stowageType = [];
    (siteList || []).forEach(item =>
      sites.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    const _siteLineList = [];
    (siteLineList || []).forEach(item =>
      _siteLineList.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    // 主营服务
    STOWAGE_TYPE.forEach((item) => {
      stowageType.push(<Option value={item.key} key={item.key}>{item.name}</Option>);
    });

    return (
      <div>
        <div className="searchBar">
          <Form layout="inline" >
            <FormItem label="配载单号">
              <Input
                placeholder="输入配载单号查询"
                value={search.stowageNo}
                onChange={e => this.handleChange(e, 'stowageNo')}
                style={{ width: 180 }}
              />
            </FormItem>
            <FormItem label="行驶线路">
              <Select
                showSearch
                placeholder="请选择行驶线路"
                value={search.siteLineId}
                onChange={value => this.handleChangeRadio(value, 'siteLineId')}
                style={{ width: 180 }}
              >
                <Option value="" key="ALL">全部</Option>
                {_siteLineList}
              </Select>
            </FormItem>
            <FormItem label="发站">
              <Select
                showSearch
                placeholder="发站"
                value={search.fromSiteId}
                onChange={value => this.handleChangeRadio(value, 'fromSiteId')}
                style={{ width: 180 }}
              >
                <Option value="" key="ALL">全部</Option>
                {sites}
              </Select>
            </FormItem>
            <FormItem label="主营服务">
              <Select
                showSearch
                placeholder="请选择主营服务"
                value={search.type}
                onChange={value => this.handleChangeRadio(value, 'type')}
                style={{ width: 180 }}
              >
                <Option value="" key="ALL">全部</Option>
                {stowageType}
              </Select>
            </FormItem>
            <FormItem label="运单号">
              <Input
                placeholder="输入运单号查询"
                value={search.waybillNo}
                onChange={e => this.handleChange(e, 'waybillNo')}
                style={{ width: 180 }}
              />
            </FormItem>
            <FormItem label="挂车车牌">
              <Input
                placeholder="输入挂车车牌号码查询"
                value={search.trailerPlateNumber}
                onChange={e => this.handleChange(e, 'trailerPlateNumber')}
                style={{ width: 180 }}
              />
            </FormItem>
            <FormItem label="到站">
              <Select
                showSearch
                placeholder="发站"
                value={search.toSiteId}
                onChange={value => this.handleChangeRadio(value, 'toSiteId')}
                style={{ width: 180 }}
              >
                <Option value="" key="ALL">全部</Option>
                {sites}
              </Select>
            </FormItem>
            <FormItem label="下单时间">
              <RangePicker
                value={search.rangeTime}
                showTime={{ format: 'HH:mm' }}
                format="MM-DD HH:mm"
                onChange={value => this.handleChangeRadio(value, 'rangeTime')}
              />
            </FormItem>
            <FormItem label="">
              <Button type="primary" onClick={this.handleSearch}>查询</Button>
              <Button onClick={this.handleReset}>重置</Button>
            </FormItem>
          </Form>
        </div>
      </div>
    );
  }
}

export default Form.create()(SearchBar);
