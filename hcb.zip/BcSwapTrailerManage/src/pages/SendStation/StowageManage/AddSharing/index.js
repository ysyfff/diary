import { connect } from 'dva';
import NP from 'number-precision';
// import _ from 'lodash';
import { Form, Button, Row, Modal, Input } from 'antd';
import styles from './index.less';
import BaseInfo from '../components/BaseInfo';
import StowageRate from '../components/StowageRate/StowageRate';
import WaybillTables from '../components/WaybillTables/WaybillTables';
import SplitModal from '../components/SplitModal/SplitModal';

@connect(({ addSharing }) => ({ ...addSharing }), dispatch => ({
  createStowage(param) {
    dispatch({ type: 'addSharing/createStowage', payload: param });
  },
  getStowageList(param) {
    dispatch({ type: 'addSharing/getStowageList', payload: param });
  },
  getSiteLineList(param) {
    dispatch({ type: 'addSharing/getSiteLineList', payload: param });
  },
  getSiteList(param) {
    dispatch({ type: 'addSharing/getSiteList', payload: param });
  },
  getCompartmentList(param) {
    dispatch({ type: 'addSharing/getCompartmentList', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'addSharing/updateState', payload: param });
  },
  getStowageSplitInfo(param) {
    dispatch({ type: 'addSharing/getStowageSplitInfo', payload: param });
  },
  dispatch,
}))
class AddSharingStowage extends React.Component {
  state = {
    splitType: 'PACKAGE',
    selected: [],
    nowSplitIndex: 0, // 当前拆单的运单序号，方便回写
    waybillNo: '', // 当前拆单的运单号
    sheetNo: '',
    hasSplit: false, // 当前所拆运单是否已经拆过
    isShowSplitModal: false,
    splitedWaybills: [], // 所有子单栈存
    nowSplitList: [] // 保存拆单时当前拆单的数据
  }

  componentWillReceiveProps = (nextProps) => {
    const { splitedWaybills, hasSplit, waybillNo } = this.state;
    const { currentSplitList = [] } = nextProps;
    if (hasSplit) {
      const list = splitedWaybills.filter(item => item.waybillNo === waybillNo) || [];
      this.setState({ // 已经拆过单的运单，直接从保存的子单数据中获取当前拆单数据
        splitType: list[0].splitType || 'PACKAGE',
        nowSplitList: list
      });
    } else {
      const _currentSplitList = currentSplitList === null ? [] : currentSplitList.slice();
      if (!_currentSplitList.length) _currentSplitList.push({ packages: 0 });
      this.setState({
        splitType: _currentSplitList[0].splitType || 'PACKAGE',
        nowSplitList: _currentSplitList // 未拆单的运单，从数据源中获取最新数据
      });
    }
  }

  onSelectFieldChange = (value, field) => {
    const { nowStowage, updateState } = this.props;
    const { stowage } = nowStowage;
    const _stowage = { ...stowage };

    if (field === 'remark') _stowage.remark = value;
    updateState({
      nowStowage: {
        ...nowStowage,
        stowage: _stowage
      }
    });
  }

  onCancelAdd = () => {
    window.location.hash = '#/sendStation/stowageManage';
  }

  onSaveStowage = async () => {
    const { nowStowage } = this.props;
    const { splitCargoList } = nowStowage;

    if (!splitCargoList.length) {
      Modal.error({ title: '至少选择一个运单' });
      return;
    }

    // 检查分摊费用是否达标
    const flag = this.checkFieightOk();
    if (!flag) {
      Modal.confirm({
        title: '提示',
        content: '已配载运单的运费并未达到该线路的最低运费要求，是否仍然继续？',
        okText: '确认继续',
        cancelText: '取消',
        onOk: async () => {
          this.createStowage();
        }
      });
    } else {
      this.createStowage();
    }
  }

  writeBackLoadRemark = () => {
    const { nowStowage } = this.props;
    const { splitedWaybills } = this.state;
    const { splitCargoList } = nowStowage;
    const _splitedWaybills = splitedWaybills.slice();

    splitCargoList.forEach((a) => {
      splitedWaybills.forEach((b, i) => {
        if (a.waybillNo === b.waybillNo) {
          _splitedWaybills[i].remark = a.loadRemark;
        }
      });
    });

    return new Promise((resolve) => {
      this.setState({
        splitedWaybills: _splitedWaybills
      }, () => {
        resolve();
      });
    });
  }

  createStowage = async () => {
    const { nowStowage } = this.props;
    const { createStowage } = this.props;
    const { splitedWaybills } = this.state;
    const { stowage } = nowStowage;
    const noneSplitWaybills = this.joinNoSplitWaybill(); // 先将未进行拆单的运单拆分成子单

    // 分写装车备注
    await this.writeBackLoadRemark();

    const params = {
      type: stowage.type,
      siteLineId: stowage.siteLineId,
      trailerId: stowage.trailerId,
      trailerPlateNumber: stowage.trailerPlateNumber,
      remark: stowage.remark,
      stowageNo: stowage.stowageNo,
      waybillList: splitedWaybills.concat(noneSplitWaybills)
    };

    const _params = JSON.parse(JSON.stringify(params));
    createStowage(_params);
  }

  // 用来判断配载价格是否低于最低价格
  checkFieightOk = () => {
    const { siteLineList = [], nowStowage = {} } = this.props;
    const { stowage = {}, splitCargoList } = nowStowage;
    const { siteLineId = '' } = stowage;
    let siteLine = {};
    let minPrice = 0;
    let loadPrice = 0;

    siteLine = siteLineList.filter(item => item.id === siteLineId)[0] || {};
    minPrice = siteLine.minPrice || 0;

    splitCargoList.length && splitCargoList.forEach((item) => {
      loadPrice = NP.plus(Number(loadPrice), Number(item.cargoResidualFreight));
    });

    if (loadPrice < minPrice) return false;
    return true;
  }

  // 保存时，将未拆单的运单拆分成子单
  joinNoSplitWaybill = () => {
    // const { splitedWaybills } = this.state;
    const { nowStowage } = this.props;
    const { splitCargoList } = nowStowage;
    const _splitedWaybills = []; // 保存未拆过单的运单分离后的子单

    splitCargoList.forEach((a) => {
      if (!a.hasSplit) {
        a.cargoList.forEach((item) => {
          if (item.cargoResidualPiece !== 0) { // 去除件数为0的货物
            const obj = {
              waybillNo: item.waybillNo,
              waybillCargoId: item.id,
              packageNumber: item.cargoResidualPiece,
              weight: item.cargoResidualWeight.toFixed(2),
              cubage: item.cargoResidualVolume.toFixed(2),
              remark: a.loadRemark || '' // 配载备注都是一样的
            };
            _splitedWaybills.push(obj);
          }
        });
      }
    });

    // _splitedWaybills = _splitedWaybills.concat(splitedWaybills);
    // 如果保存出错的话，会二次push，这个时候就需要去除重复的数据
    // _splitedWaybills = _.unionBy(_splitedWaybills, 'waybillCargoId');

    // return new Promise((resolve) => {
    //   this.setState({
    //     splitedWaybills: _splitedWaybills
    //   }, () => {
    //     resolve(); // setState之后在返回，保证下次获取值时是更新之后的
    //   });
    // });

    return _splitedWaybills;
  }

  updateParentState = (state) => {
    state && this.setState({ ...state });
  }

  cancelShowRemarkModal = () => {
    this.setState({
      isShowRemarkModal: false
    });
  }

  cancelSplitModal = () => {
    const { updateState } = this.props;
    this.setState({
      nowSplitList: [],
      hasSplit: false,
      isShowSplitModal: false,
      selected: []
    }, () => {
      updateState({ leftStowageList: [], currentSplitList: [], existSplitInfos: [] });
    });
  }

  render() {
    const {
      siteLineList, getSiteLineList, compartmentList, loading, updateState, existSplitInfos,
      siteList, nowStowage, getStowageList, getStowageSplitInfo, leftWaybillList, getCompartmentList,
      stowageList, getSiteList
    } = this.props;
    const { stowage = {}, splitCargoList = [] } = nowStowage;
    const {
      isShowSplitModal, splitedWaybills, nowSplitList, hasSplit, nowSplitIndex, waybillNo, selected, splitType,
      sheetNo
    } = this.state;

    const baseInfoProps = {
      siteLineList,
      compartmentList,
      stowage,
      nowStowage,
      BaseInfoRef: this.BaseInfoRef,
      isAdd: true,
      updateState,
      getSiteLineList,
      getCompartmentList
    };

    const stowageRateProps = {
      stowage,
      compartmentList,
      splitCargoList,
      siteLineList
      // trailerId: stowage.trailerId
    };

    const waybillTablesProps = {
      siteList,
      loading,
      stowage,
      nowStowage,
      getStowageList,
      getStowageSplitInfo,
      updateParentState: this.updateParentState,
      stowageList,
      splitCargoList,
      updateState,
      getSiteList,
      splitedWaybills,
      mainBusiness: 'CHANNELSERVICE'
    };

    const splitModalProps = {
      splitType,
      selected,
      updateParentState: this.updateParentState,
      nowSplitIndex,
      nowStowage,
      waybillNo,
      sheetNo,
      loading,
      hasSplit,
      leftWaybillList,
      existSplitInfos,
      nowSplitList,
      isShowSplitModal,
      updateState,
      splitedWaybills,
      cancelSplitModal: this.cancelSplitModal,
      onSplitOk: this.onSplitOk,
      isAdd: true
    };

    return (
      <div className={styles['add-stowage']}>
        <BaseInfo wrappedComponentRef={m => this.BaseInfoRef = m} {...baseInfoProps} /> {/* 基本信息 */}
        <WaybillTables {...waybillTablesProps} /> {/* 选择运单 */}
        <div style={{ overflow: 'hidden', width: '100%' }}>
          <StowageRate {...stowageRateProps} /> {/* 计算配载率 */}
        </div>
        <div style={{ marginTop: 20, display: 'flex' }}>
          <div style={{ width: 70, lineHeight: 2 }}>备注信息：</div>
          <Input
            className="textArea"
            placeholder="请输入备注信息"
            value={(nowStowage.stowage && nowStowage.stowage.remark) || ''}
            onChange={e => this.onSelectFieldChange(e.target.value, 'remark')}
            style={{ flex: 1 }}
            maxLength={200}
          />
        </div>
        <Row className="save-btns">
          <Button type="primary" onClick={this.onSaveStowage}>保存</Button>
          <Button style={{ marginLeft: 20 }} onClick={this.onCancelAdd}>取消</Button>
        </Row>
        <SplitModal {...splitModalProps} /> {/* 拆单 */}
      </div>
    );
  }
}

export default Form.create()(AddSharingStowage);
