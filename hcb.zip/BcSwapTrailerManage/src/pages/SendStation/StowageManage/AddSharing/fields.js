import { sendWays } from 'configs/constants';
import { stowageStatus } from 'configs/maps';
import { formatValue, defaultKey } from 'utils/formatValue';

export const tableFields = [{
  key: 'sequence',
  name: '序号',
  width: 60,
  render: (a, b, i) => i + 1
}, {
  key: 'sheetNo',
  name: '运单号',
  width: 80,
  render: (a, b) => <a href={`#/waybillManage/detailWaybill/${b.waybillNo}`}>{a}</a>
}, {
  key: 'putDayNum',
  name: '库存时间',
  width: 80,
  render: (a) => {
    if (a < 24 && a > 12) return <span style={{ color: '#faad14' }}>{`${a}小时`}</span>;
    if (a >= 24) return <span style={{ color: 'red' }}>{`${a}小时`}</span>;
    return `${a}小时`;
  }
}, {
  key: 'dispatchType',
  name: '派件方式',
  width: 50,
  render: a => a && sendWays.filter(item => item.key === a)[0].value
}, {
  key: 'toSite',
  name: '到站',
  width: 120,
  render: formatValue
}, {
  key: 'cargoNames',
  name: '货名',
  width: 120,
  render: a => a || defaultKey
},
// const names = [];
// b.cargoList.forEach(item => names.push(item.cargoName));
// return names.join(' / ');
{
  key: 'cargoResidualPiece',
  name: '可装车件数',
  width: 60,
  render: formatValue
}, {
  key: 'cargoResidualWeight',
  name: '可装车重量',
  width: 60,
  render: formatValue
}, {
  key: 'cargoResidualVolume',
  name: '可装车体积',
  width: 60,
  render: formatValue
}, {
  key: 'packs',
  name: '包装',
  width: 60,
  render: a => a || defaultKey
},
// , {
//   key: 'cargoPackage',
//   name: '包装',
//   render: (a, b) => {
//     const names = [];
//     b.cargoList.forEach((_item) => {
//       const name = boxType.filter(item => item.key === _item.cargoPackage)[0].value;
//       names.push(name);
//     });
//     return names.join(' / ');
//   }
// },
{
  key: 'remark',
  name: '运单备注',
  // width: 120,
  render: formatValue
}];

// 原始运单数据
export const splitWaybill = [{
  key: 'cargoName',
  name: '货物品名',
  render: formatValue
}, {
  key: 'cargoPiece',
  name: '总件数',
  render: formatValue
}, {
  key: 'cargoWeight',
  name: '总重量（千克）',
  render: formatValue
}, {
  key: 'cargoVolume',
  name: '总体积（方）',
  render: formatValue
}];

// 已有拆单
export const existWaybill = [{
  key: 'splitNo',
  name: '子运单号',
  render: a => a || defaultKey
}, {
  key: 'stowageNo',
  name: '配载单号',
  render: formatValue
}, {
  key: 'stowageStatus',
  name: '配载状态',
  render: (a) => {
    if (!a) return defaultKey;
    return stowageStatus.filter(item => item.status === a)[0].name;
  }
}, {
  key: 'cargoName',
  name: '货物品名',
  render: formatValue
}, {
  key: 'packages',
  name: '件数（件）',
  render: formatValue
}, {
  key: 'weight',
  name: '重量（千克）',
  render: formatValue
}, {
  key: 'cubage',
  name: '体积（方）',
  render: formatValue
}];

// 当前拆单
export const nowSplitFields = [{
  key: 'splitNo',
  name: '子运单号',
  render: a => a || defaultKey
}, {
  key: 'stowageNo',
  name: '配载单号',
  render: formatValue
}, {
  key: 'splitStatus',
  name: '配载状态',
  render: () => '装载中'
}];
