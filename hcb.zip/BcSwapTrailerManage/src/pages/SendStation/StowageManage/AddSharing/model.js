import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
import { tableFields, splitWaybill, existWaybill, nowSplitFields } from './fields';
import {
  getSiteLineList, getCompartmentList, getStowageList, createStowage, getSiteList, getStowageSplitInfo
} from './services';

export default Model.extend({
  namespace: 'addSharing',

  state: {
    list: [],
    loading: { list: false },
    tableFields,
    splitWaybill,
    existWaybill,
    nowSplitFields,
    siteLineList: [],
    compartmentList: [],
    stowageList: [],
    leftWaybillList: [],
    siteList: [],
    existSplitInfos: [],
    nowStowage: {
      splitCargoList: [],
      stowage: {
        type: 'CHANNELSERVICE',
        compartmentId: ''
      }
    },
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.ADD_SHARING, () => {
        dispatch({ type: 'getSiteLineList', payload: { ps: 1000, pn: 1 } });
        dispatch({ type: 'getSiteList', payload: { ps: 1000, pn: 1 } });
        dispatch({ type: 'getCompartmentList', payload: { ps: 1000, pn: 1, effective: 1 } });
        dispatch({ type: 'getStowageList', payload: { ps: 100, pn: 1, mainBusiness: 'CHANNELSERVICE' } });
        dispatch({ type: 'resetNowStowage' });
      });
    }
  },

  effects: {
    * getSiteLineList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getSiteLineList, 'list'), payload);
      yield update({ siteLineList: datas });
    },
    * getSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getSiteList, 'list'), payload);
      yield update({ siteList: datas });
    },
    * getCompartmentList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getCompartmentList, 'list'), payload);
      yield update({ compartmentList: datas });
    },
    * getStowageList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getStowageList, 'list'), { ...payload, ps: 100, pn: 1 });
      yield update({ stowageList: datas });
    },
    * createStowage({ payload }, { call }) {
      yield call(withLoading(createStowage, 'list', '创建成功'), payload);
      window.location.hash = '#/sendStation/stowageManage';
    },
    * getStowageSplitInfo({ payload }, { call, update }) {
      const splitInfos = yield call(withLoading(getStowageSplitInfo, 'list'), payload);
      yield update({ leftWaybillList: splitInfos.stockCargos, existSplitInfos: splitInfos.splitedList });
    }
  },

  reducers: {
    updateStowageList(state, { payload }) {
      return {
        ...state,
        stowageList: payload
      };
    },
    resetNowStowage(state, { payload }) {
      return {
        ...state,
        nowStowage: {
          splitCargoList: [],
          stowage: {
            type: 'CHANNELSERVICE',
            compartmentId: ''
          }
        }
      };
    }
  }
});
