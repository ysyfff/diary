import { stowageStatus, STOWAGE_TYPE } from 'configs/maps';
import { Popover } from 'antd';
import moment from 'moment';

const defultKey = '--';

const formatValue = (value) => {
  if (value !== '' && value !== undefined && value !== null) {
    if (value.length > 14) {
      return (
        <Popover content={value}>
          <span>{`${value.substr(0, 14)}...`}</span>
        </Popover>
      );
    }
    return value;
  }
  return defultKey;
};

export const tableFields = [{
  key: 'sequence',
  name: '序号',
  width: 60,
  render: (a, b, i) => i + 1
}, {
  key: 'stowageNo',
  name: '配载单号',
  width: 200,
  render: stowageNo => <a
    href={`#/sendStation/stowageManage/stowageDetail/${stowageNo}`}
    rel="noopener noreferrer"
    target="_blank"
  >{stowageNo}</a>
}, {
  key: 'status',
  name: '状态',
  render: (a) => {
    const status = stowageStatus.filter(item => item.status === a);
    if (status.length === 0) return '未知';
    if (a.indexOf('LOADING') > -1) {
      return <span style={{ color: 'green' }}>{status[0].name}</span>;
    }
    return status[0].name;
  }
}, {
  key: 'trailerPlateNumber',
  name: '挂车车牌',
  render: formatValue
}, {
  key: 'type',
  name: '主营服务',
  render: a => STOWAGE_TYPE.filter(item => item.key === a)[0].name
}, {
  key: 'siteLineCode',
  name: '行驶线路'
}, {
  key: 'totalNumber',
  name: '总单数',
  render: formatValue
}, {
  key: 'totalPackages',
  name: '总件数',
  render: formatValue
}, {
  key: 'totalWeight',
  name: '总重量（千克）',
  render: (a) => {
    if (!a || a === null) return defultKey;
    if (a / 1000 < 30) return <span style={{ color: 'red' }}>{a}</span>;
    return formatValue(a);
  }
}, {
  key: 'totalCubage',
  name: '总体积（方）',
  render: (a) => {
    if (!a || a === null) return defultKey;
    if (a < 120) return <span style={{ color: 'red' }}>{a}</span>;
    return formatValue(a);
  }
}, {
  key: 'totalFreight',
  name: '总运费（元）',
  render: formatValue
}, {
  key: 'loadUtilizationRatio',
  name: '载重利用率',
  render: (a, b) => {
    if (!a) return defultKey;
    if (b.totalWeight / 1000 < 30) return <span style={{ color: 'red' }}>{a}%</span>;
    return `${a}%`;
  }
}, {
  key: 'spaceUtilizationRatio',
  name: '空间利用率',
  render: (a, b) => {
    if (!a) return defultKey;
    if (b.totalCubage < 120) return <span style={{ color: 'red' }}>{a}%</span>;
    return `${a}%`;
  }
}, {
  key: 'sealNo',
  name: '封签号',
  render: formatValue
}, {
  key: 'createTime',
  name: '下单时间',
  render: a => moment(a).format('MM-DD HH:mm')
}, {
  key: 'remark',
  name: '配载备注',
  render: formatValue
}];

export const searchFields = [{
  key: 'oilTypeId',
  name: '创建时间',
  render: a => a || defultKey
}, {
  key: 'oilNumId',
  name: '配载单号',
}, {
  key: 'oilSpecId',
  name: '挂车车牌',
}, {
  key: 'time',
  name: '行驶路线',
  type: 'dateRange',
}];

export const stowageNoFields = [{
  key: 'stowageNo',
  name: '封签号'
}];

export const descriptionFields = [
  {
    key: 'stowageNo',
    name: '配载单号'
  },
  {
    key: 'stowageNo',
    name: '发车时间',
    render: a => a || defultKey
  },
  {
    key: 'trailerPlateNumber',
    name: '挂车车牌'
  },
  {
    key: 'toSiteName',
    name: '到站'
  },
];
