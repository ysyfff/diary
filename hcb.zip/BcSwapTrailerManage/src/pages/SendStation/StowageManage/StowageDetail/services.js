import http from 'utils/http';

const { post } = http.create('dapt');

// 查询配载单
export function getStowageInfo(params) {
  return post('/web/m/stowage/info', params);
}

// 线路查询
export function getSiteLineInfo(params) {
  return post('/web/m/siteline/get', params);
}
