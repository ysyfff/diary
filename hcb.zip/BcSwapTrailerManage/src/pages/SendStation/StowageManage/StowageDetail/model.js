import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
import { tableFields } from './fields';
import { getStowageInfo, getSiteLineInfo } from './services';


export default Model.extend({
  namespace: 'stowageDetail',

  state: {
    loading: { spin: false },
    // descriptionFields,
    tableFields,
    stowageDetail: {},
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.STOWAGE_MANAGE_DETAIL, ({ params }) => {
        const stowageNo = params[0];
        dispatch({ type: 'getStowageInfo', payload: { stowageNo } });
      });
    }
  },

  effects: {
    // 获取账户信息
    * getStowageInfo({ payload }, { call, update, put }) {
      const stowageDetail = yield call(withLoading(getStowageInfo), payload);
      yield update({ stowageDetail });
      yield put({ type: 'getSiteLineInfo', payload: { id: stowageDetail.stowage.siteLineId } });
    },
    * getSiteLineInfo({ payload }, { call, update, select }) {
      const { stowageDetail } = yield select(({ stowageDetail }) => stowageDetail);
      const info = yield call(withLoading(getSiteLineInfo), payload);
      const _stowageDetail = JSON.parse(JSON.stringify(stowageDetail));
      _stowageDetail.startSiteName = info.startSiteName;
      _stowageDetail.endSiteName = info.endSiteName;
      _stowageDetail.minPrice = info.minPrice;
      yield update({ stowageDetail: _stowageDetail });
    }
  },

  reducers: {}
});
