import { sendWays, boxType } from 'configs/constants';
import moment from 'moment';
import { formatValue } from 'utils/formatValue';

export const tableFields = [{
  key: 'sequence',
  name: '序号',
  render: (a, b, i) => i + 1
}, {
  key: 'splitNo',
  name: '运单号',
  render: (a, b) => {
    if (b.isSplit === '1' || b.isSplit === 1) {
      return <a href={`#/waybillManage/detailWaybill/${b.waybillNo}`} >{a}</a>;
    }
    return <a href={`#/waybillManage/detailWaybill/${b.waybillNo}`} >{b.sheetNo}</a>;
  }
}, {
  key: 'waybillCreateTime',
  name: '开单时间',
  render: (a, b) => moment(b.waybillDetailDTO && b.waybillDetailDTO.waybillCreateTime).format('MM-DD HH:mm')
}, {
  key: 'dispatchType',
  name: '派件方式',
  render: (a, b) => sendWays.filter(item => item.key === b.waybillDetailDTO.dispatchType)[0].value
}, {
  key: 'fromSiteName',
  name: '发站',
  render: (a, b) => b.waybillDetailDTO.fromSiteName
}, {
  key: 'toSiteName',
  name: '到站',
  render: (a, b) => b.waybillDetailDTO.toSiteName
}, {
  key: 'cargoName',
  name: '货名',
  render: formatValue
}, {
  key: 'packages',
  name: '装车件数',
  render: formatValue
}, {
  key: 'weight',
  name: '装车重量',
  render: formatValue
}, {
  key: 'cubage',
  name: '装车体积',
  render: formatValue
}, {
  key: 'freight',
  name: '分摊运费',
  render: formatValue
}, {
  key: 'packs',
  name: '包装',
  render: (a, b) => boxType.filter(item => item.key === b.stockCargo.cargoPackage)[0].value
}, {
  key: 'waybillRemark',
  name: '运单备注',
  render: (a, b) => formatValue(b.waybillDetailDTO.remarks)
}, {
  key: 'remark',
  name: '装车备注',
  render: formatValue
}];
