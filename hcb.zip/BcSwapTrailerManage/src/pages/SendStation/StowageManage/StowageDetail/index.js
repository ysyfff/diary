import { connect } from 'dva';
import { HTable } from 'carno';
import { stowageStatus } from 'configs/maps';
import { mainType } from 'configs/constants';
import styles from './index.less';

@connect(({ stowageDetail }) => ({ ...stowageDetail }))
export default class StowageDetail extends React.Component {
  render() {
    const { stowageDetail, tableFields } = this.props;
    const { splitList = [], stowage = {} } = stowageDetail;
    const _status = stowage.status ? stowageStatus.filter(item => item.status === stowage.status)[0].name : '';

    const tableProps = {
      fields: tableFields,
      search: { pn: 1, ps: 100000 },
      pagination: false,
      dataSource: splitList
    };

    const type = stowage.type ? mainType.filter(item => item.key === stowage.type)[0].value : '';

    return (
      <div className={styles['stowage-detail']}>
        <div className="title">
          <div>
            <span className="normal-label">主营服务：</span>{ type }
          </div>
          <div>
            <span>配载单号：</span>
            <span className="stowageNo">{stowage.stowageNo}</span>
            <span className="normal-label">状态：</span>
            {
              stowage.status === 'CARLOAD_LOADING'
                ? <span style={{ color: 'green' }}>{ _status }</span>
                : <span>{ _status }</span>
            }
          </div>
        </div>
        <div className="part">
          <h2>基本信息</h2>
          <table className="base-info">
            <tbody>
              <tr>
                <td className="normal-label">发车线路：</td>
                <td>{stowageDetail.startSiteName} - {stowageDetail.endSiteName}</td>
                <td className="normal-label">挂车车牌：</td><td className="bold-text">{stowage.trailerPlateNumber}</td>
              </tr>
              <tr>
                {
                  stowage.status === 'CARLOAD_LOADED'
                  || stowage.status === 'CARPOOL_LOADED'
                  || stowage.status === 'LOADED'
                  || stowage.status === 'IN_TRANSIT'
                  || stowage.status === 'DISPATCHED'
                  || stowage.status === 'ARRIVED'
                    ? <td className="normal-label">封签号：</td>
                    : null
                }
                {
                  stowage.status === 'CARLOAD_LOADED'
                  || stowage.status === 'CARPOOL_LOADED'
                  || stowage.status === 'LOADED'
                  || stowage.status === 'IN_TRANSIT'
                  || stowage.status === 'DISPATCHED'
                  || stowage.status === 'ARRIVED'
                    ? <td>{stowage.sealNo}</td>
                    : null
                }
                <td className="normal-label">配载备注：</td><td>{stowage.remark}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="part">
          <h2>装车清单</h2>
          <div className="info-list">
            <HTable
              {...tableProps}
              style={{ marginTop: 30 }}
            />
            {
              type === '整车服务'
                ? null
                :
                <table className="count">
                  <tbody>
                    <tr>
                      <td className="label">已配载重量</td><td>
                        {
                          stowage.totalWeight / 1000 < 30
                            ? <span style={{ color: 'red' }}>{stowage.totalWeight}千克</span>
                            : <span>{stowage.totalWeight}千克</span>
                        }
                      </td>
                      <td className="label">挂车载重</td><td>{stowage.trailerWeight}吨</td>
                      <td className="label">载重利用率</td><td>
                        {
                          stowage.totalWeight / 1000 < 30
                            ? <span style={{ color: 'red' }}>{stowage.loadUtilizationRatio}%</span>
                            : <span>{stowage.loadUtilizationRatio}%</span>
                        }
                      </td>
                    </tr>
                    <tr>
                      <td className="label">已配载体积</td><td>
                        {
                          stowage.totalCubage < 120
                            ? <span style={{ color: 'red' }}>{stowage.totalCubage}方</span>
                            : <span>{stowage.totalCubage}方</span>
                        }
                      </td>
                      <td className="label">挂车空间</td><td>{stowage.trailerCubage}方</td>
                      <td className="label">空间利用率</td><td>
                        {
                          stowage.totalCubage < 120
                            ? <span style={{ color: 'red' }}>{stowage.spaceUtilizationRatio}%</span>
                            : <span>{stowage.spaceUtilizationRatio}%</span>
                        }
                      </td>
                    </tr>
                    <tr>
                      {
                        stowage.type !== 'VEHICLESERVICE' ?
                          [
                            <td className="label" key="label1">已配载运费</td>,
                            <td key="value1">{
                              stowage.totalFreight < stowageDetail.minPrice ?
                                <span style={{ color: 'red' }}>{stowage.totalFreight}元</span>
                                : `${stowage.totalFreight}元`
                            }</td>,
                            <td className="label" key="label2">最低通道运费</td>,
                            <td key="value2">
                              {
                                stowageDetail.minPrice
                              }
                            </td>
                          ]
                          : [
                            <td className="label" key="label3">已配载运费</td>,
                            <td key="value3">{
                              `${stowage.totalFreight}元`
                            }</td>
                          ]
                      }
                    </tr>
                  </tbody>
                </table>
            }
          </div>
        </div>
      </div>
    );
  }
}
