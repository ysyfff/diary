import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';
import _ from 'lodash';

// import moment from 'moment';
import { tableFields, searchFields } from './fields';
import { getList, cancel, complete, enterSealNo, updateSealNo, fetchSiteList, getSiteLineList } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  waybillNo: '',
  fromSiteId: '',
  toSiteId: '',
  stowageNo: '',
  status: '',
  type: '',
  trailerPlateNumber: '',
  startTime: '',
  endTime: '',
  rangeTime: '',
  siteLineId: ''
};

export default Model.extend({
  namespace: 'stowageManage',

  state: {
    loading: { list: false },
    tableFields,
    searchFields,
    search: initialSearch,
    total: 0,
    list: [],
    completeLoadVisible: false,
    stowageNoVisible: false,
    description: {},
    siteList: [],
    siteLineList: []
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.STOWAGE_MANAGE, ({ query }) => {
        const { status, tab } = query;
        if (tab) {
          dispatch({ type: 'updateSearch', payload: { ...initialSearch, status } });
        } else {
          dispatch({ type: 'resetState' });
        }
        dispatch({ type: 'getList' });
        dispatch({ type: 'fetchSiteList' });
        dispatch({ type: 'getSiteLineList' });
      });
    }
  },

  effects: {
    * getList({ payload }, { call, update, select }) {
      const { search } = yield select(({ stowageManage }) => stowageManage);
      const _search = _.cloneDeep(search);
      delete _search.rangeTime;
      const { datas, tc } = yield call(withLoading(getList, 'list'), _search);
      yield update({ list: datas, total: tc });
    },
    * cancel({ payload }, { call, put }) {
      yield call(withLoading(cancel, 'list', '取消装载成功'), payload);
      yield put({ type: 'getList' });
    },
    * complete({ payload }, { call, put }) {
      yield call(withLoading(complete, 'list', '完成装车成功'), payload);
      yield put({ type: 'getList' });
    },
    * enterSealNo({ payload }, { call, put }) {
      yield call(withLoading(enterSealNo, 'list', '录入成功'), payload);
      yield put({ type: 'getList' });
    },
    * updateSealNo({ payload }, { call, put }) {
      yield call(withLoading(updateSealNo, 'list', '修改成功'), payload);
      yield put({ type: 'getList' });
    },
    * fetchSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(fetchSiteList, 'list'));
      yield update({ siteList: datas });
    },
    * getSiteLineList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getSiteLineList, 'truckSend'), { effective: 1 });
      yield update({ siteLineList: datas });
    },
  },

  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    resetSearch(state) {
      return {
        ...state,
        search: { ...state.search, ...initialSearch },
      };
    }
  }
});
