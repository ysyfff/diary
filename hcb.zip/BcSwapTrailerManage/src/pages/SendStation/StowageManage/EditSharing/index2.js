import { connect } from 'dva';
import { HTable } from 'carno';
import NP from 'number-precision';
import { boxType } from 'configs/constants';
import { formatValue, defaultKey } from 'utils/formatValue';
import _ from 'lodash';
import { Form, Input, Button, Row, Select, Radio, Checkbox, Modal, InputNumber } from 'antd';
import { STOWAGE_TYPE } from 'configs/maps';
import styles from './index.less';

const FormItem = Form.Item;
const { TextArea } = Input;
const Option = Select.Option;
const RadioGroup = Radio.Group;

@connect(({ editSharing }) => ({ ...editSharing }), dispatch => ({
  createStowage(param) {
    dispatch({ type: 'editSharing/createStowage', payload: param });
  },
  getStowageList(param) {
    dispatch({ type: 'editSharing/getStowageList', payload: param });
  },
  getStowageSplitInfo(param) {
    dispatch({ type: 'editSharing/getStowageSplitInfo', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'editSharing/updateState', payload: param });
  },
  dispatch,
}))
class EditSharingStowage extends React.Component {
  constructor(props) {
    super(props);
    const { compartmentList } = props;
    // let splitType = '';
    // if (props.currentSplitList[0] && props.currentSplitList[0].splitType) {
    //   if (props.currentSplitList[0].splitType === 'PACKAGE') {
    //     splitType = '0';
    //   } else if (props.currentSplitList[0].splitType === 'CUSTOM') {
    //     splitType = '1';
    //   } else {
    //     splitType = '0';
    //   }
    // }

    let truck = {};
    let truckLoad = 0;
    let truckVolumne = 0;
    let finishLoad = 0;
    let finishVolumne = 0;
    let loadPercent = 0;
    let volumnePercent = 0;

    truck = compartmentList.length && compartmentList.filter(item => item.id === props.nowStowage.stowage.trailerId)[0];
    truckLoad = truck.truckLoad;
    truckVolumne = truck.truckVolumne;
    finishLoad = props.nowStowage && props.nowStowage.splitCargoList
      && props.nowStowage.splitCargoList[0].cargoResidualWeight;
    finishVolumne = props.nowStowage && props.nowStowage.splitCargoList
      && props.nowStowage.splitCargoList[0].cargoResidualVolume;
    loadPercent = (finishLoad / truckLoad).toFixed(2) * 100;
    volumnePercent = (finishVolumne / truckVolumne).toFixed(2) * 100;

    this.state = {
      stowageList: [],
      selected: [],
      nowSplitWaybill: [],
      _nowSplitWaybill: [],
      splitType: '0',
      waybillSearchSiteId: '',
      waybillNo: '',
      splitWaybillNo: '',
      isShowSplitModal: false,
      nowSplitIndex: 0,
      stowage: {
        stowageNo: '',
        type: '',
        siteLineId: '',
        trailerId: '',
        remark: '',
        finishStowageList: ''
      },
      index: '',
      isShowRemarkModal: false,
      tmpRemark: '',
      finishOptions: {
        truckLoad, // 挂车载重
        truckVolumne, // 挂车空间
        finishLoad, // 已配载重量
        finishVolumne, // 已配载体积
        loadPercent, // 载重利用率
        volumnePercent, // 空间利用率
      }
    };
  }

  static getDerivedStateFromProps = (props, state) => {
    let stowageNo = '';
    let type = '';
    let siteLineId = '';
    let trailerId = '';
    let remark = state.stowage.remark;
    let finishStowageList = state.stowage.finishStowageList;
    let stowageList = state.stowageList;
    let nowSplitWaybill = state.nowSplitWaybill;
    const _nowSplitWaybill = state._nowSplitWaybill;
    if (props.nowStowage.stowage && props.nowStowage.stowage.stowageNo) stowageNo = props.nowStowage.stowage.stowageNo;
    if (props.nowStowage.stowage && props.nowStowage.stowage.type) type = props.nowStowage.stowage.type;
    if (props.nowStowage.stowage && props.nowStowage.stowage.siteLineId) {
      siteLineId = props.nowStowage.stowage.siteLineId;
    }
    if (props.nowStowage.stowage && props.nowStowage.stowage.trailerId) trailerId = props.nowStowage.stowage.trailerId;
    if (remark === '') {
      if (props.nowStowage.stowage && props.nowStowage.stowage.remark) remark = props.nowStowage.stowage.remark;
    }
    if (!finishStowageList.length && props.nowStowage.splitCargoList) {
      finishStowageList = props.nowStowage.splitCargoList;
    }
    if (stowageList.length === 0) stowageList = props.stowageList;
    if (nowSplitWaybill.length === 0) nowSplitWaybill = props.leftStowageList;
    if (_nowSplitWaybill.length === 0) {
      props.currentSplitList.forEach((item) => {
        _nowSplitWaybill.push({
          splitNo: item.splitNo,
          stowageNo: item.stowageNo,
          splitStatus: '装载中',
          id: item.storageCargoId,
          cargoPiece: item.packages,
          cargoWeight: item.weight,
          cargoVolume: item.cubage
        });
      });
    }

    return {
      nowSplitWaybill,
      _nowSplitWaybill,
      stowageList,
      stowage: {
        stowageNo,
        type,
        siteLineId,
        trailerId,
        remark,
        finishStowageList,
      }
    };
  };

  onChangeWaybillSearch = (value, field) => {
    this.setState({
      [field]: value
    });
  }

  onWaybillSearch = () => {
    const { getStowageList } = this.props;
    const { waybillSearchSiteId, waybillNo } = this.state;
    getStowageList({ waybillNo, to: waybillSearchSiteId, mainBusiness: 'CHANNELSERVICE' });
  }

  onResetWaybillSearch = () => {
    this.setState({
      waybillNo: '',
      waybillSearchSiteId: ''
    });
  }

  onSelectFieldChange = (value, field) => {
    const { stowage } = this.state;
    const _stowage = _.cloneDeep(stowage);
    _stowage[field] = value;
    if (field === 'type' && value === 'VEHICLESERVICE') {
      window.location.hash = '#/sendStation/stowageManage/addStowage';
      return;
    }
    this.setState({
      stowage: _stowage
    });

    if (field === 'trailerId') {
      const { compartmentList } = this.props;
      const truck = compartmentList.filter(item => item.id === value)[0];
      const truckLoad = truck.truckLoad;
      const truckVolumne = truck.truckVolumne;
      const { finishOptions } = this.state;
      const _finishOptions = _.cloneDeep(finishOptions);
      _finishOptions.truckLoad = truckLoad;
      _finishOptions.truckVolumne = truckVolumne;
      // 计算载重利用率
      _finishOptions.loadPercent = (_finishOptions.finishLoad / _finishOptions.truckLoad).toFixed(2) * 100;
      _finishOptions.volumnePercent = (_finishOptions.finishVolumne / _finishOptions.truckVolumne).toFixed(2) * 100;

      this.setState({
        finishOptions: _finishOptions
      });
    }
  }

  onChangeStowage = (e, b, i) => {
    const { stowage, finishOptions, stowageList } = this.state;
    const { finishStowageList } = stowage;
    // const { dispatch } = this.props;
    const _stowage = _.cloneDeep(stowage);
    const _finishStowageList = _.cloneDeep(finishStowageList);
    const _finishOptions = _.cloneDeep(finishOptions);
    _finishStowageList.push(b);
    _finishOptions.finishLoad = b.cargoResidualWeight;
    _finishOptions.finishVolumne = b.cargoResidualVolume;
    // 计算载重利用率
    _finishOptions.loadPercent = (_finishOptions.finishLoad / _finishOptions.truckLoad).toFixed(2) * 100;
    _finishOptions.volumnePercent = (_finishOptions.finishVolumne / _finishOptions.truckVolumne).toFixed(2) * 100;

    _stowage.finishStowageList = _finishStowageList;
    const _stowageList = [...stowageList];
    // 禁用左边
    if (_stowageList[i]) _stowageList[i].disabled = true;
    if (e.target.checked) { // 增加右边
      // dispatch({
      //   type: 'editSharing/updateStowageList',
      //   payload: _stowageList
      // });
      this.setState({
        finishOptions: _finishOptions,
        stowage: _stowage,
        stowageList: _stowageList
      });
    }
  }

  onRemoveWaybill = (index, b) => {
    const { stowage, finishOptions, stowageList } = this.state;
    // const { dispatch } = this.props;
    const _stowage = _.cloneDeep(stowage);
    const _finishOptions = _.cloneDeep(finishOptions);
    _finishOptions.loadPercent = 0;
    _finishOptions.volumnePercent = 0;
    _finishOptions.finishLoad = 0;
    _finishOptions.finishVolumne = 0;
    _stowage.finishStowageList.splice(index, 1);
    // 启用左边
    let _stowageList = (stowageList === null) ? [] : [...stowageList];
    _stowageList = _stowageList.length && _stowageList.map((item) => {
      if (item.waybillNo === b.waybillNo) {
        return { ...item, disabled: false };
      }
      return item;
    });
    // dispatch({
    //   type: 'addSharing/updateStowageList',
    //   payload: _stowageList || []
    // });
    this.setState({
      finishOptions: _finishOptions,
      stowage: _stowage,
      stowageList: _stowageList
    });
  }

  onChangeRemark = (e) => {
    const tmpRemark = e.target.value;
    this.setState({
      tmpRemark
    });
  }

  onSaveStowage = () => {
    const { stowage } = this.state;
    const { createStowage } = this.props;
    const _stowage = JSON.parse(JSON.stringify(stowage));
    const _finishStowageList = _.cloneDeep(_stowage.finishStowageList);
    const params = {
      type: _stowage.type,
      siteLineId: _stowage.siteLineId,
      trailerId: _stowage.trailerId,
      trailerPlateNumber: _stowage.trailerPlateNumber,
      remark: _stowage.remark,
      waybillList: []
    };
    _finishStowageList.forEach((a) => {
      if (a.nowSplitWaybill) {
        a.nowSplitWaybill.forEach((b) => {
          let splitType = a.splitType;
          if (splitType === '0') splitType = 'PACKAGE';
          if (splitType === '1') splitType = 'CUSTOM';
          const obj = {
            waybillNo: a.waybillNo,
            waybillCargoId: b.id,
            packageNumber: b.cargoPiece,
            weight: b.cargoWeight ? b.cargoWeight : b.cargoPiece * b.pieceWeight,
            cubage: b.cargoVolume ? b.cargoVolume : b.cargoPiece * b.pieceVolume,
            remark: a.remark,
            isSplit: 1,
            splitType
          };
          params.waybillList.push(obj);
        });
      } else {
        a.cargoList.forEach((b) => {
          const obj = {
            waybillNo: a.waybillNo,
            waybillCargoId: b.id,
            packageNumber: b.cargoResidualPiece,
            weight: b.cargoResidualWeight,
            cubage: b.cargoResidualVolume,
            remark: a.remark
          };
          params.waybillList.push(obj);
        });
      }
    });
    const _params = JSON.parse(JSON.stringify(params));
    createStowage(_params);
  }

  onCancelAdd = () => {
    window.history.go(-1);
  }

  onSplitOk = () => {
    const { splitWaybillNo, _nowSplitWaybill, stowage, nowSplitWaybill } = this.state;
    const _stowage = _.cloneDeep(stowage);
    const { finishStowageList } = _stowage;
    const _finishStowageList = _.cloneDeep(finishStowageList);
    const names = [];
    let cargoWeight = 0;
    let cargoPiece = 0;
    let cargoVolume = 0;
    const packs = [];
    nowSplitWaybill.forEach((a) => {
      _nowSplitWaybill.forEach((b) => {
        if (a.id === b.id) {
          if (this.state.splitType === '0') {
            cargoVolume = NP.plus(cargoVolume, NP.times(Number(b.cargoPiece), b.pieceVolume));
            cargoWeight = NP.plus(cargoWeight, NP.times(Number(b.cargoPiece), b.pieceWeight));
          } else if (this.state.splitType === '1') {
            cargoVolume = NP.plus(cargoVolume, b.cargoVolume);
            cargoWeight = NP.plus(cargoWeight, b.cargoWeight);
          }
          cargoPiece += b.cargoPiece;
          names.push(a.cargoName);
          const pack = boxType.filter(item => item.key === a.cargoPackage)[0].value;
          packs.push(pack);
        }
      });
    });
    _finishStowageList.forEach((item, index) => {
      if (item.waybillNo === splitWaybillNo) {
        _finishStowageList[index].cargoNames = names.join(' / '); // 回写名字
        _finishStowageList[index].cargoResidualWeight = cargoWeight;// 回写总重量
        _finishStowageList[index].cargoResidualVolume = cargoVolume; // 回写总体积
        _finishStowageList[index].cargoResidualPiece = cargoPiece; // 回写总件数
        _finishStowageList[index].packs = packs.join(' / '); // 回写总包装
        _finishStowageList[index].nowSplitWaybill = _nowSplitWaybill;
        _finishStowageList[index].selected = this.state.selected.slice();
        _finishStowageList[index].splitType = this.state.splitType;
      }
    });
    _stowage.finishStowageList = _finishStowageList;
    this.setState({
      stowage: _stowage,
    });
    // 更新原始右边数据
    this.cancelSplitModal();
  }

  onCargoPieceChange = (value, index, key) => {
    const { leftStowageList } = this.props;
    const { _nowSplitWaybill, selected } = this.state;
    const tmp = _.cloneDeep(_nowSplitWaybill);
    const _leftStowageList = leftStowageList.length > 0 ? leftStowageList.slice() : [];
    tmp[index][key] = value;
    if (key === 'id') {
      const _selected = _.cloneDeep(selected);
      _selected[index] = value;
      // 计算当前选择货物的单个重量和体积，从原始货物中找回当前货物的体积、重量
      // const cargoPiece = _leftStowageList.filter(item => item.id === value)[0].cargoPiece; // 总件数
      // const cargoWeight = _leftStowageList.filter(item => item.id === value)[0].cargoWeight; // 总重量
      // const cargoVolume = _leftStowageList.filter(item => item.id === value)[0].cargoVolume; // 总体积
      const cargoResidualPiece = _leftStowageList.filter(item => item.id === value)[0].cargoResidualPiece; // 剩余件数
      const cargoResidualWeight = _leftStowageList.filter(item => item.id === value)[0].cargoResidualWeight; // 剩余重量
      const cargoResidualVolume = _leftStowageList.filter(item => item.id === value)[0].cargoResidualVolume; // 剩余体积
      // 单个商品的重量和体积
      const pieceWeight = NP.divide(cargoResidualWeight, cargoResidualPiece).toFixed(4);
      const pieceVolume = NP.divide(cargoResidualVolume, cargoResidualPiece).toFixed(4);
      tmp[index].pieceWeight = pieceWeight;
      tmp[index].pieceVolume = pieceVolume;
      tmp[index].cargoResidualPiece = cargoResidualPiece;
      tmp[index].cargoResidualWeight = cargoResidualWeight;
      tmp[index].cargoResidualVolume = cargoResidualVolume;
      // tmp[index].cargoName = ; // 把货物名字放进去
      this.setState({ selected: _selected });
    }
    this.setState({
      _nowSplitWaybill: tmp
    });
  }

  setStowageRemark = () => {
    const { index, stowage, tmpRemark } = this.state;
    const { finishStowageList } = stowage;
    const _stowage = _.cloneDeep(stowage);
    const _finishStowageList = _.cloneDeep(finishStowageList);
    _finishStowageList[index].loadRemark = tmpRemark;
    _stowage.finishStowageList = _finishStowageList;
    this.setState({
      stowage: _stowage,
      isShowRemarkModal: false
    });
  }

  getProps() {
    const {
      tableFields, loading, existSplitInfos, splitWaybill, existWaybill,
      leftStowageList, nowSplitFields
    } = this.props;
    const { nowSplitWaybill, _nowSplitWaybill, splitType, stowage, stowageList } = this.state;
    const { finishStowageList } = stowage;
    const search = { pn: 1, ps: 500 };

    // 拿到当前拆单货物的件数，重量、体积
    const tmpNowSplitWaybill = _.cloneDeep(_nowSplitWaybill);
    const extraSplitWaybill = [{
      key: 'cargoResidualPiece',
      name: '剩余件数（件）',
      render: (a, b) => {
        let tmp = a;
        tmpNowSplitWaybill.length && tmpNowSplitWaybill.forEach((item) => {
          if (item.id && b.id === item.id) {
            tmp -= item.cargoPiece ? item.cargoPiece : 0;
          }
        });
        return <span style={{ color: 'red' }}>{tmp}</span>;
      }
    }, {
      key: 'cargoResidualWeight',
      name: '剩余重量（吨）',
      render: (a, b) => {
        if (a === null || a === undefined) return defaultKey;
        let tmp = a;
        tmpNowSplitWaybill.length && tmpNowSplitWaybill.forEach((item) => {
          if ((b.id === item.id)) {
            if (splitType !== '1') {
              tmp -= (item.pieceWeight && item.cargoPiece) ? (item.pieceWeight * item.cargoPiece) : 0;
            } else {
              tmp -= item.cargoWeight ? item.cargoWeight : 0;
            }
          }
        });
        return <span style={{ color: 'red' }}>{tmp.toFixed(2)}</span>;
      }
    }, {
      key: 'cargoResidualVolume',
      name: '剩余体积（方）',
      render: (a, b) => {
        if (a === null || a === undefined) return defaultKey;
        let tmp = a;
        tmpNowSplitWaybill.length && tmpNowSplitWaybill.forEach((item) => {
          if ((b.id === item.id)) {
            if (splitType !== '1') {
              tmp -= (item.pieceVolume && item.cargoPiece) ? (item.pieceVolume * item.cargoPiece) : 0;
            } else {
              tmp -= item.cargoVolume ? item.cargoVolume : 0;
            }
          }
        });
        return <span style={{ color: 'red' }}>{tmp.toFixed(2)}</span>;
      }
    }];

    const waitingSelectColumns = {
      key: 'action',
      name: '选择',
      fixed: 'left',
      width: 60,
      render: (a, b, i) => (
        <Checkbox checked={b.disabled} onChange={e => this.onChangeStowage(e, b, i)} disabled={b.disabled} />
      )
    };

    const finishSelectColumns = {
      key: 'action',
      name: '操作',
      render: (a, b, i) => (
        [
          <a onClick={() => this.showSplitModal(b, i)} key="split" style={{ marginLeft: 4 }}>拆单</a>,
          <a onClick={() => this.onRemoveWaybill(i, b)} key="remove" style={{ marginLeft: 4 }}>移除</a>,
          <a onClick={() => this.showRemarkModal(i)} key="remark" style={{ marginLeft: 4 }}>备注</a>
        ]
      )
    };

    const loadRemark = {
      key: 'loadRemark',
      name: '装车备注',
      render: formatValue
    };

    // 计算货物单个重量和单个体积
    const cargoNames = [];
    nowSplitWaybill && nowSplitWaybill.length && nowSplitWaybill.forEach((item) => {
      cargoNames.push(
        <Option value={item.id} key={item.id} disabled={this.state.selected.includes(item.id)}>{item.cargoName}</Option>
      );
    });
    const extraSplitFields = [{
      key: 'cargoName',
      name: '货物品名',
      render: (a, b, i) => (<Select
        style={{ width: 180 }}
        placeholder="请选择货物品名"
        value={b.id}
        onChange={value => this.onCargoPieceChange(value, i, 'id', b)}
      >
        {cargoNames}
      </Select>)
    }, {
      key: 'cargoPiece',
      name: '件数（件）',
      render: (a, b, i) => {
        let cargoResidualPiece = a || b.cargoResidualPiece || 0;
        _nowSplitWaybill.forEach((item, index) => {
          if ((item.id === b.id) && (i !== index)) {
            cargoResidualPiece -= (item.cargoPiece || 0);
          }
        });
        return (
          <InputNumber
            disabled={!b.id}
            onChange={value => this.onCargoPieceChange(Math.floor(parseInt(`0${value}`, 10)), i, 'cargoPiece')}
            style={{ width: 80 }}
            value={a}
            max={cargoResidualPiece}
            min={1}
          />
        );
      }
    }, {
      key: 'cargoWeight',
      name: '重量（吨）',
      render: (a, b, i) => {
        if (splitType === '0') return (b.pieceWeight && b.cargoPiece) ? (b.pieceWeight * b.cargoPiece).toFixed(2) : a;
        let cargoResidualWeight = b.cargoResidualWeight || 0;
        _nowSplitWaybill.forEach((item, index) => {
          if ((item.id === b.id) && (i !== index)) {
            cargoResidualWeight -= (item.cargoWeight || 0);
          }
        });
        return (
          <InputNumber
            disabled={!b.id}
            onChange={value => this.onCargoPieceChange(value, i, 'cargoWeight')}
            style={{ width: 80 }}
            value={a}
            max={cargoResidualWeight}
            min={0}
          />
        );
      }
    }, {
      key: 'cargoVolume',
      name: '体积（方）',
      render: (a, b, i) => {
        if (splitType === '0') return (b.pieceVolume && b.cargoPiece) ? (b.pieceVolume * b.cargoPiece).toFixed(2) : a;
        let cargoResidualVolume = b.cargoResidualVolume || 0;
        _nowSplitWaybill.forEach((item, index) => {
          if ((item.id === b.id) && (i !== index)) {
            cargoResidualVolume -= (item.cargoVolume || 0);
          }
        });
        return (
          <InputNumber
            disabled={!b.id}
            onChange={value => this.onCargoPieceChange(value, i, 'cargoVolume')}
            style={{ width: 80 }}
            value={a}
            max={cargoResidualVolume}
            min={0}
          />
        );
      }
    }, {
      key: 'action',
      name: '操作',
      render: (a, b, i) => (
        <div>
          {
            _nowSplitWaybill.length > 1
              ? <a onClick={() => this.deleteOneSplitCargo(i, b.id)}>删除货品</a>
              : null
          }
          {
            _nowSplitWaybill.length < cargoNames.length
              ? <a onClick={this.addOneSplitCargo} style={{ marginLeft: 4 }}>添加货品</a>
              : null
          }
        </div>
      )
    }];

    // const _cargoNames = {
    //   key: 'cargoNames',
    //   name: '货名',
    //   render: formatValue
    // };

    // const packs = {
    //   key: 'packs',
    //   name: '包装',
    //   render: formatValue
    // };

    const _tableFields = _.cloneDeep(tableFields);
    _tableFields.splice(0, 0, waitingSelectColumns);

    const _finishStowageFields = _tableFields.slice(1);
    _finishStowageFields.splice(1, 0, finishSelectColumns);
    // _finishStowageFields.splice(6, 1, _cargoNames);
    // _finishStowageFields.splice(10, 1, packs);
    _finishStowageFields.push(loadRemark);

    const _leftStowageList = leftStowageList.length > 0 ? leftStowageList.slice() : [];
    let cargoPiece = 0;
    let cargoWeight = 0;
    let cargoVolume = 0;
    let cargoResidualPiece = 0;
    let cargoResidualWeight = 0;
    let cargoResidualVolume = 0;
    _leftStowageList.forEach((item) => {
      cargoPiece += item.cargoPiece;
      cargoWeight += item.cargoWeight;
      cargoVolume += item.cargoVolume;
      cargoResidualPiece += item.cargoResidualPiece;
      cargoResidualWeight += item.cargoResidualWeight;
      cargoResidualVolume += item.cargoResidualVolume;
    });
    if (splitType !== '1') {
      tmpNowSplitWaybill.forEach((item) => {
        if (item.id) {
          cargoResidualPiece -= (item.cargoPiece ? item.cargoPiece : 0);
          cargoResidualWeight -= ((item.pieceWeight && item.cargoPiece) ? (item.pieceWeight * item.cargoPiece) : 0);
          cargoResidualVolume -= ((item.pieceVolume && item.cargoPiece) ? (item.pieceVolume * item.cargoPiece) : 0);
        }
      });
    } else {
      tmpNowSplitWaybill.forEach((item) => {
        if (item.id) {
          cargoResidualPiece -= (item.cargoPiece ? item.cargoPiece : 0);
          cargoResidualWeight -= (item.cargoWeight ? item.cargoWeight : 0);
          cargoResidualVolume -= (item.cargoVolume ? item.cargoVolume : 0);
        }
      });
    }
    _leftStowageList.push({
      cargoName: '合计',
      cargoPiece,
      cargoWeight,
      cargoVolume,
      cargoResidualPiece,
      cargoResidualWeight,
      cargoResidualVolume,
    });
    return {
      waitingSelectProps: {
        fields: _tableFields,
        search,
        loading: loading.list,
        scroll: { x: 1600 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
        dataSource: stowageList
      },
      finishSelectProps: {
        fields: _finishStowageFields,
        dataSource: finishStowageList,
        search,
        loading: loading.list,
        scroll: { x: 1600 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
      leftStowageProps: {
        fields: splitWaybill.concat(extraSplitWaybill),
        dataSource: _leftStowageList,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
      existSplitInfosProps: {
        fields: existWaybill,
        dataSource: existSplitInfos,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
      nowSplitProps: {
        fields: nowSplitFields.concat(extraSplitFields),
        dataSource: _nowSplitWaybill,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      }
    };
  }

  addOneSplitCargo = () => {
    const { _nowSplitWaybill } = this.state;
    const tmpNowSplitWaybill = _.cloneDeep(_nowSplitWaybill);
    tmpNowSplitWaybill.push({});
    this.setState({ _nowSplitWaybill: tmpNowSplitWaybill });
  }

  deleteOneSplitCargo = (index, id) => {
    const { _nowSplitWaybill, selected } = this.state;
    const tmpNowSplitWaybill = _.cloneDeep(_nowSplitWaybill);
    const _selected = _.cloneDeep(selected);
    _selected.splice(_selected.indexOf(id), 1);
    tmpNowSplitWaybill.splice(index, 1);
    this.setState({ _nowSplitWaybill: tmpNowSplitWaybill, selected: _selected });
  }

  showRemarkModal = (index) => {
    this.setState({
      index,
      isShowRemarkModal: true
    });
  }

  showSplitModal = async (splitWaybill, i) => {
    const { leftStowageList, dispatch } = this.props;
    const params = {
      waybillNo: splitWaybill.waybillNo,
      stowageNo: splitWaybill.stowageNo,
      splitNo: splitWaybill.splitNo,
    };
    await dispatch({ type: 'editSharing/getStowageSplitInfo', payload: params });
    const { _nowSplitWaybill } = this.state;
    const selected = (splitWaybill.selected || []).slice();
    _nowSplitWaybill.forEach((item) => {
      selected.push(item.id);
    });
    this.setState({
      _nowSplitWaybill,
      nowSplitWaybill: leftStowageList,
      splitWaybillNo: splitWaybill.waybillNo,
      isShowSplitModal: true,
      nowSplitIndex: i,
      selected,
      splitType: splitWaybill.splitType || '0'
    });
  }

  cancelShowRemarkModal = () => {
    this.setState({
      isShowRemarkModal: false
    });
  }

  cancelSplitModal = () => {
    this.setState({
      selected: [],
      _nowSplitWaybill: [{}],
      isShowSplitModal: false
    });
  }

  render() {
    const { siteLineList, compartmentList, form, siteList, nowStowage } = this.props;
    const { getFieldDecorator } = form;
    const {
      waitingSelectProps, finishSelectProps, existSplitInfosProps, leftStowageProps, nowSplitProps
    } = this.getProps();
    const sites = [];
    siteLineList.forEach(item =>
      sites.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    const _siteList = [];
    siteList.forEach(item =>
      _siteList.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    const compartments = [];
    compartmentList.forEach(item =>
      compartments.push(<Option value={item.id} key={item.id}>{item.plateNumber}</Option>)
    );

    const _stowageTypes = [];
    STOWAGE_TYPE.forEach((item) => {
      _stowageTypes.push(<Radio value={item.key} key={item.key}>{item.name}</Radio>);
    });

    return (
      <div className={styles['add-stowage']}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <div>
            <span style={{ color: 'red' }}>*</span> 主营服务
            <RadioGroup
              disabled
              value={(nowStowage.stowage && nowStowage.stowage.type) || ''}
              style={{ marginLeft: 20 }}
            >
              {_stowageTypes}
            </RadioGroup>
          </div>
          <div>配载单号：{(nowStowage.stowage && nowStowage.stowage.stowageNo) || '' }</div>
        </div>
        <div className="capacity">
          <h1>基本信息</h1>
          <div className="form">
            <Form layout="inline" >
              <FormItem label="发车线路">
                {getFieldDecorator('siteLineId', {
                  initialValue: this.state.stowage.siteLineId,
                  rules: [
                    { required: true, message: '请选择发车线路' },
                  ],
                })(
                  <Select
                    disabled
                    style={{ width: 180 }}
                    placeholder="请选择发车线路"
                  >
                    {sites}
                  </Select>
                )}
              </FormItem>
              <FormItem label="挂车车牌">
                {getFieldDecorator('trailerId', {
                  initialValue: this.state.stowage.trailerId,
                  rules: [
                    { required: true, message: '请选择挂车车牌' },
                  ],
                })(
                  <Select
                    disabled
                    style={{ width: 180 }}
                    placeholder="请选择挂车车牌"
                  >
                    {compartments}
                  </Select>
                )}
              </FormItem>
              <br />
              <FormItem label="配载备注">
                <TextArea
                  className="textArea"
                  placeholder="请输入备注信息"
                  value={this.state.stowage.remark}
                  onChange={e => this.onSelectFieldChange(e.target.value, 'remark')}
                  rows={4}
                  style={{ width: 684 }}
                  maxLength={200}
                />
              </FormItem>
            </Form>
          </div>
        </div>
        <div className="add-waybill">
          <h1>
            选择运单
          </h1>
          <div className="cont">
            <div className="l-cont">
              <h2>可选运单</h2>
              <div className="search">
                <div style={{ padding: 10 }}>
                  <Input
                    placeholder="运单号"
                    onClick={this.showSelectTruckModal}
                    className="cond"
                    value={this.state.waybillNo}
                    onChange={e => this.onChangeWaybillSearch(e.target.value, 'waybillNo')}
                  />
                  <Select
                    value={this.state.waybillSearchSiteId}
                    style={{ width: 140, marginLeft: 2 }}
                    placeholder="请选择到站"
                    onChange={value => this.onChangeWaybillSearch(value, 'waybillSearchSiteId')}
                  >
                    <Option value="">全部</Option>
                    {_siteList}
                  </Select>
                  <Button type="primary" className="btn" onClick={this.onWaybillSearch}>查询</Button>
                  <Button className="btn" onClick={this.onResetWaybillSearch}>重置</Button>
                </div>
                <div style={{ height: 370, background: '#fff', overflow: 'scroll' }}>
                  <HTable {...waitingSelectProps} style={{ marginTop: 0 }} />
                </div>
              </div>
            </div>
            <div className="actions">
              {/* <Button className="btn"> &gt; </Button>
              <Button className="btn" style={{ marginTop: 4 }}> &lt; </Button> */}
            </div>
            <div className="r-cont">
              <h2>装车清单</h2>
              <div className="search">
                <div style={{ padding: 10 }}>
                  {/* <Input
                    placeholder="运单号"
                    onClick={this.showSelectTruckModal}
                    onChange={() => {}}
                    className="cond"
                  />
                  <Button type="primary" className="btn">查询</Button>
                  <Button className="btn">重置</Button> */}
                </div>
                <div style={{ height: 370, background: '#fff', overflow: 'scroll', marginTop: 30 }}>
                  <HTable {...finishSelectProps} style={{ marginTop: 0 }} />
                </div>
              </div>
              <table className="count-table">
                <tbody>
                  <tr>
                    <td className="label">已配载重量：</td><td>{this.state.finishOptions.finishLoad}吨</td>
                    <td className="label">挂车载重</td><td>{this.state.finishOptions.truckLoad}吨</td>
                    <td className="label">载重利用率</td>
                    <td>{`${(this.state.finishOptions.loadPercent === Infinity) ? '--'
                      : `${this.state.finishOptions.loadPercent}%`}`}</td>
                  </tr>
                  <tr>
                    <td className="label">已配载体积：</td><td>{this.state.finishOptions.finishVolumne}方</td>
                    <td className="label">挂车空间</td><td>{this.state.finishOptions.truckVolumne}方</td>
                    <td className="label">空间利用率</td>
                    <td>{`${(this.state.finishOptions.volumnePercent === Infinity) ? '--'
                      : `${this.state.finishOptions.volumnePercent}%`}`}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <Row className="save-btns">
          <Button type="primary" onClick={this.onSaveStowage}>保存</Button>
          <Button style={{ marginLeft: 20 }} onClick={this.onCancelAdd}>取消</Button>
        </Row>

        <Modal
          title="备注"
          visible={this.state.isShowRemarkModal}
          onOk={this.setStowageRemark}
          onCancel={this.cancelShowRemarkModal}
          width={300}
        >
        备注：
          <Input
            placeholder="请输入装车备注"
            style={{ width: 200 }}
            value={this.state.tmpRemark}
            onChange={this.onChangeRemark}
          />
        </Modal>

        {/* 拆单 */}
        <Modal
          title="拆单"
          visible={this.state.isShowSplitModal}
          onOk={this.onSplitOk}
          onCancel={this.cancelSplitModal}
          width={1200}
        >
          <div style={{ marginBottom: 20 }}>运单号：{this.state.splitWaybillNo}</div>
          <HTable {...leftStowageProps} style={{ marginTop: 0 }} />
          <div style={{ margin: '20px 0' }}>已有拆单</div>
          <HTable {...existSplitInfosProps} style={{ marginTop: 0 }} />
          <div style={{ margin: '20px 0', display: 'flex', justifyContent: 'space-between' }}>
            <span>当前拆单</span>
            <span>拆单方式：
              <RadioGroup
                value={this.state.splitType}
                style={{ marginLeft: 20 }}
                onChange={e => this.onChangeWaybillSearch(e.target.value, 'splitType')}
              >
                <Radio value="0" key="按件数">按件数</Radio>
                <Radio value="1" key="自定义">自定义</Radio>
              </RadioGroup>
            </span>
          </div>
          <HTable {...nowSplitProps} style={{ marginTop: 0 }} />
        </Modal>
      </div>
    );
  }
}

export default Form.create()(EditSharingStowage);
