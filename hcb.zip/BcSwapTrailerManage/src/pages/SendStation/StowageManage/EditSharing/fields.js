// import { sendWays } from 'configs/constants';
// import { stowageStatus } from 'configs/maps';
// import { formatValue, defaultKey } from 'utils/formatValue';

// 原始运单数据
// export const splitWaybillFields = [{
//   key: 'cargoName',
//   name: '货物品名',
//   render: formatValue
// }, {
//   key: 'cargoPiece',
//   name: '总件数',
//   render: formatValue
// }, {
//   key: 'cargoWeight',
//   name: '总重量（吨）',
//   render: formatValue
// }, {
//   key: 'cargoVolume',
//   name: '总体积（方）',
//   render: formatValue
// }];

// // 已有拆单
// export const existWaybill = [{
//   key: 'splitNo',
//   name: '子运单号',
//   render: a => a || defaultKey
// }, {
//   key: 'stowageNo',
//   name: '配载单号',
//   render: formatValue
// }, {
//   key: 'stowageStatus',
//   name: '配载状态',
//   render: a => stowageStatus.filter(item => item.status === a)[0].name
// }, {
//   key: 'cargoName',
//   name: '货物品名',
//   render: formatValue
// }, {
//   key: 'packages',
//   name: '件数（件）',
//   render: formatValue
// }, {
//   key: 'weight',
//   name: '重量（吨）',
//   render: formatValue
// }, {
//   key: 'cubage',
//   name: '体积（方）',
//   render: formatValue
// }];

// // 当前拆单
// export const nowSplitFields = [{
//   key: 'splitNo',
//   name: '子运单号',
//   render: a => a || defaultKey
// }, {
//   key: 'stowageNo',
//   name: '配载单号',
//   render: formatValue
// }, {
//   key: 'splitStatus',
//   name: '配载状态',
//   render: () => '装载中'
// }];
