import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
// import { splitWaybillFields, existWaybill, nowSplitFields } from './fields';
import {
  getSiteLineList, getCompartmentList, getStowageList, createStowage, getSiteList, getStowageSplitInfo,
  loadStowageDetail
} from './services';

export default Model.extend({
  namespace: 'editSharing',

  state: {
    list: [],
    loading: { list: false },
    // tableFields,
    // splitWaybillFields,
    // existWaybill,
    // nowSplitFields,
    siteLineList: [],
    compartmentList: [],
    stowageList: [],
    leftWaybillList: [],
    siteList: [],
    existSplitInfos: [],
    nowStowage: {},
    currentSplitList: [],
    originalStockCargos: []
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.EDIT_SHARING, async ({ params }) => {
        dispatch({ type: 'getSiteLineList', payload: { ps: 1000, pn: 1 } });
        dispatch({ type: 'getSiteList', payload: { ps: 1000, pn: 1 } });
        dispatch({ type: 'getCompartmentList', payload: { ps: 1000, pn: 1, effective: 1 } });
        dispatch({ type: 'getStowageList', payload: { ps: 100, pn: 1, mainBusiness: 'CHANNELSERVICE' } });
        dispatch({ type: 'loadStowageDetail', payload: { stowageNo: params[0] } });
      });
    }
  },

  effects: {
    // 所有线路列表
    * getSiteLineList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getSiteLineList, 'list'), payload);
      yield update({ siteLineList: datas });
    },
    // 所有站点列表
    * getSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getSiteList, 'list'), payload);
      yield update({ siteList: datas });
    },
    // 所有挂车车牌
    * getCompartmentList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getCompartmentList, 'list'), payload);
      yield update({ compartmentList: datas });
    },
    // 所有运单列表
    * getStowageList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getStowageList, 'list'), { ...payload, ps: 100, pn: 1 });
      yield update({ stowageList: datas });
    },
    // 新增保存
    * createStowage({ payload }, { call }) {
      yield call(withLoading(createStowage, 'list', '修改成功'), payload);
      window.location.hash = '#/sendStation/stowageManage';
    },
    // 查询当前拆单信息
    * getStowageSplitInfo({ payload }, { call, update }) {
      const splitInfos = yield call(withLoading(getStowageSplitInfo, 'list'), payload);
      yield update({
        leftWaybillList: splitInfos.stockCargos, // 总剩余
        existSplitInfos: splitInfos.splitedList, // 已有拆单
        currentSplitList: splitInfos.currentSplitList, // 当前拆单
        originalStockCargos: // 初始总数据
          (splitInfos.originalStockCargos !== null && splitInfos.originalStockCargos.length)
            ? splitInfos.originalStockCargos
            : splitInfos.stockCargos
      });
    },
    // 查询当前配载单数据
    * loadStowageDetail({ payload }, { call, update }) {
      const nowStowage = yield call(withLoading(loadStowageDetail, 'list'), payload);
      yield update({ nowStowage });
    }
  },

  reducers: {
    updateStowageList(state, { payload }) {
      return {
        ...state,
        stowageList: payload
      };
    }
  }
});
