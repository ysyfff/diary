import NP from 'number-precision';
import styles from './StowageRate.less';

export default class StowageRate extends React.PureComponent {
  // 计算载重百分比，当前车辆信息不变，传入当前已选择的货物信息
  calculateFinishOptions = () => {
    const { compartmentList = [], splitCargoList, stowage = {}, siteLineList } = this.props;
    const { trailerId = '', siteLineId = '' } = stowage;
    let truck = {};
    let siteLine = {};
    let truckLoad = 0;
    let truckVolumne = 0;
    let finishLoad = 0;
    let finishVolumne = 0;
    let loadPercent = 0;
    let volumnePercent = 0;
    let loadPrice = 0;
    let minPrice = 0;

    truck = compartmentList.filter(item => item.id === trailerId)[0] || {};
    siteLine = siteLineList.filter(item => item.id === siteLineId)[0] || {};

    truckLoad = truck.truckLoad || 0;
    truckVolumne = truck.truckVolumne || 0;
    minPrice = siteLine.minPrice || 0;

    splitCargoList.length && splitCargoList.forEach((item) => {
      finishLoad = NP.plus(Number(finishLoad), Number(item.cargoResidualWeight)).toFixed(2);
      finishVolumne = NP.plus(Number(finishVolumne), Number(item.cargoResidualVolume)).toFixed(2);
      loadPrice = NP.plus(Number(loadPrice), Number(item.cargoResidualFreight));
    });

    if (finishLoad === 0) loadPercent = 0;
    else if (truckLoad === 0) loadPercent = '--';
    else loadPercent = NP.times((NP.divide(finishLoad / 1000, truckLoad).toFixed(4)), 100);

    if (finishVolumne === 0) volumnePercent = 0;
    else if (truckLoad === 0) volumnePercent = '--';
    else volumnePercent = NP.times((NP.divide(finishVolumne, truckVolumne).toFixed(4)), 100);

    const finishOptions = {
      truckLoad,
      truckVolumne,
      finishLoad,
      finishVolumne,
      loadPercent,
      volumnePercent,
      loadPrice,
      minPrice
    };

    return finishOptions;
  }

  render() {
    const finishOptions = this.calculateFinishOptions();

    return (
      <div style={{ width: '100%' }}>
        <table className={styles['count-table']}>
          <tbody>
            <tr>
              <td className="label">已配载重量</td><td>{
                finishOptions.finishLoad / 1000 < 30 ?
                  <span style={{ color: 'red' }}>{finishOptions.finishLoad}千克</span>
                  : `${finishOptions.finishLoad}千克`
              }</td>
              <td className="label">挂车载重</td><td>{finishOptions.truckLoad}吨</td>
              <td className="label">载重利用率</td><td>{
                finishOptions.finishLoad / 1000 < 30 ?
                  <span style={{ color: 'red' }}>{finishOptions.loadPercent}%</span>
                  : `${finishOptions.loadPercent}%`
              }</td>
            </tr>
            <tr>
              <td className="label">已配载体积</td><td>{
                finishOptions.finishVolumne < 120 ?
                  <span style={{ color: 'red' }}>{finishOptions.finishVolumne}方</span>
                  : `${finishOptions.finishVolumne}方`
              }</td>
              <td className="label">挂车空间</td><td>{finishOptions.truckVolumne}方</td>
              <td className="label">空间利用率</td>
              <td>{
                finishOptions.finishVolumne < 120 ?
                  <span style={{ color: 'red' }}>{finishOptions.volumnePercent}%</span>
                  : `${finishOptions.volumnePercent}%`
              }</td>
            </tr>
            <tr>
              <td className="label">已配载运费</td><td>{
                finishOptions.loadPrice < finishOptions.minPrice ?
                  <span style={{ color: 'red' }}>{finishOptions.loadPrice}元</span>
                  : `${finishOptions.loadPrice}元`
              }</td>
              <td className="label">最低通道运费</td><td>{finishOptions.minPrice}元</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}
