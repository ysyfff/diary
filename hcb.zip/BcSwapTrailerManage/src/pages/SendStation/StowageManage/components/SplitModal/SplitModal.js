import { Modal, Radio, Select, Form, InputNumber } from 'antd';
import { HTable } from 'carno';
import _ from 'lodash';
import NP from 'number-precision';
import { boxType } from 'configs/constants';
import { currentSplitFields, existSplitFields, leftWaybillFields } from './fields';

const RadioGroup = Radio.Group;
const search = { pn: 1, ps: 500 };
const Option = Select.Option;

const nowCargoTotalResidual = []; // 临时存储当前货物的总剩余件数、重量、体积

class SplitModal extends React.PureComponent {
  state = {
    cargoPieceOptions: [] // 存储拆单货品的平均重量和平均体积
  }

  onChangeWaybillSearch = (value, field) => {
    if (field === 'splitType') {
      const { updateParentState } = this.props;
      updateParentState({ nowSplitList: [{ packages: 0 }], selected: [], splitType: value });
    } else {
      this.setState({
        [field]: value
      });
    }
  }

  onSplitOk = () => {
    const {
      updateParentState, splitedWaybills, nowSplitList, nowStowage, hasSplit, nowSplitIndex, updateState,
      waybillNo, cancelSplitModal, selected, splitType } = this.props;
    const { splitCargoList } = nowStowage;
    const _splitCargoList = splitCargoList.slice();

    const tmp = [];
    // 校验当前拆单的结果里面是否有0的数据，有0的数据禁止提交
    nowSplitList.forEach((item) => {
      tmp.push(item.weight * item.cubage * item.packages);
    });
    if (!nowSplitList.length || tmp.includes(0) || tmp.includes(NaN)) {
      Modal.error({ title: '货物的件数、重量、体积必须大于0，请检查输入项！' });
      return;
    }
    // let _currentSplitList = [];
    const _currentSplitList = this.convertSplitWaybills(nowSplitList, hasSplit); // 已拆单的和未拆单的转换方式不同
    // if (!hasSplit)
    // else if (hasSplit) _currentSplitList = [];
    const {
      cargoNames, packs, cargoResidualPiece, cargoResidualVolume, cargoResidualWeight, cargoResidualFreight
    } = this.handleWriteBackParams(_currentSplitList);
    _splitCargoList[nowSplitIndex].hasSplit = true; // 标示当前拆单为已拆单
    _splitCargoList[nowSplitIndex].cargoNames = cargoNames;
    _splitCargoList[nowSplitIndex].packs = packs;
    _splitCargoList[nowSplitIndex].cargoResidualPiece = cargoResidualPiece;
    _splitCargoList[nowSplitIndex].cargoResidualVolume = cargoResidualVolume;
    _splitCargoList[nowSplitIndex].cargoResidualWeight = cargoResidualWeight;
    _splitCargoList[nowSplitIndex].cargoResidualFreight = cargoResidualFreight;
    _splitCargoList[nowSplitIndex].hasSplit = true; // 标示当前拆单为已拆单
    _splitCargoList[nowSplitIndex].waybillNo = waybillNo;
    _splitCargoList[nowSplitIndex].selected = selected;
    _splitCargoList[nowSplitIndex].splitType = splitType; // 拆单方式

    updateState({ nowStowage: { ...nowStowage, splitCargoList: _splitCargoList } });
    // 删除子单栈内 所有为当前运单的子单，重新保存
    const _splitedWaybills = splitedWaybills.filter(item => item.waybillNo !== waybillNo);
    updateParentState({
      splitedWaybills: _splitedWaybills.concat(_currentSplitList) // 更新子单栈
    });
    cancelSplitModal();
  }

  onCargoPieceChange = (value, b, i) => {
    const { storageCargoId, waybillCargoId } = b;
    const { cargoPieceOptions } = this.state;
    let nowCargoOptions = {};
    const _nowCargoOptions = cargoPieceOptions.filter(item => item.id === (storageCargoId || waybillCargoId))[0];
    const nowCargo = nowCargoTotalResidual.filter(item => item.id === (storageCargoId || waybillCargoId))[0];

    if (!nowCargo) { // 查看当前货物是否已经保存了总剩余，如果未找到则重新计算
      this.saveTotalResidual(b);
    }

    if (_nowCargoOptions) {
      nowCargoOptions = _nowCargoOptions;
    } else {
      // 计算平均值并保存
      nowCargoOptions = this.calculateAverage(storageCargoId || waybillCargoId);
      this.setState({
        cargoPieceOptions: cargoPieceOptions.concat([nowCargoOptions])
      });
    }

    // const backPiece = this.reCalculateLeftPiece(value, i); // 计算需要回写多少件
    const obj = this.reCalculateLeftAndCurrent(nowCargoOptions, value); // backPiece
    this.paintLeftAndCurrent(obj, i);
    // // 回写完后，需要手动修改nowSplitList数据，因为Form没有主动保存当前变化的件数
    const { nowSplitList, updateParentState } = this.props;
    const _nowSplitList = nowSplitList.slice();
    _nowSplitList[i].packages = value;
    updateParentState({ nowSplitList: _nowSplitList });
  }

  onCargoVWChange = (value, i, key, b) => {
    const { storageCargoId, waybillCargoId } = b;
    const { nowSplitList, updateParentState } = this.props;
    const _nowSplitList = nowSplitList.slice();
    const nowCargo = nowCargoTotalResidual.filter(item => item.id === (storageCargoId || waybillCargoId))[0];

    if (!nowCargo) { // 查看当前货物是否已经保存了总剩余，如果未找到则重新计算
      this.saveTotalResidual(b);
    }
    _nowSplitList[i][key] = value;

    // 重新计算运费
    let wPrice = 0;
    let vPrice = 0;
    if (key === 'cubage') {
      wPrice = NP.times(b.waybillFeeDTO.weightPrice, b.cargoWeight);
      vPrice = NP.times(b.waybillFeeDTO.volumePrice, value);
    } else if (key === 'weight') {
      wPrice = NP.times(b.waybillFeeDTO.weightPrice, value);
      vPrice = NP.times(b.waybillFeeDTO.volumePrice, b.cargoVolume);
    }
    _nowSplitList[i].freight = NP.plus(wPrice, vPrice) || b.freight;
    updateParentState({ nowSplitList: _nowSplitList });
  }

  onCargoNameChange = (value, b, i) => {
    const { nowSplitList, updateParentState, leftWaybillList, selected = [] } = this.props;
    const tmpObj = leftWaybillList.filter(item => item.id === value)[0];
    // const { nowSplitList, updateParentState, leftWaybillList, updateState } = this.props;
    const _nowSplitList = nowSplitList.slice();
    const _selected = selected.slice();
    // 切换名字时，先保存总数
    // 如果是从无切换为有的，则还没有 b，则直接计算当前切换的
    this.saveTotalResidual(b, value); // 刚进入编辑即切换名字时，这时还没有计算总数据，需要额外处理
    // const resetObjOptions = nowCargoTotalResidual.filter(item => item.id === b.storageCargoId)[0];

    // if (b.storageCargoId) { // 回写数据
    //   // 切换名字时，需要还原上一份货物的件数、重量、体积，如果名字从无到有，则无需还原
    //   const resetObjIndex = _.findIndex(leftWaybillList, item => item.id === b.storageCargoId);
    //   const _leftWaybillList = leftWaybillList.slice();
    //   _leftWaybillList[resetObjIndex].cargoResidualPiece = resetObjOptions.totalPiece;
    //   _leftWaybillList[resetObjIndex].cargoResidualWeight = resetObjOptions.totalWeight;
    //   _leftWaybillList[resetObjIndex].cargoResidualVolume = resetObjOptions.totalVolume;
    //   updateState({ leftWaybillList: _leftWaybillList });
    // }
    if (!_nowSplitList[i]) _nowSplitList[i] = {};
    _nowSplitList[i].cargoPackage = tmpObj.cargoPackage;
    _nowSplitList[i].cargoName = tmpObj.cargoName;
    _nowSplitList[i].waybillFeeDTO = tmpObj.waybillFeeDTO;
    _nowSplitList[i].storageCargoId = value;
    _nowSplitList[i].waybillCargoId = value;
    _nowSplitList[i].packages = 0;
    _nowSplitList[i].weight = 0;
    _nowSplitList[i].cubage = 0;
    _nowSplitList[i].freight = 0;
    _nowSplitList[i].packageNumber = 0;

    // 切换名字时，需要启用上一个已禁用的菜单，同时禁用当前选择菜单
    const selectedIndex = _.findIndex(selected, item => item === b.storageCargoId);
    if (b.storageCargoId) {
      _selected.splice(selectedIndex, 1); // 启用上一个
    }
    _selected.push(value); // 禁用当前
    updateParentState({ nowSplitList: _nowSplitList, selected: _selected });
  }

  getProps() {
    const {
      loading, leftWaybillList = [], existSplitInfos, form, nowSplitList, hasSplit, selected = [], splitType
    } = this.props;
    const cargoNames = [];
    const { getFieldDecorator } = form;
    // 已拆单和未拆单的数据结构不同，所以转换方式不同
    const currentDataSource = this.handleSplitCarogs(nowSplitList, hasSplit);

    (leftWaybillList || []).forEach((item) => {
      cargoNames.push(
        <Option value={item.id} key={item.id} disabled={selected.includes(item.id)}>{item.cargoName}</Option>
      );
    });

    const extraSplitFields = [{
      key: 'cargoName',
      name: '货物品名',
      render: (a, b, i) =>
        getFieldDecorator(`cargoName_${i}_${b.storageCargoId}`, {
          initialValue: b.storageCargoId,
          rules: [
            { required: true, message: '请选择货物品名' },
          ],
        })(
          <Select
            style={{ width: 180 }}
            placeholder="请选择货物品名"
            onChange={value => this.onCargoNameChange(value, b, i)}
          >
            {cargoNames}
          </Select>
        )
    }, {
      key: 'cargoPiece',
      name: '件数（件）',
      render: (a, b, i) => {
        let max = 999999;
        const obj = nowCargoTotalResidual.filter(item => item.id === b.storageCargoId)[0];
        if (obj) max = obj.totalPiece;
        return getFieldDecorator(`cargoPiece_${i}_${b.storageCargoId}`, {
          initialValue: a,
          rules: [
            { required: true, message: '请输入件数' },
          ],
        })(
          <InputNumber
            disabled={!b.storageCargoId}
            min={0}
            max={max}
            precision={0}
            onBlur={e => this.onCargoPieceChange(e.target.value, b, i)}
          />
        );
      }
    }, {
      key: 'cargoWeight',
      name: '重量（千克）',
      render: (a, b, i) => {
        if (splitType === 'PACKAGE') {
          if (a && !isNaN(a)) return a;
          return 0;
        }
        let max = 999999;
        const obj = nowCargoTotalResidual.filter(item => item.id === b.storageCargoId)[0];
        if (obj) max = obj.totalWeight;
        return getFieldDecorator(`cargoWeight_${i}_${b.storageCargoId}`, {
          initialValue: a,
          rules: [
            { required: true, message: '请输入重量' },
          ],
        })(
          <InputNumber
            disabled={!b.storageCargoId}
            min={0}
            max={max}
            onBlur={e => this.onCargoVWChange(e.target.value, i, 'weight', b)}
          />
        );
      }
    }, {
      key: 'cargoVolume',
      name: '体积（方）',
      render: (a, b, i) => {
        if (splitType === 'PACKAGE') {
          if (a && !isNaN(a)) return a;
          return 0;
        }
        let max = 999999;
        const obj = nowCargoTotalResidual.filter(item => item.id === b.storageCargoId)[0];
        if (obj) max = obj.totalVolume;
        return getFieldDecorator(`cargoVolume_${i}_${b.storageCargoId}`, {
          initialValue: a,
          rules: [
            { required: true, message: '请输入体积' },
          ],
        })(
          <InputNumber
            disabled={!b.storageCargoId}
            min={0}
            max={max}
            onBlur={e => this.onCargoVWChange(e.target.value, i, 'cubage', b)}
          />
        );
      }
    }, {
      key: 'freight',
      name: '已分摊运费（元）'
    }, {
      key: 'action',
      name: '操作',
      width: 80,
      render: (a, b, i) => (
        <div>
          {
            currentDataSource.length > 1
              ? <a onClick={() => this.deleteOneSplitCargo(i, b)}>删除</a>
              : null
          }
          {
            currentDataSource.length < cargoNames.length
              ? <a onClick={this.addOneSplitCargo} style={{ marginLeft: 4 }}>添加</a>
              : null
          }
        </div>
      )
    }];

    return {
      leftStowageProps: {
        fields: leftWaybillFields,
        dataSource: leftWaybillList,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
      existSplitInfosProps: {
        fields: existSplitFields,
        dataSource: existSplitInfos,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
      currentSplitProps: {
        fields: currentSplitFields.concat(extraSplitFields),
        dataSource: currentDataSource,
        search,
        loading: loading.list,
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      }
    };
  }

  // 保存总件数、重量、体积
  saveTotalResidual = (b, value) => { // value 为不存在b时，当前切换项的id
    const { leftWaybillList } = this.props;
    const obj = nowCargoTotalResidual.filter(item => item.id === b.storageCargoId)[0];
    if (obj) return; // 如果已存在保存的剩余总数，则直接返回，无需再次计算
    let tmpOriginData = {};

    // 计算总数时，需要判断b存不存在，如果切换名字时，从无到有，则b不存在
    if (b.storageCargoId) {
      tmpOriginData = leftWaybillList.filter(item => item.id === b.storageCargoId)[0];
    } else {
      tmpOriginData = leftWaybillList.filter(item => item.id === value)[0];
    }

    nowCargoTotalResidual.push({
      totalPiece: tmpOriginData.cargoResidualPiece + (b.cargoPiece || 0),
      totalWeight: NP.plus(tmpOriginData.cargoResidualWeight, (b.cargoWeight || 0)),
      totalVolume: NP.plus(tmpOriginData.cargoResidualVolume, (b.cargoVolume || 0)),
      totalFreight: NP.plus(tmpOriginData.cargoResidualFreight, (b.freight || 0)),
      id: b.storageCargoId
    });
  }

  // 回写剩余数据和当前数据
  paintLeftAndCurrent = (obj, i) => {
    // const { leftWaybillList, nowSplitList, updateState, updateParentState } = this.props;
    const { nowSplitList, updateParentState } = this.props;
    // const _leftWaybillList = leftWaybillList.slice();
    // const { originData, currentData, id } = obj;
    const { currentData } = obj;
    const _nowSplitList = nowSplitList.slice();
    // const objIndex = _.findIndex(leftWaybillList, item => item.id === id); // 找出需要修改的数据的序号
    //  const tmpOriginObject = leftWaybillList.filter(item => item.id === id)[0]; // 找出需修改的数据
    // tmpOriginObject.cargoResidualPiece = originData.newLeftPiece;
    // tmpOriginObject.cargoResidualWeight = Number(originData.newLeftWeight).toFixed(2);
    // tmpOriginObject.cargoResidualVolume = Number(originData.newLeftVolume).toFixed(2);
    _nowSplitList[i].weight = Number(currentData.newCurrentWeight).toFixed(2);
    _nowSplitList[i].cubage = Number(currentData.newCurrentVolume).toFixed(2);
    _nowSplitList[i].freight = Math.floor(Number(currentData.newCurrentFreight) * 100) / 100; // 保留两位小数，不四舍五入
    // _leftWaybillList[objIndex] = tmpOriginObject;

    // updateState({ leftWaybillList: _leftWaybillList });
    updateParentState({ nowSplitList: _nowSplitList });
  }

  addOneSplitCargo = () => {
    const { nowSplitList, updateParentState } = this.props;
    updateParentState({ nowSplitList: [...nowSplitList, { packages: 0 }] });
  }

  deleteOneSplitCargo = (i, b) => {
    const { nowSplitList, updateParentState, selected = [] } = this.props;
    const _nowSplitList = nowSplitList.slice();
    const _selected = selected.slice();
    _nowSplitList.splice(i, 1);

    if (b.storageCargoId) {
      // const writeBackData = this.handleWriteBackData(b, b.storageCargoId); // 删除之前回写数据
      this.saveTotalResidual(b); // 检查剩余总数是否存在，确保回写不出错
      // this.writeBackLineLeft(b.storageCargoId);

      const selectedIndex = _.findIndex(selected, item => item === b.storageCargoId);
      _selected.splice(selectedIndex, 1); // 启用上一个
      updateParentState({ nowSplitList: _nowSplitList, selected: _selected });
    } else {
      updateParentState({ nowSplitList: _nowSplitList }); // 回写完后再删除
    }
    // this.writeBackLineLeft(writeBackData);
    // const { currentSplitList, leftStowageList, stowage, nowSplitIndex } = this.state;
    // const { stateSplitCargoList } = stowage;
    // const _stowage = _.cloneDeep(stowage);
    // const _stateSplitCargoList = _.cloneDeep(stateSplitCargoList);

    // const { stateLeftStowageList } =
    //   _stateSplitCargoList.filter(item => item.waybillNo === this.state.splitWaybillNo)[0];
    // let curr = [];
    // if (id) {
    //   curr = stateLeftStowageList.filter(item => item.storageCargoId !== id);
    //   _stateSplitCargoList[nowSplitIndex].stateLeftStowageList = curr;
    //   _stowage.stateSplitCargoList = _stateSplitCargoList;
    // }

    // const tmpstateLeftStowageList = _.cloneDeep(currentSplitList);
    // const _selected = _.cloneDeep(selected);
    // if (id) {
    //   _selected.splice(_selected.indexOf(id), 1);
    // }
    // tmpstateLeftStowageList.splice(index, 1);

    // if (id) {
    //   const writeBackData = this.handleWriteBackData(leftStowageList, b, id); // 回写完后再删除
    //   this.writeBackLineLeft(writeBackData);
    // }
    // this.setState({ currentSplitList: tmpstateLeftStowageList, selected: _selected, stowage: _stowage });
  }

  // 回加剩余数据
  writeBackLineLeft = (id) => {
    const { leftWaybillList, updateState } = this.props;
    const _leftWaybillList = leftWaybillList.slice();
    const cargoResidualObj = nowCargoTotalResidual.filter(item => item.id === id)[0];
    const leftResidualIndex = _.findIndex(leftWaybillList, item => item.id === id);
    _leftWaybillList[leftResidualIndex].cargoResidualPiece = cargoResidualObj.totalPiece;
    _leftWaybillList[leftResidualIndex].cargoResidualWeight = cargoResidualObj.totalWeight;
    _leftWaybillList[leftResidualIndex].cargoResidualVolume = cargoResidualObj.totalVolume;

    updateState({ leftWaybillList: _leftWaybillList });
  }

  // 删除或者向同行切换时，需要回写之前状态；回写到哪，回写的行，查询id
  // handleWriteBackData = (cancelLine, id) => {
  //   const { leftWaybillList } = this.props;
  //   const tmpOriginObject = leftWaybillList.filter(item => item.id === id)[0];

  //   const cargoResidualPiece = tmpOriginObject.cargoResidualPiece; // 剩余件数
  //   const cargoResidualWeight = tmpOriginObject.cargoResidualWeight; // 剩余重量
  //   const cargoResidualVolume = tmpOriginObject.cargoResidualVolume; // 剩余体积
  //   const currentLinePiece = cancelLine.cargoPiece; // 回写行的件数
  //   const currentLineWeight = cancelLine.cargoWeight; // 回写行的重量
  //   const currentLineVolume = cancelLine.cargoVolume; // 回写行的体积

  //   let originData = {};
  //   let newLeftPiece = 0; // 新的剩余件数
  //   let newLeftWeight = 0; // 新的剩余重量
  //   let newLeftVolume = 0; // 新的剩余体积

  //   newLeftPiece = cargoResidualPiece + currentLinePiece;
  //   newLeftWeight = NP.plus(cargoResidualWeight, currentLineWeight);
  //   newLeftVolume = NP.plus(cargoResidualVolume, currentLineVolume);

  //   originData = { newLeftPiece, newLeftWeight, newLeftVolume, id };

  //   return originData;
  // }

  // 回写装车清单参数计算
  handleWriteBackParams = (currentSplitList = []) => {
    const cargoNames = [];
    const packs = [];
    let cargoResidualPiece = 0;
    let cargoResidualVolume = 0;
    let cargoResidualWeight = 0;
    let cargoResidualFreight = 0;

    currentSplitList.forEach((item) => {
      cargoNames.push(item.cargoName);
      packs.push(boxType.filter(x => x.key === item.cargoPackage)[0].value);
      cargoResidualPiece = Number(cargoResidualPiece) + Number(item.packageNumber);
      cargoResidualVolume = NP.plus(Number(cargoResidualVolume), item.cubage).toFixed(2);
      cargoResidualWeight = NP.plus(Number(cargoResidualWeight), item.weight).toFixed(2);
      cargoResidualFreight = Number(cargoResidualFreight) + Number(item.freight);
    });

    return {
      cargoNames: cargoNames.join(' / '),
      packs: packs.join(' / '),
      cargoResidualPiece,
      cargoResidualVolume,
      cargoResidualWeight,
      cargoResidualFreight: Math.floor(cargoResidualFreight * 100) / 100
    };
  }

  // 将获取的已有拆单信息进行转换
  handleSplitCarogs = (currentSplitList = [], hasSplit) => {
    const _currentSplitList = [];
    const tmpCurrentSplitList = currentSplitList.slice();

    // if (!currentSplitList[0]) {
    //   tmpCurrentSplitList = [{ packages: 0 }];
    // }

    tmpCurrentSplitList.forEach((item) => {
      _currentSplitList.push({
        cargoName: item.cargoName,
        cargoPackage: item.cargoPackage,
        splitNo: item.splitNo,
        stowageNo: item.stowageNo,
        splitStatus: '--',
        storageCargoId: hasSplit ? item.waybillCargoId : item.storageCargoId,
        cargoPiece: hasSplit ? item.packageNumber : item.packages,
        cargoWeight: item.weight || 0,
        cargoVolume: item.cubage || 0,
        freight: item.freight || 0,
        waybillFeeDTO: item.waybillFeeDTO || {}
      });
    });
    return _currentSplitList;
  }
  // 拆单保存时转换为所有子单存储在父级splitedWaybills
  convertSplitWaybills = (currentSplitList) => {
    const { waybillNo, splitType } = this.props;
    const _splitedWaybills = [];
    let splitNo = '';

    currentSplitList.forEach((item) => {
      if (!splitNo) splitNo = (item.splitNo || '');
      const obj = {
        cargoName: item.cargoName,
        cargoPackage: item.cargoPackage,
        splitNo,
        stowageNo: item.stowageNo,
        // 实际配载单保存时不需要以上参数，只是方便二次编辑
        waybillNo,
        waybillCargoId: item.storageCargoId,
        packageNumber: item.packages,
        packages: item.packages,
        storageCargoId: item.storageCargoId,
        weight: Number(item.weight).toFixed(2),
        cubage: Number(item.cubage).toFixed(2),
        freight: item.freight,
        // remark: item.loadRemark || '',
        isSplit: 1, // 1 表示为拆单的子单
        splitType,
        waybillFeeDTO: item.waybillFeeDTO
      };
      _splitedWaybills.push(obj);
    });
    return _splitedWaybills;
  }

  // 计算平均值
  calculateAverage = (storageCargoId) => {
    const { leftWaybillList, nowSplitList } = this.props;
    const tmpOriginObject = leftWaybillList.filter(item => item.id === storageCargoId)[0];
    const tmpCurrentObject = nowSplitList.filter(item => item.storageCargoId === storageCargoId)[0];
    const cargoResidualPiece = NP.plus(tmpOriginObject.cargoResidualPiece, (tmpCurrentObject.packages || 0)); // 总剩余件数
    const cargoResidualWeight = NP.plus(tmpOriginObject.cargoResidualWeight, (tmpCurrentObject.weight || 0)); // 总剩余重量
    const cargoResidualVolume = NP.plus(tmpOriginObject.cargoResidualVolume, (tmpCurrentObject.cubage || 0)); // 总剩余体积
    let pieceWeight = 0;
    let pieceVolume = 0;

    pieceWeight = (NP.divide(cargoResidualWeight, cargoResidualPiece)).toFixed(6);
    pieceVolume = (NP.divide(cargoResidualVolume, cargoResidualPiece)).toFixed(6);

    return { id: storageCargoId, pieceWeight, pieceVolume };
  }

  // 计算需要回写的件数
  // reCalculateLeftPiece = (value, i) => {
  //   const { nowSplitList } = this.props;
  //   const backPiece = nowSplitList[i].packages - value;
  //   if (backPiece < 0) return 0;
  //   return backPiece;
  // }

  // 重新计算剩余数量和当前重量、体积、运费
  reCalculateLeftAndCurrent = (nowCargoOptions, piece) => { // backPiece
    const { leftWaybillList = [], nowSplitList = [], splitType } = this.props;
    const tmpOriginObject = leftWaybillList.filter(item => item.id === nowCargoOptions.id)[0];
    const tmpCurrentObject = nowSplitList.filter(item => item.storageCargoId === nowCargoOptions.id)[0];
    let originData = {};
    let currentData = {};
    let newCurrentWeight = 0; // 新的当前重量
    let newCurrentVolume = 0; // 新的当前体积
    let newCurrentFreight = 0; // 新的当前运费
    let newLeftPiece = 0; // 新的剩余件数
    let newLeftWeight = 0; // 新的剩余重量
    let newLeftVolume = 0; // 新的剩余体积
    let newLeftFreight = 0; // 新的剩余运费

    if (splitType === 'PACKAGE') { // 按件数拆单，每件重量、体积用剩余的重量（体积） / 剩余件数
      // 判断当前输入的件数和剩余件数是否相等，相等则带出全部剩余重量和体积；如果剩余件数为1，则直接带出所有剩余重量和体积
      if ((tmpCurrentObject.packages === tmpOriginObject.cargoResidualPiece)
        || (tmpOriginObject.cargoResidualPiece === 1)) {
        newCurrentWeight = tmpOriginObject.cargoResidualWeight;
        newCurrentVolume = tmpOriginObject.cargoResidualVolume;
        newCurrentFreight = tmpOriginObject.cargoResidualFreight;
      } else {
        newCurrentWeight = NP.times(nowCargoOptions.pieceWeight, piece).toFixed(6);
        newCurrentVolume = NP.times(nowCargoOptions.pieceVolume, piece).toFixed(6);

        const wPrice = NP.times(tmpCurrentObject.waybillFeeDTO.weightPrice, newCurrentWeight);
        const vPrice = NP.times(tmpCurrentObject.waybillFeeDTO.volumePrice, newCurrentVolume);
        newCurrentFreight = NP.plus(wPrice, vPrice);
      }
    } else if (splitType === 'CUSTOM') { // 自定义拆单
      newCurrentWeight = tmpCurrentObject.weight;
      newCurrentVolume = tmpCurrentObject.cubage;

      const wPrice = NP.times(tmpCurrentObject.waybillFeeDTO.weightPrice, newCurrentWeight);
      const vPrice = NP.times(tmpCurrentObject.waybillFeeDTO.volumePrice, newCurrentVolume);
      newCurrentFreight = NP.plus(wPrice, vPrice);
    }

    // if (tmpOriginObject.cargoResidualPiece <= piece) {
    //   newLeftPiece += backPiece;
    //   newLeftWeight += NP.times(backPiece, nowCargoOptions.pieceWeight);
    //   newLeftVolume += NP.times(backPiece, nowCargoOptions.pieceVolume);
    // } else {
    // 总剩余件数应该是不变的，所以需要一个全局变量来进行保存控制
    const obj = nowCargoTotalResidual.filter(item => item.id === nowCargoOptions.id)[0];
    newLeftPiece = NP.minus(obj.totalPiece, piece);
    newLeftWeight = NP.minus(obj.totalWeight, newCurrentWeight);
    newLeftVolume = NP.minus(obj.totalVolume, newCurrentVolume);
    newLeftFreight = NP.minus(obj.totalFreight, newCurrentFreight);
    // }

    originData = { newLeftPiece, newLeftWeight, newLeftVolume, newLeftFreight };
    currentData = { newCurrentWeight, newCurrentVolume, newCurrentFreight };

    return { originData, currentData, id: nowCargoOptions.id };
  }

  render() {
    const { isShowSplitModal, cancelSplitModal, sheetNo, splitType } = this.props;
    const { leftStowageProps, existSplitInfosProps, currentSplitProps } = this.getProps();

    return (
      <Modal
        title="拆单"
        visible={isShowSplitModal}
        onOk={this.onSplitOk}
        onCancel={cancelSplitModal}
        width={1200}
      >
        <div style={{ marginBottom: 20 }}>运单号：{sheetNo}</div>
        <HTable {...leftStowageProps} style={{ marginTop: 0 }} />
        <div style={{ margin: '20px 0' }}>已有拆单</div>
        <HTable {...existSplitInfosProps} style={{ marginTop: 0 }} />
        <div style={{ margin: '20px 0', display: 'flex', justifyContent: 'space-between' }}>
          <span>当前拆单</span>
          <span>拆单方式：
            <RadioGroup
              value={splitType}
              style={{ marginLeft: 20 }}
              onChange={e => this.onChangeWaybillSearch(e.target.value, 'splitType')}
            >
              <Radio value="PACKAGE" key="按件数">按件数</Radio>
              <Radio value="CUSTOM" key="自定义">自定义</Radio>
            </RadioGroup>
          </span>
        </div>
        <HTable {...currentSplitProps} style={{ marginTop: 0 }} />
      </Modal>
    );
  }
}

export default Form.create()(SplitModal);
