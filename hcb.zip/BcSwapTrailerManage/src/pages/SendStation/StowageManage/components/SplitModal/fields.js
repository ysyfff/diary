
import { formatValue, defaultKey } from 'utils/formatValue';
import { stowageStatus } from 'configs/maps';

// 原始运单数据
export const leftWaybillFields = [{
  key: 'cargoName',
  name: '货物品名',
  render: formatValue
}, {
  key: 'cargoPiece',
  name: '总件数',
  render: formatValue
}, {
  key: 'cargoWeight',
  name: '总重量（千克）',
  render: formatValue
}, {
  key: 'cargoVolume',
  name: '总体积（方）',
  render: formatValue
}, {
  key: 'cargoResidualPiece',
  name: '剩余件数（件）', // 总剩余件数
  render: a => (<span style={{ color: 'red' }}>{a}</span>)
}, {
  key: 'cargoResidualWeight',
  name: '剩余重量（千克）', // 总剩余重量
  render: a => (<span style={{ color: 'red' }}>{a}</span>)
}, {
  key: 'cargoResidualVolume',
  name: '剩余体积（方）', // 总剩余体积
  render: a => (<span style={{ color: 'red' }}>{a}</span>)
}, {
  key: 'cargoResidualFreight',
  name: '待分摊运费（元）',
  render: a => (<span style={{ color: 'red' }}>{a}</span>)
}];


// 已有拆单
export const existSplitFields = [{
  key: 'splitNo',
  name: '子运单号',
  render: a => a || defaultKey
}, {
  key: 'stowageNo',
  name: '配载单号',
  render: formatValue
}, {
  key: 'stowageStatus',
  name: '配载状态',
  render: a => stowageStatus.filter(item => item.status === a)[0].name
}, {
  key: 'cargoName',
  name: '货物品名',
  render: formatValue
}, {
  key: 'packages',
  name: '件数（件）',
  render: formatValue
}, {
  key: 'weight',
  name: '重量（千克）',
  render: formatValue
}, {
  key: 'cubage',
  name: '体积（方）',
  render: formatValue
}, {
  key: 'freight',
  name: '已分摊运费（元）',
  render: formatValue
}];

// 当前拆单
export const currentSplitFields = [{
  key: 'splitNo',
  name: '子运单号',
  render: a => a || defaultKey
}, {
  key: 'stowageNo',
  name: '配载单号',
  render: formatValue
}, {
  key: 'splitStatus',
  name: '配载状态',
  render: () => '--'
}];
