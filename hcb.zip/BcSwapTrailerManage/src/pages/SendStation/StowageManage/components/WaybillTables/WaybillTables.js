import { Input, Select, Button, Checkbox, Modal } from 'antd';
import { HTable } from 'carno';
import _ from 'lodash';
import { tableFields, loadRemark } from './fields';

const { Option } = Select;
const search = { pn: 1, ps: 500 };

export default class WaybillTables extends React.PureComponent {
  state = {
    sheetNo: '',
    finishSheetNo: '', // 装车清单查询
    tmpFinishSheetNo: '',
    from: '',
    to: '',
    isShowRemarkModal: false,
    tmpRemark: '',
    disabledAdd: [] // 所有当前已禁用选择的项
  }

  componentWillReceiveProps = (props) => {
    const { disabledAdd } = this.state;
    if (!disabledAdd.length) {
      const _disabledAdd = disabledAdd.slice();
      const { nowStowage } = props;
      const { splitCargoList = [] } = nowStowage;
      (splitCargoList || []).forEach((item) => {
        _disabledAdd.push(item.waybillNo);
      });
      this.setState({ disabledAdd: _disabledAdd });
    }
  }

  onChangeField = (value, field) => {
    this.setState({
      [field]: value
    });
  }

  onWaybillSearch = () => {
    const { getStowageList, mainBusiness } = this.props;
    const { from, to, sheetNo } = this.state;
    getStowageList({ waybillNo: sheetNo, from, to, mainBusiness });
  }

  onChangeStowage = (e, b) => {
    if (!e.target.checked) return;
    const { nowStowage, updateState } = this.props;
    const { disabledAdd } = this.state;
    const { splitCargoList } = nowStowage;
    const _splitCargoList = splitCargoList.slice();
    const _disabledAdd = disabledAdd.slice();

    // 禁用左边项
    _disabledAdd.push(b.waybillNo);
    this.setState({ disabledAdd: _disabledAdd });

    // 增加右边
    const _b = { ...b }; // 避免左右引用影响
    _splitCargoList.push(_b);
    updateState({
      nowStowage: {
        ...nowStowage,
        splitCargoList: _splitCargoList
      }
    });
  }

  onResetWaybillSearch = () => {
    const { getStowageList, mainBusiness } = this.props;
    this.setState({
      sheetNo: '',
      from: '',
      to: ''
    });
    getStowageList({ mainBusiness });
  }

  onRemoveWaybill = (b) => {
    const { updateState, nowStowage, updateParentState, splitedWaybills } = this.props;
    const { disabledAdd } = this.state;
    const { splitCargoList } = nowStowage;
    const _splitCargoList = splitCargoList.slice();
    const _disabledAdd = disabledAdd.slice();
    const disabledIndex = _.findIndex(disabledAdd, item => item === b.waybillNo);
    if (_disabledAdd[disabledIndex]) {
      _disabledAdd.splice(disabledIndex, 1);
      this.setState({ disabledAdd: _disabledAdd });
    }
    const selectedWaybillIndex = _.findIndex(splitCargoList, item => item.sheetNo === b.sheetNo);
    _splitCargoList.splice(selectedWaybillIndex, 1);
    updateState({
      nowStowage: {
        ...nowStowage,
        splitCargoList: _splitCargoList
      }
    });
    // 移除子单栈中相同单号的数据
    let _splitedWaybills = splitedWaybills.slice();
    _splitedWaybills = _splitedWaybills.filter(item => item.waybillNo !== b.waybillNo);
    updateParentState({
      splitedWaybills: _splitedWaybills
    });
  }

  setStowageRemark = () => {
    const { nowStowage, updateState } = this.props;
    const { index, tmpRemark } = this.state;
    const { splitCargoList } = nowStowage;
    const _splitCargoList = splitCargoList.slice();

    _splitCargoList[index].loadRemark = tmpRemark;
    updateState({ nowStowage: { ...nowStowage, splitCargoList: _splitCargoList } });
    this.setState({
      isShowRemarkModal: false
    });
  }

  getTableProps() {
    const { loading, stowageList, splitCargoList } = this.props;
    const { tmpFinishSheetNo } = this.state;
    const { waitingSelectFields, finishSelectFields } = this.getFields();
    let _splitCargoList = splitCargoList.slice();
    if (tmpFinishSheetNo) {
      _splitCargoList = _splitCargoList.filter(x => x.sheetNo.indexOf(tmpFinishSheetNo) > -1);
    }

    return {
      waitingSelectProps: {
        fields: waitingSelectFields,
        search,
        loading: loading.list,
        scroll: { x: 1000, y: 300 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
        dataSource: stowageList
      },
      finishSelectProps: {
        fields: finishSelectFields,
        dataSource: _splitCargoList,
        search,
        loading: loading.list,
        scroll: { x: 1180, y: 300 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 }
      },
    };
  }

  getFields() {
    const { disabledAdd } = this.state;

    const waitingSelectColumns = {
      key: 'action',
      name: '选择',
      fixed: 'left',
      width: 60,
      render: (a, b, i) => (
        <Checkbox
          checked={disabledAdd.includes(b.waybillNo)}
          onChange={e => this.onChangeStowage(e, b, i)}
          disabled={disabledAdd.includes(b.waybillNo)}
        />
      )
    };
    const finishSelectColumns = {
      key: 'action',
      name: '操作',
      width: 110,
      render: (a, b) => (
        [
          <a onClick={() => this.showSplitModal(b)} key="split" style={{ marginLeft: 4 }}>拆单</a>,
          <a onClick={() => this.onRemoveWaybill(b)} key="remove" style={{ marginLeft: 4 }}>移除</a>,
          <a onClick={() => this.showRemarkModal(b)} key="remark" style={{ marginLeft: 4 }}>备注</a>
        ]
      )
    };
    const [finishSelectFirst, ...finishSelectLast] = tableFields;

    return {
      waitingSelectFields: [waitingSelectColumns, ...tableFields],
      finishSelectFields: [finishSelectFirst, finishSelectColumns, ...finishSelectLast, loadRemark]
    };
  }

  showRemarkModal = (b) => {
    const { splitCargoList } = this.props;
    const selectedWaybillIndex = _.findIndex(splitCargoList, item => item.sheetNo === b.sheetNo);
    this.setState({
      tmpRemark: '',
      index: selectedWaybillIndex,
      isShowRemarkModal: true
    });
  }

  cancelShowRemarkModal = () => {
    this.setState({
      isShowRemarkModal: false
    });
  }

  showSplitModal = (splitWaybill) => {
    const { getStowageSplitInfo, updateParentState, splitCargoList } = this.props;
    const params = {
      waybillNo: splitWaybill.waybillNo,
      stowageNo: splitWaybill.stowageNo || '',
      splitNo: splitWaybill.splitNo || '',
    };
    getStowageSplitInfo(params);
    // 注意：当已选列表查询后在拆单时，序号会发生变化，所以从原始数据查询当前单的序号来进行操作
    const selectedWaybillIndex = _.findIndex(splitCargoList, item => item.sheetNo === splitWaybill.sheetNo);
    updateParentState({
      nowSplitIndex: selectedWaybillIndex, // 当前拆单的运单序号，方便回写
      waybillNo: splitWaybill.waybillNo,
      sheetNo: splitWaybill.sheetNo,
      hasSplit: splitWaybill.hasSplit || false,
      selected: splitWaybill.selected || splitWaybill.stockCargoIds,
      isShowSplitModal: true
    });
  }

  finishWaybillSearch = () => {
    const { finishSheetNo } = this.state;
    this.setState({
      tmpFinishSheetNo: finishSheetNo
    });
  }

  resetFinishWaybillSearch = () => {
    this.setState({
      finishSheetNo: '',
      tmpFinishSheetNo: ''
    });
  }

  render() {
    const { siteList = [], getSiteList } = this.props;
    const { waitingSelectProps, finishSelectProps } = this.getTableProps();

    return (
      <div className="add-waybill">
        <h1>
          选择运单
        </h1>
        <div className="cont">
          <div className="l-cont">
            <h2>可选运单</h2>
            <div className="search">
              <div style={{ paddingTop: 10, paddingBottom: 10 }}>
                <Input
                  placeholder="请输入运单号"
                  className="cond"
                  style={{ width: 120 }}
                  value={this.state.sheetNo}
                  onChange={e => this.onChangeField(e.target.value, 'sheetNo')}
                />
                <Select
                  showSearch
                  value={this.state.from}
                  style={{ width: 120, marginLeft: 2 }}
                  placeholder="请选择发站"
                  optionFilterProp="children"
                  onBlur={() => getSiteList({ ps: 1000 })}
                  onSearch={value => getSiteList({ nameLike: value, ps: 1000 })}
                  onChange={value => this.onChangeField(value, 'from')}
                >
                  <Option value="">请选择发站</Option>
                  {
                    (siteList || []).map(({ id, name }) => <Option value={id} key={id}>{name}</Option>)
                  }
                </Select>
                <Select
                  showSearch
                  value={this.state.to}
                  style={{ width: 120, marginLeft: 2 }}
                  placeholder="请选择到站"
                  optionFilterProp="children"
                  onBlur={() => getSiteList({ ps: 1000 })}
                  onSearch={value => getSiteList({ nameLike: value, ps: 1000 })}
                  onChange={value => this.onChangeField(value, 'to')}
                >
                  <Option value="">请选择到站</Option>
                  {
                    (siteList || []).map(({ id, name }) => <Option value={id} key={id}>{name}</Option>)
                  }
                </Select>
                <Button type="primary" className="btn" onClick={this.onWaybillSearch}>查询</Button>
                <Button className="btn" onClick={this.onResetWaybillSearch}>重置</Button>
              </div>
              <div style={{ height: 370, background: '#fff' }}>
                <HTable {...waitingSelectProps} style={{ marginTop: 0 }} />
              </div>
            </div>
          </div>
          <div className="actions" />
          <div className="r-cont">
            <h2>装车清单</h2>
            <div className="search">
              <div style={{ paddingTop: 10, paddingBottom: 10 }}>
                <Input
                  placeholder="请输入运单号"
                  className="cond"
                  style={{ width: 120 }}
                  value={this.state.finishSheetNo}
                  onChange={e => this.onChangeField(e.target.value, 'finishSheetNo')}
                />
                <Button type="primary" className="btn" onClick={this.finishWaybillSearch}>查询</Button>
                <Button className="btn" onClick={this.resetFinishWaybillSearch}>重置</Button>
              </div>
              <div style={{ height: 370, background: '#fff' }}>
                <HTable {...finishSelectProps} style={{ marginTop: 0 }} />
              </div>
            </div>
          </div>
        </div>
        <Modal
          title="备注"
          visible={this.state.isShowRemarkModal}
          onOk={this.setStowageRemark}
          onCancel={this.cancelShowRemarkModal}
          width={300}
        >
        备注：
          <Input
            placeholder="请输入装车备注"
            style={{ width: 200 }}
            value={this.state.tmpRemark}
            onChange={e => this.onChangeField(e.target.value, 'tmpRemark')}
          />
        </Modal>
      </div>
    );
  }
}
