import { sendWays } from 'configs/constants';
import { formatValue } from 'utils/formatValue';

export const tableFields = [{
  key: 'sheetNo',
  name: '运单号',
  width: 100,
  render: (a, b) =>
    <a href={`#/waybillManage/detailWaybill/${b.waybillNo}`} target="_blank" rel="noopener noreferrer">{a}</a>
}, {
  key: 'putDayNum',
  name: '库存时间',
  width: 100,
  render: (a) => {
    if (a < 24 && a > 12) return <span style={{ color: '#faad14' }}>{`${a}小时`}</span>;
    if (a >= 24) return <span style={{ color: 'red' }}>{`${a}小时`}</span>;
    return `${a}小时`;
  }
}, {
  key: 'toSite',
  name: '到站',
  width: 90,
  render: formatValue
}, {
  key: 'cargoNames',
  name: '货名',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualPiece',
  name: '可装车件数',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualWeight',
  name: '可装车重量',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualVolume',
  name: '可装车体积',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualFreight',
  name: '可分摊运费',
  width: 90,
  render: formatValue
}, {
  key: 'dispatchType',
  name: '产品时效',
  width: 90,
  render: a => a && sendWays.filter(item => item.key === a)[0].value
}, {
  key: 'packs',
  name: '包装',
  width: 120,
  render: formatValue
}, {
  key: 'remark',
  name: '运单备注',
  width: 120,
  render: formatValue
}];

export const loadRemark = {
  key: 'loadRemark',
  name: '装车备注',
  width: 140,
  render: formatValue
};
