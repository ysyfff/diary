import { Form, Select } from 'antd';
import { STOWAGE_TYPE } from 'configs/maps';

const { Option } = Select;
const { Item } = Form;
// const { TextArea } = Input;

class BaseInfo extends React.PureComponent {
  onFieldsChange = (props, field) => {
    const { nowStowage, stowage, updateState } = props;
    const _stowage = { ...stowage };

    if (field.siteLineId) _stowage.siteLineId = field.siteLineId.value;
    if (field.trailerId) _stowage.trailerId = field.trailerId.value;

    updateState({
      nowStowage: {
        ...nowStowage,
        stowage: _stowage
      }
    });
  }

  onSelectFieldChange = (value, field) => {
    if (field === 'type' && value === 'VEHICLESERVICE') {
      window.location.hash = '#/sendStation/stowageManage/addStowage';
    }
  }

  render() {
    const { form, siteLineList = [], compartmentList = [], nowStowage, stowage = {}, isAdd, getSiteLineList,
      getCompartmentList } = this.props;

    const { getFieldDecorator } = form;
    const { siteLineId = '', trailerId = '' } = stowage || {};

    const _stowageTypes = [];
    STOWAGE_TYPE.forEach((item) => {
      _stowageTypes.push(<Option value={item.key} key={item.key}>{item.name}</Option>);
    });

    return (
      <div className="form" style={{ display: 'flex', justifyContent: 'space-between' }}>
        <Form layout="inline" >
          <Item label="主营服务">
            {getFieldDecorator('type', {
              initialValue: 'CHANNELSERVICE',
              rules: [
                { required: true, message: '请选择主营服务' },
              ],
            })(
              <Select
                disabled={!isAdd}
                style={{ width: 180 }}
                placeholder="请选择主营服务"
                onChange={value => this.onSelectFieldChange(value, 'type')}
              >
                {_stowageTypes}
              </Select>
            )}
          </Item>
          <Item label="发车线路">
            {getFieldDecorator('siteLineId', {
              initialValue: siteLineId,
              rules: [
                { required: true, message: '请选择线路' },
              ],
            })(
              <Select
                showSearch
                disabled={!isAdd}
                style={{ width: 180 }}
                placeholder="请选择线路"
                optionFilterProp="children"
                onBlur={() => getSiteLineList({ ps: 1000 })}
                onSearch={value => getSiteLineList({ nameLike: value, ps: 1000 })}
              >
                <Option value="">请选择线路</Option>
                {
                  siteLineList.map(({ id, name }) => <Option value={id} key={id}>{name}</Option>)
                }
              </Select>
            )}
          </Item>
          <Item label="挂车车牌">
            {getFieldDecorator('trailerId', {
              initialValue: trailerId,
              rules: [
                { required: true, message: '请选择挂车车牌' },
              ],
            })(
              <Select
                showSearch
                disabled={!isAdd}
                style={{ width: 180 }}
                placeholder="请选择挂车车牌"
                optionFilterProp="children"
                onBlur={() => getCompartmentList({ ps: 1000 })}
                onSearch={value => getCompartmentList({ nameLike: value, ps: 1000 })}
              >
                <Option value="">请选择挂车车牌</Option>
                {
                  compartmentList.map(({ id, plateNumber }) => <Option value={id} key={id}>{plateNumber}</Option>)
                }
              </Select>
            )}
          </Item>
        </Form>
        {
          nowStowage.stowage && nowStowage.stowage.stowageNo
            ? <div>配载单号：{(nowStowage.stowage && nowStowage.stowage.stowageNo) || ''}</div>
            : null
        }
      </div>
    );
  }
}

export default Form.create({
  onFieldsChange: (props, field) => {
    props.BaseInfoRef.onFieldsChange(props, field);
  }
})(BaseInfo);
