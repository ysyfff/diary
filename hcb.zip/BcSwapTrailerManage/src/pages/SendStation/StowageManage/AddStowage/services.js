import http from 'utils/http';

const { post } = http.create('dapt');

// 获取发车线路
export function getSiteLineList(param) {
  return post('/web/m/siteline/list', param);
}

// 获取所有挂车
export function getCompartmentList(param) {
  return post('/web/e/compartment/list', param);
}

// 获取站点信息
export function getSiteList(param) {
  return post('/web/e/site/search', param);
}

// 查询所有运单
export function getStowageList(param) {
  return post('/web/m/stowage/stock/list', param);
}

// 创建配载单
export function createStowage(param) {
  return post('/web/m/stowage/create', param, { contentType: 'json' });
}
