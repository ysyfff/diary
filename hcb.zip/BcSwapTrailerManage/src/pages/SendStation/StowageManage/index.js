import { connect } from 'dva';
import { Row, Col, Button, Popover, Icon, Modal, Input, Radio } from 'antd';
import { HTable } from 'carno';
import { AuthortyWarpper } from 'components';
import { bind } from 'bind-decorator';
import _ from 'lodash';
import buttonAuthoritesConfig from 'configs/buttonAuthoritesConfig';
import SearchBar from './SearchBar';
import styles from './index.less';

@connect(({ stowageManage }) => ({ ...stowageManage }), dispatch => ({
  getList(param) {
    dispatch({ type: 'stowageManage/updateSearch', payload: param });
    dispatch({ type: 'stowageManage/getList' });
  },
  updateSearch(param) {
    dispatch({ type: 'stowageManage/updateSearch', payload: param });
  },
  cancel(param) {
    dispatch({ type: 'stowageManage/cancel', payload: param });
  },
  complete(param) {
    dispatch({ type: 'stowageManage/complete', payload: param });
  },
  enterSealNo(param) {
    dispatch({ type: 'stowageManage/enterSealNo', payload: param });
  },
  updateSealNo(param) {
    dispatch({ type: 'stowageManage/updateSealNo', payload: param });
  },
  resetSearch() {
    dispatch({ type: 'stowageManage/resetSearch' });
  },
}))
export default class StowageManage extends React.Component {
  state = {
    finishStowageModal: false,
    cancelStowageModal: false,
    enterSealNoModal: false,
    nowStowage: {},
    sealNo: [],
    stowageNo: '',
    // nowSelectBtn: '',
    visiblepop: this.props.list.map(() => false),
    trailerPlateNumber: '',
    sealIpts: 3,
    isUpdateSealno: false
  }

  componentWillReceiveProps(a) {
    this.setState({
      visiblepop: a.list.map(() => false)
    });
  }

  @bind
  onRef(ref) {
    this.searchBar = ref;
  }

  @bind
  onDeleteSealNo(i) {
    const { sealNo, sealIpts } = this.state;
    const _sealIpts = sealIpts - 1;
    const _sealNo = sealNo.slice();
    _sealNo.splice(i, 1);
    this.setState({
      sealNo: _sealNo,
      sealIpts: _sealIpts
    });
  }

  @bind
  onAddSealNo() {
    const { sealIpts } = this.state;
    if (sealIpts !== 5) {
      const _sealIpts = sealIpts + 1;
      this.setState({
        sealIpts: _sealIpts
      });
    }
  }

  @bind
  setSealNo(e, index) {
    const value = e.target.value;
    const { sealNo } = this.state;
    const _sealNo = sealNo.slice();
    _sealNo[index] = value;
    this.setState({
      sealNo: _sealNo
    });
  }

  getProps() {
    const { tableFields, search, total, list, loading, getList } = this.props;
    const { pn, ps } = search;

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getList({ pn }),
      onShowSizeChange: (current, size) => getList({ ps: size, pn: 1 })
    };

    const columns = [
      {
        key: 'action',
        name: '操作',
        render: (a, b, i) => (<Popover
          placement="right"
          trigger="hover"
          visible={this.state.visiblepop[i]}
          onVisibleChange={() => this.changePop(i, false)}
          content={
            <div onClick={() => this.changePop(i, false)}>
              <ul className="operate-button">
                {
                  b.status === 'CARLOAD_LOADING' || b.status === 'CARPOOL_LOADING'
                    ? [
                      b.type === 'VEHICLESERVICE'
                        ? <AuthortyWarpper code={buttonAuthoritesConfig.stowage.modify}>
                          <li key="update">
                            <a
                              href={`#/sendStation/stowageManage/editStowage/${b.stowageNo}`}
                              targe="_blank"
                              rel="noopener noreferrer"
                            >修改配载</a>
                          </li>
                        </AuthortyWarpper>
                        : null,
                      b.type === 'CHANNELSERVICE'
                        ? <AuthortyWarpper code={buttonAuthoritesConfig.stowage.modify}>
                          <li key="update">
                            <a
                              href={`#/sendStation/stowageManage/editSharing/${b.stowageNo}`}
                              target="_blank"
                              rel="noopener noreferrer"
                            >修改配载</a>
                          </li>
                        </AuthortyWarpper>
                        : null,
                      <AuthortyWarpper code={buttonAuthoritesConfig.stowage.loadComplete}>
                        <li key="finish"><a onClick={() => this.handleShowFinishStowageModal(false, b)}>完成装车</a></li>
                      </AuthortyWarpper>
                    ]
                    : null
                }
                {
                  b.status === 'CARLOAD_LOADED' || b.status === 'CARPOOL_LOADED'
                    ? [
                      <AuthortyWarpper code={buttonAuthoritesConfig.stowage.stowageDispatch}>
                        <li key="truck">
                          <a
                            onClick={() => this.truckDispatch(b.stowageNo)}
                            target="_blank"
                            rel="noopener noreferrer"
                          >调度派车</a></li>
                      </AuthortyWarpper>,
                      <AuthortyWarpper code={buttonAuthoritesConfig.stowage.sealNoEntering}>
                        <li key="updateseal">
                          <a onClick={() => this.handleShowFinishStowageModal(true, b)}>修改封签</a>
                        </li>
                      </AuthortyWarpper>
                    ]
                    : null
                }
                {
                  b.status !== 'DISPATCHED' && b.status !== 'IN_TRANSIT' && b.status !== 'ARRIVED'
                    ? <AuthortyWarpper code={buttonAuthoritesConfig.stowage.loadCancel}>
                      <li><a onClick={() => this.handleShowCancelStowageModal(b)}>取消装车</a></li>
                    </AuthortyWarpper>
                    : null
                }
                <li>
                  <a
                    href={`#/sendStation/stowageManage/stowageDetail/${b.stowageNo}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >查看详情</a></li>
              </ul>
            </div>
          }
        ><a><Icon type="menu-unfold" onMouseOver={() => this.changePop(i, true)} /></a></Popover>
        )
      }];

    const _tableFields = _.cloneDeep(tableFields);
    _tableFields.splice(3, 0, ...columns);

    return {
      tableProps: {
        fields: _tableFields,
        dataSource: list,
        loading: loading.list,
        search,
        scroll: { x: 3000 },
        pagination,
        locale: { emptyText: '暂无数据' },
        style: { marginTop: 16 },
      },
    };
  }

  truckDispatch = (stowageNo) => {
    window.open(`#/sendStation/truckSend/truckDispatch/${stowageNo}`, '_blank');
  }

  @bind
  handleShowFinishStowageModal(status, b) {
    const { sealNo } = this.state;
    let _sealNo = sealNo.slice();
    if (status) {
      _sealNo = b.sealNo.split(',');
    }
    this.setState({
      sealNo: status ? _sealNo : [],
      sealIpts: status ? _sealNo.length : 3,
      stowageNo: b.stowageNo,
      trailerPlateNumber: b.trailerPlateNumber,
      finishStowageModal: true,
      isUpdateSealno: status // 是修改封签
    });
  }

  @bind
  handleCancelFinishStowageModal() {
    this.setState({
      finishStowageModal: false
    });
  }

  @bind
  handleShowCancelStowageModal(b) {
    this.setState({
      stowageNo: b.stowageNo,
      trailerPlateNumber: b.trailerPlateNumber,
      cancelStowageModal: true
    });
  }

  @bind
  handleCancelCancelStowageModal() {
    this.setState({
      cancelStowageModal: false
    });
  }

  @bind
  handleTabChange(e) {
    const status = e.target.value;
    const { getList } = this.props;
    // this.setState({
    //   nowSelectBtn: status
    // });
    getList({ status, pn: 1 });
  }

  @bind
  finishStowage() {
    const { complete, updateSealNo } = this.props;
    const { sealNo, stowageNo, isUpdateSealno } = this.state;
    if (sealNo.length === 0) {
      Modal.error({ title: '至少填入一个封签号！' });
      return;
    }
    const _sealNo = sealNo.filter(x => x);
    if (isUpdateSealno) {
      updateSealNo({ stowageNo, sealNo: _sealNo.join(',') });
    } else {
      complete({ stowageNo, sealNo: _sealNo.join(',') });
    }
    this.setState({
      sealNo: [],
      finishStowageModal: false
    });
  }

  @bind
  cancelStowage() {
    const { cancel } = this.props;
    const { stowageNo } = this.state;
    cancel({ stowageNo });
    this.setState({
      cancelStowageModal: false
    });
  }

  @bind
  handleCancelEnterSealNoModal() {
    this.setState({
      enterSealNoModal: false
    });
  }

  @bind
  enterSealNo() {
    const { enterSealNo } = this.props;
    const { sealNo, stowageNo } = this.state;

    enterSealNo({ stowageNo, sealNo });
    this.handleCancelEnterSealNoModal();
    this.setState({
      sealNo: []
    });
  }

  @bind
  exportStowage() {
    this.searchBar.exportStowage();
  }

  @bind
  pushToAddStowage() { // eslint-disable-line
    window.open('#/sendStation/stowageManage/addSharing', '_blank');
  }

  @bind
  changePop(i, status) {
    const { visiblepop } = this.state;
    let _visiblepop = visiblepop.slice();
    _visiblepop = _visiblepop.map(() => false);
    _visiblepop.splice(i, 1, status);
    this.setState({
      visiblepop: _visiblepop
    });
  }

  render() {
    const { getList, search, updateSearch, siteList, resetSearch, siteLineList = [] } = this.props;
    const { tableProps } = this.getProps();
    const { sealIpts, isUpdateSealno } = this.state;
    const SearchBarProps = {
      search,
      updateSearch,
      onSearch: getList,
      siteList,
      siteLineList,
      resetSearch,
      getList
    };

    const _sealIpts = [];
    for (let i = 0; i < sealIpts; i += 1) {
      _sealIpts.push(
        <div key={`seal_${i}`}>
          <span>封签{i + 1}：</span>
          <Input
            placeholder="请输入封签号"
            maxLength={20}
            style={{ width: 180, marginTop: 10 }}
            onInput={e => this.setSealNo(e, i)}
            value={this.state.sealNo[i]}
          />
          {
            i !== 0 ?
              <a onClick={() => this.onDeleteSealNo(i)} style={{ marginLeft: 4 }}>删除</a>
              : null
          }
        </div>
      );
    }

    return (
      <div className={styles['stowage-manage']}>
        <SearchBar {...SearchBarProps} onRef={this.onRef} />
        <Row type="flex" justify="space-between">
          <Col span={18} style={{ paddingTop: 14 }}>
            {/* {btns} */}
            <Radio.Group buttonStyle="solid" value={search.status} onChange={this.handleTabChange}>
              <Radio.Button value="">全部</Radio.Button>
              <Radio.Button value="LOADING">装载中</Radio.Button>
              <Radio.Button value="LOADED">已装车</Radio.Button>
              <Radio.Button value="DISPATCHED">已派车</Radio.Button>
              <Radio.Button value="IN_TRANSIT">在途中</Radio.Button>
              <Radio.Button value="ARRIVED">已到达</Radio.Button>
            </Radio.Group>
          </Col>
          <Col span={6}>
            <div className="order-list-button">
              <AuthortyWarpper code={buttonAuthoritesConfig.stowage.create}>
                <Button type="primary" onClick={this.pushToAddStowage}>新建配载单</Button>
              </AuthortyWarpper>
              <AuthortyWarpper code={buttonAuthoritesConfig.stowage.export}>
                <Button onClick={this.exportStowage}>导出表单</Button>
              </AuthortyWarpper>
            </div>
          </Col>
        </Row>
        <HTable {...tableProps} />

        <Modal
          title={isUpdateSealno ? '修改封签' : '完成装车'}
          visible={this.state.finishStowageModal}
          onOk={this.finishStowage}
          okText={isUpdateSealno ? '确认修改' : '完成装车'}
          onCancel={this.handleCancelFinishStowageModal}
        >
          {
            isUpdateSealno ?
              <div>
                <Icon type="exclamation-circle" style={{ color: '#e2e210', fontSize: 30, marginRight: 10 }} />
                确认修改挂车【{this.state.trailerPlateNumber}】的封签号
              </div>
              :
              <div>
                <Icon type="exclamation-circle" style={{ color: '#e2e210', fontSize: 30, marginRight: 10 }} />
                确认已完成挂车【{this.state.trailerPlateNumber}】的装车
              </div>
          }

          <div style={{ marginBottom: 10, marginLeft: 40, marginTop: 10 }}>
            {_sealIpts}
            {
              this.state.sealIpts !== 5 ?
                <a onClick={this.onAddSealNo}>+ 添加</a>
                : null
            }
          </div>
        </Modal>
        <Modal
          title="取消装车"
          visible={this.state.cancelStowageModal}
          onOk={this.cancelStowage}
          okText="确认取消"
          onCancel={this.handleCancelCancelStowageModal}
        >
          <div>
            <Icon type="exclamation-circle" style={{ color: '#e2e210', fontSize: 30, marginRight: 10 }} />
            <span>确认取消挂车{this.state.trailerPlateNumber}的装车</span>
          </div>
        </Modal>
      </div>
    );
  }
}
