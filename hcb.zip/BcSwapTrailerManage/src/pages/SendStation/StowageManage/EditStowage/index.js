/**
 * 整车的修改
 */

import { connect } from 'dva';
import { HTable } from 'carno';
import NP from 'number-precision';
import { formatValue } from 'utils/formatValue';
import _ from 'lodash';
import { Form, Input, Button, Row, Select, Radio, Checkbox, Modal } from 'antd';
import { STOWAGE_TYPE } from 'configs/maps';
import styles from './index.less';

const FormItem = Form.Item;
// const { TextArea } = Input;
const Option = Select.Option;
// const RadioGroup = Radio.Group;

@connect(({ editStowage }) => ({ ...editStowage }), dispatch => ({
  getStowageList(param) {
    dispatch({ type: 'editStowage/getStowageList', payload: param });
  },
  editStowage(param) {
    dispatch({ type: 'editStowage/editStowage', payload: param });
  },
  updateState(param) {
    dispatch({ type: 'editStowage/updateState', payload: param });
  },
  getSiteLineList(param) {
    dispatch({ type: 'addStowage/getSiteLineList', payload: param });
  },
  getCompartmentList(param) {
    dispatch({ type: 'addStowage/getCompartmentList', payload: param });
  },
  getSiteList(param) {
    dispatch({ type: 'addStowage/getSiteList', payload: param });
  },
  dispatch,
}))
class EditStowage extends React.Component {
  state = {
    from: '',
    to: '',
    sheetNo: '',
    index: '',
    isShowRemarkModal: false,
    tmpRemark: ''
  }

  onChangeWaybillSearch = (value, field) => {
    this.setState({
      [field]: value
    });
  }

  onWaybillSearch = () => {
    const { getStowageList } = this.props;
    const { from, to, sheetNo } = this.state;
    getStowageList({ waybillNo: sheetNo, from, to, mainBusiness: 'VEHICLESERVICE' });
  }

  onResetWaybillSearch = () => {
    const { getStowageList } = this.props;
    this.setState({
      sheetNo: '',
      from: '',
      to: ''
    });
    getStowageList({ mainBusiness: 'VEHICLESERVICE' });
  }

  onSelectFieldChange = (value, field) => {
    const { nowStowage, updateState } = this.props;
    const _nowStowage = _.cloneDeep(nowStowage);
    const { stowage } = _nowStowage;
    stowage[field] = value;
    updateState({ nowStowage: _nowStowage });
  }

  onChangeStowage = (e, b, i) => {
    if (!e.target.checked) return;
    const { nowStowage, updateState, stowageList } = this.props;
    const { splitCargoList } = nowStowage;
    const _splitCargoList = _.cloneDeep(splitCargoList);
    _splitCargoList.push(b);
    if (_splitCargoList.length > 1) {
      Modal.error({ title: '整车只能选择一条运单' });
      return;
    }

    const _stowageList = [...stowageList];
    // 禁用左边
    _stowageList[i].disabled = true;
    updateState({ stowageList: _stowageList });

    const _nowStowage = _.cloneDeep(nowStowage);
    _nowStowage.splitCargoList = _splitCargoList;
    if (b.compartmentId) {
      _nowStowage.stowage.trailerId = b.compartmentId;
    }
    updateState({ nowStowage: _nowStowage });
  }

  onRemoveWaybill = (b) => {
    const { nowStowage, updateState, stowageList } = this.props;
    const _nowStowage = _.cloneDeep(nowStowage);
    _nowStowage.splitCargoList = []; // 直接右边置为空
    // 启用左边
    let _stowageList = _.cloneDeep(stowageList);
    _stowageList = stowageList.map((item) => {
      if (item.waybillNo === b.waybillNo) {
        return { ...item, disabled: false };
      }
      return item;
    });
    updateState({ nowStowage: _nowStowage, stowageList: _stowageList });
  }

  onChangeRemark = (e) => {
    const tmpRemark = e.target.value;
    this.setState({
      tmpRemark
    });
  }

  onSaveStowage = () => {
    const { nowStowage } = this.props;
    const { splitCargoList } = nowStowage;

    if (!splitCargoList.length) {
      Modal.error({ title: '至少选择一个运单' });
      return;
    }
    // 检查分摊费用是否达标
    // const flag = this.checkFieightOk();
    // if (!flag) {
    //   Modal.confirm({
    //     title: '提示',
    //     content: '已配载运单的运费并未达到该线路的最低运费要求，是否仍然继续？',
    //     okText: '确认继续',
    //     cancelText: '取消',
    //     onOk: async () => {
    //       this.createStowage();
    //     }
    //   });
    // } else {
    //   this.createStowage();
    // }
    this.createStowage();
  }

  onCancelAdd = () => {
    window.location.hash = '#/sendStation/stowageManage';
  }

  setStowageRemark = () => {
    const { nowStowage, updateState } = this.props;
    const { index, tmpRemark } = this.state;
    const { splitCargoList } = nowStowage;
    const _nowStowage = _.cloneDeep(nowStowage);
    const _splitCargoList = _.cloneDeep(splitCargoList);
    _splitCargoList[index].loadRemark = tmpRemark;
    _nowStowage.splitCargoList = _splitCargoList;
    this.setState({
      // stowage: _stowage,
      isShowRemarkModal: false
    });
    updateState({ nowStowage: _nowStowage });
  }

  getProps() {
    const { tableFields, loading, stowageList, nowStowage } = this.props;
    const search = { pn: 1, ps: 500 };

    const waitingSelectColumns = {
      key: 'action',
      name: '选择',
      fixed: 'left',
      width: 60,
      render: (a, b, i) => (
        <Checkbox checked={b.disabled} onChange={e => this.onChangeStowage(e, b, i)} disabled={b.disabled} />
      )
    };

    const finishSelectColumns = {
      key: 'action',
      name: '操作',
      width: 100,
      render: (a, b, i) => (
        [
          <a onClick={() => this.onRemoveWaybill(b)} key="remove" style={{ marginLeft: 4 }}>移除</a>,
          <a onClick={() => this.showRemarkModal(i, b.remark)} key="remark" style={{ marginLeft: 4 }}>备注</a>
        ]
      )
    };

    const cargoNames = {
      key: 'cargoNames',
      name: '货名',
      width: 90,
      render: formatValue
    };

    const truckRemark = {
      key: 'loadRemark',
      name: '装车备注',
      width: 120,
      render: formatValue
    };

    const packs = {
      key: 'packs',
      name: '包装',
      width: 90,
      render: formatValue
    };

    const _tableFields = _.cloneDeep(tableFields);
    _tableFields.splice(0, 0, waitingSelectColumns);

    const _finishStowageFields = _tableFields.slice(1);
    _finishStowageFields.splice(1, 0, finishSelectColumns);
    _finishStowageFields.splice(4, 1, cargoNames);
    _finishStowageFields.splice(9, 1, packs);
    _finishStowageFields.push(truckRemark);

    return {
      waitingSelectProps: {
        fields: _tableFields,
        search,
        loading: loading.list,
        scroll: { x: 1000, y: 300 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
        dataSource: stowageList
      },
      finishSelectProps: {
        fields: _finishStowageFields,
        dataSource: nowStowage.splitCargoList || [],
        search,
        loading: loading.list,
        scroll: { x: 1140, y: 300 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      }
    };
  }

  // 用来判断配载价格是否低于最低价格
  checkFieightOk = () => {
    const { siteLineList = [], nowStowage = {} } = this.props;
    const { stowage = {}, splitCargoList } = nowStowage;
    const { siteLineId = '' } = stowage;
    let siteLine = {};
    let minPrice = 0;
    let loadPrice = 0;

    siteLine = siteLineList.filter(item => item.id === siteLineId)[0] || {};
    minPrice = siteLine.minPrice || 0;

    splitCargoList.length && splitCargoList.forEach((item) => {
      loadPrice = NP.plus(Number(loadPrice), Number(item.cargoResidualFreight));
    });
    if (loadPrice < minPrice) return false;
    return true;
  }

  createStowage = () => {
    const { nowStowage, editStowage } = this.props;
    const _nowStowage = _.cloneDeep(nowStowage);
    const { splitCargoList } = _nowStowage;
    const waybillList = [];
    const { stowage } = _nowStowage;
    waybillList.push({
      waybillNo: splitCargoList[0].waybillNo,
      remark: splitCargoList[0].loadRemark
    });
    let params = {
      type: stowage.type,
      stowageNo: stowage.stowageNo,
      siteLineId: stowage.siteLineId,
      trailerId: stowage.trailerId,
      remark: stowage.remark,
      waybillList
    };
    params = JSON.parse(JSON.stringify(params));
    editStowage(params);
  }

  // 计算载重百分比，当前车辆信息不变，传入当前已选择的货物信息
  // calculateFinishOptions = (finishStowageList = []) => {
  //   const { compartmentList = [], nowStowage = {}, siteLineList = [] } = this.props;
  //   const { stowage = {} } = nowStowage;
  //   let truck = {};
  //   let siteLine = {};
  //   let truckLoad = 0;
  //   let truckVolumne = 0;
  //   let finishLoad = 0;
  //   let finishVolumne = 0;
  //   let loadPercent = 0;
  //   let volumnePercent = 0;
  //   let loadPrice = 0;
  //   let minPrice = 0;

  //   if (stowage.trailerId) {
  //     truck = compartmentList.length && compartmentList.filter(item => item.id === stowage.trailerId)[0];
  //   }

  //   if (stowage.siteLineId) {
  //     siteLine = siteLineList.filter(item => item.id === stowage.siteLineId)[0] || {};
  //   }

  //   truckLoad = truck.truckLoad || 0;
  //   truckVolumne = truck.truckVolumne || 0;
  //   minPrice = siteLine.minPrice || 0;

  //   finishStowageList.length && finishStowageList.forEach((item) => {
  //     finishLoad = NP.plus(finishLoad, item.cargoResidualWeight).toFixed(2);
  //     finishVolumne = NP.plus(finishVolumne, item.cargoResidualVolume).toFixed(2);
  //     loadPrice = NP.plus(Number(loadPrice), Number(item.cargoResidualFreight));
  //   });

  //   if (finishLoad === 0) loadPercent = 0;
  //   else if (truckLoad === 0) loadPercent = '--';
  //   else loadPercent = NP.times((NP.divide(finishLoad, truckLoad).toFixed(4)), 100);

  //   if (finishVolumne === 0) volumnePercent = 0;
  //   else if (truckLoad === 0) volumnePercent = '--';
  //   else volumnePercent = NP.times((NP.divide(finishVolumne, truckVolumne).toFixed(4)), 100);

  //   const finishOptions = {
  //     truckLoad,
  //     truckVolumne,
  //     finishLoad,
  //     finishVolumne,
  //     loadPercent,
  //     volumnePercent,
  //     loadPrice,
  //     minPrice
  //   };

  //   return finishOptions;
  // }

  resetFilterWaybillNo = () => {
    this.setState({
      filterWaybillNo: ''
    });
  }

  showRemarkModal = (index) => {
    this.setState({
      tmpRemark: '',
      index,
      isShowRemarkModal: true
    });
  }

  cancelShowRemarkModal = () => {
    this.setState({
      isShowRemarkModal: false
    });
  }

  render() {
    const { siteLineList, compartmentList, form, siteList, nowStowage, getSiteLineList,
      getCompartmentList, getSiteList } = this.props;

    const { getFieldDecorator } = form;
    // const finishOptions = this.calculateFinishOptions(nowStowage.splitCargoList);
    const { waitingSelectProps, finishSelectProps } = this.getProps();
    const sites = [];

    siteLineList.forEach(item =>
      sites.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    const _siteList = [];
    siteList.forEach(item =>
      _siteList.push(<Option value={item.id} key={item.id}>{item.name}</Option>)
    );

    const compartments = [];
    compartmentList.forEach(item =>
      compartments.push(<Option value={item.id} key={item.id}>{item.plateNumber}</Option>)
    );

    const _stowageTypes = [];
    STOWAGE_TYPE.forEach((item) => {
      _stowageTypes.push(<Radio value={item.key} key={item.key}>{item.name}</Radio>);
    });

    return (
      <div className={styles['add-stowage']}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <div>
            <Form layout="inline" >
              <FormItem label="主营服务">
                {getFieldDecorator('type', {
                  initialValue: 'VEHICLESERVICE',
                  rules: [
                    { required: true, message: '请选择主营服务' },
                  ],
                })(
                  <Select
                    disabled
                    style={{ width: 180 }}
                    placeholder="请选择主营服务"
                    onChange={value => this.onSelectFieldChange(value, 'type')}
                  >
                    {_stowageTypes}
                  </Select>
                )}
              </FormItem>
              <FormItem label="发车线路">
                {getFieldDecorator('siteLineId', {
                  initialValue: (nowStowage.stowage && nowStowage.stowage.siteLineId) || '',
                  rules: [
                    { required: true, message: '请选择线路' },
                  ],
                })(
                  <Select
                    disabled
                    style={{ width: 180 }}
                    placeholder="请选择线路"
                    optionFilterProp="children"
                    onBlur={() => getSiteLineList({ ps: 1000 })}
                    onSearch={value => getSiteLineList({ nameLike: value, ps: 1000 })}
                    onChange={value => this.onSelectFieldChange(value, 'siteLineId')}
                  >
                    <Option value="">请选择线路</Option>
                    {sites}
                  </Select>
                )}
              </FormItem>
              <FormItem label="挂车车牌">
                {getFieldDecorator('trailerId', {
                  initialValue: (nowStowage.stowage && nowStowage.stowage.trailerId) || '',
                  rules: [
                    { required: true, message: '请选择挂车车牌' },
                  ],
                })(
                  <Select
                    disabled
                    style={{ width: 180 }}
                    placeholder="请选择挂车车牌"
                    optionFilterProp="children"
                    onBlur={() => getCompartmentList({ ps: 1000 })}
                    onSearch={value => getCompartmentList({ nameLike: value, ps: 1000 })}
                    onChange={value => this.onSelectFieldChange(value, 'trailerId')}
                  >
                    <Option value="">请选择挂车车牌</Option>
                    {compartments}
                  </Select>
                )}
              </FormItem>
            </Form>
          </div>
          <div>配载单号：{(nowStowage.stowage && nowStowage.stowage.stowageNo) || '' }</div>
        </div>
        <div className="add-waybill">
          <h1>
            选择运单
          </h1>
          <div className="cont">
            <div className="l-cont">
              <h2>可选运单</h2>
              <div className="search">
                <div style={{ paddingTop: 10, paddingBottom: 10 }}>
                  <Input
                    placeholder="请输入运单号"
                    onClick={this.showSelectTruckModal}
                    className="cond"
                    value={this.state.sheetNo}
                    onChange={e => this.onChangeWaybillSearch(e.target.value, 'sheetNo')}
                  />
                  <Select
                    showSearch
                    value={this.state.from}
                    style={{ width: 120, marginLeft: 2 }}
                    placeholder="请选择发站"
                    optionFilterProp="children"
                    onBlur={() => getSiteList({ ps: 1000 })}
                    onSearch={value => getSiteList({ nameLike: value, ps: 1000 })}
                    onChange={value => this.onChangeWaybillSearch(value, 'from')}
                  >
                    <Option value="">请选择发站</Option>
                    {_siteList}
                  </Select>
                  <Select
                    showSearch
                    value={this.state.to}
                    style={{ width: 120, marginLeft: 2 }}
                    placeholder="请选择到站"
                    optionFilterProp="children"
                    onBlur={() => getSiteList({ ps: 1000 })}
                    onSearch={value => getSiteList({ nameLike: value, ps: 1000 })}
                    onChange={value => this.onChangeWaybillSearch(value, 'to')}
                  >
                    <Option value="">请选择到站</Option>
                    {_siteList}
                  </Select>
                  <Button type="primary" className="btn" onClick={this.onWaybillSearch}>查询</Button>
                  <Button className="btn" onClick={this.onResetWaybillSearch}>重置</Button>
                </div>
                <div style={{ height: 370, background: '#fff' }}>
                  <HTable {...waitingSelectProps} style={{ marginTop: 0 }} />
                </div>
              </div>
            </div>
            <div className="actions">
              {/* <Button className="btn"> &gt; </Button>
              <Button className="btn" style={{ marginTop: 4 }}> &lt; </Button> */}
            </div>
            <div className="r-cont">
              <h2>装车清单</h2>
              <div className="search">
                <div style={{ padding: 10 }} />
                <div style={{ height: 370, background: '#fff', marginTop: 30 }}>
                  <HTable {...finishSelectProps} style={{ marginTop: 0 }} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 20, display: 'flex' }}>
          <div style={{ width: 70, lineHeight: 2 }}>备注信息：</div>
          <Input
            className="textArea"
            placeholder="请输入备注信息"
            value={(nowStowage.stowage && nowStowage.stowage.remark) || ''}
            onChange={e => this.onSelectFieldChange(e.target.value, 'remark')}
            style={{ flex: 1 }}
            maxLength={200}
          />
        </div>
        <Row className="save-btns">
          <Button type="primary" onClick={this.onSaveStowage}>保存</Button>
          <Button style={{ marginLeft: 20 }} onClick={this.onCancelAdd}>取消</Button>
        </Row>

        <Modal
          title="备注"
          visible={this.state.isShowRemarkModal}
          onOk={this.setStowageRemark}
          onCancel={this.cancelShowRemarkModal}
          width={300}
        >
        备注：
          <Input
            placeholder="请输入装车备注"
            style={{ width: 200 }}
            value={this.state.tmpRemark}
            onChange={this.onChangeRemark}
          />
        </Modal>
      </div>
    );
  }
}

export default Form.create()(EditStowage);
