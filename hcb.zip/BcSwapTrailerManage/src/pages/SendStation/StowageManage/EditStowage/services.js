import http from 'utils/http';

const { post } = http.create('dapt');

// 获取发车线路
export function getSiteLineList(param) {
  return post('/web/m/siteline/list', param);
}

// 获取站点信息
export function getSiteList(param) {
  return post('/web/e/site/search', param);
}

// 获取所有挂车
export function getCompartmentList(param) {
  return post('/web/e/compartment/list', param);
}

// 查询所有运单
export function getStowageList(param) {
  return post('/web/m/stowage/stock/list', param);
}

// 配载单详情
export function loadStowageDetail(param) {
  return post('/web/m/stowage/info', param);
}

// 编辑配载单
export function editStowage(param) {
  return post('/web/m/stowage/update', param, { contentType: 'json' });
}
