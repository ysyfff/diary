import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
import _ from 'lodash';
import { tableFields } from './fields';
import {
  getSiteLineList, getCompartmentList, getStowageList, loadStowageDetail, getSiteList,
  editStowage
} from './services';

export default Model.extend({
  namespace: 'editStowage',

  state: {
    list: [],
    loading: { list: false },
    tableFields,
    siteLineList: [],
    compartmentList: [],
    stowageList: [],
    nowStowage: {},
    siteList: [],
    stowageNo: '',
    finishOptions: {
      truckLoad: '0', // 挂车载重
      truckVolumne: '0', // 挂车空间
      finishLoad: '0', // 已配载重量
      finishVolumne: '0', // 已配载体积
      loadPercent: '0', // 载重利用率
      volumnePercent: '0', // 空间利用率
    }
  },

  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.EDIT_STOWAGE, async ({ params }) => {
        dispatch({ type: 'resetState', payload: { nowStowage: {} } });
        dispatch({ type: 'getSiteLineList', payload: { ps: 1000, pn: 1 } });
        dispatch({ type: 'getSiteList', payload: { ps: 1000, pn: 1 } });
        await dispatch({ type: 'getCompartmentList', payload: { ps: 1000, pn: 1, effective: 1 } });
        await dispatch({ type: 'getStowageList', payload: { ps: 100, pn: 1, mainBusiness: 'VEHICLESERVICE' } });
        await dispatch({ type: 'loadStowageDetail', payload: { stowageNo: params[0] } });
        dispatch({ type: 'updateState', payload: { stowageNo: params[0] } });
      });
    }
  },

  effects: {
    * getSiteLineList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getSiteLineList, 'list'), payload);
      yield update({ siteLineList: datas });
    },
    * getSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getSiteList, 'list'), payload);
      yield update({ siteList: datas });
    },
    * getCompartmentList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getCompartmentList, 'list'), payload);
      yield update({ compartmentList: datas });
    },
    * getStowageList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getStowageList, 'list'), { ...payload, ps: 100, pn: 1 });
      yield update({ stowageList: datas });
    },
    * loadStowageDetail({ payload }, { call, update, select }) {
      const nowStowage = yield call(withLoading(loadStowageDetail, 'list'), payload);
      const { compartmentList, stowageList } = yield select(({ editStowage }) => editStowage);
      let truck = {};
      let truckLoad = 0;
      let truckVolumne = 0;
      let finishLoad = 0;
      let finishVolumne = 0;
      let loadPercent = 0;
      let volumnePercent = 0;
      truck = compartmentList.filter(item => item.id === nowStowage.stowage.trailerId)[0];
      truckLoad = truck.truckLoad;
      truckVolumne = truck.truckVolumne;
      finishLoad = nowStowage.splitCargoList[0].cargoResidualWeight;
      finishVolumne = nowStowage.splitCargoList[0].cargoResidualVolume;
      loadPercent = (finishLoad / truckLoad).toFixed(2) * 100;
      volumnePercent = (finishVolumne / truckVolumne).toFixed(2) * 100;

      const finishOptions = {
        truckLoad, // 挂车载重
        truckVolumne, // 挂车空间
        finishLoad, // 已配载重量
        finishVolumne, // 已配载体积
        loadPercent, // 载重利用率
        volumnePercent, // 空间利用率
      };
      // 禁用已有项
      let _stowageList = _.cloneDeep(stowageList);
      const waybillNo = nowStowage.splitCargoList[0].waybillNo;
      _stowageList = _stowageList.map((item) => {
        if (item.waybillNo === waybillNo) {
          return { ...item, disabled: true };
        }
        return item;
      });
      yield update({ nowStowage, finishOptions, stowageList: _stowageList });
    },
    * editStowage({ payload }, { call, select }) {
      const { stowageNo } = yield select(({ editStowage }) => editStowage);
      const _payload = { ...payload, stowageNo };
      yield call(withLoading(editStowage, 'list', '修改成功'), _payload);
      window.history.go(-1);
    }
  },

  reducers: {
  }
});
