import { sendWays, boxType } from 'configs/constants';
import { formatValue } from 'utils/formatValue';
import moment from 'moment';

export const tableFields = [{
  key: 'sheetNo',
  name: '运单号',
  width: 90,
  render: (a, b) =>
    <a href={`#/waybillManage/detailWaybill/${b.waybillNo}`} rel="noopener noreferrer" target="_blank">{a}</a>
}, {
  key: 'putTime',
  name: '开单时间',
  width: 90,
  render: a => moment(a).format('MM-DD HH:mm')
}, {
  key: 'toSite',
  name: '到站',
  width: 90,
  render: formatValue
}, {
  key: 'cargoName',
  name: '货名',
  width: 90,
  render: (a, b) => {
    const names = [];
    b.cargoList && b.cargoList.forEach(item => names.push(item.cargoName));
    return formatValue(names.join(' / '));
  }
}, {
  key: 'cargoResidualPiece',
  name: '可装车件数',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualWeight',
  name: '可装车重量',
  width: 90,
  render: formatValue
}, {
  key: 'cargoResidualVolume',
  name: '可装车体积',
  width: 90,
  render: formatValue
}, {
  key: 'dispatchType',
  name: '产品时效',
  width: 90,
  render: a => a && sendWays.filter(item => item.key === a)[0].value
}, {
  key: 'cargoPackage',
  name: '包装',
  width: 90,
  render: (a, b) => {
    const names = [];
    b.cargoList && b.cargoList.forEach((_item) => {
      const name = boxType.filter(item => item.key === _item.cargoPackage)[0].value;
      names.push(name);
    });
    return formatValue(names.join(' / '));
  }
}, {
  key: 'remark',
  name: '运单备注',
  width: 140,
  render: formatValue
}];
