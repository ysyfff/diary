import http from 'utils/http';

const { post } = http.create('dapt');

export function getList(param) {
  return post('/web/m/stowage/page', param);
}

export function cancel(param) {
  return post('/web/m/stowage/load/cancel', param);
}

export function complete(param) {
  return post('/web/m/stowage/load/complete', param);
}

export function enterSealNo(param) {
  return post('/web/m/stowage/sealNo/entering', param);
}

export function exportStowage() {
  return '/web/m/stowage/list/export';
}

// 获取站点列表
export function fetchSiteList(param) {
  return post('/web/e/site/search', param);
}

// 修改封签
export function updateSealNo(param) {
  return post('/web/m/stowage/sealNo/entering', param);
}

// 查询线路列表
export function getSiteLineList(param) {
  return post('/web/m/siteline/list', param);
}
