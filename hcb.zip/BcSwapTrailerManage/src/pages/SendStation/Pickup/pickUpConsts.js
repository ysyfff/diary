const DeliveryInfoColLayout = {
  xxl: { span: 10 },
  xl: { span: 10 },
  lg: { span: 24 },
  md: { span: 24 },
  sm: { span: 24 }
};

const DeliveryGoodsInfoColLayout = {
  xxl: { span: 14 },
  xl: { span: 14 },
  lg: { span: 24 },
  md: { span: 24 },
  sm: { span: 24 }
};

const PREVIEW_PICK_UP = '/sendStation/pickup/preview';

export {
  DeliveryInfoColLayout,
  PREVIEW_PICK_UP,
  DeliveryGoodsInfoColLayout
};
