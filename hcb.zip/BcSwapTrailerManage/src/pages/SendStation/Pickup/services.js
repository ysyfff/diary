import http from 'utils/http';

const { post } = http.create('admin');
const EFFECTIVE = 1;

// 提货单确认发车
export function start(param) {
  return post('/web/m/pick-up/start', param);
}
// 提货单完成提货
export function complete(param) {
  return post('/web/m/pick-up/complete', param);
}
// 提货单取消提货
export function cancel(param) {
  return post('/web/m/pick-up/cancel', param);
}
/**
 * 获取关联订单列表
 * @param {String} orderNo
 * @param {String} mainBusiness
 */
export function getRelateOrderList(param) {
  return post('/web/m/order/query', { ...param });
}

/** new add */
// 查询订单详情
export function getOrderDetail(param) {
  return post('/web/m/order/detail', param);
}
// 查询发货公司
export function getCompanyList(param) {
  return post('/web/m/order/company-list', param);
}
// 查询订单列表
export function getOrderList(param) {
  return post('/web/m/order/query', param);
}
// 查询提货单列表
export function getPickUpList(param) {
  return post('/web/m/pick-up/list', param);
}
// 查询挂车车头
export function getTruckList(param) {
  return post('/web/m/truck/list', { ...param, effective: EFFECTIVE });
}
// 新增送货派车单
export function create(param) {
  return post('/web/m/pick-up/create', param, {
    contentType: 'json'
  });
}
// 查询送货单详情
export function getPickUpDetail(param) {
  return post('/web/m/pick-up/detail', param);
}
// 删除提货单司机
export function delDriver(param) {
  return post('/web/m/pick-up/del-driver', param);
}
// 编辑提货派车单
export function update(param) {
  return post('/web/m/pick-up/update', param, {
    contentType: 'json'
  });
}

// 查询挂车车厢列表
export function getTrailerList(param) {
  return post('/web/e/compartment/search', param);
}

