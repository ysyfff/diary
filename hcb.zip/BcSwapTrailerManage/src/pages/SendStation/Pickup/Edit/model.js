import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
// import { tableFields } from '../fields';
import {
  update,
  getTruckList,
  getTrailerList,
  getPickUpDetail,
  delDriver
} from '../services';


export default Model.extend({
  namespace: 'pickupEdit',
  state: {
    pickUpNo: '',
    orderDetail: {},
    truckList: [],
    trailerList: [],
    search: {
      ps: 1,
      pn: 10
    },
    loading: { getDetail: false, update: false }
  },
  subscriptions: {
    setupSubscriber({ listen, dispatch }) {
      listen('/sendStation/pickup/edit/:pickUpNo', async ({ params }) => {
        const pickUpNo = params[0];
        dispatch({ type: 'updateState', payload: { pickUpNo } });
        await dispatch({ type: 'getTruckList', payload: {} });
        await dispatch({ type: 'getTrailerList', payload: { carrierCompany: '' } });
        await dispatch({ type: 'getPickUpDetail', payload: { pickUpNo } });
      });
    }
  },
  effects: {
    * getTruckList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getTruckList, 'getTruckList'), { ...payload });
      yield update({
        truckList: datas.map(data => ({
          key: data.id,
          value: data.plateNumber
        }))
      });
    },
    * getTrailerList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getTrailerList, 'getTrailerList'), { ...payload });
      yield update({
        trailerList: datas.map(data => ({
          key: data.id,
          value: data.plateNumber
        }))
      });
    },
    * getPickUpDetail({ payload }, { call, update }) {
      const orderDetail = yield call(withLoading(getPickUpDetail, 'getDetail'), { ...payload });
      yield update({ orderDetail });
    },
    * delDriver({ payload }, { call }) {
      return yield call(withLoading(delDriver, 'delOrder'), payload);
    },
    * update({ payload }, { call, put }) {
      yield call(withLoading(update, { successMsg: '提货派车单修改成功！', key: 'update' }), { ...payload });
      yield put(routerRedux.push('/sendStation/pickup'));
    }
  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    }
  }
});
