export const columns = [
  {
    title: '订单号',
    dataIndex: 'orderNo',
    key: 'orderNo'
  },
  {
    title: '提货时间',
    dataIndex: 'takeTimeStr',
    key: 'takeTimeStr'
  },
  {
    title: '派件方式',
    dataIndex: 'sendWay',
    key: 'sendWay'
  },
  // {
  //   title: '订单号',
  //   dataIndex: 'name3',
  //   key: 'name3'
  // },
  {
    title: '取货地址',
    dataIndex: 'shipAddress',
    key: 'shipAddress'
  },
  {
    title: '货物品名',
    dataIndex: 'cargoName',
    key: 'cargoName'
  },
  {
    title: '总件数(件)',
    dataIndex: 'totalNum',
    key: 'totalNum'
  },
  {
    title: '总重量(吨)',
    dataIndex: 'totalWeight',
    key: 'totalWeight'
  },
  {
    title: '总体积(方)',
    dataIndex: 'totalVolume',
    key: 'totalVolume'
  },
  {
    title: '备注',
    dataIndex: 'remark',
    key: 'remark'
  },
];

// 其他费用弹出框表格配置
export const tableFields = [{
  title: '费用名称',
  dataIndex: 'costName',
  editable: true,
  align: 'center',
  width: '40%',
  fields: {
    type: 'input',
    props: {
      maxLength: 20,
      minLength: 1,
      placeholder: '请输入费用名称'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用名称'
      }]
    }
  }
}, {
  title: '费用金额',
  dataIndex: 'costFee',
  editable: true,
  align: 'center',
  width: '30%',
  fields: {
    type: 'inputnumber',
    props: {
      precision: 2,
      min: 0.01,
      max: 99999.99,
      placeholder: '请输入费用金额'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用金额'
      }]
    }
  }
}];

export const baseInfoItemLayoutProps = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 9 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 15 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 14 },
    sm: { span: 14 }
  }
};
// 其他费用FormItem布局
export const extraCostItemLayoutProps = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 6 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 14 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 14 },
    sm: { span: 14 }
  }
};
