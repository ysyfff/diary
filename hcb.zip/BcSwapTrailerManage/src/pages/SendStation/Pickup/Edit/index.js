import React from 'react';
import { SearchCard, HCard } from 'components/helper';
import { Type } from 'carno/utils';
import { BaseHTable } from 'components';
import { Row, Col, Button, message, Spin } from 'antd';
import DeliveryNoteFooter from 'components/DeliveryNote/DeliveryNoteFooter';
import goodsInfoFields from 'components/DeliveryNote/PickUpInfo/goods.info.fields';
import footerFields from 'components/DeliveryNote/DeliveryNoteFooter/search.config';
import infoFields from 'components/DeliveryNote/PickUpInfo/search.config';
import styles from 'components/DeliveryNote/index.less';
import GoodsAddress from 'components/DeliveryNote/GoodsAddress';
import {
  validateForms,
  transformPickUpDriverFormEdit,
  transformAddress,
  isSameDrivers
} from 'components/DeliveryNote/utils';
import { getRegionName } from 'utils';
import { connect } from 'dva';
import { DeliveryInfoColLayout, DeliveryGoodsInfoColLayout } from '../pickUpConsts';
import PickUpHeader from '../common/PickUpHeader';
import headerFields from '../common/PickUpHeader/search.config';

// 地址回现
const addressName = (province, city, county) => {
  const addressId = county || city || province;
  const addressCode = province ? [{ id: +addressId, name: getRegionName(addressId, '') }] : [];
  return addressCode;
};
// 转换地址
const transformAddressToComponent1 = (address = []) => address.map((addr) => {
  const { address, shipperName, shipperPhone, provinceId, cityId, countyId } = addr;
  return {
    addressDetail: address,
    contact: shipperName,
    contactPhone: shipperPhone,
    address: addressName(provinceId, cityId, countyId)
  };
});
// 转换其他费用
const transformPickUpExpenses = pickUpExpenses => pickUpExpenses.map((expenses) => {
  const { name, fee } = expenses;
  return { name, fee };
});
// 转换调度信息
const transformDriverRepVOS = driverRepVOS => (driverRepVOS || []).map((vos) => {
  const {
    id,
    driverFee,
    driverId,
    driverMobile,
    driverName,
    driverTruckId,
    driverPlateNumber,
    pickUpExpenses
  } = vos;
  return {
    id,
    driver: { driverId, driverMobile, driverName },
    truck: { key: driverTruckId, label: driverPlateNumber },
    driverFee: driverFee || undefined,
    pickUpCreateDriverOtherFee: transformPickUpExpenses(pickUpExpenses || [])
  };
});
@connect(
  ({ pickupEdit }) => ({ ...pickupEdit }),
  dispatch => ({ dispatch })
)
class AddPickUp extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      ...this.getExtraFields(),
      cargoList: [],
      showGoodsListAction: true,
      shipAddresses: [],
      id: ''
    };
    // 调度信息forms
    this.dispatchForms = {};
    // 货物信息forms
    this.goodsForms = {};
  }

  async componentDidMount() {
    // 头部
    this.headerHelper = this.header.props.helper;
    // 提货信息
    this.infoHelper = this.info.props.helper;
    // 调度信息
    this.footerHelper = this.footer.props.helper;
  }

  componentWillReceiveProps = (nextProps) => {
    if (this.props.orderDetail !== nextProps.orderDetail) {
      // handleEditDetail
      this.handleEditDetail(nextProps.orderDetail);
    }
    if (this.props.trailerList !== nextProps.trailerList) {
      this.setState({
        infoExtraFields: [{
          key: 'plateNumber',
          el: { options: nextProps.trailerList }
        }]
      });
    }
    if (this.props.truckList !== nextProps.truckList) {
      this.setState({
        footerExtraFields: [{
          key: 'pickUpDriver',
          el: { extraProps: { truck: { options: nextProps.truckList } }
          }
        }]
      });
    }
  }

  // 获取extraFields
  getExtraFields = () => ({
    headerExtraFields: [{
      key: 'orderNo',
      el: {
        placeholder: '',
        disabled: true
      }
    }],
    footerExtraFields: [{
      key: 'pickUpDriver',
      el: {
        disabledIdKeys: ['driver', 'truck'],
        onFormsChange: (forms) => {
          this.dispatchForms = forms;
        },
        onDelete: async (fields, callback) => {
          const { dispatch, pickUpNo } = this.props;
          const { driverId } = fields.driver.value;
          const payload = { driverId, pickUpNo };
          const res = await dispatch({
            type: 'pickupEdit/delDriver',
            payload
          });
          if (res && res.toLowerCase() === 'ok') {
            callback();
          } else {
            message.error('派车司机删除失败,请重试!');
          }
        },
        onPopconTitle: (fields, key) => {
          if (!fields || !fields[key] || !fields[key].driver) return '';
          const { driver } = fields[key];
          if (!driver.value) return '';
          const { driverName } = driver.value;
          return `是否取消给司机【${driverName}】的派车任务?`;
        }
      }
    }]
  });
   //  获取发货地址
   getShipAddress = (value, province, city, county) => {
     const { getFieldsValue } = this.infoHelper.getForm();
     const { companyName } = getFieldsValue();
     const { dispatch } = this.props;
     return dispatch({
       type: 'order/getAddress',
       payload: {
         companyName,
         province,
         city,
         county,
         address: value,
         type: 'FROM' } });
   }

  // 获取发货人信息
  getShipCustomer = () => {
    const { getFieldsValue } = this.info.props.helper.getForm();
    const { companyName = '' } = getFieldsValue();
    if (companyName) {
      const { dispatch } = this.props;
      return dispatch({
        type: 'order/getCustomer',
        payload: {
          shipCompanyName: companyName,
          recCompanyName: '',
          type: 'FROM'
        }
      });
    }
    return Promise.resolve([]);
  }
  // 处理详情信息回填
  handleEditDetail = (orderDetail) => {
    if (!orderDetail || (Type.isObject(orderDetail) &&
      Object.keys(orderDetail).length === 0)) return null;
    const {
      pickUpCargos,
      pickUpOrders = [],
      pickUpTime,
      plateNumber,
      driverRepVOS = [],
      remark,
      trailerId
    } = orderDetail;
    const {
      id,
      mainBusiness,
      sendWay,
      orderNo,
      companyName,
      orderAddressesList
    } = pickUpOrders[0];
    // 如果存在订单号，header area全部disabled
    if (orderNo) {
      this.setState({
        headerExtraFields: [{
          key: 'orderNo',
          el: { disabled: true }
        }, {
          key: 'mainBusiness',
          el: { disabled: true }
        }, {
          key: 'sendWay',
          el: { disabled: true }
        }],
      });
    } else {
      this.setState({
        headerExtraFields: [{
          key: 'mainBusiness',
          el: { disabled: false }
        }, {
          key: 'sendWay',
          el: { disabled: false }
        }],
      });
    }
    this.setState({
      id,
      infoExtraFields: [{
        key: 'companyName',
        el: { disabled: true }
      }],
      cargoList: pickUpCargos || [],
      showGoodsListAction: false,
      shipAddresses: transformAddressToComponent1(orderAddressesList || [])
    });
    this.headerHelper.setFieldsValues({
      orderNo: orderNo || undefined,
      mainBusiness: mainBusiness || undefined,
      sendWay: sendWay || undefined
    });
    this.infoHelper.setFieldsValues({
      companyName: companyName || '',
      pickUpTime: pickUpTime || undefined,
      plateNumber: { key: trailerId, label: plateNumber }
    });
    this.footerHelper.setFieldsValues({
      pickUpDriver: transformDriverRepVOS(driverRepVOS || []),
      remark
    });
    return null;
  }

 // 搜索发货公司
 handleCompanySearch = (value) => {
   const { dispatch } = this.props;
   return dispatch({
     type: 'pickupAdd/getCompanyList',
     payload: { shipCompanyName: value }
   });
 }
  // 提交保存
  handleSave = async () => {
    const errors = [];
    // 获取头部值
    const headerRes = this.headerHelper.getFieldsValues(true);
    errors.push(headerRes.error);
    // 获取提货信息
    const infoRes = this.infoHelper.getFieldsValues(true);
    errors.push(infoRes.error);
    // 获取地址信息
    const address = validateForms(this.address.forms, true);
    errors.push(address.error);
    // 验证调度信息
    const dispatch = validateForms(this.dispatchForms);
    errors.push(dispatch);
    // 判断所有的模块是否验证通过
    const isError = errors.some(error => error);
    if (!isError) {
      const footerValue = this.footerHelper.getFieldsValues();
      const infoValue = infoRes.value;
      const headerValue = headerRes.value;
      const addressValue = address.value;
      const { pickUpDriver } = footerValue;
      const isDispatchRight = Array.isArray(pickUpDriver) && pickUpDriver.length >= 1;
      if (!isDispatchRight) {
        message.error('至少指派一个司机执行派车任务');
        return;
      }
      if (isDispatchRight) {
        const isSame = isSameDrivers(pickUpDriver);
        if (isSame) {
          message.info('调度信息同一司机不能重复添加');
          return;
        }
        const { pickUpNo } = this.props;
        const { id } = this.state;
        const { remark } = footerValue;
        const { pickUpTime, plateNumber, companyName } = infoValue;
        const { orderNo = '', mainBusiness, sendWay } = headerValue;
        // 合成提交数据
        const payload = {
          pickUpNo,
          remark, // 派车备注
          pickUpTime, // 提货时间
          trailerId: plateNumber.key, // 挂车id
          plateNumber: plateNumber.label, // 挂车车牌
          pickUpUpdateOrders: [{
            id,
            orderNo, // 订单号
            mainBusiness, // 主营服务
            sendWay, // 产品时效
            companyName, // 公司名称
            orderAddress: transformAddress(addressValue) // 地址信息
          }],
          pickUpUpdateDrivers: transformPickUpDriverFormEdit(pickUpDriver) // 调度信息
        };
        await this.props.dispatch({
          type: 'pickupEdit/update',
          payload
        });
      }
    }
  }

  handleCancel = () => {
    window.close();
  }
  render() {
    const {
      footerExtraFields,
      headerExtraFields,
      infoExtraFields,
      cargoList,
      shipAddresses
    } = this.state;
    const { loading, search } = this.props;
    return (
      <Spin spinning={loading.getDetail || loading.update}>
        <div className={styles['pick-up']}>
          <PickUpHeader
            fields={headerFields}
            extraFields={headerExtraFields}
            wrappedComponentRef={el => this.header = el}
          />
          <Row className="delivery-info-row">
            <Col {...DeliveryInfoColLayout}>
              <SearchCard
                style={{ padding: '0 6px' }}
                wrappedComponentRef={el => this.info = el}
                title="提货信息"
                extraFields={infoExtraFields}
                fields={infoFields}
                extraContent={<GoodsAddress
                  onSearch={this.getShipCustomer}
                  value={shipAddresses}
                  onSearchAddress={
                    (value, province, city, county) => this.getShipAddress(value, province, city, county)}
                  ref={address => this.address = address}
                />}
              />
            </Col>
            <Col {...DeliveryGoodsInfoColLayout}>
              <HCard
                style={{ padding: '0 6px' }}
                title="货物信息"
              >
                <BaseHTable
                  tableFields={goodsInfoFields}
                  search={search}
                  scrollX={false}
                  list={cargoList}
                  pagination={false}
                />
              </HCard>
            </Col>
          </Row>
          <Row>
            <DeliveryNoteFooter
              fields={footerFields}
              extraFields={footerExtraFields}
              wrappedComponentRef={el => this.footer = el}
            />
          </Row>
          <Row type="flex" className="primary-button-group" justify="center" align="middle">
            <Button type="primary" onClick={this.handleSave}>保存</Button>
          </Row>
        </div>
      </Spin>
    );
  }
}

export default AddPickUp;
