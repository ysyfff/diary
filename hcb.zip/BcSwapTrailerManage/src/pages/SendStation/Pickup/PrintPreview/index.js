import React from 'react';
import { DeliveryNotePrint } from 'components';
import { connect } from 'dva';
import NP from 'number-precision';
import { isEmptyValue } from 'components/DeliveryNote/utils';

const transformDetailToDatasource = (detail) => {
  if (isEmptyValue(detail)) return [];
  const { pickUpNo, driverRepVOS, plateNumber, pickUpOrders } = detail;
  const dispatchType = '提货';
  const dispatchNo = pickUpNo;
  const { orderAddressesList, companyName } = (pickUpOrders || [{}])[0];
  const addresses = (orderAddressesList || [{}])[0];
  const { address, provinceName, shipperName, shipperPhone } = addresses;

  return (driverRepVOS || []).map((driver) => {
    const { driverPlateNumber, pickUpExpenses, driverName, driverMobile } = driver || {};
    const _pickUpExpenses = pickUpExpenses || [];
    let sum = 0;
    _pickUpExpenses.forEach((expenses) => {
      const { fee } = expenses;
      sum = NP.plus(sum, fee);
    });
    return {
      dispatchNo,
      dispatchType,
      customer: companyName,
      plateNumber, // 挂车车牌
      driverPlateNumber,
      concatUser1: driverName,
      concatMobile1: driverMobile,
      concatUser2: shipperName,
      concatMobile2: shipperPhone,
      arriveAddress: `${provinceName || ''}${address || ''}`,
      otherFee: sum === 0 ? '' : sum
    };
  });
};

@connect(({ pickupDetail }) => ({ ...pickupDetail }))
class PrintPreview extends React.PureComponent {
  render() {
    const { loading, orderDetail } = this.props;
    const dataSource = transformDetailToDatasource(orderDetail);
    return (
      <DeliveryNotePrint
        loading={loading.getDetail}
        dataSource={dataSource}
      />
    );
  }
}

export default PrintPreview;
