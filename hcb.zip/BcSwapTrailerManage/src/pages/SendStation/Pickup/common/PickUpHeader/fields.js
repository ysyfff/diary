import { EllipsisRecord } from 'components';
import { mainBusiness } from 'components/DeliveryNote/deliveryNoteConsts';

// 关联运单table columns
const wayBillColumns = [{
  title: '订单号',
  dataIndex: 'orderNo',
  key: 'orderNo',
  width: 70,
  render: record => <EllipsisRecord record={record} row={2} />
}, {
  title: '主营服务',
  key: 'mainBusiness',
  dataIndex: 'mainBusiness',
  width: 70,
  render: record => <EllipsisRecord record={mainBusiness[record] || '--'} row={2} />
}, {
  title: '产品时效',
  key: 'sendWay',
  width: 50,
  dataIndex: 'sendWay',
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  title: '提货时间',
  key: 'takeTimeStr',
  dataIndex: 'takeTimeStr',
  width: 80,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  title: '提货地址',
  dataIndex: 'shipAddress',
  key: 'shipAddress',
  width: 120,
  render: (record) => {
    if (!record) return '--';
    const address = record.split(',');
    const recordText = [];
    const popoverContent = address.map((addr) => {
      recordText.push(`${addr}\n`);
      return (
        <p key={address} style={{ margin: 0 }}>{addr}</p>
      );
    });
    return <EllipsisRecord record={recordText} row={2} popoverContent={popoverContent} />;
  }
}, {
  title: '发货公司',
  key: 'shipCompanyName',
  dataIndex: 'shipCompanyName',
  width: 110,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  title: '发货联系人',
  key: 'contactUser',
  dataIndex: 'contactUser',
  width: 120,
  render: (record) => {
    if (!record) return '--';
    const users = record.split(',');
    const recordText = [];
    const popoverContent = users.map((user) => {
      const text = user.replace('|', ',');
      recordText.push(`${text}\n`);
      return <p key={text} style={{ margin: 0 }}>{text}</p>;
    });
    return <EllipsisRecord popoverContent={popoverContent} record={recordText} row={2} />;
  }
}, {
  title: '货品',
  dataIndex: 'cargoName',
  key: 'cargoName',
  width: 100,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  title: '总件数（件）',
  key: 'totalNum',
  dataIndex: 'totalNum',
  width: 60,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  title: '总重量（千克）',
  key: 'totalWeight',
  dataIndex: 'totalWeight',
  width: 60,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  title: '总体积（方）',
  key: 'totalVolume',
  dataIndex: 'totalVolume',
  width: 60,
  render: record => <EllipsisRecord record={record || 0} row={2} />
}, {
  title: '备注',
  key: 'remarks',
  dataIndex: 'remarks',
  width: 70,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}];

export default wayBillColumns;
