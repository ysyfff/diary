import { mainType, sendWays } from 'configs/constants';
import AutoSearchInput from 'components/DeliveryNote/AutoSearchInput';
import tableFields from './fields';

const COL = {
  xxl: { span: 8 },
  xl: { span: 8 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 6 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 14 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const fields = [{
  key: 'orderNo',
  label: '提货订单',
  col: { ...COL },
  el: {
    placeholder: '请选择提货订单'
  },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  },
  render: ({ form, ...props }) => (
    <AutoSearchInput
      {...props}
      inputKey="orderNo"
      columns={tableFields}
      dropDownTableWidth={1190}
      defaultSearchValue="DD"
      scrollX={false}
    />
  )
}, {
  key: 'mainBusiness',
  label: '主营服务',
  type: 'select',
  col: { ...COL },
  el: {
    placeholder: '请选择主营服务',
    options: mainType
  },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请选择主营服务'
      }]
    }
  }
}, {
  key: 'sendWay',
  label: '产品时效',
  type: 'select',
  col: { ...COL },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请选择产品时效'
      }]
    }
  },
  el: {
    placeholder: '请选择产品时效',
    options: sendWays
  }
}];

export default fields;
