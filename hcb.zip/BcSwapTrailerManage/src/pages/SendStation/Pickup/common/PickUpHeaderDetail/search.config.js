import { mainType, sendWays, pickUpStatus, transform2FullObject } from 'configs/constants';

const pickUpStatusObj = transform2FullObject(pickUpStatus);

const COL = {
  xxl: { span: 6 },
  xl: { span: 6 },
  lg: { span: 12 }
};

const FORM_ITEM_COL_LAYOUT = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 8 },
    lg: { span: 8 },
    md: { span: 4 },
    sm: { span: 4 }
  },
  wrapperCol: {
    xxl: { span: 14 },
    xl: { span: 16 },
    lg: { span: 14 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const fields = [{
  key: 'pickUpNo',
  label: '派车单号',
  col: { ...COL },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  },
  render: ({ form, ...props }) => {
    const { value = {} } = props;
    let status = value.status || '--';
    let color = '#333';
    if (value.status) {
      color = pickUpStatusObj[value.status].color;
      status = pickUpStatusObj[value.status].value;
    }
    return (
      <span>
        <span name="pickUpNo">{value.pickUpNo || '--'}</span>
        <span style={{ marginLeft: '10px', color }}>{status}</span>
      </span>
    );
  }
}, {
  key: 'orderNo',
  label: '提货订单',
  col: { ...COL },
  el: {
    placeholder: '请选择提货订单',
    disabled: true
  },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  }
}, {
  key: 'mainBusiness',
  label: '主营服务',
  type: 'select',
  col: { ...COL },
  el: {
    placeholder: '请选择主营服务',
    options: mainType,
    disabled: true
  },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT },
    options: {
      rules: [{
        required: true,
        message: '请选择主营服务'
      }]
    }
  }
}, {
  key: 'sendWay',
  label: '产品时效',
  type: 'select',
  col: { ...COL },
  formItem: {
    props: { ...FORM_ITEM_COL_LAYOUT }
  },
  el: {
    placeholder: '请选择产品时效',
    options: sendWays,
    disabled: true
  }
}];

export default fields;
