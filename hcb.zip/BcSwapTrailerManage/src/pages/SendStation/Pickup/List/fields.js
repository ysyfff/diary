import {
  mainType,
  sendWays,
  transform2SearchOptions,
  pickUpStatus,
  transform2FullObject
} from 'configs/constants';
import renderFormFactory from 'components/common/renderFormFactory';
import { EllipsisRecord } from 'components';
import { Link } from 'dva/router';
import { Type } from 'carno/utils';

const pickUpStatusObj = transform2FullObject(pickUpStatus);
const mainTypeOptions = transform2SearchOptions(mainType);
const sendWaysOptions = transform2SearchOptions(sendWays);

mainTypeOptions.unshift({ key: '全部', value: '' });
sendWaysOptions.unshift({ key: '全部', value: '' });

const searchFields = [
  {
    key: 'pickUpNo',
    label: '派车单号',
    type: 'input',
    placeholder: '请输入派车单号'
  },
  {
    key: 'driver',
    label: '司机',
    type: 'input',
    placeholder: '请输入司机姓名或手机'
  },
  {
    key: 'pickUpTime',
    label: '提货时间',
    type: 'rangepicker',
    showTime: true,
    format: 'YYYY-MM-DD HH:mm'
  },
  {
    key: 'mainBusiness',
    label: '主营服务',
    type: 'select',
    defaultValue: '',
    options: mainTypeOptions,
    placeholder: '请选择主营服务'
  },
  {
    key: 'createUserName',
    label: '新建人',
    type: 'input',
    placeholder: '请输入新建人'
  },
  {
    key: 'orderNo',
    label: '关联订单',
    type: 'input',
    placeholder: '请输入关联订单'
  },
  {
    key: 'driverPlateNumber',
    label: '车头车牌',
    type: 'input',
    placeholder: '请输入车头车牌'
  },
  {
    key: 'trailerPlateNumber',
    label: '挂车车牌',
    type: 'input',
    placeholder: '请输入挂车车牌'
  },
  {
    key: 'sendWay',
    label: '产品时效',
    type: 'select',
    defaultValue: '',
    options: sendWaysOptions
  },
  {
    key: 'createTime',
    label: '下单时间',
    type: 'rangepicker',
    showTime: true,
    format: 'YYYY-MM-DD HH:mm'
  }
];

export default renderFormFactory(searchFields, (values) => {
  const { pickUpTime, createTime, ...other } = values;
  const rangePickUpTime = pickUpTime || [undefined, undefined];
  const pickUpTimeStart = rangePickUpTime[0] && rangePickUpTime[0].format('YYYY-MM-DD HH:mm:ss');
  const pickUpTimeEnd = rangePickUpTime[1] && rangePickUpTime[1].format('YYYY-MM-DD HH:mm:ss');
  const rangeCreateTime = createTime || [undefined, undefined];
  const createTimeStart = rangeCreateTime[0] && rangeCreateTime[0].format('YYYY-MM-DD HH:mm:ss');
  const createTimeEnd = rangeCreateTime[1] && rangeCreateTime[1].format('YYYY-MM-DD HH:mm:ss');

  return { pickUpTimeStart, pickUpTimeEnd, createTimeStart, createTimeEnd, ...other };
}, { xxl: { span: 6 }, xl: { span: 8 }, lg: { span: 12 }, md: { span: 12 } });


export const tableFields = [
  {
    key: 'orderId',
    name: '序号',
    width: 80
  },
  {
    key: 'pickUpNo',
    name: '派车单号',
    width: 180,
  },
  {
    key: 'status',
    name: '状态',
    width: 90,
    render: (record) => {
      const color = pickUpStatusObj[record].color;
      const text = pickUpStatusObj[record].value;
      return (<span style={{ color }}>{text}</span>);
    }
  },
  {
    key: 'oper',
    name: '操作',
    width: 60
  },
  {
    key: 'orderNo',
    name: '关联订单',
    width: 180,
    render: record => record ? <Link
      target="_blank"
      rel="noopener noreferrer"
      to={`/orderManage/detailOrder/${record}`}
    >{record}</Link> : '--'

  },
  {
    key: 'trailerPlateNumber',
    name: '挂车车牌',
    width: 120
  },
  {
    key: 'mainBusiness',
    name: '主营服务',
    width: 100,
    record: record => record || '--'
  }, {
    key: 'sendWay',
    name: '产品时效',
    width: 90,
    record: record => record || '--'
  },
  {
    key: 'pickUpTime',
    name: '提货时间',
    width: 120
  },
  {
    key: 'pickUpAddressList',
    name: '提货地址',
    width: 200,
    render: (record) => {
      if (!record) return '--';
      if (Type.isArray(record)) {
        if (record.length === 0) return '--';
        const recordText = [];
        const popoverContent = record.map((r, index) => {
          recordText.push(r);
          if (index !== record.length - 1) {
            recordText.push('\n');
          }
          return <p key={r} style={{ margin: 0 }}>{r}</p>;
        });
        return <EllipsisRecord record={recordText} popoverContent={popoverContent} row={2} />;
      }
      return '--';
    }
  },
  {
    key: 'driverList',
    name: '派车信息',
    width: 300,
    render: (record) => {
      if (!record) return '--';
      if (Type.isArray(record)) {
        if (record.length === 0) return '--';
        const recordText = [];
        const popoverContent = record.map((r, index) => {
          const text = `${r.driverName},${r.driverMobile},${r.plateNumber}`;
          recordText.push(text);
          if (index !== record.length - 1) {
            recordText.push('\n');
          }
          return <p key={text} style={{ margin: 0 }}>{text}</p>;
        });
        return <EllipsisRecord record={recordText} popoverContent={popoverContent} row={2} />;
      }
      return '--';
    }
  },
  {
    key: 'fee',
    name: '运费',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'otherFee',
    name: '其他费用',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'totalFee',
    name: '费用合计',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  }, {
    key: 'createUserName',
    name: '新建人',
    width: 100,
    render: record => <EllipsisRecord record={record || '--'} width={100} />
  },
  {
    key: 'createTime',
    name: '下单时间',
    width: 140,
    render: record => <EllipsisRecord record={record || '--'} width={140} />
  },
  {
    key: 'remark',
    name: '派车备注',
    width: 200,
    render: record => <EllipsisRecord enabelPlacement row={2} record={record || '--'} />
  },
];
