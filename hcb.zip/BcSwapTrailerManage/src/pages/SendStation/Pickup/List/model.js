import { Model } from 'carno/addons';
import { PAGE_SIZE } from 'configs/constants';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
import { tableFields } from './fields';
import {
  getPickUpList,
  start,
  cancel,
  complete
} from '../services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  status: ''
};

export default Model.extend({
  namespace: 'pickupList',
  state: {
    loading: { list: false },
    search: initialSearch,
    tableFields,
    list: [],
    total: 0
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.SEND_STATION_PICKUP, () => {
        dispatch({
          type: 'global/changeSearch',
          payload: {
            action: { type: 'pickupList/resetSearch' },
            noClearSearchPaths: [
              '/sendStation/pickup/detail',
              '/sendStation/pickup/edit',
              '/orderManage/detailOrder'
            ]
          }
        });
        dispatch({ type: 'getPickUpList' });
      });
    }
  },
  effects: {
    * getPickUpList({ payload }, { call, update, select }) {
      const { search } = yield select(({ pickupList }) => pickupList);
      const { datas, tc } = (yield call(withLoading(getPickUpList, 'list'), search) || {});
      yield update({ list: datas, total: tc });
    },
    * start({ payload }, { call }) {
      yield call(withLoading(start, 'changeStatus'), { ...payload });
    },
    * cancel({ payload }, { call }) {
      yield call(withLoading(cancel, 'changeStatus'), { ...payload });
    },
    * complete({ payload }, { call }) {
      yield call(withLoading(complete, 'changeStatus'), { ...payload });
    }
  },
  reducers: {
    resetSearch(state) {
      return {
        ...state,
        search: { ...initialSearch }
      };
    },
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload }
      };
    }
  }
});
