import React from 'react';
import { connect } from 'dva';
import { Link } from 'dva/router';
import { Button, Row, Col, Radio, Popover, Icon, Modal } from 'antd';
import { bind } from 'bind-decorator';
import { downFile } from 'utils';
import { Type } from 'carno/utils';
import { AuthortyWarpper } from 'components';
import { moment, _ } from 'carno/third-party';
import { pickUpStatus, transform2Options, transform2KeyKey } from 'configs/constants';
import searchRender from './fields';
import { BaseSearchBar, BaseHTable } from '../../../../components';

const searchBarLayout = {
  labelCol: {
    xxl: { span: 6 },
    xl: { span: 6 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 18 },
    xl: { span: 18 },
    lg: { span: 18 },
    md: { span: 18 },
    sm: { span: 18 }
  }
};

const pickUpStatusOptions = transform2Options(pickUpStatus);
pickUpStatusOptions.unshift({ label: '全部', value: '' });
const pickUpStatusKeys = transform2KeyKey(pickUpStatus);

function getRangepickerConfig(key, search, startKey, endKey) {
  const startTime = search[startKey];
  const endTime = search[endKey];
  let defaultValue = null;
  if (startTime && startTime) {
    defaultValue = [moment(startTime), moment(endTime)];
  } else {
    defaultValue = undefined;
  }
  return { key, defaultValue };
}

@connect(({ pickupList }) => ({ ...pickupList }), dispatch => ({ dispatch }))
export default class List extends React.PureComponent {
  state = { searchRender };

  componentWillReceiveProps(nextProps) {
    if (_.isEqual(this.props.search, nextProps.search)) {
      this.rerender(nextProps);
    }
  }
  @bind
  onPaginationSearch(value) {
    const { dispatch } = this.props;
    this.updateSearch(value);
    dispatch({ type: 'pickupList/getPickUpList' });
  }

  getExtraFields() {
    return [
      {
        key: 'orderId',
        render: (v, row, index) => index + 1
      },
      {
        key: 'pickUpNo',
        render: v => (
          <Link
            target="_blank"
            rel="noopener noreferrer"
            to={`/sendStation/pickup/detail/${v}`}
          >{v}</Link>
        )
      },
      {
        key: 'oper',
        name: '操作',
        render: (v, row) => {
          const content = `【挂车：${row.trailerPlateNumber}】`;
          const completePickUpContent = `【挂车：${row.trailerPlateNumber}】`;
          const { dispatch, permission } = this.props;
          return (
            <Popover
              placement="right"
              overlayStyle={{ zIndex: 999 }}
              content={
                <ul className="table-operate-button">
                  {row.status === pickUpStatusKeys.WAITLOAD ?
                    <AuthortyWarpper code={permission.pickup.start}>
                      <li><a onClick={() => {
                        Modal.confirm({
                          title: '确认发车',
                          okText: '确认发车',
                          cancelText: '取消',
                          content: <div>{`确认${content}发车`}</div>,
                          async onOk() {
                            const { pickUpNo } = row;
                            await dispatch({
                              type: 'pickupList/start',
                              payload: {
                                pickUpNo,
                                status: pickUpStatusKeys.LOADING
                              }
                            });
                            dispatch({ type: 'pickupList/getPickUpList' });
                          }
                        });
                      }}
                      >确认发车</a></li>
                    </AuthortyWarpper>
                    : null}
                  {row.status === pickUpStatusKeys.LOADING ?
                    <AuthortyWarpper code={permission.pickup.complete}>
                      <li><a onClick={() => {
                        Modal.confirm({
                          title: '完成提货',
                          okText: '完成提货',
                          cancelText: '取消',
                          content: <div>{`确认${completePickUpContent}完成提货`}</div>,
                          async onOk() {
                            const { pickUpNo } = row;
                            await dispatch({
                              type: 'pickupList/complete',
                              payload: {
                                pickUpNo,
                                status: pickUpStatusKeys.COMPLETELOAD
                              }
                            });
                            dispatch({ type: 'pickupList/getPickUpList' });
                          }
                        });
                      }}
                      >完成提货</a></li>
                    </AuthortyWarpper>
                    : null}
                  {row.status !== pickUpStatusKeys.CANCEL ?
                    <AuthortyWarpper code={permission.pickup.modify}>
                      <li><Link
                        target="_blank"
                        to={`/sendStation/pickup/edit/${row.pickUpNo}`}
                        rel="noopener noreferrer"
                      >修改派车</Link></li>
                    </AuthortyWarpper>
                    : null}
                  {row.status === pickUpStatusKeys.WAITLOAD || row.status === pickUpStatusKeys.LOADING ?
                    <AuthortyWarpper code={permission.pickup.cancel}>
                      <li><a onClick={() => {
                        Modal.confirm({
                          title: '取消派车',
                          okText: '取消派车',
                          cancelText: '取消',
                          content: '确认取消派车?',
                          async onOk() {
                            const { pickUpNo } = row;
                            await dispatch({
                              type: 'pickupList/cancel',
                              payload: {
                                pickUpNo,
                                status: pickUpStatusKeys.CANCEL
                              }
                            });
                            dispatch({ type: 'pickupList/getPickUpList' });
                          }
                        });
                      }}
                      >取消派车</a></li>
                    </AuthortyWarpper>
                    : null}
                  <li>
                    <Link
                      target="_blank"
                      rel="noopener noreferrer"
                      to={`/sendStation/pickup/detail/${row.pickUpNo}`}
                    >派车详情</Link></li>
                </ul>
              }
            >
              <a><Icon type="menu-unfold" /></a>
            </Popover>
          );
        }
      }
    ];
  }
  @bind
  updateSearch(param) {
    const { dispatch } = this.props;
    dispatch({
      type: 'pickupList/updateSearch',
      payload: param
    });
  }

  @bind
  handleSearch(values) {
    const { dispatch } = this.props;
    this.updateSearch({ ...values, pn: 1 });
    dispatch({ type: 'pickupList/getPickUpList', pn: 1 });
  }

  @bind
  handleStatusChange(e) {
    const { dispatch } = this.props;
    this.updateSearch({ status: e.target.value, pn: 1 });
    dispatch({ type: 'pickupList/getPickUpList' });
  }

  @bind
  downlaodFile() {
    const { search } = this.props;
    downFile({
      server: 'admin',
      url: '/web/m/pick-up/list-export',
      params: { ...search }
    });
  }

  @bind
  rerender(nextProps) {
    let searchBarConfig = [];
    const { search } = nextProps;
    const searchBarKeys = [
      'driver',
      'pickUpNo',
      'orderNo',
      'createUserName',
      'driverPlateNumber',
      'trailerPlateNumber',
    ];
    searchBarConfig = searchBarKeys.map(key => ({
      key,
      defaultValue: Type.isNill(search[key]) ? undefined : search[key]
    }));
    searchBarConfig.push({
      key: 'sendWay',
      defaultValue: search.sendWay || ''
    });
    searchBarConfig.push({
      key: 'mainBusiness',
      defaultValue: search.mainBusiness || ''
    });
    searchBarConfig.push(getRangepickerConfig(
      'pickUpTime', search, 'pickUpTimeStart', 'pickUpTimeEnd'
    ));
    searchBarConfig.push(getRangepickerConfig(
      'createTime', search, 'createTimeStart', 'createTimeEnd'
    ));
    this.setState({
      searchRender: searchRender.rerender(searchBarConfig)
    });
  }

  render() {
    const { searchRender } = this.state;
    const { search, permission } = this.props;
    const extraFields = this.getExtraFields();
    return (
      <div>
        <BaseSearchBar
          search={search}
          render={searchRender}
          onSearch={this.handleSearch}
          onValueChange={this.handleValueChange}
          baseItemLayout={searchBarLayout}
        />
        <div>
          <Row type="flex" justify="space-between">
            <Col className="arrive-namage-tool-bar">
              <Radio.Group
                onChange={this.handleStatusChange}
                value={this.props.search.status}
                buttonStyle="solid"
              >
                {pickUpStatusOptions.map(item => (
                  <Radio.Button key={item.value} value={item.value}>{item.label}</Radio.Button>))}
              </Radio.Group>
            </Col>
            <Col>
              <div className="arrive-namage-tool-bar">
                <AuthortyWarpper code={permission.pickup.create}>
                  <Link
                    to="/sendStation/pickup/add"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <Button type="primary">新建提货派车单</Button>
                  </Link>
                </AuthortyWarpper>
                <AuthortyWarpper code={permission.pickup.export}>
                  <Button className="ml10" onClick={this.downlaodFile} >导出表单</Button>
                </AuthortyWarpper>
              </div>
            </Col>
          </Row>
        </div>
        <BaseHTable
          extraFields={extraFields}
          onPaginationSearch={this.onPaginationSearch}
          scrollX={2400}
          {...this.props}
        />
      </div >
    );
  }
}
