import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths } from 'configs/constants';
import { getPickUpDetail } from '../services';

const PAGE_SIZE = 10;

export default Model.extend({
  namespace: 'pickupDetail',

  state: {
    pickUpNo: '',
    orderDetail: {
    },
    search: {
      pn: 1,
      ps: PAGE_SIZE,
    },
    loading: { getDetail: false }
  },

  subscriptions: {
    setupSubscriber({ listen, dispatch }) {
      // 监听打开详情页面
      listen(Paths.SEND_STATION_PICKUP_DETAIL, ({ params }) => {
        const pickUpNo = params[0];
        dispatch({ type: 'updatePickUpNo', payload: { pickUpNo } });
        dispatch({ type: 'getPickUpDetail', payload: { pickUpNo } });
      });
      // 监听打开提货派车单打印
      listen(Paths.PREVIEW_PICK_UP, ({ params }) => {
        const pickUpNo = params[0];
        dispatch({ type: 'updatePickUpNo', payload: { pickUpNo } });
        dispatch({ type: 'getPickUpDetail', payload: { pickUpNo } });
      });
    }
  },

  effects: {
    * getPickUpDetail({ payload }, { call, update }) {
      const orderDetail = yield call(withLoading(getPickUpDetail, 'getDetail'), { ...payload });
      yield update({ orderDetail });
    },
  },

  reducers: {
    updatePickUpNo(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    },
    updateSearch(state, { payload }) {
      return {
        ...state,
      };
    },
    resetSearch(state) {
      return {
        ...state,
      };
    },
  }
});
