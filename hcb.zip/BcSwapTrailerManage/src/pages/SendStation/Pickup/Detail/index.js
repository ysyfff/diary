import React from 'react';
import { Row, Col, Form, Input, Spin, Button, message } from 'antd';
import DeliveryNoteDetailFooter from 'components/DeliveryNote/DeliveryNoteDetailFooter';
import { connect } from 'dva';
import { Type } from 'carno/utils';
import moment from 'moment';
import NP from 'number-precision';
import { getRegionName } from 'utils';
import { Link } from 'dva/router';
import { isEmptyValue } from 'components/DeliveryNote/utils';
import { SearchCard, HCard } from 'components/helper';
import { REMARK_FORM_ITEM_LAYOUT } from 'components/DeliveryNote/deliveryNoteConsts';
import { BaseHTable } from 'components';
import goodsInfoFields from 'components/DeliveryNote/PickUpInfo/goods.info.fields';
import GoodsAddressDetail from 'components/DeliveryNote/GoodsAddressDetail';
import infoDetailFields from 'components/DeliveryNote/PickUpInfo/search.detail.config';
import styles from 'components/DeliveryNote/index.less';
import {
  DeliveryInfoColLayout,
  DeliveryGoodsInfoColLayout,
  PREVIEW_PICK_UP
} from '../pickUpConsts';
import PickUpHeaderDetail from '../common/PickUpHeaderDetail';
import pickUpHeaderDetailFields from '../common/PickUpHeaderDetail/search.config';

const FormItem = Form.Item;
// 地址回现
const addressName = (province, city, county) => {
  const fromId = county || city || province;
  let address = getRegionName(fromId);
  if (address) {
    const addr = address.split('-');
    address = addr.join('/');
  } else {
    address = '--';
  }
  return address;
};
// 转换地址
const transformAddressToComponent = (address = []) => address.map((addr) => {
  const { address, shipperName, shipperPhone, provinceId, cityId, countyId } = addr;
  return {
    addressDetail: address,
    contact: shipperName,
    contactPhone: shipperPhone,
    address: addressName(provinceId, cityId, countyId)
  };
});
// 转换派车信息
const transformDispatchInfo = driverRepVOS => driverRepVOS.map((vos) => {
  const {
    driverName = '--',
    driverMobile = '--',
    driverPlateNumber = '--',
    driverFee,
    pickUpExpenses = []
  } = vos;
  let sum = 0;
  const pickUpCreateDriverOtherFee = [];
  const _pickUpExpenses = pickUpExpenses || [];
  _pickUpExpenses.forEach((expenses) => {
    const { name, fee } = expenses;
    pickUpCreateDriverOtherFee.push(`${name}：${fee}`);
    sum = NP.plus(sum, fee);
  });
  sum = NP.plus(sum, driverFee || 0);
  return {
    driver: `${driverName},${driverMobile}`,
    truck: driverPlateNumber,
    driverFee: driverFee || 0,
    pickUpCreateDriverOtherFee: pickUpCreateDriverOtherFee.length === 0 ?
      '--' : pickUpCreateDriverOtherFee.join('；'),
    sum
  };
});

@connect(({ pickupDetail }) => ({ ...pickupDetail }))
class PickUpDetail extends React.PureComponent {
  getPickUpDetailList = () => {
    const { orderDetail } = this.props;
    if (!orderDetail || (Type.isObject(orderDetail) && Object.keys(orderDetail).length === 0)) return {};
    const {
      pickUpNo,
      status,
      pickUpCargos,
      pickUpOrders,
      pickUpTime,
      plateNumber,
      driverRepVOS,
      remark
    } = orderDetail;
    const {
      mainBusiness,
      sendWay,
      orderNo,
      companyName,
      orderAddressesList
    } = isEmptyValue(pickUpOrders) ? [{}] : pickUpOrders[0];
    return {
      headerDetailList: {
        pickUpNo: { pickUpNo, status },
        orderNo,
        mainBusiness,
        sendWay,
        status
      },
      pickUpCargos,
      address: transformAddressToComponent(orderAddressesList || []),
      infoDetailList: {
        pickUpTime: pickUpTime ? moment(pickUpTime).format('YYYY-MM-DD HH:mm') : '',
        plateNumber,
        companyName
      },
      dispatchList: transformDispatchInfo(driverRepVOS || []),
      remark
    };
  }
  // 打印派车单
  handlePrint = () => {
    message.info('打印模板升级中...');
  }

  handleCancel = () => {
    window.close();
  }
  render() {
    const {
      address = [],
      headerDetailList = {},
      infoDetailList = {},
      pickUpCargos = [],
      dispatchList = [],
      remark
    } = this.getPickUpDetailList();
    const { search, loading, pickUpNo } = this.props;
    return (
      <Spin spinning={loading.getDetail}>
        <div className={styles['pick-up']}>
          <PickUpHeaderDetail list={headerDetailList} fields={pickUpHeaderDetailFields} />
          <Row className="delivery-info-row">
            <Col {...DeliveryInfoColLayout}>
              <SearchCard
                style={{ padding: '0 6px' }}
                title="提货信息"
                fields={infoDetailFields}
                list={infoDetailList}
                extraContent={<GoodsAddressDetail
                  value={address}
                />}
              />
            </Col>
            <Col {...DeliveryGoodsInfoColLayout}>
              <HCard
                style={{ padding: '0 6px' }}
                title="货物信息"
              >
                <BaseHTable
                  tableFields={goodsInfoFields}
                  search={search}
                  scrollX={false}
                  list={pickUpCargos}
                  pagination={false}
                />
              </HCard>
            </Col>
          </Row>
          <Row>
            <HCard title="调度信息" style={{ padding: '12px 6px' }}>
              <BaseHTable
                tableFields={DeliveryNoteDetailFooter}
                search={search}
                scrollX={false}
                list={dispatchList}
                pagination={false}
              />
            </HCard>
            <Col span={24}>
              <FormItem label="备注信息" {...REMARK_FORM_ITEM_LAYOUT}>
                <Input disabled value={remark} />
              </FormItem>
            </Col>
          </Row>
          <Row type="flex" className="primary-button-group" justify="center" align="middle">
            { headerDetailList.status !== 'CANCEL' && (
              <Link to={`${PREVIEW_PICK_UP}/${pickUpNo}`}>
                <Button type="primary">打印派车单</Button>
              </Link>)
            }
          </Row>
        </div>
      </Spin>
    );
  }
}

export default PickUpDetail;
