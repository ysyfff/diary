import React from 'react';
import { SearchCard } from 'components/helper';
import { Row, Col, Button, message, Spin } from 'antd';
import {
  transformCargoList,
  transformAddressToComponent,
  validateForms,
  transformAddress,
  transformPickUpDriver,
  isSameDrivers
} from 'components/DeliveryNote/utils';
import DeliveryNoteFooter from 'components/DeliveryNote/DeliveryNoteFooter';
import { goodsFields, goodsDisabledFields } from 'components/DeliveryNote/PickUpGoodsInfo';
import footerFields from 'components/DeliveryNote/DeliveryNoteFooter/search.config';
import infoFields from 'components/DeliveryNote/PickUpInfo/search.config';
import styles from 'components/DeliveryNote/index.less';
import CustomedTableForm from 'components/DeliveryNote/CustomedTableForm';
import GoodsAddress from 'components/DeliveryNote/GoodsAddress';
import { qs } from 'utils';
import { connect } from 'dva';
import { DeliveryInfoColLayout, DeliveryGoodsInfoColLayout } from '../pickUpConsts';
import PickUpHeader from '../common/PickUpHeader';
import headerFields from '../common/PickUpHeader/search.config';

@connect(
  ({ pickupAdd }) => ({ ...pickupAdd }),
  dispatch => ({ dispatch })
)
class AddPickUp extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      ...this.getExtraFields(),
      cargoList: [],
      showGoodsListAction: true,
      shipAddresses: []
    };
    // 调度信息forms
    this.dispatchForms = {};
    // 货物信息forms
    this.goodsForms = {};
  }

  async componentDidMount() {
    // 头部
    this.headerHelper = this.header.props.helper;
    // 提货信息
    this.infoHelper = this.info.props.helper;
    // 调度信息
    this.footerHelper = this.footer.props.helper;
    // 重置记录
    this.handleRestOrderRecord();
    const { dispatch } = this.props;
    // 获取qs
    const orderNo = qs('orderNo');
    if (orderNo) {
      const datas = await dispatch({
        type: 'pickupAdd/getOrderDetail',
        payload: { orderNo }
      });
      this.handleAddOrderRecord(datas);
      this.handleAddOrderNo();
      this.headerHelper.setFieldsValues({
        orderNo
      });
    }
  }

  componentWillReceiveProps = (nextProps) => {
    if (this.props.trailerList !== nextProps.trailerList) {
      this.setState({
        infoExtraFields: [{
          key: 'plateNumber',
          el: { options: nextProps.trailerList }
        }]
      });
    }

    if (this.props.truckList !== nextProps.truckList) {
      this.setState({
        footerExtraFields: [{
          key: 'pickUpDriver',
          el: { extraProps: { truck: { options: nextProps.truckList } } }
        }]
      });
    }
  }

  // 货物信息爱forms监听
  onGoodsFormsChange = (forms) => {
    this.goodsForms = forms;
  }
  // 获取extraFields
  getExtraFields = () => ({
    infoExtraFields: [{
      key: 'companyName',
      el: {
        onSearch: this.handleCompanySearch
      }
    }],
    headerExtraFields: [{
      key: 'orderNo',
      el: {
        onSearch: this.handleWaybillSearch,
        onSelect: this.handleOrderSelect
      }
    }],
    footerExtraFields: [{
      key: 'pickUpDriver',
      el: {
        onFormsChange: (forms) => {
          this.dispatchForms = forms;
        }
      }
    }]
  });
   //  获取发货地址
   getShipAddress = (value, province, city, county) => {
     const { getFieldsValue } = this.infoHelper.getForm();
     const { companyName } = getFieldsValue();
     const { dispatch } = this.props;
     return dispatch({
       type: 'order/getAddress',
       payload: {
         companyName,
         province,
         city,
         county,
         address: value,
         type: 'FROM'
       } });
   }

  // 获取发货人信息
  getShipCustomer = () => {
    const { getFieldsValue } = this.info.props.helper.getForm();
    const { companyName = '' } = getFieldsValue();
    if (companyName) {
      const { dispatch } = this.props;
      return dispatch({
        type: 'order/getCustomer',
        payload: {
          shipCompanyName: companyName,
          recCompanyName: '',
          type: 'FROM'
        }
      });
    }
    return Promise.resolve([]);
  }
  // 操作订单记录
  handleAddOrderNo = () => {
    this.setState({
      headerExtraFields: [{
        key: 'orderNo',
        el: {
          disabled: true
        }
      }]
    });
  }
  // 查询提货订单
 handleWaybillSearch = (orderNo) => {
   const { dispatch } = this.props;
   return dispatch({
     type: 'pickupAdd/getOrderList',
     payload: { orderNo }
   });
 }
 // 搜索发货公司
 handleCompanySearch = (value) => {
   const { dispatch } = this.props;
   return dispatch({
     type: 'pickupAdd/getCompanyList',
     payload: { shipCompanyName: value }
   });
 }
 // 重置订单记录
 handleRestOrderRecord = () => {
   this.setState({
     infoExtraFields: [{
       key: 'companyName',
       el: { disabled: false }
     }],
     headerExtraFields: [{
       key: 'mainBusiness',
       el: { disabled: false }
     }, {
       key: 'sendWay',
       el: { disabled: false }
     }],
     cargoList: [],
     showGoodsListAction: true,
     shipAddresses: []
   });
   // 重置header和提货信息
   this.headerHelper.resetFields();
   this.infoHelper.resetFields();
 }
 // 回填订单记录
 handleAddOrderRecord = (datas) => {
   // 货物列表
   const { cargoList, shipAddresses } = datas;
   const _cargoList = transformCargoList(cargoList);

   // 更改组件状态
   this.setState({
     infoExtraFields: [{
       key: 'companyName',
       el: { disabled: true }
     }],
     headerExtraFields: [{
       key: 'mainBusiness',
       el: { disabled: true }
     }, {
       key: 'sendWay',
       el: { disabled: true }
     }],
     cargoList: _cargoList,
     showGoodsListAction: false,
     shipAddresses: transformAddressToComponent(shipAddresses)
   });
   this.headerHelper.setFieldsValues({
     mainBusiness: datas.mainBusiness,
     sendWay: datas.sendWay
   });
   this.infoHelper.setFieldsValues({
     pickUpTime: datas.takeTime || undefined,
     companyName: datas.shipCompanyName
   });
 }
 // 处理选择订单记录
 handleOrderSelect = async (record) => {
   const { dispatch } = this.props;
   if (record) {
     // 订单记录回填
     const datas = await dispatch({
       type: 'pickupAdd/getOrderDetail',
       payload: {
         orderNo: record.orderNo
       }
     });
     this.handleAddOrderRecord(datas);
   } else {
     this.handleRestOrderRecord();
   }
 }
 // 提交保存
  handleSave = (type) => {
    const errors = [];
    // 获取头部值
    const headerRes = this.headerHelper.getFieldsValues(true);
    errors.push(headerRes.error);
    // 获取提货信息
    const infoRes = this.infoHelper.getFieldsValues(true);
    errors.push(infoRes.error);
    // 获取地址信息
    const address = validateForms(this.address.forms, true);
    errors.push(address.error);
    // 验证货物信息
    const goods = validateForms(this.goodsForms, true);
    errors.push(goods.error);
    // 验证调度信息
    const dispatch = validateForms(this.dispatchForms);
    errors.push(dispatch);
    // 判断所有的模块是否验证通过
    const isError = errors.some(error => error);
    if (!isError) {
      const footerValue = this.footerHelper.getFieldsValues();
      const infoValue = infoRes.value;
      const headerValue = headerRes.value;
      const addressValue = address.value;
      const { pickUpDriver } = footerValue;
      const isGoodsRight = Array.isArray(goods.value) && goods.value.length >= 1;
      const isDispatchRight = Array.isArray(pickUpDriver) && pickUpDriver.length >= 1;
      // 判断货物信息条数
      if (!isGoodsRight) {
        message.error('请输入货物信息');
      }
      if (!isDispatchRight) {
        message.error('至少指派一个司机执行派车任务');
        return;
      }
      if (isGoodsRight && isDispatchRight) {
        const isSame = isSameDrivers(pickUpDriver);
        if (isSame) {
          message.info('调度信息同一司机不能重复添加');
          return;
        }
        const { remark } = footerValue;
        const { pickUpTime, plateNumber, companyName } = infoValue;
        const { orderNo = '', mainBusiness, sendWay } = headerValue;
        // 合成提交数据
        const payload = {
          remark, // 派车备注
          pickUpTime, // 提货时间
          trailerId: plateNumber.key, // 挂车id
          plateNumber: plateNumber.label, // 挂车车牌
          pickUpOrder: [{
            orderNo, // 订单号
            mainBusiness, // 主营服务
            sendWay, // 产品时效
            companyName, // 公司名称
            orderAddress: transformAddress(addressValue) // 地址信息
          }],
          pickUpCargo: goods.value, // 货物信息
          pickUpDriver: transformPickUpDriver(pickUpDriver) // 调度信息
        };
        this.props.dispatch({
          type,
          payload
        });
      }
    }
  }

  handleSaveAndPrint = () => {
    this.handleSave('pickupAdd/createAndPrint');
  }

  handleSaveOrder = () => {
    this.handleSave('pickupAdd/create');
  }

  render() {
    const {
      footerExtraFields,
      headerExtraFields,
      infoExtraFields,
      cargoList,
      showGoodsListAction,
      shipAddresses
    } = this.state;
    const goodsTableFields = showGoodsListAction ? goodsFields : goodsDisabledFields;
    const { loading } = this.props;
    return (
      <Spin spinning={loading.createOrder}>
        <div className={styles['pick-up']}>
          <PickUpHeader
            fields={headerFields}
            extraFields={headerExtraFields}
            wrappedComponentRef={el => this.header = el}
          />
          <Row className="delivery-info-row">
            <Col {...DeliveryInfoColLayout}>
              <SearchCard
                style={{ padding: '0 6px' }}
                wrappedComponentRef={el => this.info = el}
                title="提货信息"
                extraFields={infoExtraFields}
                fields={infoFields}
                extraContent={<GoodsAddress
                  onSearch={this.getShipCustomer}
                  value={shipAddresses}
                  onSearchAddress={
                    (value, province, city, county) => this.getShipAddress(value, province, city, county)}
                  ref={address => this.address = address}
                />}
              />
            </Col>
            <Col {...DeliveryGoodsInfoColLayout}>
              <CustomedTableForm
                style={{ padding: '0 6px' }}
                title="货物信息"
                tableFields={goodsTableFields}
                value={cargoList}
                showAction={showGoodsListAction}
                onFormsChange={this.onGoodsFormsChange}
              />
            </Col>
          </Row>
          <Row>
            <DeliveryNoteFooter
              fields={footerFields}
              extraFields={footerExtraFields}
              wrappedComponentRef={el => this.footer = el}
            />
          </Row>
          <Row type="flex" className="primary-button-group" justify="center" align="middle">
            <Button type="primary" onClick={this.handleSaveOrder}>保存</Button>
            <Button type="primary" onClick={this.handleSaveAndPrint}>保存并打印</Button>
          </Row>
        </div>
      </Spin>
    );
  }
}

export default AddPickUp;
