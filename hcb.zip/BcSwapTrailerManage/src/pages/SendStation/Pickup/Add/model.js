import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { routerRedux } from 'dva/router';
import {
  getOrderDetail,
  getTruckList,
  getTrailerList,
  create,
  getCompanyList,
  getOrderList
} from '../services';
import { PREVIEW_PICK_UP } from '../pickUpConsts';

export default Model.extend({
  namespace: 'pickupAdd',
  state: {
    loading: { list: false, createOrder: false },
    yundanDatas: [],
    truckList: [],
    trailerList: []
  },
  subscriptions: {
    setupSubscriber({ listen, dispatch }) {
      listen('/sendStation/pickup/add', () => {
        dispatch({ type: 'getTruckList', payload: {} });
        dispatch({ type: 'getTrailerList', payload: { carrierCompany: '' } });
      });
    }
  },
  effects: {
    // 查询订单详情
    * getOrderDetail({ payload }, { call }) {
      const datas = yield call(getOrderDetail, payload);
      return datas;
    },
    * getTruckList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getTruckList, 'getTruckList'), { ...payload });
      yield update({
        truckList: datas.map(data => ({
          key: data.id,
          value: data.plateNumber
        }))
      });
    },
    * getTrailerList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getTrailerList, 'getTrailerList'), { ...payload });
      yield update({
        trailerList: datas.map(data => ({
          key: data.id,
          value: data.plateNumber
        }))
      });
    },
    * create({ payload }, { call, put }) {
      yield call(withLoading(create, { successMsg: '提货派车单新增成功！', key: 'createOrder' }), { ...payload });
      yield put(routerRedux.push('/sendStation/pickup'));
    },
    * createAndPrint({ payload }, { call, put }) {
      const data = yield call(withLoading(create,
        { successMsg: '提货派车单新增成功！', key: 'createOrder' }), { ...payload });
      yield put(routerRedux.replace(`${PREVIEW_PICK_UP}/${data}`));
    },
    * getCompanyList({ payload }, { call }) {
      const datas = yield call(getCompanyList, payload);
      const companyList = datas || [];
      return companyList.map(company => ({
        shipCompanyName: company
      }));
    },
    * getOrderList({ payload }, { call }) {
      return yield call(getOrderList, payload);
    }
  },
  reducers: {
    updateYundanDatas(state, { payload }) {
      return {
        ...state,
        yundanDatas: payload
      };
    },
  }
});
