import { formatValue, defaultKey } from 'utils/formatValue';
import { Popover } from 'antd';
import { EllipsisRecord } from 'components';
import moment from 'moment';
import { TRUCK_STATUS, STOWAGE_TYPE } from '../../../configs/maps';
import BillsModal from './BillsModal';

const Comp = params => (<BillsModal arterys={params} />);
const splitTime = (time) => {
  if (time) return moment(time).format('MM-DD HH:mm:ss');
  return defaultKey;
};

export const tableFields = [{
  key: 'no',
  name: '序号',
  width: 60,
  render: (a, b, i) => i + 1
}, {
  key: 'dispatchNo',
  name: '派车单号',
  width: 140,
  render: (a) => {
    if (a) {
      return (
        <a href={`#/sendStation/truckSend/truckDetail/${a}`} target="_blank" rel="noopener noreferrer">{a}</a>
      );
    }
    return defaultKey;
  }
}, {
  key: 'status',
  name: '状态',
  width: 80,
  render: (a) => {
    const s = (TRUCK_STATUS.filter(x => (x.key === a))[0].name);
    if (a === 'WAIT_DEPART') return <span style={{ color: 'rgb(255, 162, 61)' }}>{s}</span>;
    if (a === 'IN_TRANSIT') return <span style={{ color: 'rgb(33, 168, 59)' }}>{s}</span>;
    if (a) return s;
    return defaultKey;
  }
}, {
  key: 'stowageNo',
  name: '配载单号',
  width: 140,
  render: formatValue
}, {
  key: 'compartmentPlateNumber',
  name: '挂车车牌',
  width: 140,
  render: formatValue
}, {
  key: 'stowageType',
  name: '主营服务',
  width: 140,
  render: a => STOWAGE_TYPE.filter(item => item.key === a)[0].name
}, {
  key: 'siteLineName',
  name: '运行线路',
  width: 140,
  render: formatValue
}, {
  key: 'departureDate',
  name: '发车时间',
  width: 180,
  render: a => a || defaultKey
}, {
  key: 'arriveDate',
  name: '到达时间',
  width: 180,
  render: a => a || defaultKey
}, {
  key: 'totalArteryCount',
  name: '运输进度',
  width: 80,
  render: (a, b) => (
    <div>
      <span>{`${b.completeArteryCount}/${a}`}</span>
      <Popover content={Comp(b.arterys)} placement="top">
        <div className="icon-progress" />
      </Popover>
    </div>
  )
}, {
  key: 'totalOrders',
  name: '总单数',
  width: 80,
  render: formatValue
}, {
  key: 'totalPiece',
  name: '总件数',
  width: 80,
  render: formatValue
}, {
  key: 'totalWeight',
  name: '总重量（公斤）',
  width: 120,
  render: formatValue
}, {
  key: 'totalVolume',
  name: '总体积（方）',
  width: 120,
  render: formatValue
}, {
  key: 'totalFreight',
  name: '总费用（元）',
  width: 120,
  render: formatValue
}, {
  key: 'createTime',
  name: '下单时间',
  width: 180,
  render: (a) => {
    if (a) return a;
    return defaultKey;
  }
}, {
  key: 'remark',
  name: '派车备注',
  width: 200,
  render: formatValue
}];

export const billsFields = [{
  key: 'no',
  name: '序号',
  width: 60,
  render: (a, b, i) => i + 1
}, {
  key: 'startSiteName',
  name: '出发地',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'endSiteName',
  name: '目的地',
  width: 120,
  render: record => <EllipsisRecord record={record || '--'} row={2} />
}, {
  key: 'driverName',
  name: '司机',
  width: 180,
  render: (a, b) => {
    let str = a || '';
    const driverMobile = b.driverMobile || '';
    const plateNumber = b.plateNumber || '';
    if (str) {
      if (driverMobile) str += `，${driverMobile}`;
      if (plateNumber) str += `，${plateNumber} `;
    } else {
      str = driverMobile;
      if (str) {
        str += `，${plateNumber} `;
      } else {
        str = plateNumber;
      }
    }
    return str || '--';
  }
}, {
  key: 'planDepartureDate',
  name: '计划发车时间',
  width: 120,
  render: splitTime
}, {
  key: 'actualDepartureDate',
  name: '实际发车时间',
  width: 120,
  render: splitTime
}, {
  key: 'planArriveDate',
  name: '计划到达时间',
  width: 120,
  render: splitTime
}, {
  key: 'actualArriveDate',
  name: '实际到达时间',
  width: 120,
  render: splitTime
}];
