import React from 'react';
import { HTable } from 'carno';
import { billsFields } from './fields';

export default class BillsModal extends React.Component {
  state = {
    fields: billsFields,
    dataSource: [],
    search: { pn: 1, ps: 999 },
    pagination: false,
    scroll: { x: 1200 },
    locale: { emptyText: '暂无信息' },
    style: { marginTop: 16 },
  }

  static getDerivedStateFromProps = nextProps => ({
    dataSource: nextProps.arterys
  })

  render() {
    return (
      <div style={{ maxWidth: '1200px' }}>
        <HTable
          bordered
          {...this.state}
        />
      </div>
    );
  }
}
