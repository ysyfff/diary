import { connect } from 'dva';
import { Input, DatePicker, Select } from 'antd';
import NP from 'number-precision';
import { HTable } from 'carno';
// import { moment } from 'carno/third-party';
import _ from 'lodash';
import { Button, Radio, Form } from 'antd';
import ExtraCostInput from 'pages/ToSiteManage/DeliveryManage/ExtraCostInput';
import SelectDriver from '../../SelectDriver';
import { STOWAGE_TYPE, DRIVER_TYPE } from '../../../../configs/maps';
import styles from './index.less';

const RadioGroup = Radio.Group;
const { TextArea } = Input;
const FormItem = Form.Item;
const Option = Select.Option;

const RequiredTableTitle = ({ label }) =>
  (<FormItem
    style={{ marginBottom: 0 }}
    required
    label={label}
    colon={false}
  />);

const freightTableFields = [{
  title: '费用名称',
  dataIndex: 'costCategory',
  editable: true,
  width: '40%',
  fields: {
    type: 'input',
    props: {
      maxLength: 20,
      minLength: 1,
      placeholder: '请输入费用名称'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用名称'
      }]
    }
  }
}, {
  title: '费用金额',
  dataIndex: 'freightAmount',
  editable: true,
  width: '30%',
  fields: {
    type: 'inputnumber',
    props: {
      precision: 2,
      min: 0.01,
      max: 99999.99,
      placeholder: '请输入费用金额'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用金额'
      }]
    }
  }
}];
@connect(({ truckDispatch }) => ({ ...truckDispatch }), dispatch => ({
  updateSearch(params) {
    dispatch({ type: 'truckDispatch/updateSearch', payload: params });
  },
  getSiteLine(params) {
    dispatch({ type: 'truckDispatch/getSiteLine', payload: params });
  },
  updateState(params) {
    dispatch({ type: 'truckDispatch/updateState', payload: params });
  },
  save(params) {
    dispatch({ type: 'truckDispatch/save', payload: params });
  },
  saveAndPrint(params) {
    dispatch({ type: 'addTruck/saveAndPrint', payload: params });
  },
  dispatch
}))
export default class TruckDispatch extends React.Component {
  state = {
    updateDetail: {},
    nowOtherFregihts: [],
    isShowOtherFreightsModal: false,
    freightIndex: 0,
  }

  componentWillReceiveProps = (nextProps) => {
    const _stowage = nextProps.stowageList[0] || {};
    const { arterys } = this.state.updateDetail;
    if (!arterys || !arterys.length) {
      this.setState({
        updateDetail: {
          stowageNo: '',
          remark: '',
          arterys: [],
          ..._stowage
        }
      });
    }
  }

  componentWillUnmount = () => {
    const { updateState } = this.props;
    this.setState({
      updateDetail: {}
    });
    updateState({ nowSiteLine: {} });
  }

  onChangeRemark = (e) => {
    const remark = e.target.value;
    const { updateDetail } = this.state;
    this.setState({
      updateDetail: { ...updateDetail, remark }
    });
  }

  onSave = () => {
    const { save } = this.props;
    const { updateDetail } = this.state;
    const _updateDetail = JSON.parse(JSON.stringify(updateDetail));
    save(_updateDetail);
  }

  onSaveAndPrint = () => {
    const { saveAndPrint } = this.props;
    const { updateDetail } = this.state;
    const _updateDetail = JSON.parse(JSON.stringify(updateDetail));
    saveAndPrint(_updateDetail);
  }

  onChangeRadio = (e) => {
    const type = e.target.value;
    const { updateSearch } = this.props;
    updateSearch({ type });
  }

  onChangeStowage = async (value) => {
    this.setState({
      updateDetail: {
        stowageNo: '',
        remark: '',
        arterys: [],
      }
    });
    const { updateSearch, stowageList, updateState, dispatch } = this.props;
    updateSearch({ stowageNo: value });
    updateState({ nowSiteLine: {} });
    if (value.length === 14) {
      const { updateDetail } = this.state;
      const _updateDetail = stowageList.filter(item => item.stowageNo === value)[0];
      this.setState({
        updateDetail: { ...updateDetail, ..._updateDetail }
      });
      await dispatch({ type: 'truckDispatch/getSiteLine', payload: { id: _updateDetail.siteLineId } });
      this.handleDataSourceSiteList();
    }
  }

  onConfirmSelectDriver = (value, index) => {
    const { updateDetail } = this.state;
    const _updateDetail = _.cloneDeep(updateDetail);
    const { arterys } = _updateDetail;
    const _arterys = _.cloneDeep(arterys);
    _arterys[index].driverName = value.userName;
    _arterys[index].plateNumber = value.truckPlateNumber;
    _arterys[index].driverMobile = value.mobile;
    _arterys[index].driverId = value.userId;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onChangeDate = (value, field, index) => {
    const _value = value.format('YYYY-MM-DD HH:mm:ss');
    const { updateDetail } = this.state;
    const _updateDetail = _.cloneDeep(updateDetail);
    const { arterys } = _updateDetail;
    const _arterys = _.cloneDeep(arterys);
    _arterys[index][field] = _value;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onChangePlateNumber = (value, index) => {
    const { updateDetail } = this.state;
    const _updateDetail = _.cloneDeep(updateDetail);
    const { arterys } = _updateDetail;
    const _arterys = _.cloneDeep(arterys);
    _arterys[index].plateNumber = value;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onChangeFreight = (e, index) => {
    const freight = e.target.value;
    const { updateDetail } = this.state;
    const _updateDetail = _.cloneDeep(updateDetail);
    const { arterys } = _updateDetail;
    const _arterys = _.cloneDeep(arterys);
    _arterys[index].freight = freight;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onOtherFreightsChange = (value) => {
    const { freightIndex, updateDetail } = this.state;
    const { arterys } = updateDetail;
    const _arterys = _.cloneDeep(arterys);
    _arterys[freightIndex].otherFreights = value;
    this.setState({
      updateDetail: { ...updateDetail, arterys: _arterys }
    });
  }

  getProps() {
    const { tableFields, search, loading, drivers, trucks } = this.props;
    const _drivers = [];
    const options = [];
    const { updateDetail } = this.state;
    const { arterys, sequence = [] } = updateDetail;

    for (let i = 0; i < sequence.length - 1; i += 1) {
      arterys[i] = {
        ...arterys[i],
        index: sequence[i].index,
        startSiteId: sequence[i].siteId,
        startSiteName: sequence[i].siteName,
        endSiteName: sequence[i + 1].siteName,
        endSiteId: sequence[i + 1].siteId
      };
    }

    drivers.forEach((item) => {
      _drivers.push({
        driverName: item.userName,
        phone: item.mobile,
        category: item.belongType,
        plateNumber: item.truckPlateNumber
      });
    });

    trucks.forEach((item, index) => {
      options.push(<Option value={item.plateNumber} key={index}>{item.plateNumber}</Option>);
    });

    const columns = [{
      key: 'planDepartureDate',
      name: <RequiredTableTitle label="计划发车时间" />,
      render: (a, b, i) => (
        <DatePicker
          showTime
          format="MM-DD HH:mm"
          style={{ width: 170 }}
          placeholder="请选择计划发车时间"
          onChange={e => this.onChangeDate(e, 'planDepartureDate', i)}
        />
      )
    }, {
      key: 'planArriveDate',
      name: <RequiredTableTitle label="计划到达时间" />,
      render: (a, b, i) => (
        <DatePicker
          showTime
          format="MM-DD HH:mm"
          style={{ width: 170 }}
          placeholder="请选择计划到达时间"
          onChange={e => this.onChangeDate(e, 'planArriveDate', i)}
        />
      )
    }, {
      key: 'driverName',
      name: <RequiredTableTitle label="司机" />,
      render: (a, b, i) => (
        <SelectDriver
          disabled={i !== 0}
          style={{ width: 200 }}
          dataSource={_drivers}
          status={DRIVER_TYPE}
          nowStatus="GROUNDLINE"
          onConfirm={value => this.onConfirmSelectDriver(value, i)}
        />
      )
    }, {
      key: 'plateNumber',
      name: <RequiredTableTitle label="车头车牌" />,
      render: (a, b, i) => (
        <Select
          disabled={i !== 0}
          style={{ width: 120 }}
          value={a}
          onChange={value => this.onChangePlateNumber(value, i)}
        >
          {options}
        </Select>
      )
    }, {
      name: '运费',
      key: 'freight',
      width: 140,
      render: (a, b, i) => (
        <Input
          disabled={i !== 0}
          placeholder="请输入运费信息"
          style={{ width: 170 }}
          value={a}
          onChange={e => this.onChangeFreight(e, i)}
        />
      )
    }, {
      name: '其他费用',
      key: 'otherFreights',
      width: 300,
      render: (a, b, i) => {
        if (i !== 0) {
          return <Input disabled />;
        }
        const source = (a === null ? [] : (a || []));
        return (<ExtraCostInput
          source={source}
          modalProps={{ title: '其他费用', width: 600 }}
          tableFields={freightTableFields}
          format={this.format}
          calculateKey="freightAmount"
          onClick={() => this.handleFreightsClick(i)}
          euxuChange
          onChange={this.onOtherFreightsChange}
        />);
      }
    }, {
      key: 'totalFreights',
      name: '费用合计',
      render: (a, b) => {
        let total = b.freight ? Number(b.freight) : 0;
        if (b.otherFreights && b.otherFreights[0].costCategory) {
          b.otherFreights.forEach((item) => {
            total = NP.plus(total, Number(item.freightAmount));
          });
          return total;
        }
        return total;
      }
    }];

    const _tableFields = tableFields.slice();
    _tableFields.splice(6, 0, ...columns);

    return {
      tableProps: {
        fields: _tableFields,
        dataSource: arterys,
        search,
        loading: loading.addTruck,
        scroll: { x: 1800 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
    };
  }

  // getStowageList = async () => {
  //   const { dispatch } = this.props;
  //   await dispatch({ type: 'truckDispatch/getStowageList' });
  // }

  // 查询线路详细信息
  getSiteLine = (id) => {
    const { getSiteLine } = this.props;
    getSiteLine({ id });
  }


  // 根据站点线路动态修改table的数据源
  handleDataSourceSiteList = () => {
    const { nowSiteLine } = this.props;
    const { updateDetail } = this.state;
    let _updateDetail = _.cloneDeep(updateDetail);
    _updateDetail = { ..._updateDetail, ...nowSiteLine };
    this.setState({
      updateDetail: { ...updateDetail, ..._updateDetail }
    });
  }

  format = fields => Object.keys(fields)
    .map((fieldKey) => {
      const field = fields[fieldKey];
      return ['costCategory', 'freightAmount'].map(key => field[key].value).join('：');
    }).join('；');

  cancelOtherFreightsModal = () => {
    this.setState({
      isShowOtherFreightsModal: false
    });
  }

  cancel = () => {
    window.location.hash = '#/sendStation/truckSend';
  }

  handleFreightsClick = (freightIndex) => {
    this.setState({
      freightIndex
    });
  }

  render() {
    const { updateDetail } = this.state;
    const { stowageList, search, nowSiteLine } = this.props;
    const { tableProps } = this.getProps();
    const _stowageType = [];
    STOWAGE_TYPE.forEach((item, index) => {
      _stowageType.push(
        <Radio value={item.key} key={index}>{item.name}</Radio>
      );
    });

    return (
      <div className={styles['stowage-detail']}>
        <div className="title">
          <div>
            <span className="normal-label"><span style={{ color: 'red' }}>*</span> 主营服务：</span>
            <RadioGroup value={search.type} disabled>
              {_stowageType}
            </RadioGroup>
          </div>
        </div>
        <div className="part">
          <h2>基本信息</h2>
          <table className="base-info">
            <tbody>
              <tr>
                <td className="normal-label">配载单号：</td>
                <td style={{ width: 260 }}>
                  <div style={{ width: 200 }}>
                    {/* <AutoSearchInput
                      inputKey="stowageNo"
                      columns={searchInputFields}
                      dropDownTableWidth={800}
                      onSearch={this.getStowageList}
                      dataSource={stowageList}
                      onChange={this.onChangeStowage}
                    /> */}
                    <Input disabled value={(stowageList[0] && stowageList[0].stowageNo) || ''} />
                  </div>
                </td>
                <td className="normal-label">发车线路：</td>
                <td>{
                  nowSiteLine.startSiteName ?
                    `${nowSiteLine.startSiteName} - ${nowSiteLine.endSiteName}`
                    : '--'
                }</td>
                <td className="normal-label">挂车车牌：</td>
                {
                  updateDetail.trailerPlateNumber ?
                    <td className="bold-text">{updateDetail.trailerPlateNumber }</td>
                    : <td>--</td>
                }
              </tr>
              <tr>
                <td className="normal-label">派车备注：</td>
                <td colSpan={5}>
                  <TextArea
                    maxLength={125}
                    value={updateDetail.remark}
                    rows={4}
                    placeholder="请输入备注"
                    onChange={this.onChangeRemark}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="part">
          <h2>调度信息</h2>
          <div className="info-list">
            <HTable
              {...tableProps}
              style={{ marginTop: 30 }}
            />
          </div>
        </div>
        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <Button type="primary" onClick={this.onSaveAndPrint}>新建并打印</Button>
          <Button type="primary" style={{ marginLeft: 10 }} onClick={this.onSave}>新建</Button>
          <Button style={{ marginLeft: 10 }} onClick={this.cancel}>取消</Button>
        </div>
      </div>
    );
  }
}
