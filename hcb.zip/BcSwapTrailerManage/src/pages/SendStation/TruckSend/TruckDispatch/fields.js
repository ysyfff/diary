import { formatValue } from 'utils/formatValue';

export const tableFields = [{
  key: 'startSiteName',
  name: '出发地',
  render: formatValue
}, {
  key: 'endSiteName',
  name: '目的地',
  render: formatValue
}];
