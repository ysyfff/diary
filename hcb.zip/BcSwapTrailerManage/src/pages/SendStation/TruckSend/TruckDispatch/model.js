import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { PAGE_SIZE, Paths } from 'configs/constants';
import _ from 'lodash';
import { routerRedux } from 'dva/router';
import { tableFields } from './fields';
import { getStowageList, getSiteLine, getTrucks, save } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  stowageNo: '',
  status: '',
  trailerPlateNumber: '',
  siteLineId: '',
  type: 'CHANNELSERVICE'
};

export default Model.extend({
  namespace: 'truckDispatch',
  state: {
    loading: { truckDispatch: false },
    tableFields,
    search: initialSearch,
    stowageList: [],
    nowSiteLine: {},
    drivers: [],
    trucks: []
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.TRUCK_SEND_TRUCK_DISPATCH, async ({ params }) => {
        dispatch({ type: 'updateSearch', payload: { stowageNo: params[0], type: '' } });
        await dispatch({ type: 'getStowageList' });
        await dispatch({ type: 'getSiteLine' });
        dispatch({ type: 'getTrucks', payload: { effective: 1 } });
      });
    }
  },
  effects: {
    * getStowageList({ payload }, { call, select, update }) {
      const { search } = yield select(({ truckDispatch }) => truckDispatch);
      const { datas } = yield call(withLoading(getStowageList, 'truckDispatch'), search);
      const [{ type }] = datas || [{}];
      yield update({ stowageList: datas, search: { ...search, type } });
    },
    * getSiteLine({ payload }, { call, update, select }) {
      const { stowageList } = yield select(({ truckDispatch }) => truckDispatch);
      const nowSiteLine = yield call(withLoading(getSiteLine, 'truckDispatch'),
        { id: stowageList[0].siteLineId });
      const _stowageList = _.cloneDeep(stowageList);
      _stowageList[0] = { ..._stowageList[0], sequence: nowSiteLine.sequence };
      yield update({ nowSiteLine, stowageList: _stowageList });
    },
    * getTrucks({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getTrucks, 'addTruck'), payload);
      yield update({ trucks: datas });
    },
    * save({ payload }, { call }) {
      yield call(withLoading(save, 'truckDispatch', '派车成功'), payload);
      window.location.hash = '#/sendStation/truckSend';
    },
    * saveAndPrint({ payload }, { call, put }) {
      const dispathNo = yield call(withLoading(save, 'addTruck', '派车成功'), payload);
      const { stowageNo } = payload;
      yield put(routerRedux.replace(`/sendStation/printHandOver/${stowageNo}/${dispathNo}/2`));
    }
  },
  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
