import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';
import { tableFields } from './fields';
import {
  getDispatchList, getSiteLineList, confirmDepart, cancelDepart, departDetail, updateDepart, getSiteList
} from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  status: '',
  waybillNo: '',
  driver: '',
  stowageNo: '',
  dispatchNo: '',
  plateNumber: '',
  compartmentPlateNumber: '',
  siteLineId: '',
  stowageType: '',
  startSiteId: '',
  createTime: '',
  dispatchDate: '',
  arriveDate: ''
};

export default Model.extend({
  namespace: 'truckSend',
  state: {
    tableFields,
    loading: { truckSend: false },
    search: { ...initialSearch },
    list: [],
    siteList: [], // 线路列表
    sites: [], // 站点列表
    total: 0
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.TRUCK_SEND, async () => {
        await dispatch({ type: 'resetSearch' });
        dispatch({ type: 'getDispatchList' });
      });
    }
  },
  effects: {
    * getDispatchList({ payload }, { call, update, select }) {
      const { search } = yield select(({ truckSend }) => truckSend);
      const { datas, tc } = yield call(withLoading(getDispatchList, 'truckSend'), search);
      yield update({ list: datas, total: tc });
    },
    * getSiteList({ payload }, { call, update }) {
      const datas = yield call(withLoading(getSiteList, 'list'), payload);
      yield update({ sites: datas });
    },
    * getSiteLineList({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getSiteLineList, 'truckSend'), { effective: 1 });
      yield update({ siteList: datas });
    },
    * confirmDepart({ payload }, { call, put }) {
      yield call(withLoading(confirmDepart, 'truckSend', '发车成功'), payload);
      yield put({ type: 'getDispatchList' });
    },
    * updateDepart({ payload }, { call, put }) {
      yield call(withLoading(updateDepart, 'truckSend', '修改成功'), payload);
      yield put({ type: 'getDispatchList' });
    },
    * cancelDepart({ payload }, { call, put }) {
      yield call(withLoading(cancelDepart, 'truckSend', '取消成功'), payload);
      yield put({ type: 'getDispatchList' });
    },
    * departDetail({ payload }, { call }) {
      yield call(withLoading(departDetail, 'truckSend'), payload);
    },
  },
  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
    resetSearch(state, { payload }) {
      return {
        ...state,
        search: { ...initialSearch }
      };
    },
  },
});
