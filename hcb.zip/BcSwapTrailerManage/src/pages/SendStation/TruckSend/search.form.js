import { STOWAGE_TYPE } from 'configs/maps';
import renderFormFactory from '../../../components/common/renderFormFactory';

const stowageType = STOWAGE_TYPE.map(item => ({ key: item.name, value: item.key }));

const formConfig = [{
  key: 'dispatchNo',
  label: '派车单号',
  type: 'input',
  placeholder: '请输入派车单号'
}, {
  key: 'waybillNo',
  label: '运单号',
  type: 'input',
  placeholder: '请输入运单号'
}, {
  key: 'driver',
  label: '司机',
  type: 'input',
  placeholder: '请输入司机姓名或手机'
}, {
  key: 'siteLineId',
  label: '运行线路',
  type: 'select',
  options: [],
  placeholder: '请选择线路'
}, {
  key: 'stowageType',
  label: '主营服务',
  type: 'select',
  options: stowageType,
  placeholder: '请选择主营服务'
}, {
  key: 'stowageNo',
  label: '配载单号',
  type: 'input',
  placeholder: '请输入配载单号'
}, {
  key: 'compartmentPlateNumber',
  label: '挂车车牌',
  type: 'input',
  placeholder: '请输入挂车车牌'
}, {
  key: 'plateNumber',
  label: '车头车牌',
  type: 'input',
  placeholder: '请输入车头车牌'
}, {
  key: 'startSiteId',
  label: '始发站点',
  type: 'select',
  options: [],
  placeholder: '请选择站点'
}, {
  key: 'dispatchDate',
  label: '发车时间',
  type: 'rangepicker',
  showTime: true,
  format: 'MM-DD HH:mm'
}, {
  key: 'arriveDate',
  label: '到达时间',
  type: 'rangepicker',
  showTime: true,
  format: 'MM-DD HH:mm'
}, {
  key: 'createTime',
  label: '下单时间',
  type: 'rangepicker',
  showTime: true,
  format: 'MM-DD HH:mm'
}];

export default renderFormFactory(formConfig, (values) => {
  const { dispatchDate, arriveDate, createTime, ...otherValues } = values;
  // 发车时间
  const dispatchRangeDate = dispatchDate || ['', ''];
  const dispatchBeginDate = dispatchRangeDate[0] && dispatchRangeDate[0].format('YYYY-MM-DD HH:mm:ss');
  const dispatchEndDate = dispatchRangeDate[1] && dispatchRangeDate[1].format('YYYY-MM-DD HH:mm:ss');

  // 到达时间
  const arriveRangeDate = arriveDate || ['', ''];
  const arriveBeginDate = arriveRangeDate[0] && arriveRangeDate[0].format('YYYY-MM-DD HH:mm:ss');
  const arriveEndDate = arriveRangeDate[1] && arriveRangeDate[1].format('YYYY-MM-DD HH:mm:ss');

  // 下单时间
  const createRangeDate = createTime || ['', ''];
  const createBeginDate = createRangeDate[0] && createRangeDate[0].format('YYYY-MM-DD HH:mm:ss');
  const createEndDate = createRangeDate[1] && createRangeDate[1].format('YYYY-MM-DD HH:mm:ss');

  return {
    dispatchBeginDate,
    dispatchEndDate,
    arriveBeginDate,
    arriveEndDate,
    createBeginDate,
    createEndDate,
    ...otherValues
  };
}, { xl: { span: 8 } });
