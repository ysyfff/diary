import NP from 'number-precision';
import { formatValue, defaultKey } from 'utils/formatValue';

export const tableFields = [{
  key: 'startSiteName',
  name: '出发地',
  render: formatValue
}, {
  key: 'endSiteName',
  name: '目的地',
  render: formatValue
}, {
  key: 'planDepartureDate',
  name: '计划发车时间',
  render: (a) => {
    if (a) return a;
    return defaultKey;
  }
}, {
  key: 'actualDepartureDate',
  name: '实际发车时间',
  render: (a) => {
    if (a) return a;
    return defaultKey;
  }
}, {
  key: 'departMileage',
  name: '发车里程数（公里）',
  render: formatValue
}, {
  key: 'planArriveDate',
  name: '计划到达时间',
  render: (a) => {
    if (a) return a;
    return defaultKey;
  }
}, {
  key: 'actualArriveDate',
  name: '实际到达时间',
  render: (a) => {
    if (a) return a;
    return defaultKey;
  }
}, {
  key: 'arriveMileage',
  name: '到达里程数（公里）',
  render: formatValue
}, {
  key: 'driverName',
  name: '司机',
  render: (a, b) => {
    let str = a || '';
    const driverMobile = b.driverMobile || '';
    const plateNumber = b.plateNumber || '';
    if (str) {
      if (driverMobile) str += `，${driverMobile}`;
      if (plateNumber) str += `，${plateNumber} `;
    } else {
      str = driverMobile;
      if (str) {
        str += `，${plateNumber} `;
      } else {
        str = plateNumber;
      }
    }
    return str || '--';
  }
}, {
  key: 'freight',
  name: '运费',
  render: formatValue
}, {
  key: 'otherFreights',
  name: '其他费用',
  render: (a) => {
    if (a && a[0].costCategory) {
      let str = '';
      a.map(item => str += `${item.costCategory}: ${item.freightAmount}; `);
      return formatValue(str);
    }
    return defaultKey;
  }
}, {
  key: 'totalFreights',
  name: '费用合计',
  render: (a, b) => {
    let total = Number(b.freight) || 0;
    if (b.otherFreights && b.otherFreights[0].costCategory) {
      b.otherFreights.forEach((item) => {
        total = NP.plus(total, Number(item.freightAmount));
      });
    }
    return total;
  }
}];
