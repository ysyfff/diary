import { connect } from 'dva';
import { Button } from 'antd';
import { HTable } from 'carno';
import { bind } from 'bind-decorator';
import { STOWAGE_TYPE, TRUCK_STATUS } from '../../../../configs/maps';
import styles from './index.less';

@connect(({ truckDetail }) => ({ ...truckDetail }))
export default class TruckDetail extends React.Component {
  getProps() {
    const { tableFields, search, loading, dispatchDetail } = this.props;
    const { arterys } = dispatchDetail;

    return {
      tableProps: {
        fields: tableFields,
        dataSource: arterys,
        search,
        loading: loading.truckDetail,
        scroll: { x: 2250 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
    };
  }

  print = () => {
    window.print();
  }

  @bind
  printHandOver() {
    const { history, dispatchNo, dispatchDetail } = this.props;
    const { stowageNo } = dispatchDetail;
    history.push(`/sendStation/printHandOver/${stowageNo}/${dispatchNo}/1`);
  }

  render() {
    const { dispatchDetail, showPrint = true } = this.props;
    const { stowageType, status } = dispatchDetail;
    const { tableProps } = this.getProps();
    let _stowageType = '';
    let _status = '';
    if (stowageType) {
      _stowageType = STOWAGE_TYPE.filter(x => x.key === stowageType)[0].name;
      _status = TRUCK_STATUS.filter(x => x.key === status)[0].name;
    }

    return (
      <div className={styles['stowage-detail']}>
        <div className="title">
          <div>
            <span className="normal-label">主营服务：</span>{_stowageType}
          </div>
          <div>
            {showPrint &&
              <span className="mr10">
                {status !== 'CANCEL' && <Button type="primary" onClick={this.printHandOver}>打印清单</Button>}
              </span>
            }
            <span>派车单号：</span><span style={{ color: '#0f9efa', marginRight: 10 }}>{dispatchDetail.dispatchNo} </span>
            <span className="normal-label">状态：</span><span style={{ color: 'rgb(17, 165, 33)' }}>{_status}</span>
          </div>
        </div>
        <div className="part">
          <h2>基本信息</h2>
          <table className="base-info">
            <tbody>
              <tr>
                <td className="normal-label">配载单号：</td>
                <td className="bold-text">
                  {
                    _status !== '已取消' ?
                      <a href={`#/sendStation/stowageManage/stowageDetail/${dispatchDetail.stowageNo}`}>
                        {dispatchDetail.stowageNo}
                      </a> : null
                  }
                  {
                    _status === '已取消' ? dispatchDetail.stowageNo : null
                  }
                </td>
                <td className="normal-label">发车线路：</td><td>{dispatchDetail.siteLineName}</td>
                <td className="normal-label">挂车车牌：</td>
                <td className="bold-text">{dispatchDetail.compartmentPlateNumber}</td>
              </tr>
              <tr>
                <td className="normal-label">配载备注：</td><td>{dispatchDetail.remark}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="part">
          <h2>调度信息</h2>
          <div className="info-list">
            <HTable
              {...tableProps}
              style={{ marginTop: 30 }}
            />
          </div>
        </div>
        {/* <div style={{ textAlign: 'center', marginTop: 20 }}>
          <Button type="primary" onClick={this.print}>打印派车单</Button>
        </div> */}
      </div>
    );
  }
}
