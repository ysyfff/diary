import http from 'utils/http';

const { post } = http.create('dapt');

// 获取干线派车单详情
export function getDispatchDetail(params) {
  return post('/web/m/dispatch/detail', params);
}
