import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getDispatchDetail } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE
};

export default Model.extend({
  namespace: 'truckDetail',
  state: {
    loading: { truckDetail: false },
    tableFields,
    search: initialSearch,
    dispatchDetail: {},
    dispatchNo: ''
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(`${Paths.TRUCK_SEND_TRUCK_DETAIL}`, ({ params }) => {
        const dispatchNo = params.dispatchNo;
        dispatch({ type: 'updateState', payload: { dispatchNo } });
        dispatch({ type: 'getDispatchDetail', payload: { dispatchNo } });
      });
      listen(`${Paths.ARRIVE_DETAIL}`, ({ params }) => {
        const dispatchNo = params.dispatchNo;
        dispatch({ type: 'updateState', payload: { dispatchNo } });
        dispatch({ type: 'getDispatchDetail', payload: { dispatchNo } });
      });
    }
  },
  effects: {
    * getDispatchDetail({ payload }, { call, update }) {
      const dispatchDetail = yield call(withLoading(getDispatchDetail), payload);
      yield update({ dispatchDetail });
    },
  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload
      };
    }
  }
});
