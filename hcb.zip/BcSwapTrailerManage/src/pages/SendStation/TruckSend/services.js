import http from 'utils/http';
import { getDeployEnv } from 'carno/utils';
import { servers as serverConfigs } from 'configs';

export function getServer(servers = serverConfigs) {
  return servers[getDeployEnv(process.env.DEPLOY_ENV)];
}

const { post } = http.create('dapt');

// 查询首页列表
export function getDispatchList(param) {
  return post('/web/m/dispatch/list', param);
}

// 查询线路列表
export function getSiteLineList(param) {
  return post('/web/m/siteline/list', param);
}

// 导出首页列表
export function exportDispatch() {
  return '/web/m/dispatch/export';
}

// 确认发车
export function confirmDepart(param) {
  return post('/web/m/dispatch/confirm-depart', param);
}

// 编辑
export function updateDepart(param) {
  return post('/web/m/dispatch/modify', param);
}

// 取消
export function cancelDepart(param) {
  return post('/web/m/dispatch/cancel-depart', param);
}

// 详情
export function departDetail(param) {
  return post('/web/m/dispatch/detail', param);
}

// 获取站点信息
export function getSiteList(param) {
  return post('/web/e/site/search', param);
}

// 库存导出
// export function exportStockList({ server, url, params }) {
//   const qsparms = { ...params, sid: cookie.get('sid'), st: cookie.get('st') };
//   const serverUrl = `${getServer()[server]}${url}?${qs.stringify({ ...qsparms })}`;
//   window.open(serverUrl, '_blank');
// }
