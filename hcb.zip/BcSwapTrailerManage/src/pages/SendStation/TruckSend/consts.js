const baseItemLayout = {
  labelCol: {
    xxl: { span: 8 },
    xl: { span: 6 },
    lg: { span: 6 },
    md: { span: 6 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xxl: { span: 12 },
    xl: { span: 16 },
    lg: { span: 14 },
    md: { span: 14 },
    sm: { span: 14 }
  }
};

export {
  baseItemLayout
};
