
/**
 * @author 江林
 * @description 干线派车
 * @since 2018.09.10
 */
import React from 'react';
import { Row, Col, Button, Popover, Icon, Radio, Modal, DatePicker, InputNumber } from 'antd';
import { connect } from 'dva';
import { Paths } from 'configs/constants';
import { Link } from 'dva/router';
import moment from 'moment';
import _ from 'lodash';
import { HTable } from 'carno';
import { STOWAGE_TYPE } from 'configs/maps';
import { AuthortyWarpper } from 'components';
import buttonAuthoritesConfig from 'configs/buttonAuthoritesConfig';
import searchRender from './search.form';
import { baseItemLayout } from './consts';
import { BaseSearchBar } from '../../../components';
import { downFile } from '../../../utils/downloadFile';
import { exportDispatch } from './services';
import styles from './index.less';

function range(start, end) {
  const result = [];
  for (let i = start; i < end; i += 1) {
    result.push(i);
  }
  return result;
}

const stowageType = STOWAGE_TYPE.map(item => ({ key: item.name, value: item.key }));

// 获取rangepick默认值
function getRangepickerConfig(key, search, startKey, endKey) {
  const startTime = search[startKey];
  const endTime = search[endKey];
  let defaultValue = null;
  if (startTime && endTime) {
    defaultValue = [moment(startTime), moment(endTime)];
  } else {
    defaultValue = undefined;
  }
  return { key, defaultValue };
}

@connect(({ truckSend }) => ({ ...truckSend }), dispatch => ({
  getDispatchList(params) {
    dispatch({ type: 'truckSend/updateSearch', payload: params });
    dispatch({ type: 'truckSend/getDispatchList' });
  },
  updateSearch(params) {
    dispatch({ type: 'truckSend/updateSearch', payload: params });
  },
  confirmDepart(params) {
    dispatch({ type: 'truckSend/confirmDepart', payload: params });
  },
  cancelDepart(params) {
    dispatch({ type: 'truckSend/cancelDepart', payload: params });
  },
  dispatch
}))
class DeliveryManage extends React.PureComponent {
  state = {
    searchRender,
    visiblepop: [],
    isShowConfirmDepartModal: false,
    isShowCancelDepartModal: false,
    dispatchNo: '',
    depart: {},
    truckStartTime: moment().format('YYYY-MM-DD HH:mm:ss'),
    mileage: ''
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    await dispatch({ type: 'truckSend/getSiteLineList' });
    await dispatch({ type: 'truckSend/getSiteList' });

    this.handleSites();
    this.handleSiteList();
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      visiblepop: nextProps.list.map(() => false)
    });
    if (_.isEqual(this.props.search, nextProps.search)) {
      this.rerender();
    }
  }

  onStartTruckTimeChange = (date, dateString) => {
    this.setState({
      truckStartTime: dateString
    });
  }

  onMileageChange = (mileage) => {
    this.setState({
      mileage
    });
  }

  getExtraFields= () => ({
    key: 'action',
    name: '操作',
    width: 80,
    render: (a, b, i) => (
      <Popover
        placement="right"
        trigger="hover"
        visible={this.state.visiblepop[i]}
        onVisibleChange={() => this.changePop(i, false)}
        content={
          <div onClick={() => this.changePop(i, false)}>
            <ul className="table-operate-button">
              {
                b.status === 'WAIT_DEPART'
                  ? <AuthortyWarpper code={buttonAuthoritesConfig.dispatch.depart}>
                    <li><a onClick={() => this.showConfirmDepartModal(b.dispatchNo, b)}>确认发车</a></li>
                  </AuthortyWarpper>
                  : null
              }
              {
                (b.status === 'IN_TRANSIT') || (b.status === 'ARRIVED')
                  ? <AuthortyWarpper code={buttonAuthoritesConfig.dispatch.modify}>
                    <li><a onClick={() => this.updateDepart(b.dispatchNo)}>修改派车</a></li>
                  </AuthortyWarpper>
                  : null
              }
              {
                b.status === 'WAIT_DEPART'
                  ? <AuthortyWarpper code={buttonAuthoritesConfig.dispatch.cancel}>
                    <li><a onClick={() => this.showCancelDepartModal(b.dispatchNo)}>取消派车</a></li>
                  </AuthortyWarpper>
                  : null
              }
              <li>
                <a
                  href={`#/sendStation/truckSend/truckDetail/${b.dispatchNo}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                    派车详情
                </a>
              </li>
            </ul>
          </div>
        }
      >
        <a><Icon type="menu-unfold" onMouseOver={() => this.changePop(i, true)} /></a>
      </Popover>
    )
  })

  getProps = () => {
    const { tableFields, search, total, list, loading, getDispatchList } = this.props;
    const { pn, ps } = search;
    const extraField = this.getExtraFields();
    const _tableFields = tableFields.slice();
    _tableFields.splice(3, 0, extraField);

    const pagination = {
      current: pn,
      pageSize: ps,
      total,
      showQuickJumper: true,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
      showTotal: total => `总共 ${total} 条`,
      onChange: pn => getDispatchList({ pn }),
      onShowSizeChange: (current, size) => getDispatchList({ ps: size, pn: 1 })
    };

    return {
      tableProps: {
        fields: _tableFields,
        dataSource: list,
        loading: loading.truckSend,
        search,
        scroll: { x: 3000 },
        pagination,
        locale: { emptyText: '暂无数据' },
        style: { marginTop: 16 },
      }
    };
  }

  rerender = () => {
    const { search, siteList, sites } = this.props;
    const _siteList = [];
    for (let i = 0; i < siteList.length; i += 1) {
      const obj = {};
      obj.key = siteList[i].name;
      obj.value = siteList[i].id;
      _siteList.push(obj);
    }

    const _sites = [];
    for (let i = 0; i < sites.length; i += 1) {
      const obj = {};
      obj.key = sites[i].name;
      obj.value = sites[i].id;
      _sites.push(obj);
    }

    const searchBarConfig = [{
      key: 'waybillNo',
      defaultValue: search.waybillNo || ''
    }, {
      key: 'driver',
      defaultValue: search.driver || ''
    }, {
      key: 'stowageNo',
      defaultValue: search.stowageNo || ''
    }, {
      key: 'dispatchNo',
      defaultValue: search.dispatchNo || ''
    }, {
      key: 'plateNumber',
      defaultValue: search.plateNumber || ''
    }, {
      key: 'compartmentPlateNumber',
      defaultValue: search.compartmentPlateNumber || ''
    }, {
      key: 'siteLineId',
      options: [{ key: '全部', value: '' }].concat(_siteList),
      defaultValue: search.siteLineId || ''
    }, {
      key: 'stowageType',
      options: [{ key: '全部', value: '' }].concat(stowageType),
      defaultValue: search.stowageType || ''
    }, {
      key: 'startSiteId',
      options: [{ key: '全部', value: '' }].concat(_sites),
      defaultValue: search.startSiteId || ''
    }, getRangepickerConfig(
      'createTime',
      search,
      'createBeginDate',
      'createEndDate',
    ), getRangepickerConfig(
      'arriveDate',
      search,
      'arriveBeginDate',
      'arriveEndDate',
    ), getRangepickerConfig(
      'dispatchDate',
      search,
      'dispatchBeginDate',
      'dispatchEndDate',
    )];
    // rerender到站、发站select
    this.setState({
      searchRender: searchRender.rerender(searchBarConfig)
    });
  }

  changePop = (i, status) => {
    const { visiblepop } = this.state;
    let _visiblepop = visiblepop.slice();
    _visiblepop = _visiblepop.map(() => false);
    _visiblepop.splice(i, 1, status);
    this.setState({
      visiblepop: _visiblepop
    });
  }

  // 组长线路下拉菜单
  handleSiteList = () => {
    const { siteList } = this.props;
    const _siteList = [];
    for (let i = 0; i < siteList.length; i += 1) {
      const obj = {};
      obj.key = siteList[i].name;
      obj.value = siteList[i].id;
      _siteList.push(obj);
    }
    this.setState({
      searchRender: searchRender.rerender([
        {
          key: 'siteLineId',
          options: [{ key: '全部', value: '' }].concat(_siteList)
        }])
    });
  }

  handleSites = () => {
    const { sites } = this.props;
    const _sites = [];
    for (let i = 0; i < sites.length; i += 1) {
      const obj = {};
      obj.key = sites[i].name;
      obj.value = sites[i].id;
      _sites.push(obj);
    }
    this.setState({
      searchRender: searchRender.rerender([
        {
          key: 'startSiteId',
          options: [{ key: '全部', value: '' }].concat(_sites)
        }])
    });
  }

  handleSearch = (values) => {
    const { getDispatchList } = this.props;
    getDispatchList(values);
  }

  handleStatusChange = (e) => {
    const { getDispatchList } = this.props;
    const status = e.target.value;
    getDispatchList({ status, pn: 1 });
  }

  handleValuesChange = (values) => {
    const { updateSearch } = this.props;
    updateSearch(values);
  }

  exportDispatch = () => {
    const { search } = this.props;
    downFile({ server: 'dapt', url: exportDispatch(), params: search });
  }

  confirmDepart = () => {
    const { confirmDepart } = this.props;
    const { dispatchNo, truckStartTime, mileage } = this.state;
    if (!truckStartTime) {
      Modal.error({
        title: '请填写发车时间'
      });
      return;
    }
    if (!mileage) {
      Modal.error({
        title: '请填写里程数'
      });
      return;
    }
    confirmDepart({ dispatchNo, dispatchDate: truckStartTime, dispatchMileage: mileage });
    this.cancelConfirmDepartModal();
  }

  updateDepart = (dispatchNo) => {
    window.location.hash = `#/sendStation/truckSend/updateTruck/${dispatchNo}`;
  }

  cancelDepart = () => {
    const { cancelDepart } = this.props;
    const { dispatchNo } = this.state;
    cancelDepart({ dispatchNo });
    this.cancelCancelDepartModal();
  }

  showConfirmDepartModal = (dispatchNo, depart) => {
    this.setState({
      dispatchNo,
      depart,
      isShowConfirmDepartModal: true
    });
  }

  cancelConfirmDepartModal = () => {
    this.setState({
      truckStartTime: moment().format('YYYY-MM-DD HH:mm:ss'),
      mileage: '',
      isShowConfirmDepartModal: false
    });
  }

  showCancelDepartModal = (dispatchNo) => {
    this.setState({
      dispatchNo,
      isShowCancelDepartModal: true
    });
  }

  cancelCancelDepartModal = () => {
    this.setState({
      isShowCancelDepartModal: false
    });
  }

  disabledStartDate = current => current && current > moment()

  disabledStartTime = () => ({
    disabledHours: () => range(new Date().getHours() + 1, 24),
    disabledMinutes: () => range(new Date().getMinutes() + 1, 60)
  })

  render() {
    const { search } = this.props;
    const { searchRender } = this.state;
    const { tableProps } = this.getProps();
    const plateNumber = this.state.depart.arterys ? this.state.depart.arterys[0].plateNumber : '';
    return (
      <div className={styles['truck-send']}>
        <BaseSearchBar
          onSearch={this.handleSearch}
          render={searchRender}
          onValuesChange={this.handleValuesChange}
          baseItemLayout={baseItemLayout}
        />
        <div>
          <Row type="flex" justify="space-between">
            <Col className="arrive-namage-tool-bar">
              <Radio.Group onChange={this.handleStatusChange} value={search.status} buttonStyle="solid">
                <Radio.Button value="">全部</Radio.Button>
                <Radio.Button value="WAIT_DEPART">待发车</Radio.Button>
                <Radio.Button value="IN_TRANSIT">在途中</Radio.Button>
                <Radio.Button value="ARRIVED">已完成</Radio.Button>
                <Radio.Button value="CANCEL">已取消</Radio.Button>
              </Radio.Group>
            </Col>
            <Col>
              <div className="arrive-namage-tool-bar">
                <AuthortyWarpper code={buttonAuthoritesConfig.dispatch.create}>
                  <Link to={Paths.TRUCK_SEND_ADD_TRUCK} target="_blank">
                    <Button style={{ margin: '0 10px' }} type="primary">新建干线派车单</Button>
                  </Link>
                </AuthortyWarpper>
                <AuthortyWarpper code={buttonAuthoritesConfig.dispatch.export}>
                  <Button style={{ margin: '0 10px' }} onClick={this.exportDispatch}>导出表单</Button>
                </AuthortyWarpper>
              </div>
            </Col>
          </Row>
          <HTable
            {...tableProps}
          />
        </div>
        <Modal
          title="确认发车"
          visible={this.state.isShowConfirmDepartModal}
          onOk={this.confirmDepart}
          onCancel={this.cancelConfirmDepartModal}
          okText="确认发车"
        >
          <h3>确认【车头：{plateNumber}；挂车：{this.state.depart.compartmentPlateNumber}】发车</h3>
          <div>发车时间：
            <DatePicker
              disabledDate={this.disabledStartDate}
              disabledTime={this.disabledStartTime}
              showTime
              format="YYYY-MM-DD HH:mm:ss"
              placeholder="请选择发车时间"
              defaultValue={moment()}
              onChange={this.onStartTruckTimeChange}
              style={{ width: 200, marginTop: 10 }}
            />
          </div>
          <div>
            当前里程：
            <InputNumber
              placeholder="请输入当前里程"
              value={this.state.mileage}
              style={{ width: 200, marginTop: 10 }}
              onChange={this.onMileageChange}
              max={9999999.99}
              min={0.01}
              precision={2}
            />
          </div>
        </Modal>
        <Modal
          title="取消派车"
          visible={this.state.isShowCancelDepartModal}
          onOk={this.cancelDepart}
          onCancel={this.cancelCancelDepartModal}
          okText="确认取消"
        >
          <h3 style={{ textAlign: 'center' }}>确认取消派车？</h3>
        </Modal>
      </div>
    );
  }
}

export default DeliveryManage;

