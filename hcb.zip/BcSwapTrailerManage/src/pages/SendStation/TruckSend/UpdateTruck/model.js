import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { Paths, PAGE_SIZE } from 'configs/constants';

import { tableFields } from './fields';
import { getDispatchDetail, dispatchUpdate } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE
};

export default Model.extend({
  namespace: 'updateTruck',
  state: {
    loading: { updateTruck: false },
    tableFields,
    search: initialSearch,
    dispatchDetail: {},
    dispatchNo: ''
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(`${Paths.TRUCK_SEND_UPDATE_TRUCK}`, ({ params }) => {
        const dispatchNo = params.dispatchNo;
        dispatch({ type: 'getDispatchDetail', payload: { dispatchNo } });
      });
    }
  },
  effects: {
    * getDispatchDetail({ payload }, { call, update }) {
      const dispatchDetail = yield call(withLoading(getDispatchDetail), payload);
      const { dispatchNo } = dispatchDetail;
      yield update({ dispatchDetail, dispatchNo });
    },
    * dispatchUpdate({ payload }, { call }) {
      yield call(withLoading(dispatchUpdate, 'updateTruck', '修改成功'), payload);
      window.history.go(-1);
    }
  },
  reducers: {}
});
