import { formatValue } from 'utils/formatValue';

export const tableFields = [{
  key: 'startSiteName',
  name: '出发地',
  render: formatValue
}, {
  key: 'endSiteName',
  name: '目的地',
  render: formatValue
}, {
  key: 'planDepartureDate',
  name: '计划发车时间'
}, {
  key: 'planArriveDate',
  name: '计划到达时间'
}, {
  key: 'driverName',
  name: '司机',
  render: formatValue
}, {
  key: 'plateNumber',
  name: '车头车牌',
  render: formatValue
}];
