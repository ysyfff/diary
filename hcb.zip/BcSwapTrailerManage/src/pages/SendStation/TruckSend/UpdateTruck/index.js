import { connect } from 'dva';
import { Input, DatePicker, Form } from 'antd';
import NP from 'number-precision';
import { moment } from 'carno/third-party';
import { HTable, HEditableCell } from 'carno';
// import _ from 'lodash';
import { Button } from 'antd';
import ExtraCostInput from 'pages/ToSiteManage/DeliveryManage/ExtraCostInput';
import { STOWAGE_TYPE } from '../../../../configs/maps';
import styles from './index.less';

const { TextArea } = Input;

const FormItem = Form.Item;

const RequiredTableTitle = ({ label }) =>
  (<FormItem
    style={{ marginBottom: 0 }}
    required
    label={label}
    colon={false}
  />);

const freightTableFields = [{
  title: '费用名称',
  dataIndex: 'costCategory',
  editable: true,
  width: '40%',
  fields: {
    type: 'input',
    props: {
      maxLength: 20,
      minLength: 1,
      placeholder: '请输入费用名称'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用名称'
      }]
    }
  }
}, {
  title: '费用金额',
  dataIndex: 'freightAmount',
  editable: true,
  width: '30%',
  fields: {
    type: 'inputnumber',
    props: {
      precision: 2,
      min: 0.01,
      max: 99999.99,
      placeholder: '请输入费用金额'
    },
    validator: {
      rules: [{
        required: true,
        message: '请输入费用金额'
      }]
    }
  }
}];

@connect(({ updateTruck }) => ({ ...updateTruck }), dispatch => ({
  dispatchUpdate(params) {
    dispatch({ type: 'updateTruck/dispatchUpdate', payload: params });
  },
  dispatch
}))
export default class UpdateTruck extends React.Component {
  state = {
    updateDetail: {},
    nowOtherFregihts: [],
    isShowOtherFreightsModal: false,
    freightIndex: 0
  }


  componentWillReceiveProps = (props) => {
    const { updateDetail } = this.state;
    const { dispatchDetail } = props;
    if (!updateDetail.stowageNo) {
      this.setState({
        updateDetail: dispatchDetail
      });
    }
  }

  onCellChange = (index, value, field) => {
    const { updateDetail } = this.state;
    const _updateDetail = { ...updateDetail };
    const { arterys } = _updateDetail;
    const _arterys = arterys.slice();
    _arterys[index][field] = value;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onChangeRemark = (e) => {
    const remark = e.target.value;
    const { updateDetail } = this.state;
    const _updateDetail = { ...updateDetail };
    _updateDetail.remark = remark;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onChangeDate = (value, field, index) => {
    const _value = value ? value.format('YYYY-MM-DD HH:mm:ss') : '';
    const { updateDetail } = this.state;
    const _updateDetail = { ...updateDetail };
    const { arterys } = _updateDetail;
    const _arterys = arterys.slice();
    _arterys[index][field] = _value;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onClickOtherFreights = (freights) => {
    this.setState({
      nowOtherFregihts: freights,
      isShowOtherFreightsModal: true
    });
  }

  onOtherFreightsChange = (value) => {
    const { freightIndex, updateDetail } = this.state;
    const { arterys } = updateDetail;
    const _arterys = arterys.slice();
    const _updateDetail = { ...updateDetail };
    _arterys[freightIndex].otherFreights = value;
    _updateDetail.arterys = _arterys;
    this.setState({
      updateDetail: _updateDetail
    });
  }

  onSave = () => {
    let { updateDetail } = this.state;
    const { dispatchUpdate } = this.props;
    updateDetail = JSON.parse(JSON.stringify(updateDetail));
    dispatchUpdate(updateDetail);
  }

  getProps() {
    const { tableFields, search, loading } = this.props;
    const { updateDetail } = this.state;
    const { arterys } = updateDetail;

    const dateColumns = [{
      key: 'planDepartureDate',
      name: <RequiredTableTitle label="计划发车时间" />,
      render: (a, b, i) => (
        <DatePicker
          showTime
          format="MM-DD HH:mm"
          style={{ width: 170 }}
          placeholder="请选择计划发车时间"
          value={moment(a)}
          onChange={e => this.onChangeDate(e, 'planDepartureDate', i)}
        />
      )
    }, {
      key: 'planArriveDate',
      name: <RequiredTableTitle label="计划到达时间" />,
      render: (a, b, i) => (
        <DatePicker
          showTime
          format="MM-DD HH:mm"
          style={{ width: 170 }}
          value={moment(a)}
          placeholder="请选择计划到达时间"
          onChange={e => this.onChangeDate(e, 'planArriveDate', i)}
        />
      )
    }];

    const columns = [{
      name: '运费',
      key: 'freight',
      width: 140,
      render: (text, record, index) => {
        if (index !== 0 && !(record.driverName)) {
          return <Input disabled value={(text || '').toString()} />;
        }
        return (<HEditableCell
          id={`servers_${index}`}
          value={(text || 0).toString()}
          loading={loading.updateTruck}
          confirm={{ title: '注意', content: '确认修改为', isMask: true }}
          rules={[
            { required: true, message: '运费信息不能为空' },
          ]}
          onSubmit={value => this.onCellChange(index, value, 'freight')}
        />);
      }
    }, {
      name: '其他费用',
      key: 'otherFreights',
      width: 300,
      render: (a, b, i) => {
        if (i !== 0 && !(b.driverName)) {
          return <Input disabled />;
        }
        const source = (a === null ? [] : (a || []));
        return (<ExtraCostInput
          source={source}
          modalProps={{ title: '其他费用', width: 600 }}
          tableFields={freightTableFields}
          format={this.format}
          calculateKey="freightAmount"
          onClick={() => this.handleFreightsClick(i)}
          euxuChange
          onChange={this.onOtherFreightsChange}
        />);
      }
    }, {
      key: 'totalFreights',
      name: '费用合计',
      render: (a, b) => {
        let total = Number(b.freight) || 0;
        if (b.otherFreights && b.otherFreights[0].costCategory) {
          b.otherFreights.forEach((item) => {
            total = NP.plus(total, Number(item.freightAmount));
          });
        }
        return total;
      }
    }];

    const _tableFields = tableFields.slice();
    _tableFields.splice(2, 2, ...dateColumns);
    _tableFields.splice(6, 0, ...columns);

    return {
      tableProps: {
        fields: _tableFields,
        dataSource: arterys,
        search,
        loading: loading.updateTruck,
        scroll: { x: 1400 },
        pagination: false,
        locale: { emptyText: '暂无信息' },
        style: { marginTop: 16 },
      },
    };
  }

  format = fields => Object.keys(fields)
    .map((fieldKey) => {
      const field = fields[fieldKey];
      return ['costCategory', 'freightAmount'].map(key => field[key].value).join('：');
    }).join('；');

  cancelOtherFreightsModal = () => {
    this.setState({
      isShowOtherFreightsModal: false
    });
  }

  cancel = () => {
    window.history.go(-1);
  }

  handleFreightsClick = (freightIndex) => {
    this.setState({
      freightIndex
    });
  }

  render() {
    const { updateDetail } = this.state;
    const { stowageType } = updateDetail;
    const { tableProps } = this.getProps();
    let _stowageType = '';
    if (stowageType) {
      _stowageType = STOWAGE_TYPE.filter(x => x.key === stowageType)[0].name;
    }

    return (
      <div className={styles['stowage-detail']}>
        <div className="title">
          <div>
            <span className="normal-label">主营服务：</span>
            { _stowageType }
          </div>
        </div>
        <div className="part">
          <h2>基本信息</h2>
          <table className="base-info">
            <tbody>
              <tr>
                <td className="normal-label">配载单号：</td>
                <td className="bold-text">{updateDetail.stowageNo}</td>
                <td className="normal-label">发车线路：</td><td>{ updateDetail.siteLineName }</td>
                <td className="normal-label">挂车车牌：</td>
                <td className="bold-text">{ updateDetail.compartmentPlateNumber }</td>
              </tr>
              <tr>
                <td className="normal-label">派车备注：</td>
                <td colSpan={5}>
                  <TextArea
                    maxLength={125}
                    value={updateDetail.remark}
                    rows={4}
                    laceholder="请输入备注"
                    onChange={this.onChangeRemark}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="part">
          <h2>调度信息</h2>
          <div className="info-list">
            <HTable
              {...tableProps}
              style={{ marginTop: 30 }}
            />
          </div>
        </div>
        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <Button type="primary" onClick={this.onSave}>保存</Button>
          <Button style={{ marginLeft: 10 }} onClick={this.cancel}>取消</Button>
        </div>
      </div>
    );
  }
}
