import { Model } from 'carno/addons';
import { withLoading } from 'carno/utils';
import { PAGE_SIZE, Paths } from 'configs/constants';
import { routerRedux } from 'dva/router';
import { tableFields } from './fields';
import { getStowageList, getSiteLine, getTempDrivers, getTrucks, save } from './services';

const initialSearch = {
  pn: 1,
  ps: PAGE_SIZE,
  stowageNo: '',
  status: 'LOADED',
  trailerPlateNumber: '',
  siteLineId: '',
  type: 'CHANNELSERVICE'
};

export default Model.extend({
  namespace: 'addTruck',
  state: {
    loading: { addTruck: false },
    tableFields,
    search: initialSearch,
    stowageList: [],
    nowSiteLine: {},
    drivers: [],
    trucks: []
  },
  subscriptions: {
    setup({ dispatch, listen }) {
      listen(Paths.TRUCK_SEND_ADD_TRUCK, () => {
        // dispatch({ type: 'getDrivers', payload: { effective: 1, driverType: 'GROUNDLINE' } });
        dispatch({ type: 'getTrucks', payload: { effective: 1 } });
      });
    }
  },
  effects: {
    * getStowageList({ payload }, { call, select, update }) {
      const { search } = yield select(({ addTruck }) => addTruck);
      const { datas } = yield call(withLoading(getStowageList, 'addTruck'), search);
      yield update({ stowageList: datas });
    },
    * getSiteLine({ payload }, { call, update }) {
      const nowSiteLine = yield call(withLoading(getSiteLine, 'addTruck'), payload);
      yield update({ nowSiteLine });
    },
    * getTempDrivers({ payload }, { call, update }) {
      const drivers = yield call(withLoading(getTempDrivers, 'addTruck'), payload);
      yield update({ drivers });
    },
    * getTrucks({ payload }, { call, update }) {
      const { datas } = yield call(withLoading(getTrucks, 'addTruck'), payload);
      yield update({ trucks: datas });
    },
    * save({ payload }, { call }) {
      yield call(withLoading(save, 'addTruck', '新建成功'), payload);
      window.location.hash = '#/sendStation/truckSend';
    },
    * saveAndPrint({ payload }, { call, put }) {
      const dispathNo = yield call(withLoading(save, 'addTruck', '新建成功'), payload);
      const { stowageNo } = payload;
      yield put(routerRedux.push(`/sendStation/printHandOver/${stowageNo}/${dispathNo}/2`));
    }
  },
  reducers: {
    updateSearch(state, { payload }) {
      return {
        ...state,
        search: { ...state.search, ...payload },
      };
    },
  }
});
