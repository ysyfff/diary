import { formatValue, defaultKey } from 'utils/formatValue';
import { STOWAGE_TYPE } from 'configs/maps';

export const tableFields = [{
  key: 'startSiteName',
  name: '出发地',
  render: formatValue
}, {
  key: 'endSiteName',
  name: '目的地',
  render: formatValue
}];

export const searchInputFields = [{
  key: 'stowageNo',
  title: '配载单号',
  dataIndex: 'stowageNo',
  width: 160,
  fixed: 'left',
  render: formatValue
}, {
  key: 'type',
  title: '主营服务',
  dataIndex: 'type',
  render: a => STOWAGE_TYPE.filter(item => item.key === a)[0].name
}, {
  key: 'siteLineId',
  title: '行驶路线',
  dataIndex: 'siteLineRangeName',
  render: formatValue
}, {
  key: 'totalNumber',
  title: '总单数',
  dataIndex: 'totalNumber',
  render: formatValue
}, {
  key: 'totalPackages',
  title: '总件数',
  dataIndex: 'totalPackages',
  render: formatValue
}, {
  key: 'totalWeight',
  title: '总重量（吨）',
  dataIndex: 'totalWeight',
  render: formatValue
}, {
  key: 'totalCubage',
  title: '总体积（方）',
  dataIndex: 'totalCubage',
  render: formatValue
}, {
  key: 'loadUtilizationRatio',
  title: '载重利用率',
  dataIndex: 'loadUtilizationRatio',
  render: (a, b) => {
    if (!a) return defaultKey;
    if (b.totalWeight < 30) return <span style={{ color: 'red' }}>{a}%</span>;
    return `${a}%`;
  }
}, {
  key: 'spaceUtilizationRatio',
  title: '空间利用率',
  dataIndex: 'spaceUtilizationRatio',
  render: (a, b) => {
    if (!a) return defaultKey;
    if (b.totalCubage < 30) return <span style={{ color: 'red' }}>{a}%</span>;
    return `${a}%`;
  }
}, {
  key: 'createTime',
  title: '下单时间',
  dataIndex: 'createTime',
  render: a => a || defaultKey
}, {
  key: 'remark',
  title: '配载备注',
  dataIndex: 'remark',
  render: formatValue
}];
