import http from 'utils/http';

const { post } = http.create('dapt');

// 查询配载单列表
export function getStowageList(params) {
  return post('/web/m/stowage/list', params);
}

// 配载线路详细信息查询
export function getSiteLine(params) {
  return post('/web/m/siteline/get', params);
}

// 查询临调司机
export function getTempDrivers(params) {
  return post('/web/m/hcb-driver/search', params);
}

// 查询所有车头车牌
export function getTrucks(params) {
  return post('/web/m/truck/list', params);
}

// 新建保存
export function save(params) {
  return post('/web/m/dispatch/post', params, { contentType: 'json' });
}
