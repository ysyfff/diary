/**
 * @author 江林
 * @description 选取司机组建
 * @since 2018.09.13
 *
 * 参数列表：
 * @param {Array} dataSource 数据源
 * eg:
 *  dataSource: [{
 *    "userName": "张阿三",
 *    "mobile": "18328221234",
 *    "category": "短波司机，自有司机",
 *    "plateNumber": "川A12345"
 *  }]
 *
 * @param {Array} status 所有可切换的状态
 * eg:
 *  [{name: '短驳司机', value: 'duanbo'}, {name: '干线司机', value: 'ganxian'}, {name: '临调司机', value: 'lindiao'}]
 *
 * @param {string} nowStatus 当前选择的项，例如当前选择短驳司机 duanbo
 * @param {function} onSearch 点击查询按钮和切换选择状态项时的回调方法
 * @param {function} onConfirm 点击确认选择时回调方法
 */

import React from 'react';
import { Input, Modal, Button, Radio, Spin } from 'antd';
import { connect } from 'dva';
import { bind } from 'bind-decorator';
import { Type } from 'carno/utils';
import { transform2Object, transform2Options } from 'configs/constants';
import styles from './index.less';

const initialState = {
  nowSelected: 0,
  searchValue: ''
};

// status内部定义死
const status = [{
  key: 'SHORT',
  value: '短驳司机'
}, {
  key: 'GROUNDLINE',
  value: '干线司机'
}, {
  key: 'HCB',
  value: '临调司机'
}];

const belongType = [
  {
    key: 'OWN',
    value: '自有司机'
  },
  {
    key: 'PARTNER',
    value: '合伙人'
  }, {
    key: 'HCB',
    value: '临调司机'
  }
];

const belongTypeObj = transform2Object(belongType);
const statusObj = transform2Object(status);
const statusOpt = transform2Options(status);


const EFFECTIVE = 1;

@connect(({ selectDriver }) => ({ ...selectDriver }), dispatch => ({ dispatch }))
export default class SelectDriver extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      driver: '',
      value: props.value,
      nowStatus: props.nowStatus || 'SHORT',
      ...initialState,
    };
  }

  onChangeStatus = (e) => {
    const value = e.target.value;
    const { searchValue } = this.state;
    this.setState({
      nowStatus: value,
      nowSelected: 0
    });
    // debugger
    this.doSearch(value, searchValue);
  }


  onSearch = () => {
    const { nowStatus, searchValue } = this.state;
    // debugger
    this.doSearch(nowStatus, searchValue);
  }

  onChangeSearchValue = (e) => {
    const searchValue = e.target.value;
    this.setState({
      searchValue
    });
  }

  setValue = (obj) => {
    const driver = Type.isEmpty(obj) ? '' : `${obj.userName}, ${obj.mobile}`;
    this.setState({
      driver
    });
  }

  @bind
  doSearch(status, searchValue) {
    const { dispatch } = this.props;
    if (status === 'HCB') {
      if (searchValue) {
        dispatch({
          type: 'selectDriver/getHcbDriver',
          payload: {
            // effective: EFFECTIVE,
            // driverType: status,
            keyword: searchValue
          }
        });
      } else {
        dispatch({
          type: 'selectDriver/updateDriverList',
          payload: []
        });
      }
    } else {
      dispatch({
        type: 'selectDriver/getDriver',
        payload: {
          effective: EFFECTIVE,
          routeTypeEnum: status,
          keyword: searchValue
        }
      });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
      nowStatus: this.props.nowStatus // 打开Modal时，重置nowStatus
    });
    this.resetSearch();
  }

  handleCancel = () => {
    this.setState({
      visible: false
    });
  }

  handleOk = () => {
    const { onConfirm = () => 1, driverList } = this.props;
    const { nowSelected } = this.state;
    const selected = driverList[nowSelected];
    onConfirm(selected);
    const driver = `${selected.userName}, ${selected.mobile}`;
    this.setState({
      driver,
      visible: false
    });
  }

  resetSearch = () => {
    this.setState({
      ...initialState
    }, () => {
      this.doSearch(this.state.nowStatus, this.state.searchValue);
    });
  }

  selectDriver = (nowSelected) => {
    this.setState({
      nowSelected
    });
  }

  render() {
    // const { dataSource } = this.state;
    const { style, driverList, disabled, getRef = () => 1 } = this.props;
    const { nowStatus } = this.state;
    getRef(this);
    const _dataSource = [];
    const _buttons = [];

    (driverList || []).forEach((item, index) => {
      _dataSource.push(
        <li key={index} className={(this.state.nowSelected === index) ? 'selected-driver' : ''}>
          <div className="cont" onClick={() => this.selectDriver(index)}>
            <h3>{item.userName}</h3>
            <div>手机：{item.mobile}</div>
            <div>类别：
              {
                !Type.isEmpty(statusObj[item.driverType]) && <span>{statusObj[item.driverType]}</span>
              }
              {
                !Type.isEmpty(belongTypeObj[item.belongType]) &&
                <span>{Type.isEmpty(statusObj[item.driverType]) ? '' : ','} {belongTypeObj[item.belongType]}</span>
              }
            </div>
            <div>车辆：{item.truckPlateNumber}</div>
          </div>
        </li>
      );
    });

    statusOpt.forEach((item) => {
      _buttons.push(
        <Radio.Button value={item.value} key={item.value}>{item.label}</Radio.Button>
      );
    });

    return (
      <div className={styles['select-driver']}>
        <Input
          placeholder="请选择司机"
          value={this.state.driver}
          style={style}
          disabled={disabled}
          className="select-ipt"
          onClick={this.showModal}
        />
        <Modal
          title="选择司机"
          visible={this.state.visible}
          onOk={this.handleOk}
          okText="确认选择"
          onCancel={this.handleCancel}
          width={860}
        >
          <Spin spinning={this.props.loading.list}>
            <div className={styles['select-modal']}>
              <div className="search">
                <Input
                  placeholder={nowStatus === 'HCB' ? '司机姓名、手机' : '司机姓名、手机、车牌号码'}
                  className="select-ipt"
                  value={this.state.searchValue}
                  onChange={this.onChangeSearchValue}
                />
                <Button type="primary" className="btn" onClick={this.onSearch}>查询</Button>
                <Button className="btn" onClick={() => { this.resetSearch(); }}>重置</Button>
              </div>
              <Radio.Group
                value={this.state.nowStatus}
                buttonStyle="solid"
                className="radios"
                onChange={this.onChangeStatus}
              >
                {_buttons}
              </Radio.Group>
              <ul
                className="driver-list"
                style={{
                  justifyContent: _dataSource.length === 0 ? 'center' : 'flex-start'
                }}
              >
                {_dataSource}
                {_dataSource.length === 0
                  && <span className="no-drivers">未找到你查询的司机</span>
                }
              </ul>
            </div>
          </Spin>
        </Modal>
      </div>
    );
  }
}
