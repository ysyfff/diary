import React from 'react';
import { Modal } from 'antd';
// import { connect } from 'dva';
import { print } from 'utils';
import PrintHandOver from '../../common/PrintHandOver';

class Handover extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: Symbol('visible')
    };
  }

  render() {
    const { visible, onCancel, onOk, title = '打印预览', ...other } = this.props;
    const modalProps = {
      visible,
      onCancel,
      onOk() {
        onOk();
        print('jj');
      },
      okText: '打印',
      title,
    };

    return (
      <Modal
        {...other}
        {...modalProps}
      >
        <div id="jj">
          <PrintHandOver
            dataSource={[]}
          />
        </div>
      </Modal >
    );
  }
}

export default Handover;
