import { Model } from 'carno/addons';

export default Model.extend({
  namespace: 'global',

  state: {
  },

  subscriptions: {
    // 全局路由监听
    setup({ dispatch, history }) {
      return history.listen(() => {
        dispatch({ type: 'getStorageAuthority' });
      });
    }
  },

  effects: {
    * changeSearch({ payload }, { put, select }) {
      const { prevPath } = yield select(({ layout }) => layout);
      if (!prevPath) return;
      const noClearSearchPaths = payload.noClearSearchPaths || [];
      const paths = noClearSearchPaths.filter(path => prevPath.indexOf(path) > -1);
      if (paths.length === 0) {
        yield put(payload.action);
      }
    },
    * getStorageAuthority({ payload }, { put }) {
      yield put({ type: 'login/getStorageAuthority', payload });
    }
  },

  reducers: {}
});
