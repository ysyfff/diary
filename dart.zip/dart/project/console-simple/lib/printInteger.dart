printInterger(int aNumber) {
  print('The number is $aNumber');
}
