void enableFlags({bool bold = false, bool hidden = false}) {
  print('$bold $hidden');
}

void disableFlag(bool bold, bool hidden, [String msg = 'wtf']){
  print('$bold, $hidden, $msg');
}